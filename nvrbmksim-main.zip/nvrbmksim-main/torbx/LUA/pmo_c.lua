newmodel40 = workspace.prefabs.pmo_centered:clone()
newmodel40:PivotTo(CFrame.new(-68.20523434353645, 3.6650695200000003, 27.01700593684489) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel40.Parent = workspace.devices.pmo_centered
newmodel41 = workspace.prefabs.pmo_centered:clone()
newmodel41:PivotTo(CFrame.new(-68.13370644340804, 3.22384, 27.10561978397512) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel41.Parent = workspace.devices.pmo_centered
newmodel42 = workspace.prefabs.pmo_centered:clone()
newmodel42:PivotTo(CFrame.new(-67.87693962243424, 2.68072, 27.423720773673374) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel42.Parent = workspace.devices.pmo_centered
newmodel43 = workspace.prefabs.pmo_centered:clone()
newmodel43:PivotTo(CFrame.new(-68.13370644340804, 2.68072, 27.10561978397512) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel43.Parent = workspace.devices.pmo_centered
newmodel44 = workspace.prefabs.pmo_centered:clone()
newmodel44:PivotTo(CFrame.new(-68.32169643733528, 3.22384, 26.872724416517464) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel44.Parent = workspace.devices.pmo_centered
newmodel45 = workspace.prefabs.pmo_centered:clone()
newmodel45:PivotTo(CFrame.new(-68.50968643126252, 3.22384, 26.63982904905981) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel45.Parent = workspace.devices.pmo_centered
newmodel46 = workspace.prefabs.pmo_centered:clone()
newmodel46:PivotTo(CFrame.new(-68.75544895990886, 3.7319200000000006, 26.335360958920045) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel46.Parent = workspace.devices.pmo_centered
