newmodel0 = workspace.prefabs.ivh:clone()
newmodel0:PivotTo(CFrame.new(-14.041468292504977, 6.8534, 27.885898438078616) * CFrame.fromEulerAngles(0, math.rad(45.96), 0))
newmodel0.Parent = workspace.devices.ivh
newmodel1 = workspace.prefabs.ivh:clone()
newmodel1:PivotTo(CFrame.new(-14.041468292504977, 6.37744, 27.885898438078616) * CFrame.fromEulerAngles(0, math.rad(45.96), 0))
newmodel1.Parent = workspace.devices.ivh
