newmodel0 = workspace.scam.prefabs.Selector_w:clone()
newmodel0.Parent = workspace.scam.np
newmodel0.Value.Value = 1
newmodel0.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_0-8 (1)'
newmodel0:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.8, 0, -0.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel1 = workspace.scam.prefabs.Selector_w:clone()
newmodel1.Parent = workspace.scam.np
newmodel1.Value.Value = 2
newmodel1.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_0-10 (1)'
newmodel1:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0, 0, -0.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel2 = workspace.scam.prefabs.Selector_w:clone()
newmodel2.Parent = workspace.scam.np
newmodel2.Value.Value = 3
newmodel2.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_0-12 (1)'
newmodel2:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.2, 0, -0.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel3 = workspace.scam.prefabs.Selector_w:clone()
newmodel3.Parent = workspace.scam.np
newmodel3.Value.Value = 4
newmodel3.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_0-14 (1)'
newmodel3:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.4000000000000001, 0, -0.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel4 = workspace.scam.prefabs.Selector_b:clone()
newmodel4.Parent = workspace.scam.np
newmodel4.Value.Value = 5
newmodel4.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_1-5 (1)'
newmodel4:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.5, 0, -0.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel5 = workspace.scam.prefabs.Selector_b:clone()
newmodel5.Parent = workspace.scam.np
newmodel5.Value.Value = 6
newmodel5.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_1-7 (1)'
newmodel5:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.7000000000000001, 0, -0.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel6 = workspace.scam.prefabs.Selector_y:clone()
newmodel6.Parent = workspace.scam.np
newmodel6.Value.Value = 7
newmodel6.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_1-9 (1)'
newmodel6:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.9000000000000001, 0, -0.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel7 = workspace.scam.prefabs.Selector_w:clone()
newmodel7.Parent = workspace.scam.np
newmodel7.Value.Value = 8
newmodel7.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_1-11 (1)'
newmodel7:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0999999999999999, 0, -0.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel8 = workspace.scam.prefabs.Selector_y:clone()
newmodel8.Parent = workspace.scam.np
newmodel8.Value.Value = 9
newmodel8.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_1-13 (1)'
newmodel8:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.3, 0, -0.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel9 = workspace.scam.prefabs.Selector_w:clone()
newmodel9.Parent = workspace.scam.np
newmodel9.Value.Value = 10
newmodel9.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_1-15 (1)'
newmodel9:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.5, 0, -0.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel10 = workspace.scam.prefabs.Selector_w:clone()
newmodel10.Parent = workspace.scam.np
newmodel10.Value.Value = 11
newmodel10.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_1-17 (1)'
newmodel10:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.7000000000000002, 0, -0.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel11 = workspace.scam.prefabs.Selector_b:clone()
newmodel11.Parent = workspace.scam.np
newmodel11.Value.Value = 12
newmodel11.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_2-4 (1)'
newmodel11:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.4, 0, -0.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel12 = workspace.scam.prefabs.Selector_b:clone()
newmodel12.Parent = workspace.scam.np
newmodel12.Value.Value = 13
newmodel12.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_2-6 (1)'
newmodel12:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.6, 0, -0.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel13 = workspace.scam.prefabs.Selector_w:clone()
newmodel13.Parent = workspace.scam.np
newmodel13.Value.Value = 14
newmodel13.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_2-8 (1)'
newmodel13:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.8, 0, -0.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel14 = workspace.scam.prefabs.Selector_w:clone()
newmodel14.Parent = workspace.scam.np
newmodel14.Value.Value = 15
newmodel14.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_2-10 (1)'
newmodel14:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0, 0, -0.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel15 = workspace.scam.prefabs.Selector_w:clone()
newmodel15.Parent = workspace.scam.np
newmodel15.Value.Value = 16
newmodel15.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_2-12 (1)'
newmodel15:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.2, 0, -0.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel16 = workspace.scam.prefabs.Selector_w:clone()
newmodel16.Parent = workspace.scam.np
newmodel16.Value.Value = 17
newmodel16.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_2-14 (1)'
newmodel16:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.4000000000000001, 0, -0.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel17 = workspace.scam.prefabs.Selector_w:clone()
newmodel17.Parent = workspace.scam.np
newmodel17.Value.Value = 18
newmodel17.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_2-16 (1)'
newmodel17:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.6, 0, -0.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel18 = workspace.scam.prefabs.Selector_w:clone()
newmodel18.Parent = workspace.scam.np
newmodel18.Value.Value = 19
newmodel18.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_2-18 (1)'
newmodel18:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.8000000000000003, 0, -0.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel19 = workspace.scam.prefabs.Selector_b:clone()
newmodel19.Parent = workspace.scam.np
newmodel19.Value.Value = 20
newmodel19.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_3-3 (1)'
newmodel19:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.3, 0, -0.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel20 = workspace.scam.prefabs.Selector_b:clone()
newmodel20.Parent = workspace.scam.np
newmodel20.Value.Value = 21
newmodel20.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_3-5 (1)'
newmodel20:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.5, 0, -0.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel21 = workspace.scam.prefabs.Selector_b:clone()
newmodel21.Parent = workspace.scam.np
newmodel21.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_3-7 (1)'
newmodel21:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.7000000000000001, 0, -0.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel22 = workspace.scam.prefabs.Selector_w:clone()
newmodel22.Parent = workspace.scam.np
newmodel22.Value.Value = 22
newmodel22.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_3-9 (1)'
newmodel22:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.9000000000000001, 0, -0.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel23 = workspace.scam.prefabs.Selector_w:clone()
newmodel23.Parent = workspace.scam.np
newmodel23.Value.Value = 23
newmodel23.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_3-11 (1)'
newmodel23:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0999999999999999, 0, -0.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel24 = workspace.scam.prefabs.Selector_w:clone()
newmodel24.Parent = workspace.scam.np
newmodel24.Value.Value = 24
newmodel24.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_3-13 (1)'
newmodel24:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.3, 0, -0.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel25 = workspace.scam.prefabs.Selector_b:clone()
newmodel25.Parent = workspace.scam.np
newmodel25.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_3-15 (1)'
newmodel25:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.5, 0, -0.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel26 = workspace.scam.prefabs.Selector_w:clone()
newmodel26.Parent = workspace.scam.np
newmodel26.Value.Value = 25
newmodel26.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_3-17 (1)'
newmodel26:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.7000000000000002, 0, -0.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel27 = workspace.scam.prefabs.Selector_b:clone()
newmodel27.Parent = workspace.scam.np
newmodel27.Value.Value = 26
newmodel27.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_3-19 (1)'
newmodel27:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.9, 0, -0.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel28 = workspace.scam.prefabs.Selector_b:clone()
newmodel28.Parent = workspace.scam.np
newmodel28.Value.Value = 27
newmodel28.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_4-2 (1)'
newmodel28:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.2, 0, -0.4)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel29 = workspace.scam.prefabs.Selector_b:clone()
newmodel29.Parent = workspace.scam.np
newmodel29.Value.Value = 28
newmodel29.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_4-4 (1)'
newmodel29:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.4, 0, -0.4)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel30 = workspace.scam.prefabs.Selector_b:clone()
newmodel30.Parent = workspace.scam.np
newmodel30.Value.Value = 29
newmodel30.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_4-6 (1)'
newmodel30:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.6, 0, -0.4)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel31 = workspace.scam.prefabs.Selector_b:clone()
newmodel31.Parent = workspace.scam.np
newmodel31.Value.Value = 30
newmodel31.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_4-8 (1)'
newmodel31:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.8, 0, -0.4)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel32 = workspace.scam.prefabs.Selector_w:clone()
newmodel32.Parent = workspace.scam.np
newmodel32.Value.Value = 31
newmodel32.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_4-10 (1)'
newmodel32:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0, 0, -0.4)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel33 = workspace.scam.prefabs.Selector_w:clone()
newmodel33.Parent = workspace.scam.np
newmodel33.Value.Value = 32
newmodel33.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_4-12 (1)'
newmodel33:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.2, 0, -0.4)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel34 = workspace.scam.prefabs.Selector_w:clone()
newmodel34.Parent = workspace.scam.np
newmodel34.Value.Value = 33
newmodel34.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_4-14 (1)'
newmodel34:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.4000000000000001, 0, -0.4)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel35 = workspace.scam.prefabs.Selector_w:clone()
newmodel35.Parent = workspace.scam.np
newmodel35.Value.Value = 34
newmodel35.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_4-16 (1)'
newmodel35:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.6, 0, -0.4)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel36 = workspace.scam.prefabs.Selector_b:clone()
newmodel36.Parent = workspace.scam.np
newmodel36.Value.Value = 35
newmodel36.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_4-18 (1)'
newmodel36:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.8000000000000003, 0, -0.4)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel37 = workspace.scam.prefabs.Selector_b:clone()
newmodel37.Parent = workspace.scam.np
newmodel37.Value.Value = 36
newmodel37.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_4-20 (1)'
newmodel37:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.0, 0, -0.4)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel38 = workspace.scam.prefabs.Selector_b:clone()
newmodel38.Parent = workspace.scam.np
newmodel38.Value.Value = 37
newmodel38.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_5-1 (1)'
newmodel38:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.1, 0, -0.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel39 = workspace.scam.prefabs.Selector_b:clone()
newmodel39.Parent = workspace.scam.np
newmodel39.Value.Value = 38
newmodel39.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_5-3 (1)'
newmodel39:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.3, 0, -0.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel40 = workspace.scam.prefabs.Selector_y:clone()
newmodel40.Parent = workspace.scam.np
newmodel40.Value.Value = 39
newmodel40.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_5-5 (1)'
newmodel40:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.5, 0, -0.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel41 = workspace.scam.prefabs.Selector_b:clone()
newmodel41.Parent = workspace.scam.np
newmodel41.Value.Value = 40
newmodel41.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_5-7 (1)'
newmodel41:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.7000000000000001, 0, -0.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel42 = workspace.scam.prefabs.Selector_y:clone()
newmodel42.Parent = workspace.scam.np
newmodel42.Value.Value = 41
newmodel42.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_5-9 (1)'
newmodel42:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.9000000000000001, 0, -0.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel43 = workspace.scam.prefabs.Selector_c:clone()
newmodel43.Parent = workspace.scam.np
newmodel43.Value.Value = 42
newmodel43.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_5-11 (1)'
newmodel43:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0999999999999999, 0, -0.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel44 = workspace.scam.prefabs.Selector_y:clone()
newmodel44.Parent = workspace.scam.np
newmodel44.Value.Value = 43
newmodel44.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_5-13 (1)'
newmodel44:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.3, 0, -0.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel45 = workspace.scam.prefabs.Selector_w:clone()
newmodel45.Parent = workspace.scam.np
newmodel45.Value.Value = 44
newmodel45.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_5-15 (1)'
newmodel45:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.5, 0, -0.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel46 = workspace.scam.prefabs.Selector_y:clone()
newmodel46.Parent = workspace.scam.np
newmodel46.Value.Value = 45
newmodel46.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_5-17 (1)'
newmodel46:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.7000000000000002, 0, -0.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel47 = workspace.scam.prefabs.Selector_b:clone()
newmodel47.Parent = workspace.scam.np
newmodel47.Value.Value = 46
newmodel47.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_5-19 (1)'
newmodel47:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.9, 0, -0.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel48 = workspace.scam.prefabs.Selector_b:clone()
newmodel48.Parent = workspace.scam.np
newmodel48.Value.Value = 47
newmodel48.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_5-21 (1)'
newmodel48:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.1, 0, -0.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel49 = workspace.scam.prefabs.Selector_b:clone()
newmodel49.Parent = workspace.scam.np
newmodel49.Value.Value = 48
newmodel49.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_6-2 (1)'
newmodel49:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.2, 0, -0.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel50 = workspace.scam.prefabs.Selector_b:clone()
newmodel50.Parent = workspace.scam.np
newmodel50.Value.Value = 49
newmodel50.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_6-4 (1)'
newmodel50:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.4, 0, -0.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel51 = workspace.scam.prefabs.Selector_b:clone()
newmodel51.Parent = workspace.scam.np
newmodel51.Value.Value = 50
newmodel51.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_6-6 (1)'
newmodel51:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.6, 0, -0.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel52 = workspace.scam.prefabs.Selector_b:clone()
newmodel52.Parent = workspace.scam.np
newmodel52.Value.Value = 51
newmodel52.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_6-8 (1)'
newmodel52:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.8, 0, -0.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel53 = workspace.scam.prefabs.Selector_w:clone()
newmodel53.Parent = workspace.scam.np
newmodel53.Value.Value = 52
newmodel53.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_6-10 (1)'
newmodel53:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0, 0, -0.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel54 = workspace.scam.prefabs.Selector_w:clone()
newmodel54.Parent = workspace.scam.np
newmodel54.Value.Value = 53
newmodel54.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_6-12 (1)'
newmodel54:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.2, 0, -0.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel55 = workspace.scam.prefabs.Selector_w:clone()
newmodel55.Parent = workspace.scam.np
newmodel55.Value.Value = 54
newmodel55.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_6-14 (1)'
newmodel55:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.4000000000000001, 0, -0.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel56 = workspace.scam.prefabs.Selector_b:clone()
newmodel56.Parent = workspace.scam.np
newmodel56.Value.Value = 55
newmodel56.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_6-16 (1)'
newmodel56:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.6, 0, -0.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel57 = workspace.scam.prefabs.Selector_b:clone()
newmodel57.Parent = workspace.scam.np
newmodel57.Value.Value = 56
newmodel57.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_6-18 (1)'
newmodel57:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.8000000000000003, 0, -0.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel58 = workspace.scam.prefabs.Selector_b:clone()
newmodel58.Parent = workspace.scam.np
newmodel58.Value.Value = 57
newmodel58.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_6-20 (1)'
newmodel58:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.0, 0, -0.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel59 = workspace.scam.prefabs.Selector_b:clone()
newmodel59.Parent = workspace.scam.np
newmodel59.Value.Value = 58
newmodel59.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_7-1 (1)'
newmodel59:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.1, 0, -0.7000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel60 = workspace.scam.prefabs.Selector_b:clone()
newmodel60.Parent = workspace.scam.np
newmodel60.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_7-3 (1)'
newmodel60:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.3, 0, -0.7000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel61 = workspace.scam.prefabs.Selector_b:clone()
newmodel61.Parent = workspace.scam.np
newmodel61.Value.Value = 59
newmodel61.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_7-5 (1)'
newmodel61:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.5, 0, -0.7000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel62 = workspace.scam.prefabs.Selector_c:clone()
newmodel62.Parent = workspace.scam.np
newmodel62.Value.Value = 60
newmodel62.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_7-7 (1)'
newmodel62:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.7000000000000001, 0, -0.7000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel63 = workspace.scam.prefabs.Selector_b:clone()
newmodel63.Parent = workspace.scam.np
newmodel63.Value.Value = 61
newmodel63.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_7-9 (1)'
newmodel63:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.9000000000000001, 0, -0.7000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel64 = workspace.scam.prefabs.Selector_b:clone()
newmodel64.Parent = workspace.scam.np
newmodel64.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_7-11 (1)'
newmodel64:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0999999999999999, 0, -0.7000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel65 = workspace.scam.prefabs.Selector_w:clone()
newmodel65.Parent = workspace.scam.np
newmodel65.Value.Value = 62
newmodel65.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_7-13 (1)'
newmodel65:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.3, 0, -0.7000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel66 = workspace.scam.prefabs.Selector_c:clone()
newmodel66.Parent = workspace.scam.np
newmodel66.Value.Value = 63
newmodel66.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_7-15 (1)'
newmodel66:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.5, 0, -0.7000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel67 = workspace.scam.prefabs.Selector_b:clone()
newmodel67.Parent = workspace.scam.np
newmodel67.Value.Value = 64
newmodel67.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_7-17 (1)'
newmodel67:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.7000000000000002, 0, -0.7000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel68 = workspace.scam.prefabs.Selector_b:clone()
newmodel68.Parent = workspace.scam.np
newmodel68.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_7-19 (1)'
newmodel68:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.9, 0, -0.7000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel69 = workspace.scam.prefabs.Selector_b:clone()
newmodel69.Parent = workspace.scam.np
newmodel69.Value.Value = 65
newmodel69.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_7-21 (1)'
newmodel69:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.1, 0, -0.7000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel70 = workspace.scam.prefabs.Selector_w:clone()
newmodel70.Parent = workspace.scam.np
newmodel70.Value.Value = 66
newmodel70.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_8-0 (1)'
newmodel70:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.0, 0, -0.8)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel71 = workspace.scam.prefabs.Selector_b:clone()
newmodel71.Parent = workspace.scam.np
newmodel71.Value.Value = 67
newmodel71.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_8-2 (1)'
newmodel71:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.2, 0, -0.8)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel72 = workspace.scam.prefabs.Selector_b:clone()
newmodel72.Parent = workspace.scam.np
newmodel72.Value.Value = 68
newmodel72.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_8-4 (1)'
newmodel72:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.4, 0, -0.8)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel73 = workspace.scam.prefabs.Selector_b:clone()
newmodel73.Parent = workspace.scam.np
newmodel73.Value.Value = 69
newmodel73.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_8-6 (1)'
newmodel73:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.6, 0, -0.8)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel74 = workspace.scam.prefabs.Selector_b:clone()
newmodel74.Parent = workspace.scam.np
newmodel74.Value.Value = 70
newmodel74.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_8-8 (1)'
newmodel74:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.8, 0, -0.8)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel75 = workspace.scam.prefabs.Selector_w:clone()
newmodel75.Parent = workspace.scam.np
newmodel75.Value.Value = 71
newmodel75.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_8-10 (1)'
newmodel75:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0, 0, -0.8)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel76 = workspace.scam.prefabs.Selector_w:clone()
newmodel76.Parent = workspace.scam.np
newmodel76.Value.Value = 72
newmodel76.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_8-12 (1)'
newmodel76:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.2, 0, -0.8)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel77 = workspace.scam.prefabs.Selector_w:clone()
newmodel77.Parent = workspace.scam.np
newmodel77.Value.Value = 73
newmodel77.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_8-14 (1)'
newmodel77:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.4000000000000001, 0, -0.8)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel78 = workspace.scam.prefabs.Selector_b:clone()
newmodel78.Parent = workspace.scam.np
newmodel78.Value.Value = 74
newmodel78.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_8-16 (1)'
newmodel78:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.6, 0, -0.8)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel79 = workspace.scam.prefabs.Selector_b:clone()
newmodel79.Parent = workspace.scam.np
newmodel79.Value.Value = 75
newmodel79.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_8-18 (1)'
newmodel79:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.8000000000000003, 0, -0.8)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel80 = workspace.scam.prefabs.Selector_b:clone()
newmodel80.Parent = workspace.scam.np
newmodel80.Value.Value = 76
newmodel80.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_8-20 (1)'
newmodel80:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.0, 0, -0.8)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel81 = workspace.scam.prefabs.Selector_b:clone()
newmodel81.Parent = workspace.scam.np
newmodel81.Value.Value = 77
newmodel81.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_8-22 (1)'
newmodel81:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.1999999999999997, 0, -0.8)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel82 = workspace.scam.prefabs.Selector_y:clone()
newmodel82.Parent = workspace.scam.np
newmodel82.Value.Value = 78
newmodel82.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_9-1 (1)'
newmodel82:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.1, 0, -0.9000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel83 = workspace.scam.prefabs.Selector_b:clone()
newmodel83.Parent = workspace.scam.np
newmodel83.Value.Value = 79
newmodel83.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_9-3 (1)'
newmodel83:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.3, 0, -0.9000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel84 = workspace.scam.prefabs.Selector_y:clone()
newmodel84.Parent = workspace.scam.np
newmodel84.Value.Value = 80
newmodel84.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_9-5 (1)'
newmodel84:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.5, 0, -0.9000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel85 = workspace.scam.prefabs.Selector_b:clone()
newmodel85.Parent = workspace.scam.np
newmodel85.Value.Value = 81
newmodel85.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_9-7 (1)'
newmodel85:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.7000000000000001, 0, -0.9000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel86 = workspace.scam.prefabs.Selector_y:clone()
newmodel86.Parent = workspace.scam.np
newmodel86.Value.Value = 82
newmodel86.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_9-9 (1)'
newmodel86:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.9000000000000001, 0, -0.9000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel87 = workspace.scam.prefabs.Selector_c:clone()
newmodel87.Parent = workspace.scam.np
newmodel87.Value.Value = 83
newmodel87.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_9-11 (1)'
newmodel87:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0999999999999999, 0, -0.9000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel88 = workspace.scam.prefabs.Selector_y:clone()
newmodel88.Parent = workspace.scam.np
newmodel88.Value.Value = 84
newmodel88.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_9-13 (1)'
newmodel88:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.3, 0, -0.9000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel89 = workspace.scam.prefabs.Selector_b:clone()
newmodel89.Parent = workspace.scam.np
newmodel89.Value.Value = 85
newmodel89.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_9-15 (1)'
newmodel89:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.5, 0, -0.9000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel90 = workspace.scam.prefabs.Selector_y:clone()
newmodel90.Parent = workspace.scam.np
newmodel90.Value.Value = 86
newmodel90.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_9-17 (1)'
newmodel90:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.7000000000000002, 0, -0.9000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel91 = workspace.scam.prefabs.Selector_b:clone()
newmodel91.Parent = workspace.scam.np
newmodel91.Value.Value = 87
newmodel91.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_9-19 (1)'
newmodel91:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.9, 0, -0.9000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel92 = workspace.scam.prefabs.Selector_y:clone()
newmodel92.Parent = workspace.scam.np
newmodel92.Value.Value = 88
newmodel92.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_9-21 (1)'
newmodel92:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.1, 0, -0.9000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel93 = workspace.scam.prefabs.Selector_w:clone()
newmodel93.Parent = workspace.scam.np
newmodel93.Value.Value = 89
newmodel93.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_10-0 (1)'
newmodel93:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.0, 0, -1.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel94 = workspace.scam.prefabs.Selector_w:clone()
newmodel94.Parent = workspace.scam.np
newmodel94.Value.Value = 90
newmodel94.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_10-2 (1)'
newmodel94:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.2, 0, -1.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel95 = workspace.scam.prefabs.Selector_w:clone()
newmodel95.Parent = workspace.scam.np
newmodel95.Value.Value = 91
newmodel95.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_10-4 (1)'
newmodel95:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.4, 0, -1.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel96 = workspace.scam.prefabs.Selector_w:clone()
newmodel96.Parent = workspace.scam.np
newmodel96.Value.Value = 92
newmodel96.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_10-6 (1)'
newmodel96:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.6, 0, -1.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel97 = workspace.scam.prefabs.Selector_b:clone()
newmodel97.Parent = workspace.scam.np
newmodel97.Value.Value = 93
newmodel97.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_10-8 (1)'
newmodel97:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.8, 0, -1.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel98 = workspace.scam.prefabs.Selector_b:clone()
newmodel98.Parent = workspace.scam.np
newmodel98.Value.Value = 94
newmodel98.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_10-10 (1)'
newmodel98:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0, 0, -1.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel99 = workspace.scam.prefabs.Selector_b:clone()
newmodel99.Parent = workspace.scam.np
newmodel99.Value.Value = 95
newmodel99.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_10-12 (1)'
newmodel99:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.2, 0, -1.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel100 = workspace.scam.prefabs.Selector_b:clone()
newmodel100.Parent = workspace.scam.np
newmodel100.Value.Value = 96
newmodel100.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_10-14 (1)'
newmodel100:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.4000000000000001, 0, -1.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel101 = workspace.scam.prefabs.Selector_b:clone()
newmodel101.Parent = workspace.scam.np
newmodel101.Value.Value = 97
newmodel101.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_10-16 (1)'
newmodel101:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.6, 0, -1.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel102 = workspace.scam.prefabs.Selector_b:clone()
newmodel102.Parent = workspace.scam.np
newmodel102.Value.Value = 98
newmodel102.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_10-18 (1)'
newmodel102:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.8000000000000003, 0, -1.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel103 = workspace.scam.prefabs.Selector_b:clone()
newmodel103.Parent = workspace.scam.np
newmodel103.Value.Value = 99
newmodel103.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_10-20 (1)'
newmodel103:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.0, 0, -1.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel104 = workspace.scam.prefabs.Selector_b:clone()
newmodel104.Parent = workspace.scam.np
newmodel104.Value.Value = 100
newmodel104.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_10-22 (1)'
newmodel104:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.1999999999999997, 0, -1.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel105 = workspace.scam.prefabs.Selector_w:clone()
newmodel105.Parent = workspace.scam.np
newmodel105.Value.Value = 101
newmodel105.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_11-1 (1)'
newmodel105:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.1, 0, -1.0999999999999999)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel106 = workspace.scam.prefabs.Selector_w:clone()
newmodel106.Parent = workspace.scam.np
newmodel106.Value.Value = 102
newmodel106.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_11-3 (1)'
newmodel106:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.3, 0, -1.0999999999999999)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel107 = workspace.scam.prefabs.Selector_c:clone()
newmodel107.Parent = workspace.scam.np
newmodel107.Value.Value = 103
newmodel107.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_11-5 (1)'
newmodel107:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.5, 0, -1.0999999999999999)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel108 = workspace.scam.prefabs.Selector_b:clone()
newmodel108.Parent = workspace.scam.np
newmodel108.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_11-7 (1)'
newmodel108:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.7000000000000001, 0, -1.0999999999999999)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel109 = workspace.scam.prefabs.Selector_c:clone()
newmodel109.Parent = workspace.scam.np
newmodel109.Value.Value = 104
newmodel109.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_11-9 (1)'
newmodel109:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.9000000000000001, 0, -1.0999999999999999)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel110 = workspace.scam.prefabs.Selector_w:clone()
newmodel110.Parent = workspace.scam.np
newmodel110.Value.Value = 105
newmodel110.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_11-11 (1)'
newmodel110:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0999999999999999, 0, -1.0999999999999999)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel111 = workspace.scam.prefabs.Selector_c:clone()
newmodel111.Parent = workspace.scam.np
newmodel111.Value.Value = 106
newmodel111.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_11-13 (1)'
newmodel111:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.3, 0, -1.0999999999999999)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel112 = workspace.scam.prefabs.Selector_b:clone()
newmodel112.Parent = workspace.scam.np
newmodel112.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_11-15 (1)'
newmodel112:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.5, 0, -1.0999999999999999)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel113 = workspace.scam.prefabs.Selector_c:clone()
newmodel113.Parent = workspace.scam.np
newmodel113.Value.Value = 107
newmodel113.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_11-17 (1)'
newmodel113:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.7000000000000002, 0, -1.0999999999999999)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel114 = workspace.scam.prefabs.Selector_b:clone()
newmodel114.Parent = workspace.scam.np
newmodel114.Value.Value = 108
newmodel114.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_11-19 (1)'
newmodel114:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.9, 0, -1.0999999999999999)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel115 = workspace.scam.prefabs.Selector_b:clone()
newmodel115.Parent = workspace.scam.np
newmodel115.Value.Value = 109
newmodel115.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_11-21 (1)'
newmodel115:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.1, 0, -1.0999999999999999)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel116 = workspace.scam.prefabs.Selector_w:clone()
newmodel116.Parent = workspace.scam.np
newmodel116.Value.Value = 110
newmodel116.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_12-0 (1)'
newmodel116:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.0, 0, -1.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel117 = workspace.scam.prefabs.Selector_w:clone()
newmodel117.Parent = workspace.scam.np
newmodel117.Value.Value = 111
newmodel117.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_12-2 (1)'
newmodel117:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.2, 0, -1.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel118 = workspace.scam.prefabs.Selector_w:clone()
newmodel118.Parent = workspace.scam.np
newmodel118.Value.Value = 112
newmodel118.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_12-4 (1)'
newmodel118:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.4, 0, -1.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel119 = workspace.scam.prefabs.Selector_w:clone()
newmodel119.Parent = workspace.scam.np
newmodel119.Value.Value = 113
newmodel119.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_12-6 (1)'
newmodel119:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.6, 0, -1.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel120 = workspace.scam.prefabs.Selector_w:clone()
newmodel120.Parent = workspace.scam.np
newmodel120.Value.Value = 114
newmodel120.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_12-8 (1)'
newmodel120:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.8, 0, -1.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel121 = workspace.scam.prefabs.Selector_w:clone()
newmodel121.Parent = workspace.scam.np
newmodel121.Value.Value = 115
newmodel121.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_12-10 (1)'
newmodel121:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0, 0, -1.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel122 = workspace.scam.prefabs.Selector_w:clone()
newmodel122.Parent = workspace.scam.np
newmodel122.Value.Value = 116
newmodel122.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_12-12 (1)'
newmodel122:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.2, 0, -1.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel123 = workspace.scam.prefabs.Selector_w:clone()
newmodel123.Parent = workspace.scam.np
newmodel123.Value.Value = 117
newmodel123.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_12-14 (1)'
newmodel123:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.4000000000000001, 0, -1.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel124 = workspace.scam.prefabs.Selector_b:clone()
newmodel124.Parent = workspace.scam.np
newmodel124.Value.Value = 118
newmodel124.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_12-16 (1)'
newmodel124:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.6, 0, -1.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel125 = workspace.scam.prefabs.Selector_b:clone()
newmodel125.Parent = workspace.scam.np
newmodel125.Value.Value = 119
newmodel125.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_12-18 (1)'
newmodel125:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.8000000000000003, 0, -1.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel126 = workspace.scam.prefabs.Selector_b:clone()
newmodel126.Parent = workspace.scam.np
newmodel126.Value.Value = 120
newmodel126.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_12-20 (1)'
newmodel126:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.0, 0, -1.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel127 = workspace.scam.prefabs.Selector_b:clone()
newmodel127.Parent = workspace.scam.np
newmodel127.Value.Value = 121
newmodel127.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_12-22 (1)'
newmodel127:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.1999999999999997, 0, -1.2)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel128 = workspace.scam.prefabs.Selector_y:clone()
newmodel128.Parent = workspace.scam.np
newmodel128.Value.Value = 122
newmodel128.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_13-1 (1)'
newmodel128:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.1, 0, -1.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel129 = workspace.scam.prefabs.Selector_w:clone()
newmodel129.Parent = workspace.scam.np
newmodel129.Value.Value = 123
newmodel129.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_13-3 (1)'
newmodel129:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.3, 0, -1.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel130 = workspace.scam.prefabs.Selector_y:clone()
newmodel130.Parent = workspace.scam.np
newmodel130.Value.Value = 124
newmodel130.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_13-5 (1)'
newmodel130:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.5, 0, -1.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel131 = workspace.scam.prefabs.Selector_w:clone()
newmodel131.Parent = workspace.scam.np
newmodel131.Value.Value = 125
newmodel131.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_13-7 (1)'
newmodel131:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.7000000000000001, 0, -1.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel132 = workspace.scam.prefabs.Selector_y:clone()
newmodel132.Parent = workspace.scam.np
newmodel132.Value.Value = 126
newmodel132.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_13-9 (1)'
newmodel132:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.9000000000000001, 0, -1.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel133 = workspace.scam.prefabs.Selector_c:clone()
newmodel133.Parent = workspace.scam.np
newmodel133.Value.Value = 127
newmodel133.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_13-11 (1)'
newmodel133:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0999999999999999, 0, -1.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel134 = workspace.scam.prefabs.Selector_y:clone()
newmodel134.Parent = workspace.scam.np
newmodel134.Value.Value = 128
newmodel134.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_13-13 (1)'
newmodel134:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.3, 0, -1.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel135 = workspace.scam.prefabs.Selector_w:clone()
newmodel135.Parent = workspace.scam.np
newmodel135.Value.Value = 129
newmodel135.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_13-15 (1)'
newmodel135:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.5, 0, -1.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel136 = workspace.scam.prefabs.Selector_y:clone()
newmodel136.Parent = workspace.scam.np
newmodel136.Value.Value = 130
newmodel136.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_13-17 (1)'
newmodel136:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.7000000000000002, 0, -1.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel137 = workspace.scam.prefabs.Selector_b:clone()
newmodel137.Parent = workspace.scam.np
newmodel137.Value.Value = 131
newmodel137.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_13-19 (1)'
newmodel137:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.9, 0, -1.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel138 = workspace.scam.prefabs.Selector_y:clone()
newmodel138.Parent = workspace.scam.np
newmodel138.Value.Value = 132
newmodel138.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_13-21 (1)'
newmodel138:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.1, 0, -1.3)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel139 = workspace.scam.prefabs.Selector_w:clone()
newmodel139.Parent = workspace.scam.np
newmodel139.Value.Value = 133
newmodel139.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_14-0 (1)'
newmodel139:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.0, 0, -1.4000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel140 = workspace.scam.prefabs.Selector_w:clone()
newmodel140.Parent = workspace.scam.np
newmodel140.Value.Value = 134
newmodel140.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_14-2 (1)'
newmodel140:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.2, 0, -1.4000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel141 = workspace.scam.prefabs.Selector_w:clone()
newmodel141.Parent = workspace.scam.np
newmodel141.Value.Value = 135
newmodel141.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_14-4 (1)'
newmodel141:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.4, 0, -1.4000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel142 = workspace.scam.prefabs.Selector_w:clone()
newmodel142.Parent = workspace.scam.np
newmodel142.Value.Value = 136
newmodel142.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_14-6 (1)'
newmodel142:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.6, 0, -1.4000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel143 = workspace.scam.prefabs.Selector_b:clone()
newmodel143.Parent = workspace.scam.np
newmodel143.Value.Value = 137
newmodel143.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_14-8 (1)'
newmodel143:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.8, 0, -1.4000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel144 = workspace.scam.prefabs.Selector_b:clone()
newmodel144.Parent = workspace.scam.np
newmodel144.Value.Value = 138
newmodel144.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_14-10 (1)'
newmodel144:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0, 0, -1.4000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel145 = workspace.scam.prefabs.Selector_b:clone()
newmodel145.Parent = workspace.scam.np
newmodel145.Value.Value = 139
newmodel145.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_14-12 (1)'
newmodel145:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.2, 0, -1.4000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel146 = workspace.scam.prefabs.Selector_w:clone()
newmodel146.Parent = workspace.scam.np
newmodel146.Value.Value = 140
newmodel146.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_14-14 (1)'
newmodel146:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.4000000000000001, 0, -1.4000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel147 = workspace.scam.prefabs.Selector_w:clone()
newmodel147.Parent = workspace.scam.np
newmodel147.Value.Value = 141
newmodel147.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_14-16 (1)'
newmodel147:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.6, 0, -1.4000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel148 = workspace.scam.prefabs.Selector_w:clone()
newmodel148.Parent = workspace.scam.np
newmodel148.Value.Value = 142
newmodel148.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_14-18 (1)'
newmodel148:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.8000000000000003, 0, -1.4000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel149 = workspace.scam.prefabs.Selector_w:clone()
newmodel149.Parent = workspace.scam.np
newmodel149.Value.Value = 143
newmodel149.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_14-20 (1)'
newmodel149:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.0, 0, -1.4000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel150 = workspace.scam.prefabs.Selector_w:clone()
newmodel150.Parent = workspace.scam.np
newmodel150.Value.Value = 144
newmodel150.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_14-22 (1)'
newmodel150:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.1999999999999997, 0, -1.4000000000000001)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel151 = workspace.scam.prefabs.Selector_w:clone()
newmodel151.Parent = workspace.scam.np
newmodel151.Value.Value = 145
newmodel151.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_15-1 (1)'
newmodel151:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.1, 0, -1.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel152 = workspace.scam.prefabs.Selector_b:clone()
newmodel152.Parent = workspace.scam.np
newmodel152.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_15-3 (1)'
newmodel152:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.3, 0, -1.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel153 = workspace.scam.prefabs.Selector_w:clone()
newmodel153.Parent = workspace.scam.np
newmodel153.Value.Value = 146
newmodel153.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_15-5 (1)'
newmodel153:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.5, 0, -1.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel154 = workspace.scam.prefabs.Selector_c:clone()
newmodel154.Parent = workspace.scam.np
newmodel154.Value.Value = 147
newmodel154.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_15-7 (1)'
newmodel154:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.7000000000000001, 0, -1.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel155 = workspace.scam.prefabs.Selector_b:clone()
newmodel155.Parent = workspace.scam.np
newmodel155.Value.Value = 148
newmodel155.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_15-9 (1)'
newmodel155:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.9000000000000001, 0, -1.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel156 = workspace.scam.prefabs.Selector_b:clone()
newmodel156.Parent = workspace.scam.np
newmodel156.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_15-11 (1)'
newmodel156:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0999999999999999, 0, -1.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel157 = workspace.scam.prefabs.Selector_w:clone()
newmodel157.Parent = workspace.scam.np
newmodel157.Value.Value = 149
newmodel157.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_15-13 (1)'
newmodel157:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.3, 0, -1.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel158 = workspace.scam.prefabs.Selector_c:clone()
newmodel158.Parent = workspace.scam.np
newmodel158.Value.Value = 150
newmodel158.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_15-15 (1)'
newmodel158:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.5, 0, -1.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel159 = workspace.scam.prefabs.Selector_w:clone()
newmodel159.Parent = workspace.scam.np
newmodel159.Value.Value = 151
newmodel159.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_15-17 (1)'
newmodel159:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.7000000000000002, 0, -1.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel160 = workspace.scam.prefabs.Selector_b:clone()
newmodel160.Parent = workspace.scam.np
newmodel160.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_15-19 (1)'
newmodel160:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.9, 0, -1.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel161 = workspace.scam.prefabs.Selector_w:clone()
newmodel161.Parent = workspace.scam.np
newmodel161.Value.Value = 152
newmodel161.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_15-21 (1)'
newmodel161:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.1, 0, -1.5)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel162 = workspace.scam.prefabs.Selector_w:clone()
newmodel162.Parent = workspace.scam.np
newmodel162.Value.Value = 153
newmodel162.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_16-2 (1)'
newmodel162:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.2, 0, -1.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel163 = workspace.scam.prefabs.Selector_w:clone()
newmodel163.Parent = workspace.scam.np
newmodel163.Value.Value = 154
newmodel163.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_16-4 (1)'
newmodel163:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.4, 0, -1.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel164 = workspace.scam.prefabs.Selector_w:clone()
newmodel164.Parent = workspace.scam.np
newmodel164.Value.Value = 155
newmodel164.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_16-6 (1)'
newmodel164:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.6, 0, -1.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel165 = workspace.scam.prefabs.Selector_b:clone()
newmodel165.Parent = workspace.scam.np
newmodel165.Value.Value = 156
newmodel165.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_16-8 (1)'
newmodel165:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.8, 0, -1.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel166 = workspace.scam.prefabs.Selector_b:clone()
newmodel166.Parent = workspace.scam.np
newmodel166.Value.Value = 157
newmodel166.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_16-10 (1)'
newmodel166:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0, 0, -1.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel167 = workspace.scam.prefabs.Selector_b:clone()
newmodel167.Parent = workspace.scam.np
newmodel167.Value.Value = 158
newmodel167.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_16-12 (1)'
newmodel167:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.2, 0, -1.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel168 = workspace.scam.prefabs.Selector_w:clone()
newmodel168.Parent = workspace.scam.np
newmodel168.Value.Value = 159
newmodel168.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_16-14 (1)'
newmodel168:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.4000000000000001, 0, -1.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel169 = workspace.scam.prefabs.Selector_w:clone()
newmodel169.Parent = workspace.scam.np
newmodel169.Value.Value = 160
newmodel169.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_16-16 (1)'
newmodel169:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.6, 0, -1.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel170 = workspace.scam.prefabs.Selector_w:clone()
newmodel170.Parent = workspace.scam.np
newmodel170.Value.Value = 161
newmodel170.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_16-18 (1)'
newmodel170:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.8000000000000003, 0, -1.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel171 = workspace.scam.prefabs.Selector_w:clone()
newmodel171.Parent = workspace.scam.np
newmodel171.Value.Value = 162
newmodel171.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_16-20 (1)'
newmodel171:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.0, 0, -1.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel172 = workspace.scam.prefabs.Selector_w:clone()
newmodel172.Parent = workspace.scam.np
newmodel172.Value.Value = 163
newmodel172.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_16-22 (1)'
newmodel172:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.1999999999999997, 0, -1.6)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel173 = workspace.scam.prefabs.Selector_w:clone()
newmodel173.Parent = workspace.scam.np
newmodel173.Value.Value = 164
newmodel173.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_17-1 (1)'
newmodel173:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.1, 0, -1.7000000000000002)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel174 = workspace.scam.prefabs.Selector_w:clone()
newmodel174.Parent = workspace.scam.np
newmodel174.Value.Value = 165
newmodel174.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_17-3 (1)'
newmodel174:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.3, 0, -1.7000000000000002)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel175 = workspace.scam.prefabs.Selector_y:clone()
newmodel175.Parent = workspace.scam.np
newmodel175.Value.Value = 166
newmodel175.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_17-5 (1)'
newmodel175:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.5, 0, -1.7000000000000002)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel176 = workspace.scam.prefabs.Selector_b:clone()
newmodel176.Parent = workspace.scam.np
newmodel176.Value.Value = 167
newmodel176.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_17-7 (1)'
newmodel176:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.7000000000000001, 0, -1.7000000000000002)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel177 = workspace.scam.prefabs.Selector_y:clone()
newmodel177.Parent = workspace.scam.np
newmodel177.Value.Value = 168
newmodel177.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_17-9 (1)'
newmodel177:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.9000000000000001, 0, -1.7000000000000002)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel178 = workspace.scam.prefabs.Selector_c:clone()
newmodel178.Parent = workspace.scam.np
newmodel178.Value.Value = 169
newmodel178.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_17-11 (1)'
newmodel178:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0999999999999999, 0, -1.7000000000000002)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel179 = workspace.scam.prefabs.Selector_y:clone()
newmodel179.Parent = workspace.scam.np
newmodel179.Value.Value = 170
newmodel179.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_17-13 (1)'
newmodel179:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.3, 0, -1.7000000000000002)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel180 = workspace.scam.prefabs.Selector_w:clone()
newmodel180.Parent = workspace.scam.np
newmodel180.Value.Value = 171
newmodel180.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_17-15 (1)'
newmodel180:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.5, 0, -1.7000000000000002)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel181 = workspace.scam.prefabs.Selector_y:clone()
newmodel181.Parent = workspace.scam.np
newmodel181.Value.Value = 172
newmodel181.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_17-17 (1)'
newmodel181:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.7000000000000002, 0, -1.7000000000000002)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel182 = workspace.scam.prefabs.Selector_w:clone()
newmodel182.Parent = workspace.scam.np
newmodel182.Value.Value = 173
newmodel182.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_17-19 (1)'
newmodel182:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.9, 0, -1.7000000000000002)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel183 = workspace.scam.prefabs.Selector_w:clone()
newmodel183.Parent = workspace.scam.np
newmodel183.Value.Value = 174
newmodel183.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_17-21 (1)'
newmodel183:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.1, 0, -1.7000000000000002)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel184 = workspace.scam.prefabs.Selector_w:clone()
newmodel184.Parent = workspace.scam.np
newmodel184.Value.Value = 175
newmodel184.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_18-2 (1)'
newmodel184:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.2, 0, -1.8000000000000003)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel185 = workspace.scam.prefabs.Selector_w:clone()
newmodel185.Parent = workspace.scam.np
newmodel185.Value.Value = 176
newmodel185.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_18-4 (1)'
newmodel185:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.4, 0, -1.8000000000000003)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel186 = workspace.scam.prefabs.Selector_b:clone()
newmodel186.Parent = workspace.scam.np
newmodel186.Value.Value = 177
newmodel186.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_18-6 (1)'
newmodel186:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.6, 0, -1.8000000000000003)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel187 = workspace.scam.prefabs.Selector_b:clone()
newmodel187.Parent = workspace.scam.np
newmodel187.Value.Value = 178
newmodel187.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_18-8 (1)'
newmodel187:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.8, 0, -1.8000000000000003)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel188 = workspace.scam.prefabs.Selector_b:clone()
newmodel188.Parent = workspace.scam.np
newmodel188.Value.Value = 179
newmodel188.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_18-10 (1)'
newmodel188:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0, 0, -1.8000000000000003)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel189 = workspace.scam.prefabs.Selector_b:clone()
newmodel189.Parent = workspace.scam.np
newmodel189.Value.Value = 180
newmodel189.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_18-12 (1)'
newmodel189:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.2, 0, -1.8000000000000003)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel190 = workspace.scam.prefabs.Selector_w:clone()
newmodel190.Parent = workspace.scam.np
newmodel190.Value.Value = 181
newmodel190.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_18-14 (1)'
newmodel190:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.4000000000000001, 0, -1.8000000000000003)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel191 = workspace.scam.prefabs.Selector_w:clone()
newmodel191.Parent = workspace.scam.np
newmodel191.Value.Value = 182
newmodel191.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_18-16 (1)'
newmodel191:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.6, 0, -1.8000000000000003)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel192 = workspace.scam.prefabs.Selector_w:clone()
newmodel192.Parent = workspace.scam.np
newmodel192.Value.Value = 183
newmodel192.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_18-18 (1)'
newmodel192:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.8000000000000003, 0, -1.8000000000000003)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel193 = workspace.scam.prefabs.Selector_w:clone()
newmodel193.Parent = workspace.scam.np
newmodel193.Value.Value = 184
newmodel193.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_18-20 (1)'
newmodel193:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-2.0, 0, -1.8000000000000003)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel194 = workspace.scam.prefabs.Selector_w:clone()
newmodel194.Parent = workspace.scam.np
newmodel194.Value.Value = 185
newmodel194.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_19-3 (1)'
newmodel194:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.3, 0, -1.9)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel195 = workspace.scam.prefabs.Selector_b:clone()
newmodel195.Parent = workspace.scam.np
newmodel195.Value.Value = 186
newmodel195.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_19-5 (1)'
newmodel195:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.5, 0, -1.9)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel196 = workspace.scam.prefabs.Selector_b:clone()
newmodel196.Parent = workspace.scam.np
newmodel196.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_19-7 (1)'
newmodel196:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.7000000000000001, 0, -1.9)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel197 = workspace.scam.prefabs.Selector_b:clone()
newmodel197.Parent = workspace.scam.np
newmodel197.Value.Value = 187
newmodel197.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_19-9 (1)'
newmodel197:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.9000000000000001, 0, -1.9)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel198 = workspace.scam.prefabs.Selector_b:clone()
newmodel198.Parent = workspace.scam.np
newmodel198.Value.Value = 188
newmodel198.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_19-11 (1)'
newmodel198:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0999999999999999, 0, -1.9)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel199 = workspace.scam.prefabs.Selector_b:clone()
newmodel199.Parent = workspace.scam.np
newmodel199.Value.Value = 189
newmodel199.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_19-13 (1)'
newmodel199:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.3, 0, -1.9)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel200 = workspace.scam.prefabs.Selector_b:clone()
newmodel200.Parent = workspace.scam.np
newmodel200.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_19-15 (1)'
newmodel200:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.5, 0, -1.9)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel201 = workspace.scam.prefabs.Selector_w:clone()
newmodel201.Parent = workspace.scam.np
newmodel201.Value.Value = 190
newmodel201.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_19-17 (1)'
newmodel201:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.7000000000000002, 0, -1.9)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel202 = workspace.scam.prefabs.Selector_w:clone()
newmodel202.Parent = workspace.scam.np
newmodel202.Value.Value = 191
newmodel202.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_19-19 (1)'
newmodel202:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.9, 0, -1.9)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel203 = workspace.scam.prefabs.Selector_b:clone()
newmodel203.Parent = workspace.scam.np
newmodel203.Value.Value = 192
newmodel203.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_20-4 (1)'
newmodel203:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.4, 0, -2.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel204 = workspace.scam.prefabs.Selector_b:clone()
newmodel204.Parent = workspace.scam.np
newmodel204.Value.Value = 193
newmodel204.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_20-6 (1)'
newmodel204:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.6, 0, -2.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel205 = workspace.scam.prefabs.Selector_b:clone()
newmodel205.Parent = workspace.scam.np
newmodel205.Value.Value = 194
newmodel205.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_20-8 (1)'
newmodel205:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.8, 0, -2.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel206 = workspace.scam.prefabs.Selector_b:clone()
newmodel206.Parent = workspace.scam.np
newmodel206.Value.Value = 195
newmodel206.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_20-10 (1)'
newmodel206:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0, 0, -2.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel207 = workspace.scam.prefabs.Selector_b:clone()
newmodel207.Parent = workspace.scam.np
newmodel207.Value.Value = 196
newmodel207.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_20-12 (1)'
newmodel207:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.2, 0, -2.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel208 = workspace.scam.prefabs.Selector_b:clone()
newmodel208.Parent = workspace.scam.np
newmodel208.Value.Value = 197
newmodel208.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_20-14 (1)'
newmodel208:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.4000000000000001, 0, -2.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel209 = workspace.scam.prefabs.Selector_w:clone()
newmodel209.Parent = workspace.scam.np
newmodel209.Value.Value = 198
newmodel209.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_20-16 (1)'
newmodel209:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.6, 0, -2.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel210 = workspace.scam.prefabs.Selector_w:clone()
newmodel210.Parent = workspace.scam.np
newmodel210.Value.Value = 199
newmodel210.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_20-18 (1)'
newmodel210:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.8000000000000003, 0, -2.0)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel211 = workspace.scam.prefabs.Selector_b:clone()
newmodel211.Parent = workspace.scam.np
newmodel211.Value.Value = 200
newmodel211.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_21-5 (1)'
newmodel211:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.5, 0, -2.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel212 = workspace.scam.prefabs.Selector_b:clone()
newmodel212.Parent = workspace.scam.np
newmodel212.Value.Value = 201
newmodel212.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_21-7 (1)'
newmodel212:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.7000000000000001, 0, -2.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel213 = workspace.scam.prefabs.Selector_y:clone()
newmodel213.Parent = workspace.scam.np
newmodel213.Value.Value = 202
newmodel213.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_21-9 (1)'
newmodel213:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.9000000000000001, 0, -2.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel214 = workspace.scam.prefabs.Selector_b:clone()
newmodel214.Parent = workspace.scam.np
newmodel214.Value.Value = 203
newmodel214.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_21-11 (1)'
newmodel214:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0999999999999999, 0, -2.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel215 = workspace.scam.prefabs.Selector_y:clone()
newmodel215.Parent = workspace.scam.np
newmodel215.Value.Value = 204
newmodel215.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_21-13 (1)'
newmodel215:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.3, 0, -2.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel216 = workspace.scam.prefabs.Selector_w:clone()
newmodel216.Parent = workspace.scam.np
newmodel216.Value.Value = 205
newmodel216.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_21-15 (1)'
newmodel216:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.5, 0, -2.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel217 = workspace.scam.prefabs.Selector_w:clone()
newmodel217.Parent = workspace.scam.np
newmodel217.Value.Value = 206
newmodel217.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_21-17 (1)'
newmodel217:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.7000000000000002, 0, -2.1)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel218 = workspace.scam.prefabs.Selector_b:clone()
newmodel218.Parent = workspace.scam.np
newmodel218.Value.Value = 207
newmodel218.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_22-8 (1)'
newmodel218:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-0.8, 0, -2.1999999999999997)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel219 = workspace.scam.prefabs.Selector_b:clone()
newmodel219.Parent = workspace.scam.np
newmodel219.Value.Value = 208
newmodel219.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_22-10 (1)'
newmodel219:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.0, 0, -2.1999999999999997)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel220 = workspace.scam.prefabs.Selector_b:clone()
newmodel220.Parent = workspace.scam.np
newmodel220.Value.Value = 209
newmodel220.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_22-12 (1)'
newmodel220:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.2, 0, -2.1999999999999997)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel221 = workspace.scam.prefabs.Selector_b:clone()
newmodel221.Parent = workspace.scam.np
newmodel221.Value.Value = 210
newmodel221.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_22-14 (1)'
newmodel221:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.4000000000000001, 0, -2.1999999999999997)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
newmodel222 = workspace.scam.prefabs.Selector_w:clone()
newmodel222.Parent = workspace.scam.np
newmodel222.Value.Value = 211
newmodel222.p2p.Body7.SurfaceGui.ImageLabel.Image = 'rbxgameasset://Images/NPBTN_22-16 (1)'
newmodel222:PivotTo(CFrame.new(workspace.scam.prefabs.Part.CFrame.Position + Vector3.new(-1.6, 0, -2.1999999999999997)) * CFrame.fromEulerAngles(0, math.rad(180), 0))
