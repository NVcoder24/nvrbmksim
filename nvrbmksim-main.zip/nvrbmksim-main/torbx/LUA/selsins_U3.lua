newmodel0 = workspace.scam.prefabs.sdef:clone()
newmodel0.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel0:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -0.44, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel0:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -0.44, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel0.Parent = workspace.scam.selsins.s
newmodel1 = workspace.scam.prefabs.sdef:clone()
newmodel1.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel1:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -0.44, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel1:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -0.44, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel1.Parent = workspace.scam.selsins.s
newmodel2 = workspace.scam.prefabs.sdef:clone()
newmodel2.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel2:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -0.44, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel2:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -0.44, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel2.Parent = workspace.scam.selsins.s
newmodel3 = workspace.scam.prefabs.sdef:clone()
newmodel3.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel3:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -0.44, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel3:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -0.44, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel3.Parent = workspace.scam.selsins.s
newmodel4 = workspace.scam.prefabs.sdef:clone()
newmodel4.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel4:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -0.7226, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel4.Parent = workspace.scam.selsins.s
newmodel5 = workspace.scam.prefabs.sdef:clone()
newmodel5.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel5:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -0.7226, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel5:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -0.7226, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel5.Parent = workspace.scam.selsins.s
newmodel6 = workspace.scam.prefabs.susp:clone()
newmodel6:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -0.7226, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel6:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -0.7226, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel6.Parent = workspace.scam.selsins.s
newmodel7 = workspace.scam.prefabs.sdef:clone()
newmodel7.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel7:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -0.7226, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel7:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -0.7226, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel7.Parent = workspace.scam.selsins.s
newmodel8 = workspace.scam.prefabs.susp:clone()
newmodel8:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -0.7226, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel8:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -0.7226, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel8.Parent = workspace.scam.selsins.s
newmodel9 = workspace.scam.prefabs.sdef:clone()
newmodel9.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel9:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -0.7226, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel9:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -0.7226, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel9.Parent = workspace.scam.selsins.s
newmodel10 = workspace.scam.prefabs.sdef:clone()
newmodel10.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel10:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -0.7226, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel10:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -0.7226, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel10.Parent = workspace.scam.selsins.s
newmodel11 = workspace.scam.prefabs.sdef:clone()
newmodel11.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel11:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel11.Parent = workspace.scam.selsins.s
newmodel12 = workspace.scam.prefabs.sdef:clone()
newmodel12.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel12:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel12:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel12.Parent = workspace.scam.selsins.s
newmodel13 = workspace.scam.prefabs.sdef:clone()
newmodel13.Body4.Color = Color3.fromRGB(52, 129, 176)
newmodel13:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel13:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel13.Parent = workspace.scam.selsins.s
newmodel14 = workspace.scam.prefabs.sdef:clone()
newmodel14.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel14:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel14:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel14.Parent = workspace.scam.selsins.s
newmodel15 = workspace.scam.prefabs.sdef:clone()
newmodel15.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel15:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel15:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel15.Parent = workspace.scam.selsins.s
newmodel16 = workspace.scam.prefabs.sdef:clone()
newmodel16.Body4.Color = Color3.fromRGB(52, 129, 176)
newmodel16:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel16:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel16.Parent = workspace.scam.selsins.s
newmodel17 = workspace.scam.prefabs.sdef:clone()
newmodel17.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel17:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel17:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel17.Parent = workspace.scam.selsins.s
newmodel18 = workspace.scam.prefabs.sdef:clone()
newmodel18.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel18:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel18:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -1.0052, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel18.Parent = workspace.scam.selsins.s
newmodel19 = workspace.scam.prefabs.sdef:clone()
newmodel19.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel19:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -1.2878000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel19.Parent = workspace.scam.selsins.s
newmodel20 = workspace.scam.prefabs.sdef:clone()
newmodel20.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel20:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -1.2878000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel20.Parent = workspace.scam.selsins.s
newmodel21 = workspace.scam.prefabs.sdef:clone()
newmodel21.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel21:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -1.2878000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel21:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -1.2878000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel21.Parent = workspace.scam.selsins.s
newmodel22 = workspace.scam.prefabs.sdef:clone()
newmodel22.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel22:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -1.2878000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel22:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -1.2878000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel22.Parent = workspace.scam.selsins.s
newmodel23 = workspace.scam.prefabs.sdef:clone()
newmodel23.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel23:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -1.2878000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel23:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -1.2878000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel23.Parent = workspace.scam.selsins.s
newmodel24 = workspace.scam.prefabs.sdef:clone()
newmodel24.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel24:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -1.2878000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel24:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -1.2878000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel24.Parent = workspace.scam.selsins.s
newmodel25 = workspace.scam.prefabs.sdef:clone()
newmodel25.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel25:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -1.2878000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel25:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -1.2878000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel25.Parent = workspace.scam.selsins.s
newmodel26 = workspace.scam.prefabs.sdef:clone()
newmodel26.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel26:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel26.Parent = workspace.scam.selsins.s
newmodel27 = workspace.scam.prefabs.sdef:clone()
newmodel27.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel27:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel27.Parent = workspace.scam.selsins.s
newmodel28 = workspace.scam.prefabs.sdef:clone()
newmodel28.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel28:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel28:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel28.Parent = workspace.scam.selsins.s
newmodel29 = workspace.scam.prefabs.sdef:clone()
newmodel29.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel29:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel29:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel29.Parent = workspace.scam.selsins.s
newmodel30 = workspace.scam.prefabs.sdef:clone()
newmodel30.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel30:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel30:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel30.Parent = workspace.scam.selsins.s
newmodel31 = workspace.scam.prefabs.sdef:clone()
newmodel31.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel31:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel31:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel31.Parent = workspace.scam.selsins.s
newmodel32 = workspace.scam.prefabs.sdef:clone()
newmodel32.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel32:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel32:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel32.Parent = workspace.scam.selsins.s
newmodel33 = workspace.scam.prefabs.sdef:clone()
newmodel33.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel33:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel33:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel33.Parent = workspace.scam.selsins.s
newmodel34 = workspace.scam.prefabs.sdef:clone()
newmodel34.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel34:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel34:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel34.Parent = workspace.scam.selsins.s
newmodel35 = workspace.scam.prefabs.sdef:clone()
newmodel35.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel35:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel35:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -1.5704, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel35.Parent = workspace.scam.selsins.s
newmodel36 = workspace.scam.prefabs.sdef:clone()
newmodel36.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel36:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel36.Parent = workspace.scam.selsins.s
newmodel37 = workspace.scam.prefabs.sdef:clone()
newmodel37.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel37:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel37.Parent = workspace.scam.selsins.s
newmodel38 = workspace.scam.prefabs.susp:clone()
newmodel38:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel38.Parent = workspace.scam.selsins.s
newmodel39 = workspace.scam.prefabs.sdef:clone()
newmodel39.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel39:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel39:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel39.Parent = workspace.scam.selsins.s
newmodel40 = workspace.scam.prefabs.susp:clone()
newmodel40:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel40:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel40.Parent = workspace.scam.selsins.s
newmodel41 = workspace.scam.prefabs.sdef:clone()
newmodel41.Body4.Color = Color3.fromRGB(18, 97, 0)
newmodel41:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel41:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel41.Parent = workspace.scam.selsins.s
newmodel42 = workspace.scam.prefabs.susp:clone()
newmodel42:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel42:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel42.Parent = workspace.scam.selsins.s
newmodel43 = workspace.scam.prefabs.sdef:clone()
newmodel43.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel43:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel43:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel43.Parent = workspace.scam.selsins.s
newmodel44 = workspace.scam.prefabs.susp:clone()
newmodel44:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel44:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel44.Parent = workspace.scam.selsins.s
newmodel45 = workspace.scam.prefabs.sdef:clone()
newmodel45.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel45:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel45:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel45.Parent = workspace.scam.selsins.s
newmodel46 = workspace.scam.prefabs.sdef:clone()
newmodel46.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel46:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel46:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -1.853, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel46.Parent = workspace.scam.selsins.s
newmodel47 = workspace.scam.prefabs.sdef:clone()
newmodel47.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel47:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel47.Parent = workspace.scam.selsins.s
newmodel48 = workspace.scam.prefabs.sdef:clone()
newmodel48.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel48:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel48.Parent = workspace.scam.selsins.s
newmodel49 = workspace.scam.prefabs.sdef:clone()
newmodel49.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel49:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel49:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel49.Parent = workspace.scam.selsins.s
newmodel50 = workspace.scam.prefabs.sdef:clone()
newmodel50.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel50:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel50:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel50.Parent = workspace.scam.selsins.s
newmodel51 = workspace.scam.prefabs.sdef:clone()
newmodel51.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel51:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel51:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel51.Parent = workspace.scam.selsins.s
newmodel52 = workspace.scam.prefabs.sdef:clone()
newmodel52.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel52:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel52:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel52.Parent = workspace.scam.selsins.s
newmodel53 = workspace.scam.prefabs.sdef:clone()
newmodel53.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel53:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel53:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel53.Parent = workspace.scam.selsins.s
newmodel54 = workspace.scam.prefabs.sdef:clone()
newmodel54.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel54:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel54:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel54.Parent = workspace.scam.selsins.s
newmodel55 = workspace.scam.prefabs.sdef:clone()
newmodel55.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel55:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel55:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel55.Parent = workspace.scam.selsins.s
newmodel56 = workspace.scam.prefabs.sdef:clone()
newmodel56.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel56:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel56:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -2.1356000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel56.Parent = workspace.scam.selsins.s
newmodel57 = workspace.scam.prefabs.sdef:clone()
newmodel57.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel57:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel57.Parent = workspace.scam.selsins.s
newmodel58 = workspace.scam.prefabs.sdef:clone()
newmodel58.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel58:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel58.Parent = workspace.scam.selsins.s
newmodel59 = workspace.scam.prefabs.sdef:clone()
newmodel59.Body4.Color = Color3.fromRGB(18, 97, 0)
newmodel59:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel59:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel59.Parent = workspace.scam.selsins.s
newmodel60 = workspace.scam.prefabs.sdef:clone()
newmodel60.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel60:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel60:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel60.Parent = workspace.scam.selsins.s
newmodel61 = workspace.scam.prefabs.sdef:clone()
newmodel61.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel61:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel61:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel61.Parent = workspace.scam.selsins.s
newmodel62 = workspace.scam.prefabs.sdef:clone()
newmodel62.Body4.Color = Color3.fromRGB(18, 97, 0)
newmodel62:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel62:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel62.Parent = workspace.scam.selsins.s
newmodel63 = workspace.scam.prefabs.sdef:clone()
newmodel63.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel63:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel63:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel63.Parent = workspace.scam.selsins.s
newmodel64 = workspace.scam.prefabs.sdef:clone()
newmodel64.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel64:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel64:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -2.4182, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel64.Parent = workspace.scam.selsins.s
newmodel65 = workspace.scam.prefabs.sdef:clone()
newmodel65.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel65:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.19, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel65.Parent = workspace.scam.selsins.s
newmodel66 = workspace.scam.prefabs.sdef:clone()
newmodel66.Body4.Color = Color3.fromRGB(52, 129, 176)
newmodel66:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel66.Parent = workspace.scam.selsins.s
newmodel67 = workspace.scam.prefabs.sdef:clone()
newmodel67.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel67:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel67.Parent = workspace.scam.selsins.s
newmodel68 = workspace.scam.prefabs.sdef:clone()
newmodel68.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel68:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel68:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel68.Parent = workspace.scam.selsins.s
newmodel69 = workspace.scam.prefabs.sdef:clone()
newmodel69.Body4.Color = Color3.fromRGB(52, 129, 176)
newmodel69:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel69:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel69.Parent = workspace.scam.selsins.s
newmodel70 = workspace.scam.prefabs.sdef:clone()
newmodel70.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel70:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel70:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel70.Parent = workspace.scam.selsins.s
newmodel71 = workspace.scam.prefabs.sdef:clone()
newmodel71.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel71:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel71:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel71.Parent = workspace.scam.selsins.s
newmodel72 = workspace.scam.prefabs.sdef:clone()
newmodel72.Body4.Color = Color3.fromRGB(52, 129, 176)
newmodel72:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel72:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel72.Parent = workspace.scam.selsins.s
newmodel73 = workspace.scam.prefabs.sdef:clone()
newmodel73.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel73:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel73:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel73.Parent = workspace.scam.selsins.s
newmodel74 = workspace.scam.prefabs.sdef:clone()
newmodel74.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel74:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel74:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel74.Parent = workspace.scam.selsins.s
newmodel75 = workspace.scam.prefabs.sdef:clone()
newmodel75.Body4.Color = Color3.fromRGB(52, 129, 176)
newmodel75:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel75:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel75.Parent = workspace.scam.selsins.s
newmodel76 = workspace.scam.prefabs.sdef:clone()
newmodel76.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel76:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel76:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-2.114, -2.7008, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel76.Parent = workspace.scam.selsins.s
newmodel77 = workspace.scam.prefabs.susp:clone()
newmodel77:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel77.Parent = workspace.scam.selsins.s
newmodel78 = workspace.scam.prefabs.sdef:clone()
newmodel78.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel78:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel78.Parent = workspace.scam.selsins.s
newmodel79 = workspace.scam.prefabs.susp:clone()
newmodel79:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel79.Parent = workspace.scam.selsins.s
newmodel80 = workspace.scam.prefabs.sdef:clone()
newmodel80.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel80:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel80:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel80.Parent = workspace.scam.selsins.s
newmodel81 = workspace.scam.prefabs.susp:clone()
newmodel81:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel81:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel81.Parent = workspace.scam.selsins.s
newmodel82 = workspace.scam.prefabs.sdef:clone()
newmodel82.Body4.Color = Color3.fromRGB(18, 97, 0)
newmodel82:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel82:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel82.Parent = workspace.scam.selsins.s
newmodel83 = workspace.scam.prefabs.susp:clone()
newmodel83:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel83:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel83.Parent = workspace.scam.selsins.s
newmodel84 = workspace.scam.prefabs.sdef:clone()
newmodel84.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel84:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel84:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel84.Parent = workspace.scam.selsins.s
newmodel85 = workspace.scam.prefabs.susp:clone()
newmodel85:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel85:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel85.Parent = workspace.scam.selsins.s
newmodel86 = workspace.scam.prefabs.sdef:clone()
newmodel86.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel86:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel86:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel86.Parent = workspace.scam.selsins.s
newmodel87 = workspace.scam.prefabs.susp:clone()
newmodel87:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel87:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -2.9834, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel87.Parent = workspace.scam.selsins.s
newmodel88 = workspace.scam.prefabs.sdef:clone()
newmodel88.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel88:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.19, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel88.Parent = workspace.scam.selsins.s
newmodel89 = workspace.scam.prefabs.sdef:clone()
newmodel89.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel89:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel89.Parent = workspace.scam.selsins.s
newmodel90 = workspace.scam.prefabs.sdef:clone()
newmodel90.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel90:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel90.Parent = workspace.scam.selsins.s
newmodel91 = workspace.scam.prefabs.sdef:clone()
newmodel91.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel91:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel91:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel91.Parent = workspace.scam.selsins.s
newmodel92 = workspace.scam.prefabs.sdef:clone()
newmodel92.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel92:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel92:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel92.Parent = workspace.scam.selsins.s
newmodel93 = workspace.scam.prefabs.sdef:clone()
newmodel93.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel93:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel93:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel93.Parent = workspace.scam.selsins.s
newmodel94 = workspace.scam.prefabs.sdef:clone()
newmodel94.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel94:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel94:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel94.Parent = workspace.scam.selsins.s
newmodel95 = workspace.scam.prefabs.sdef:clone()
newmodel95.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel95:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel95:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel95.Parent = workspace.scam.selsins.s
newmodel96 = workspace.scam.prefabs.sdef:clone()
newmodel96.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel96:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel96:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel96.Parent = workspace.scam.selsins.s
newmodel97 = workspace.scam.prefabs.sdef:clone()
newmodel97.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel97:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel97:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel97.Parent = workspace.scam.selsins.s
newmodel98 = workspace.scam.prefabs.sdef:clone()
newmodel98.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel98:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel98:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel98.Parent = workspace.scam.selsins.s
newmodel99 = workspace.scam.prefabs.sdef:clone()
newmodel99.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel99:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel99:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-2.114, -3.266, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel99.Parent = workspace.scam.selsins.s
newmodel100 = workspace.scam.prefabs.sdef:clone()
newmodel100.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel100:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel100.Parent = workspace.scam.selsins.s
newmodel101 = workspace.scam.prefabs.sdef:clone()
newmodel101.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel101:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel101.Parent = workspace.scam.selsins.s
newmodel102 = workspace.scam.prefabs.sdef:clone()
newmodel102.Body4.Color = Color3.fromRGB(18, 97, 0)
newmodel102:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel102.Parent = workspace.scam.selsins.s
newmodel103 = workspace.scam.prefabs.sdef:clone()
newmodel103.Body4.Color = Color3.fromRGB(18, 97, 0)
newmodel103:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel103:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel103.Parent = workspace.scam.selsins.s
newmodel104 = workspace.scam.prefabs.sdef:clone()
newmodel104.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel104:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel104:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel104.Parent = workspace.scam.selsins.s
newmodel105 = workspace.scam.prefabs.sdef:clone()
newmodel105.Body4.Color = Color3.fromRGB(18, 97, 0)
newmodel105:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel105:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel105.Parent = workspace.scam.selsins.s
newmodel106 = workspace.scam.prefabs.sdef:clone()
newmodel106.Body4.Color = Color3.fromRGB(18, 97, 0)
newmodel106:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel106:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel106.Parent = workspace.scam.selsins.s
newmodel107 = workspace.scam.prefabs.sdef:clone()
newmodel107.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel107:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel107:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel107.Parent = workspace.scam.selsins.s
newmodel108 = workspace.scam.prefabs.sdef:clone()
newmodel108.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel108:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel108:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -3.5486000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel108.Parent = workspace.scam.selsins.s
newmodel109 = workspace.scam.prefabs.sdef:clone()
newmodel109.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel109:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.19, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel109.Parent = workspace.scam.selsins.s
newmodel110 = workspace.scam.prefabs.sdef:clone()
newmodel110.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel110:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel110.Parent = workspace.scam.selsins.s
newmodel111 = workspace.scam.prefabs.sdef:clone()
newmodel111.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel111:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel111.Parent = workspace.scam.selsins.s
newmodel112 = workspace.scam.prefabs.sdef:clone()
newmodel112.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel112:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel112:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel112.Parent = workspace.scam.selsins.s
newmodel113 = workspace.scam.prefabs.sdef:clone()
newmodel113.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel113:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel113:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel113.Parent = workspace.scam.selsins.s
newmodel114 = workspace.scam.prefabs.sdef:clone()
newmodel114.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel114:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel114:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel114.Parent = workspace.scam.selsins.s
newmodel115 = workspace.scam.prefabs.sdef:clone()
newmodel115.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel115:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel115:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel115.Parent = workspace.scam.selsins.s
newmodel116 = workspace.scam.prefabs.sdef:clone()
newmodel116.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel116:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel116:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel116.Parent = workspace.scam.selsins.s
newmodel117 = workspace.scam.prefabs.sdef:clone()
newmodel117.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel117:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel117:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel117.Parent = workspace.scam.selsins.s
newmodel118 = workspace.scam.prefabs.sdef:clone()
newmodel118.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel118:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel118:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel118.Parent = workspace.scam.selsins.s
newmodel119 = workspace.scam.prefabs.sdef:clone()
newmodel119.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel119:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel119:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel119.Parent = workspace.scam.selsins.s
newmodel120 = workspace.scam.prefabs.sdef:clone()
newmodel120.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel120:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel120:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-2.114, -3.8312000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel120.Parent = workspace.scam.selsins.s
newmodel121 = workspace.scam.prefabs.susp:clone()
newmodel121:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel121.Parent = workspace.scam.selsins.s
newmodel122 = workspace.scam.prefabs.sdef:clone()
newmodel122.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel122:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel122.Parent = workspace.scam.selsins.s
newmodel123 = workspace.scam.prefabs.susp:clone()
newmodel123:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel123.Parent = workspace.scam.selsins.s
newmodel124 = workspace.scam.prefabs.sdef:clone()
newmodel124.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel124:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel124:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel124.Parent = workspace.scam.selsins.s
newmodel125 = workspace.scam.prefabs.susp:clone()
newmodel125:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel125:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel125.Parent = workspace.scam.selsins.s
newmodel126 = workspace.scam.prefabs.sdef:clone()
newmodel126.Body4.Color = Color3.fromRGB(18, 97, 0)
newmodel126:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel126:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel126.Parent = workspace.scam.selsins.s
newmodel127 = workspace.scam.prefabs.susp:clone()
newmodel127:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel127:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel127.Parent = workspace.scam.selsins.s
newmodel128 = workspace.scam.prefabs.sdef:clone()
newmodel128.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel128:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel128:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel128.Parent = workspace.scam.selsins.s
newmodel129 = workspace.scam.prefabs.susp:clone()
newmodel129:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel129:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel129.Parent = workspace.scam.selsins.s
newmodel130 = workspace.scam.prefabs.sdef:clone()
newmodel130.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel130:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel130:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel130.Parent = workspace.scam.selsins.s
newmodel131 = workspace.scam.prefabs.susp:clone()
newmodel131:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel131:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -4.1138, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel131.Parent = workspace.scam.selsins.s
newmodel132 = workspace.scam.prefabs.sdef:clone()
newmodel132.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel132:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.19, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel132.Parent = workspace.scam.selsins.s
newmodel133 = workspace.scam.prefabs.sdef:clone()
newmodel133.Body4.Color = Color3.fromRGB(52, 129, 176)
newmodel133:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel133.Parent = workspace.scam.selsins.s
newmodel134 = workspace.scam.prefabs.sdef:clone()
newmodel134.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel134:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel134.Parent = workspace.scam.selsins.s
newmodel135 = workspace.scam.prefabs.sdef:clone()
newmodel135.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel135:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel135:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel135.Parent = workspace.scam.selsins.s
newmodel136 = workspace.scam.prefabs.sdef:clone()
newmodel136.Body4.Color = Color3.fromRGB(52, 129, 176)
newmodel136:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel136:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel136.Parent = workspace.scam.selsins.s
newmodel137 = workspace.scam.prefabs.sdef:clone()
newmodel137.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel137:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel137:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel137.Parent = workspace.scam.selsins.s
newmodel138 = workspace.scam.prefabs.sdef:clone()
newmodel138.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel138:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel138:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel138.Parent = workspace.scam.selsins.s
newmodel139 = workspace.scam.prefabs.sdef:clone()
newmodel139.Body4.Color = Color3.fromRGB(52, 129, 176)
newmodel139:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel139:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel139.Parent = workspace.scam.selsins.s
newmodel140 = workspace.scam.prefabs.sdef:clone()
newmodel140.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel140:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel140:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel140.Parent = workspace.scam.selsins.s
newmodel141 = workspace.scam.prefabs.sdef:clone()
newmodel141.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel141:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel141:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel141.Parent = workspace.scam.selsins.s
newmodel142 = workspace.scam.prefabs.sdef:clone()
newmodel142.Body4.Color = Color3.fromRGB(52, 129, 176)
newmodel142:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel142:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel142.Parent = workspace.scam.selsins.s
newmodel143 = workspace.scam.prefabs.sdef:clone()
newmodel143.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel143:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel143:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-2.114, -4.396400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel143.Parent = workspace.scam.selsins.s
newmodel144 = workspace.scam.prefabs.sdef:clone()
newmodel144.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel144:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel144.Parent = workspace.scam.selsins.s
newmodel145 = workspace.scam.prefabs.sdef:clone()
newmodel145.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel145:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel145.Parent = workspace.scam.selsins.s
newmodel146 = workspace.scam.prefabs.sdef:clone()
newmodel146.Body4.Color = Color3.fromRGB(18, 97, 0)
newmodel146:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel146:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel146.Parent = workspace.scam.selsins.s
newmodel147 = workspace.scam.prefabs.sdef:clone()
newmodel147.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel147:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel147:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel147.Parent = workspace.scam.selsins.s
newmodel148 = workspace.scam.prefabs.sdef:clone()
newmodel148.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel148:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel148:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel148.Parent = workspace.scam.selsins.s
newmodel149 = workspace.scam.prefabs.sdef:clone()
newmodel149.Body4.Color = Color3.fromRGB(18, 97, 0)
newmodel149:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel149:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel149.Parent = workspace.scam.selsins.s
newmodel150 = workspace.scam.prefabs.sdef:clone()
newmodel150.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel150:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel150:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel150.Parent = workspace.scam.selsins.s
newmodel151 = workspace.scam.prefabs.sdef:clone()
newmodel151.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel151:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel151:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -4.679, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel151.Parent = workspace.scam.selsins.s
newmodel152 = workspace.scam.prefabs.sdef:clone()
newmodel152.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel152:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel152.Parent = workspace.scam.selsins.s
newmodel153 = workspace.scam.prefabs.sdef:clone()
newmodel153.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel153:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel153.Parent = workspace.scam.selsins.s
newmodel154 = workspace.scam.prefabs.sdef:clone()
newmodel154.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel154:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel154:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel154.Parent = workspace.scam.selsins.s
newmodel155 = workspace.scam.prefabs.sdef:clone()
newmodel155.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel155:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel155:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel155.Parent = workspace.scam.selsins.s
newmodel156 = workspace.scam.prefabs.sdef:clone()
newmodel156.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel156:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel156:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel156.Parent = workspace.scam.selsins.s
newmodel157 = workspace.scam.prefabs.sdef:clone()
newmodel157.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel157:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel157:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel157.Parent = workspace.scam.selsins.s
newmodel158 = workspace.scam.prefabs.sdef:clone()
newmodel158.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel158:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel158:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel158.Parent = workspace.scam.selsins.s
newmodel159 = workspace.scam.prefabs.sdef:clone()
newmodel159.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel159:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel159:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel159.Parent = workspace.scam.selsins.s
newmodel160 = workspace.scam.prefabs.sdef:clone()
newmodel160.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel160:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel160:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel160.Parent = workspace.scam.selsins.s
newmodel161 = workspace.scam.prefabs.sdef:clone()
newmodel161.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel161:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel161:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel161.Parent = workspace.scam.selsins.s
newmodel162 = workspace.scam.prefabs.sdef:clone()
newmodel162.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel162:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel162:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-2.114, -4.961600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel162.Parent = workspace.scam.selsins.s
newmodel163 = workspace.scam.prefabs.sdef:clone()
newmodel163.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel163:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel163.Parent = workspace.scam.selsins.s
newmodel164 = workspace.scam.prefabs.sdef:clone()
newmodel164.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel164:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel164.Parent = workspace.scam.selsins.s
newmodel165 = workspace.scam.prefabs.susp:clone()
newmodel165:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel165.Parent = workspace.scam.selsins.s
newmodel166 = workspace.scam.prefabs.sdef:clone()
newmodel166.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel166:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel166:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel166.Parent = workspace.scam.selsins.s
newmodel167 = workspace.scam.prefabs.susp:clone()
newmodel167:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel167:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel167.Parent = workspace.scam.selsins.s
newmodel168 = workspace.scam.prefabs.sdef:clone()
newmodel168.Body4.Color = Color3.fromRGB(18, 97, 0)
newmodel168:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel168:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel168.Parent = workspace.scam.selsins.s
newmodel169 = workspace.scam.prefabs.susp:clone()
newmodel169:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel169:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel169.Parent = workspace.scam.selsins.s
newmodel170 = workspace.scam.prefabs.sdef:clone()
newmodel170.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel170:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel170:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel170.Parent = workspace.scam.selsins.s
newmodel171 = workspace.scam.prefabs.susp:clone()
newmodel171:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel171:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel171.Parent = workspace.scam.selsins.s
newmodel172 = workspace.scam.prefabs.sdef:clone()
newmodel172.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel172:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel172:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel172.Parent = workspace.scam.selsins.s
newmodel173 = workspace.scam.prefabs.sdef:clone()
newmodel173.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel173:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel173:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -5.244200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel173.Parent = workspace.scam.selsins.s
newmodel174 = workspace.scam.prefabs.sdef:clone()
newmodel174.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel174:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel174.Parent = workspace.scam.selsins.s
newmodel175 = workspace.scam.prefabs.sdef:clone()
newmodel175.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel175:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel175.Parent = workspace.scam.selsins.s
newmodel176 = workspace.scam.prefabs.sdef:clone()
newmodel176.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel176:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel176:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel176.Parent = workspace.scam.selsins.s
newmodel177 = workspace.scam.prefabs.sdef:clone()
newmodel177.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel177:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel177:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel177.Parent = workspace.scam.selsins.s
newmodel178 = workspace.scam.prefabs.sdef:clone()
newmodel178.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel178:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel178:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel178.Parent = workspace.scam.selsins.s
newmodel179 = workspace.scam.prefabs.sdef:clone()
newmodel179.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel179:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel179:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel179.Parent = workspace.scam.selsins.s
newmodel180 = workspace.scam.prefabs.sdef:clone()
newmodel180.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel180:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel180:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel180.Parent = workspace.scam.selsins.s
newmodel181 = workspace.scam.prefabs.sdef:clone()
newmodel181.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel181:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel181:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel181.Parent = workspace.scam.selsins.s
newmodel182 = workspace.scam.prefabs.sdef:clone()
newmodel182.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel182:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel182:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel182.Parent = workspace.scam.selsins.s
newmodel183 = workspace.scam.prefabs.sdef:clone()
newmodel183.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel183:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel183:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -5.526800000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel183.Parent = workspace.scam.selsins.s
newmodel184 = workspace.scam.prefabs.sdef:clone()
newmodel184.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel184:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -5.809400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel184.Parent = workspace.scam.selsins.s
newmodel185 = workspace.scam.prefabs.sdef:clone()
newmodel185.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel185:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -5.809400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel185.Parent = workspace.scam.selsins.s
newmodel186 = workspace.scam.prefabs.sdef:clone()
newmodel186.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel186:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -5.809400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel186:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -5.809400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel186.Parent = workspace.scam.selsins.s
newmodel187 = workspace.scam.prefabs.sdef:clone()
newmodel187.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel187:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -5.809400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel187:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -5.809400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel187.Parent = workspace.scam.selsins.s
newmodel188 = workspace.scam.prefabs.sdef:clone()
newmodel188.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel188:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -5.809400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel188:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -5.809400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel188.Parent = workspace.scam.selsins.s
newmodel189 = workspace.scam.prefabs.sdef:clone()
newmodel189.Body4.Color = Color3.fromRGB(184, 72, 27)
newmodel189:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -5.809400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel189:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -5.809400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel189.Parent = workspace.scam.selsins.s
newmodel190 = workspace.scam.prefabs.sdef:clone()
newmodel190.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel190:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -5.809400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel190:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -5.809400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel190.Parent = workspace.scam.selsins.s
newmodel191 = workspace.scam.prefabs.sdef:clone()
newmodel191.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel191:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel191.Parent = workspace.scam.selsins.s
newmodel192 = workspace.scam.prefabs.sdef:clone()
newmodel192.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel192:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel192:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel192.Parent = workspace.scam.selsins.s
newmodel193 = workspace.scam.prefabs.sdef:clone()
newmodel193.Body4.Color = Color3.fromRGB(52, 129, 176)
newmodel193:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel193:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel193.Parent = workspace.scam.selsins.s
newmodel194 = workspace.scam.prefabs.sdef:clone()
newmodel194.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel194:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel194:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel194.Parent = workspace.scam.selsins.s
newmodel195 = workspace.scam.prefabs.sdef:clone()
newmodel195.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel195:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel195:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel195.Parent = workspace.scam.selsins.s
newmodel196 = workspace.scam.prefabs.sdef:clone()
newmodel196.Body4.Color = Color3.fromRGB(52, 129, 176)
newmodel196:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel196:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel196.Parent = workspace.scam.selsins.s
newmodel197 = workspace.scam.prefabs.sdef:clone()
newmodel197.Body4.Color = Color3.fromRGB(255, 255, 255)
newmodel197:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel197:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel197.Parent = workspace.scam.selsins.s
newmodel198 = workspace.scam.prefabs.sdef:clone()
newmodel198.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel198:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel198:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -6.0920000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel198.Parent = workspace.scam.selsins.s
newmodel199 = workspace.scam.prefabs.sdef:clone()
newmodel199.Body4.Color = Color3.fromRGB(18, 97, 0)
newmodel199:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -6.374600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel199.Parent = workspace.scam.selsins.s
newmodel200 = workspace.scam.prefabs.sdef:clone()
newmodel200.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel200:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -6.374600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel200:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -6.374600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel200.Parent = workspace.scam.selsins.s
newmodel201 = workspace.scam.prefabs.susp:clone()
newmodel201:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -6.374600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel201:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -6.374600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel201.Parent = workspace.scam.selsins.s
newmodel202 = workspace.scam.prefabs.sdef:clone()
newmodel202.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel202:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -6.374600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel202:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -6.374600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel202.Parent = workspace.scam.selsins.s
newmodel203 = workspace.scam.prefabs.susp:clone()
newmodel203:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -6.374600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel203:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -6.374600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel203.Parent = workspace.scam.selsins.s
newmodel204 = workspace.scam.prefabs.sdef:clone()
newmodel204.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel204:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -6.374600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel204:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -6.374600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel204.Parent = workspace.scam.selsins.s
newmodel205 = workspace.scam.prefabs.sdef:clone()
newmodel205.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel205:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -6.374600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel205:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -6.374600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel205.Parent = workspace.scam.selsins.s
newmodel206 = workspace.scam.prefabs.sdef:clone()
newmodel206.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel206:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -6.6572000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel206:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -6.6572000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel206.Parent = workspace.scam.selsins.s
newmodel207 = workspace.scam.prefabs.sdef:clone()
newmodel207.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel207:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -6.6572000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel207:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -6.6572000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel207.Parent = workspace.scam.selsins.s
newmodel208 = workspace.scam.prefabs.sdef:clone()
newmodel208.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel208:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -6.6572000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel208:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -6.6572000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel208.Parent = workspace.scam.selsins.s
newmodel209 = workspace.scam.prefabs.sdef:clone()
newmodel209.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel209:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -6.6572000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel209:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -6.6572000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel209.Parent = workspace.scam.selsins.s
newmodel210 = workspace.scam.prefabs.sdef:clone()
newmodel210.Body4.Color = Color3.fromRGB(82, 78, 97)
newmodel210:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -6.6572000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel210:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -6.6572000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel210.Parent = workspace.scam.selsins.s
