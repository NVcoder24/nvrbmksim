newmodel0 = workspace.prefabs.cd_part1_fix:clone()
newmodel0:PivotTo(CFrame.new(-18.02961530901618, 2.640836311572522, 22.33132969438475) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.cd
newmodel1 = workspace.prefabs.cd_part2_fix:clone()
newmodel1:PivotTo(CFrame.new(-18.604772676325766, 2.640836311572522, 23.00363487838195) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.devices.cd
newmodel2 = workspace.prefabs.cd_part1_fix:clone()
newmodel2:PivotTo(CFrame.new(-34.92710576232738, 2.6892412166026873, 33.54920043309906) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.cd
newmodel3 = workspace.prefabs.cd_part2_fix:clone()
newmodel3:PivotTo(CFrame.new(-35.78852945624833, 2.6892412166026873, 33.73785621793373) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.cd
newmodel4 = workspace.prefabs.cd_part1_fix:clone()
newmodel4:PivotTo(CFrame.new(-55.52874759823713, 2.6884268333424535, 30.607344072260194) * CFrame.fromEulerAngles(0, math.rad(-30.046980000000005), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.cd
newmodel5 = workspace.prefabs.cd_part2_fix:clone()
newmodel5:PivotTo(CFrame.new(-56.31483001450876, 2.6884268333424535, 30.15263936673302) * CFrame.fromEulerAngles(0, math.rad(-30.046980000000005), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.cd
