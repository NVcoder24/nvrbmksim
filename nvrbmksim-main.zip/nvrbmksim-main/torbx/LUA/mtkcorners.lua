newmodel4088 = workspace.prefabs.mtkc_t:clone()
newmodel4088:PivotTo(CFrame.new(-22.88126207196735, 9.1748, 34.938719830344425) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4088.Parent = workspace.devices.mtkcorners
newmodel4089 = workspace.prefabs.mtkc_l:clone()
newmodel4089:PivotTo(CFrame.new(-22.88126207196735, 9.1748, 34.938719830344425) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4089.Parent = workspace.devices.mtkcorners
newmodel4090 = workspace.prefabs.mtkc_t:clone()
newmodel4090:PivotTo(CFrame.new(-22.982250361375122, 9.1748, 34.99740207129083) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4090.Parent = workspace.devices.mtkcorners
newmodel4091 = workspace.prefabs.mtkc_t:clone()
newmodel4091:PivotTo(CFrame.new(-23.0832386507829, 9.1748, 35.05608431223723) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4091.Parent = workspace.devices.mtkcorners
newmodel4092 = workspace.prefabs.mtkc_t:clone()
newmodel4092:PivotTo(CFrame.new(-23.184226940190676, 9.1748, 35.11476655318363) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4092.Parent = workspace.devices.mtkcorners
newmodel4093 = workspace.prefabs.mtkc_t:clone()
newmodel4093:PivotTo(CFrame.new(-23.28521522959845, 9.1748, 35.173448794130024) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4093.Parent = workspace.devices.mtkcorners
newmodel4094 = workspace.prefabs.mtkc_t:clone()
newmodel4094:PivotTo(CFrame.new(-23.38620351900623, 9.1748, 35.23213103507643) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4094.Parent = workspace.devices.mtkcorners
newmodel4095 = workspace.prefabs.mtkc_t:clone()
newmodel4095:PivotTo(CFrame.new(-23.487191808414003, 9.1748, 35.290813276022824) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4095.Parent = workspace.devices.mtkcorners
newmodel4096 = workspace.prefabs.mtkc_t:clone()
newmodel4096:PivotTo(CFrame.new(-23.588179660791752, 9.1748, 35.3494959939332) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4096.Parent = workspace.devices.mtkcorners
newmodel4097 = workspace.prefabs.mtkc_t:clone()
newmodel4097:PivotTo(CFrame.new(-23.691631515124495, 9.1748, 35.403717335074106) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4097.Parent = workspace.devices.mtkcorners
newmodel4098 = workspace.prefabs.mtkc_t:clone()
newmodel4098:PivotTo(CFrame.new(-23.795083369457235, 9.1748, 35.457938676215) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4098.Parent = workspace.devices.mtkcorners
newmodel4099 = workspace.prefabs.mtkc_t:clone()
newmodel4099:PivotTo(CFrame.new(-23.898535223789978, 9.1748, 35.512160017355896) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4099.Parent = workspace.devices.mtkcorners
newmodel4100 = workspace.prefabs.mtkc_t:clone()
newmodel4100:PivotTo(CFrame.new(-24.001987078122717, 9.1748, 35.5663813584968) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4100.Parent = workspace.devices.mtkcorners
newmodel4101 = workspace.prefabs.mtkc_t:clone()
newmodel4101:PivotTo(CFrame.new(-24.105438932455453, 9.1748, 35.62060269963769) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4101.Parent = workspace.devices.mtkcorners
newmodel4102 = workspace.prefabs.mtkc_t:clone()
newmodel4102:PivotTo(CFrame.new(-24.208890786788196, 9.1748, 35.67482404077859) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4102.Parent = workspace.devices.mtkcorners
newmodel4103 = workspace.prefabs.mtkc_t:clone()
newmodel4103:PivotTo(CFrame.new(-24.31234264112093, 9.1748, 35.72904538191949) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4103.Parent = workspace.devices.mtkcorners
newmodel4104 = workspace.prefabs.mtkc_r:clone()
newmodel4104:PivotTo(CFrame.new(-24.31234264112093, 9.1748, 35.72904538191949) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4104.Parent = workspace.devices.mtkcorners
newmodel4105 = workspace.prefabs.mtkc_t:clone()
newmodel4105:PivotTo(CFrame.new(-22.578297203744018, 9.058, 34.76267310750523) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4105.Parent = workspace.devices.mtkcorners
newmodel4106 = workspace.prefabs.mtkc_l:clone()
newmodel4106:PivotTo(CFrame.new(-22.578297203744018, 9.058, 34.76267310750523) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4106.Parent = workspace.devices.mtkcorners
newmodel4107 = workspace.prefabs.mtkc_t:clone()
newmodel4107:PivotTo(CFrame.new(-22.679285493151795, 9.058, 34.82135534845163) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4107.Parent = workspace.devices.mtkcorners
newmodel4108 = workspace.prefabs.mtkc_t:clone()
newmodel4108:PivotTo(CFrame.new(-22.780273782559572, 9.058, 34.88003758939803) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4108.Parent = workspace.devices.mtkcorners
newmodel4109 = workspace.prefabs.mtkc_t:clone()
newmodel4109:PivotTo(CFrame.new(-24.41579449545367, 9.058, 35.783266723060386) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4109.Parent = workspace.devices.mtkcorners
newmodel4110 = workspace.prefabs.mtkc_t:clone()
newmodel4110:PivotTo(CFrame.new(-24.519246349786414, 9.058, 35.83748806420128) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4110.Parent = workspace.devices.mtkcorners
newmodel4111 = workspace.prefabs.mtkc_r:clone()
newmodel4111:PivotTo(CFrame.new(-24.519246349786414, 9.058, 35.83748806420128) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4111.Parent = workspace.devices.mtkcorners
newmodel4112 = workspace.prefabs.mtkc_t:clone()
newmodel4112:PivotTo(CFrame.new(-22.376320624928468, 8.941199999999998, 34.64530862561243) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4112.Parent = workspace.devices.mtkcorners
newmodel4113 = workspace.prefabs.mtkc_l:clone()
newmodel4113:PivotTo(CFrame.new(-22.376320624928468, 8.941199999999998, 34.64530862561243) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4113.Parent = workspace.devices.mtkcorners
newmodel4114 = workspace.prefabs.mtkc_t:clone()
newmodel4114:PivotTo(CFrame.new(-22.47730891433624, 8.941199999999998, 34.703990866558826) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4114.Parent = workspace.devices.mtkcorners
newmodel4115 = workspace.prefabs.mtkc_t:clone()
newmodel4115:PivotTo(CFrame.new(-24.622698204119153, 8.941199999999998, 35.89170940534218) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4115.Parent = workspace.devices.mtkcorners
newmodel4116 = workspace.prefabs.mtkc_t:clone()
newmodel4116:PivotTo(CFrame.new(-24.726150058451893, 8.941199999999998, 35.94593074648308) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4116.Parent = workspace.devices.mtkcorners
newmodel4117 = workspace.prefabs.mtkc_r:clone()
newmodel4117:PivotTo(CFrame.new(-24.726150058451893, 8.941199999999998, 35.94593074648308) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4117.Parent = workspace.devices.mtkcorners
newmodel4118 = workspace.prefabs.mtkc_t:clone()
newmodel4118:PivotTo(CFrame.new(-22.174344046112914, 8.824399999999999, 34.52794414371963) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4118.Parent = workspace.devices.mtkcorners
newmodel4119 = workspace.prefabs.mtkc_l:clone()
newmodel4119:PivotTo(CFrame.new(-22.174344046112914, 8.824399999999999, 34.52794414371963) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4119.Parent = workspace.devices.mtkcorners
newmodel4120 = workspace.prefabs.mtkc_t:clone()
newmodel4120:PivotTo(CFrame.new(-22.27533233552069, 8.824399999999999, 34.58662638466603) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4120.Parent = workspace.devices.mtkcorners
newmodel4121 = workspace.prefabs.mtkc_t:clone()
newmodel4121:PivotTo(CFrame.new(-24.829601912784632, 8.824399999999999, 36.00015208762398) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4121.Parent = workspace.devices.mtkcorners
newmodel4122 = workspace.prefabs.mtkc_t:clone()
newmodel4122:PivotTo(CFrame.new(-24.93305376711737, 8.824399999999999, 36.054373428764876) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4122.Parent = workspace.devices.mtkcorners
newmodel4123 = workspace.prefabs.mtkc_r:clone()
newmodel4123:PivotTo(CFrame.new(-24.93305376711737, 8.824399999999999, 36.054373428764876) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4123.Parent = workspace.devices.mtkcorners
newmodel4124 = workspace.prefabs.mtkc_t:clone()
newmodel4124:PivotTo(CFrame.new(-22.07335575670514, 8.7076, 34.46926190277323) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4124.Parent = workspace.devices.mtkcorners
newmodel4125 = workspace.prefabs.mtkc_l:clone()
newmodel4125:PivotTo(CFrame.new(-22.07335575670514, 8.7076, 34.46926190277323) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4125.Parent = workspace.devices.mtkcorners
newmodel4126 = workspace.prefabs.mtkc_t:clone()
newmodel4126:PivotTo(CFrame.new(-25.03650562145011, 8.7076, 36.10859476990578) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4126.Parent = workspace.devices.mtkcorners
newmodel4127 = workspace.prefabs.mtkc_r:clone()
newmodel4127:PivotTo(CFrame.new(-25.03650562145011, 8.7076, 36.10859476990578) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4127.Parent = workspace.devices.mtkcorners
newmodel4128 = workspace.prefabs.mtkc_t:clone()
newmodel4128:PivotTo(CFrame.new(-21.97236746729736, 8.5908, 34.41057966182683) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4128.Parent = workspace.devices.mtkcorners
newmodel4129 = workspace.prefabs.mtkc_l:clone()
newmodel4129:PivotTo(CFrame.new(-21.97236746729736, 8.5908, 34.41057966182683) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4129.Parent = workspace.devices.mtkcorners
newmodel4130 = workspace.prefabs.mtkc_t:clone()
newmodel4130:PivotTo(CFrame.new(-25.13995747578285, 8.5908, 36.16281611104667) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4130.Parent = workspace.devices.mtkcorners
newmodel4131 = workspace.prefabs.mtkc_r:clone()
newmodel4131:PivotTo(CFrame.new(-25.13995747578285, 8.5908, 36.16281611104667) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4131.Parent = workspace.devices.mtkcorners
newmodel4132 = workspace.prefabs.mtkc_t:clone()
newmodel4132:PivotTo(CFrame.new(-21.871379177889587, 8.474, 34.351897420880434) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4132.Parent = workspace.devices.mtkcorners
newmodel4133 = workspace.prefabs.mtkc_l:clone()
newmodel4133:PivotTo(CFrame.new(-21.871379177889587, 8.474, 34.351897420880434) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4133.Parent = workspace.devices.mtkcorners
newmodel4134 = workspace.prefabs.mtkc_t:clone()
newmodel4134:PivotTo(CFrame.new(-25.24340933011559, 8.474, 36.21703745218757) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4134.Parent = workspace.devices.mtkcorners
newmodel4135 = workspace.prefabs.mtkc_r:clone()
newmodel4135:PivotTo(CFrame.new(-25.24340933011559, 8.474, 36.21703745218757) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4135.Parent = workspace.devices.mtkcorners
newmodel4136 = workspace.prefabs.mtkc_t:clone()
newmodel4136:PivotTo(CFrame.new(-21.77039088848181, 8.357199999999999, 34.29321517993404) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4136.Parent = workspace.devices.mtkcorners
newmodel4137 = workspace.prefabs.mtkc_l:clone()
newmodel4137:PivotTo(CFrame.new(-21.77039088848181, 8.357199999999999, 34.29321517993404) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4137.Parent = workspace.devices.mtkcorners
newmodel4138 = workspace.prefabs.mtkc_t:clone()
newmodel4138:PivotTo(CFrame.new(-25.34686118444833, 8.357199999999999, 36.27125879332847) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4138.Parent = workspace.devices.mtkcorners
newmodel4139 = workspace.prefabs.mtkc_r:clone()
newmodel4139:PivotTo(CFrame.new(-25.34686118444833, 8.357199999999999, 36.27125879332847) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4139.Parent = workspace.devices.mtkcorners
newmodel4140 = workspace.prefabs.mtkc_t:clone()
newmodel4140:PivotTo(CFrame.new(-21.669402599074033, 8.2404, 34.23453293898764) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4140.Parent = workspace.devices.mtkcorners
newmodel4141 = workspace.prefabs.mtkc_l:clone()
newmodel4141:PivotTo(CFrame.new(-21.669402599074033, 8.2404, 34.23453293898764) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4141.Parent = workspace.devices.mtkcorners
newmodel4142 = workspace.prefabs.mtkc_t:clone()
newmodel4142:PivotTo(CFrame.new(-25.45031303878107, 8.2404, 36.32548013446936) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4142.Parent = workspace.devices.mtkcorners
newmodel4143 = workspace.prefabs.mtkc_r:clone()
newmodel4143:PivotTo(CFrame.new(-25.45031303878107, 8.2404, 36.32548013446936) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4143.Parent = workspace.devices.mtkcorners
newmodel4144 = workspace.prefabs.mtkc_t:clone()
newmodel4144:PivotTo(CFrame.new(-21.56841430966626, 8.1236, 34.17585069804124) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4144.Parent = workspace.devices.mtkcorners
newmodel4145 = workspace.prefabs.mtkc_l:clone()
newmodel4145:PivotTo(CFrame.new(-21.56841430966626, 8.1236, 34.17585069804124) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4145.Parent = workspace.devices.mtkcorners
newmodel4146 = workspace.prefabs.mtkc_t:clone()
newmodel4146:PivotTo(CFrame.new(-25.553764893113808, 8.1236, 36.37970147561026) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4146.Parent = workspace.devices.mtkcorners
newmodel4147 = workspace.prefabs.mtkc_r:clone()
newmodel4147:PivotTo(CFrame.new(-25.553764893113808, 8.1236, 36.37970147561026) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4147.Parent = workspace.devices.mtkcorners
newmodel4148 = workspace.prefabs.mtkc_t:clone()
newmodel4148:PivotTo(CFrame.new(-21.46742602025848, 8.0068, 34.117168457094834) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4148.Parent = workspace.devices.mtkcorners
newmodel4149 = workspace.prefabs.mtkc_l:clone()
newmodel4149:PivotTo(CFrame.new(-21.46742602025848, 8.0068, 34.117168457094834) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4149.Parent = workspace.devices.mtkcorners
newmodel4150 = workspace.prefabs.mtkc_t:clone()
newmodel4150:PivotTo(CFrame.new(-25.657216747446547, 8.0068, 36.43392281675116) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4150.Parent = workspace.devices.mtkcorners
newmodel4151 = workspace.prefabs.mtkc_r:clone()
newmodel4151:PivotTo(CFrame.new(-25.657216747446547, 8.0068, 36.43392281675116) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4151.Parent = workspace.devices.mtkcorners
newmodel4152 = workspace.prefabs.mtkc_l:clone()
newmodel4152:PivotTo(CFrame.new(-21.46742602025848, 7.89, 34.117168457094834) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4152.Parent = workspace.devices.mtkcorners
newmodel4153 = workspace.prefabs.mtkc_r:clone()
newmodel4153:PivotTo(CFrame.new(-25.657216747446547, 7.89, 36.43392281675116) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4153.Parent = workspace.devices.mtkcorners
newmodel4154 = workspace.prefabs.mtkc_t:clone()
newmodel4154:PivotTo(CFrame.new(-21.366437730850706, 7.773199999999999, 34.05848621614844) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4154.Parent = workspace.devices.mtkcorners
newmodel4155 = workspace.prefabs.mtkc_l:clone()
newmodel4155:PivotTo(CFrame.new(-21.366437730850706, 7.773199999999999, 34.05848621614844) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4155.Parent = workspace.devices.mtkcorners
newmodel4156 = workspace.prefabs.mtkc_t:clone()
newmodel4156:PivotTo(CFrame.new(-25.760668601779287, 7.773199999999999, 36.48814415789205) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4156.Parent = workspace.devices.mtkcorners
newmodel4157 = workspace.prefabs.mtkc_r:clone()
newmodel4157:PivotTo(CFrame.new(-25.760668601779287, 7.773199999999999, 36.48814415789205) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4157.Parent = workspace.devices.mtkcorners
newmodel4158 = workspace.prefabs.mtkc_l:clone()
newmodel4158:PivotTo(CFrame.new(-21.366437730850706, 7.656399999999999, 34.05848621614844) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4158.Parent = workspace.devices.mtkcorners
newmodel4159 = workspace.prefabs.mtkc_r:clone()
newmodel4159:PivotTo(CFrame.new(-25.760668601779287, 7.656399999999999, 36.48814415789205) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4159.Parent = workspace.devices.mtkcorners
newmodel4160 = workspace.prefabs.mtkc_t:clone()
newmodel4160:PivotTo(CFrame.new(-21.26544944144293, 7.5396, 33.99980397520204) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4160.Parent = workspace.devices.mtkcorners
newmodel4161 = workspace.prefabs.mtkc_l:clone()
newmodel4161:PivotTo(CFrame.new(-21.26544944144293, 7.5396, 33.99980397520204) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4161.Parent = workspace.devices.mtkcorners
newmodel4162 = workspace.prefabs.mtkc_t:clone()
newmodel4162:PivotTo(CFrame.new(-25.864120456112026, 7.5396, 36.542365499032954) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4162.Parent = workspace.devices.mtkcorners
newmodel4163 = workspace.prefabs.mtkc_r:clone()
newmodel4163:PivotTo(CFrame.new(-25.864120456112026, 7.5396, 36.542365499032954) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4163.Parent = workspace.devices.mtkcorners
newmodel4164 = workspace.prefabs.mtkc_t:clone()
newmodel4164:PivotTo(CFrame.new(-21.164461152035155, 7.4228000000000005, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4164.Parent = workspace.devices.mtkcorners
newmodel4165 = workspace.prefabs.mtkc_l:clone()
newmodel4165:PivotTo(CFrame.new(-21.164461152035155, 7.4228000000000005, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4165.Parent = workspace.devices.mtkcorners
newmodel4166 = workspace.prefabs.mtkc_r:clone()
newmodel4166:PivotTo(CFrame.new(-25.864120456112026, 7.4228000000000005, 36.542365499032954) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4166.Parent = workspace.devices.mtkcorners
newmodel4167 = workspace.prefabs.mtkc_l:clone()
newmodel4167:PivotTo(CFrame.new(-21.164461152035155, 7.306, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4167.Parent = workspace.devices.mtkcorners
newmodel4168 = workspace.prefabs.mtkc_r:clone()
newmodel4168:PivotTo(CFrame.new(-25.864120456112026, 7.306, 36.542365499032954) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4168.Parent = workspace.devices.mtkcorners
newmodel4169 = workspace.prefabs.mtkc_l:clone()
newmodel4169:PivotTo(CFrame.new(-21.164461152035155, 7.1892, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4169.Parent = workspace.devices.mtkcorners
newmodel4170 = workspace.prefabs.mtkc_t:clone()
newmodel4170:PivotTo(CFrame.new(-25.967572310444766, 7.1892, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4170.Parent = workspace.devices.mtkcorners
newmodel4171 = workspace.prefabs.mtkc_r:clone()
newmodel4171:PivotTo(CFrame.new(-25.967572310444766, 7.1892, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4171.Parent = workspace.devices.mtkcorners
newmodel4172 = workspace.prefabs.mtkc_l:clone()
newmodel4172:PivotTo(CFrame.new(-21.164461152035155, 7.0724, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4172.Parent = workspace.devices.mtkcorners
newmodel4173 = workspace.prefabs.mtkc_r:clone()
newmodel4173:PivotTo(CFrame.new(-25.967572310444766, 7.0724, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4173.Parent = workspace.devices.mtkcorners
newmodel4174 = workspace.prefabs.mtkc_l:clone()
newmodel4174:PivotTo(CFrame.new(-21.164461152035155, 6.9556, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4174.Parent = workspace.devices.mtkcorners
newmodel4175 = workspace.prefabs.mtkc_r:clone()
newmodel4175:PivotTo(CFrame.new(-25.967572310444766, 6.9556, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4175.Parent = workspace.devices.mtkcorners
newmodel4176 = workspace.prefabs.mtkc_l:clone()
newmodel4176:PivotTo(CFrame.new(-21.164461152035155, 6.8388, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4176.Parent = workspace.devices.mtkcorners
newmodel4177 = workspace.prefabs.mtkc_r:clone()
newmodel4177:PivotTo(CFrame.new(-25.967572310444766, 6.8388, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4177.Parent = workspace.devices.mtkcorners
newmodel4178 = workspace.prefabs.mtkc_l:clone()
newmodel4178:PivotTo(CFrame.new(-21.164461152035155, 6.7219999999999995, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4178.Parent = workspace.devices.mtkcorners
newmodel4179 = workspace.prefabs.mtkc_r:clone()
newmodel4179:PivotTo(CFrame.new(-25.967572310444766, 6.7219999999999995, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4179.Parent = workspace.devices.mtkcorners
newmodel4180 = workspace.prefabs.mtkc_l:clone()
newmodel4180:PivotTo(CFrame.new(-21.164461152035155, 6.605199999999999, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4180.Parent = workspace.devices.mtkcorners
newmodel4181 = workspace.prefabs.mtkc_r:clone()
newmodel4181:PivotTo(CFrame.new(-25.967572310444766, 6.605199999999999, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4181.Parent = workspace.devices.mtkcorners
newmodel4182 = workspace.prefabs.mtkc_l:clone()
newmodel4182:PivotTo(CFrame.new(-21.164461152035155, 6.4883999999999995, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4182.Parent = workspace.devices.mtkcorners
newmodel4183 = workspace.prefabs.mtkc_r:clone()
newmodel4183:PivotTo(CFrame.new(-25.967572310444766, 6.4883999999999995, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4183.Parent = workspace.devices.mtkcorners
newmodel4184 = workspace.prefabs.mtkc_l:clone()
newmodel4184:PivotTo(CFrame.new(-21.164461152035155, 6.371599999999999, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4184.Parent = workspace.devices.mtkcorners
newmodel4185 = workspace.prefabs.mtkc_r:clone()
newmodel4185:PivotTo(CFrame.new(-25.967572310444766, 6.371599999999999, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4185.Parent = workspace.devices.mtkcorners
newmodel4186 = workspace.prefabs.mtkc_l:clone()
newmodel4186:PivotTo(CFrame.new(-21.164461152035155, 6.2547999999999995, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4186.Parent = workspace.devices.mtkcorners
newmodel4187 = workspace.prefabs.mtkc_r:clone()
newmodel4187:PivotTo(CFrame.new(-25.967572310444766, 6.2547999999999995, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4187.Parent = workspace.devices.mtkcorners
newmodel4188 = workspace.prefabs.mtkc_l:clone()
newmodel4188:PivotTo(CFrame.new(-21.164461152035155, 6.137999999999999, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4188.Parent = workspace.devices.mtkcorners
newmodel4189 = workspace.prefabs.mtkc_r:clone()
newmodel4189:PivotTo(CFrame.new(-25.967572310444766, 6.137999999999999, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4189.Parent = workspace.devices.mtkcorners
newmodel4190 = workspace.prefabs.mtkc_l:clone()
newmodel4190:PivotTo(CFrame.new(-21.164461152035155, 6.0211999999999986, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4190.Parent = workspace.devices.mtkcorners
newmodel4191 = workspace.prefabs.mtkc_r:clone()
newmodel4191:PivotTo(CFrame.new(-25.967572310444766, 6.0211999999999986, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4191.Parent = workspace.devices.mtkcorners
newmodel4192 = workspace.prefabs.mtkc_l:clone()
newmodel4192:PivotTo(CFrame.new(-21.164461152035155, 5.904399999999999, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4192.Parent = workspace.devices.mtkcorners
newmodel4193 = workspace.prefabs.mtkc_r:clone()
newmodel4193:PivotTo(CFrame.new(-25.967572310444766, 5.904399999999999, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4193.Parent = workspace.devices.mtkcorners
newmodel4194 = workspace.prefabs.mtkc_l:clone()
newmodel4194:PivotTo(CFrame.new(-21.164461152035155, 5.787599999999999, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4194.Parent = workspace.devices.mtkcorners
newmodel4195 = workspace.prefabs.mtkc_r:clone()
newmodel4195:PivotTo(CFrame.new(-25.967572310444766, 5.787599999999999, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4195.Parent = workspace.devices.mtkcorners
newmodel4196 = workspace.prefabs.mtkc_l:clone()
newmodel4196:PivotTo(CFrame.new(-21.164461152035155, 5.670799999999999, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4196.Parent = workspace.devices.mtkcorners
newmodel4197 = workspace.prefabs.mtkc_b:clone()
newmodel4197:PivotTo(CFrame.new(-21.164461152035155, 5.670799999999999, 33.941121734255645) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4197.Parent = workspace.devices.mtkcorners
newmodel4198 = workspace.prefabs.mtkc_r:clone()
newmodel4198:PivotTo(CFrame.new(-25.967572310444766, 5.670799999999999, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4198.Parent = workspace.devices.mtkcorners
newmodel4199 = workspace.prefabs.mtkc_l:clone()
newmodel4199:PivotTo(CFrame.new(-21.26544944144293, 5.554, 33.99980397520204) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4199.Parent = workspace.devices.mtkcorners
newmodel4200 = workspace.prefabs.mtkc_r:clone()
newmodel4200:PivotTo(CFrame.new(-25.967572310444766, 5.554, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4200.Parent = workspace.devices.mtkcorners
newmodel4201 = workspace.prefabs.mtkc_b:clone()
newmodel4201:PivotTo(CFrame.new(-25.967572310444766, 5.554, 36.596586840173856) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4201.Parent = workspace.devices.mtkcorners
newmodel4202 = workspace.prefabs.mtkc_l:clone()
newmodel4202:PivotTo(CFrame.new(-21.26544944144293, 5.4372, 33.99980397520204) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4202.Parent = workspace.devices.mtkcorners
newmodel4203 = workspace.prefabs.mtkc_r:clone()
newmodel4203:PivotTo(CFrame.new(-25.864120456112026, 5.4372, 36.542365499032954) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4203.Parent = workspace.devices.mtkcorners
newmodel4204 = workspace.prefabs.mtkc_l:clone()
newmodel4204:PivotTo(CFrame.new(-21.26544944144293, 5.320399999999999, 33.99980397520204) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4204.Parent = workspace.devices.mtkcorners
newmodel4205 = workspace.prefabs.mtkc_b:clone()
newmodel4205:PivotTo(CFrame.new(-21.26544944144293, 5.320399999999999, 33.99980397520204) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4205.Parent = workspace.devices.mtkcorners
newmodel4206 = workspace.prefabs.mtkc_r:clone()
newmodel4206:PivotTo(CFrame.new(-25.864120456112026, 5.320399999999999, 36.542365499032954) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4206.Parent = workspace.devices.mtkcorners
newmodel4207 = workspace.prefabs.mtkc_b:clone()
newmodel4207:PivotTo(CFrame.new(-25.864120456112026, 5.320399999999999, 36.542365499032954) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4207.Parent = workspace.devices.mtkcorners
newmodel4208 = workspace.prefabs.mtkc_l:clone()
newmodel4208:PivotTo(CFrame.new(-21.366437730850706, 5.2036, 34.05848621614844) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4208.Parent = workspace.devices.mtkcorners
newmodel4209 = workspace.prefabs.mtkc_r:clone()
newmodel4209:PivotTo(CFrame.new(-25.760668601779287, 5.2036, 36.48814415789205) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4209.Parent = workspace.devices.mtkcorners
newmodel4210 = workspace.prefabs.mtkc_l:clone()
newmodel4210:PivotTo(CFrame.new(-21.366437730850706, 5.086799999999999, 34.05848621614844) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4210.Parent = workspace.devices.mtkcorners
newmodel4211 = workspace.prefabs.mtkc_b:clone()
newmodel4211:PivotTo(CFrame.new(-21.366437730850706, 5.086799999999999, 34.05848621614844) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4211.Parent = workspace.devices.mtkcorners
newmodel4212 = workspace.prefabs.mtkc_r:clone()
newmodel4212:PivotTo(CFrame.new(-25.760668601779287, 5.086799999999999, 36.48814415789205) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4212.Parent = workspace.devices.mtkcorners
newmodel4213 = workspace.prefabs.mtkc_b:clone()
newmodel4213:PivotTo(CFrame.new(-25.760668601779287, 5.086799999999999, 36.48814415789205) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4213.Parent = workspace.devices.mtkcorners
newmodel4214 = workspace.prefabs.mtkc_l:clone()
newmodel4214:PivotTo(CFrame.new(-21.46742602025848, 4.97, 34.117168457094834) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4214.Parent = workspace.devices.mtkcorners
newmodel4215 = workspace.prefabs.mtkc_r:clone()
newmodel4215:PivotTo(CFrame.new(-25.657216747446547, 4.97, 36.43392281675116) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4215.Parent = workspace.devices.mtkcorners
newmodel4216 = workspace.prefabs.mtkc_l:clone()
newmodel4216:PivotTo(CFrame.new(-21.46742602025848, 4.8532, 34.117168457094834) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4216.Parent = workspace.devices.mtkcorners
newmodel4217 = workspace.prefabs.mtkc_b:clone()
newmodel4217:PivotTo(CFrame.new(-21.46742602025848, 4.8532, 34.117168457094834) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4217.Parent = workspace.devices.mtkcorners
newmodel4218 = workspace.prefabs.mtkc_r:clone()
newmodel4218:PivotTo(CFrame.new(-25.657216747446547, 4.8532, 36.43392281675116) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4218.Parent = workspace.devices.mtkcorners
newmodel4219 = workspace.prefabs.mtkc_b:clone()
newmodel4219:PivotTo(CFrame.new(-25.657216747446547, 4.8532, 36.43392281675116) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4219.Parent = workspace.devices.mtkcorners
newmodel4220 = workspace.prefabs.mtkc_l:clone()
newmodel4220:PivotTo(CFrame.new(-21.56841430966626, 4.7364, 34.17585069804124) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4220.Parent = workspace.devices.mtkcorners
newmodel4221 = workspace.prefabs.mtkc_b:clone()
newmodel4221:PivotTo(CFrame.new(-21.56841430966626, 4.7364, 34.17585069804124) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4221.Parent = workspace.devices.mtkcorners
newmodel4222 = workspace.prefabs.mtkc_r:clone()
newmodel4222:PivotTo(CFrame.new(-25.553764893113808, 4.7364, 36.37970147561026) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4222.Parent = workspace.devices.mtkcorners
newmodel4223 = workspace.prefabs.mtkc_b:clone()
newmodel4223:PivotTo(CFrame.new(-25.553764893113808, 4.7364, 36.37970147561026) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4223.Parent = workspace.devices.mtkcorners
newmodel4224 = workspace.prefabs.mtkc_l:clone()
newmodel4224:PivotTo(CFrame.new(-21.669402599074033, 4.619599999999999, 34.23453293898764) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4224.Parent = workspace.devices.mtkcorners
newmodel4225 = workspace.prefabs.mtkc_b:clone()
newmodel4225:PivotTo(CFrame.new(-21.669402599074033, 4.619599999999999, 34.23453293898764) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4225.Parent = workspace.devices.mtkcorners
newmodel4226 = workspace.prefabs.mtkc_r:clone()
newmodel4226:PivotTo(CFrame.new(-25.45031303878107, 4.619599999999999, 36.32548013446936) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4226.Parent = workspace.devices.mtkcorners
newmodel4227 = workspace.prefabs.mtkc_b:clone()
newmodel4227:PivotTo(CFrame.new(-25.45031303878107, 4.619599999999999, 36.32548013446936) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4227.Parent = workspace.devices.mtkcorners
newmodel4228 = workspace.prefabs.mtkc_l:clone()
newmodel4228:PivotTo(CFrame.new(-21.77039088848181, 4.5028, 34.29321517993404) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4228.Parent = workspace.devices.mtkcorners
newmodel4229 = workspace.prefabs.mtkc_b:clone()
newmodel4229:PivotTo(CFrame.new(-21.77039088848181, 4.5028, 34.29321517993404) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4229.Parent = workspace.devices.mtkcorners
newmodel4230 = workspace.prefabs.mtkc_r:clone()
newmodel4230:PivotTo(CFrame.new(-25.34686118444833, 4.5028, 36.27125879332847) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4230.Parent = workspace.devices.mtkcorners
newmodel4231 = workspace.prefabs.mtkc_b:clone()
newmodel4231:PivotTo(CFrame.new(-25.34686118444833, 4.5028, 36.27125879332847) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4231.Parent = workspace.devices.mtkcorners
newmodel4232 = workspace.prefabs.mtkc_l:clone()
newmodel4232:PivotTo(CFrame.new(-21.871379177889587, 4.385999999999999, 34.351897420880434) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4232.Parent = workspace.devices.mtkcorners
newmodel4233 = workspace.prefabs.mtkc_b:clone()
newmodel4233:PivotTo(CFrame.new(-21.871379177889587, 4.385999999999999, 34.351897420880434) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4233.Parent = workspace.devices.mtkcorners
newmodel4234 = workspace.prefabs.mtkc_r:clone()
newmodel4234:PivotTo(CFrame.new(-25.24340933011559, 4.385999999999999, 36.21703745218757) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4234.Parent = workspace.devices.mtkcorners
newmodel4235 = workspace.prefabs.mtkc_b:clone()
newmodel4235:PivotTo(CFrame.new(-25.24340933011559, 4.385999999999999, 36.21703745218757) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4235.Parent = workspace.devices.mtkcorners
newmodel4236 = workspace.prefabs.mtkc_l:clone()
newmodel4236:PivotTo(CFrame.new(-21.97236746729736, 4.2692, 34.41057966182683) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4236.Parent = workspace.devices.mtkcorners
newmodel4237 = workspace.prefabs.mtkc_b:clone()
newmodel4237:PivotTo(CFrame.new(-21.97236746729736, 4.2692, 34.41057966182683) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4237.Parent = workspace.devices.mtkcorners
newmodel4238 = workspace.prefabs.mtkc_r:clone()
newmodel4238:PivotTo(CFrame.new(-25.13995747578285, 4.2692, 36.16281611104667) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4238.Parent = workspace.devices.mtkcorners
newmodel4239 = workspace.prefabs.mtkc_b:clone()
newmodel4239:PivotTo(CFrame.new(-25.13995747578285, 4.2692, 36.16281611104667) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4239.Parent = workspace.devices.mtkcorners
newmodel4240 = workspace.prefabs.mtkc_l:clone()
newmodel4240:PivotTo(CFrame.new(-22.07335575670514, 4.1524, 34.46926190277323) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4240.Parent = workspace.devices.mtkcorners
newmodel4241 = workspace.prefabs.mtkc_b:clone()
newmodel4241:PivotTo(CFrame.new(-22.07335575670514, 4.1524, 34.46926190277323) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4241.Parent = workspace.devices.mtkcorners
newmodel4242 = workspace.prefabs.mtkc_r:clone()
newmodel4242:PivotTo(CFrame.new(-25.03650562145011, 4.1524, 36.10859476990578) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4242.Parent = workspace.devices.mtkcorners
newmodel4243 = workspace.prefabs.mtkc_b:clone()
newmodel4243:PivotTo(CFrame.new(-25.03650562145011, 4.1524, 36.10859476990578) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4243.Parent = workspace.devices.mtkcorners
newmodel4244 = workspace.prefabs.mtkc_l:clone()
newmodel4244:PivotTo(CFrame.new(-22.174344046112914, 4.0356, 34.52794414371963) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4244.Parent = workspace.devices.mtkcorners
newmodel4245 = workspace.prefabs.mtkc_b:clone()
newmodel4245:PivotTo(CFrame.new(-22.174344046112914, 4.0356, 34.52794414371963) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4245.Parent = workspace.devices.mtkcorners
newmodel4246 = workspace.prefabs.mtkc_b:clone()
newmodel4246:PivotTo(CFrame.new(-22.27533233552069, 4.0356, 34.58662638466603) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4246.Parent = workspace.devices.mtkcorners
newmodel4247 = workspace.prefabs.mtkc_b:clone()
newmodel4247:PivotTo(CFrame.new(-24.829601912784632, 4.0356, 36.00015208762398) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4247.Parent = workspace.devices.mtkcorners
newmodel4248 = workspace.prefabs.mtkc_r:clone()
newmodel4248:PivotTo(CFrame.new(-24.93305376711737, 4.0356, 36.054373428764876) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4248.Parent = workspace.devices.mtkcorners
newmodel4249 = workspace.prefabs.mtkc_b:clone()
newmodel4249:PivotTo(CFrame.new(-24.93305376711737, 4.0356, 36.054373428764876) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4249.Parent = workspace.devices.mtkcorners
newmodel4250 = workspace.prefabs.mtkc_l:clone()
newmodel4250:PivotTo(CFrame.new(-22.376320624928468, 3.918799999999999, 34.64530862561243) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4250.Parent = workspace.devices.mtkcorners
newmodel4251 = workspace.prefabs.mtkc_b:clone()
newmodel4251:PivotTo(CFrame.new(-22.376320624928468, 3.918799999999999, 34.64530862561243) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4251.Parent = workspace.devices.mtkcorners
newmodel4252 = workspace.prefabs.mtkc_b:clone()
newmodel4252:PivotTo(CFrame.new(-22.47730891433624, 3.918799999999999, 34.703990866558826) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4252.Parent = workspace.devices.mtkcorners
newmodel4253 = workspace.prefabs.mtkc_b:clone()
newmodel4253:PivotTo(CFrame.new(-24.622698204119153, 3.918799999999999, 35.89170940534218) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4253.Parent = workspace.devices.mtkcorners
newmodel4254 = workspace.prefabs.mtkc_r:clone()
newmodel4254:PivotTo(CFrame.new(-24.726150058451893, 3.918799999999999, 35.94593074648308) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4254.Parent = workspace.devices.mtkcorners
newmodel4255 = workspace.prefabs.mtkc_b:clone()
newmodel4255:PivotTo(CFrame.new(-24.726150058451893, 3.918799999999999, 35.94593074648308) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4255.Parent = workspace.devices.mtkcorners
newmodel4256 = workspace.prefabs.mtkc_l:clone()
newmodel4256:PivotTo(CFrame.new(-22.578297203744018, 3.801999999999999, 34.76267310750523) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4256.Parent = workspace.devices.mtkcorners
newmodel4257 = workspace.prefabs.mtkc_b:clone()
newmodel4257:PivotTo(CFrame.new(-22.578297203744018, 3.801999999999999, 34.76267310750523) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4257.Parent = workspace.devices.mtkcorners
newmodel4258 = workspace.prefabs.mtkc_b:clone()
newmodel4258:PivotTo(CFrame.new(-22.679285493151795, 3.801999999999999, 34.82135534845163) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4258.Parent = workspace.devices.mtkcorners
newmodel4259 = workspace.prefabs.mtkc_b:clone()
newmodel4259:PivotTo(CFrame.new(-24.31234264112093, 3.801999999999999, 35.72904538191949) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4259.Parent = workspace.devices.mtkcorners
newmodel4260 = workspace.prefabs.mtkc_b:clone()
newmodel4260:PivotTo(CFrame.new(-24.41579449545367, 3.801999999999999, 35.783266723060386) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4260.Parent = workspace.devices.mtkcorners
newmodel4261 = workspace.prefabs.mtkc_r:clone()
newmodel4261:PivotTo(CFrame.new(-24.519246349786414, 3.801999999999999, 35.83748806420128) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4261.Parent = workspace.devices.mtkcorners
newmodel4262 = workspace.prefabs.mtkc_b:clone()
newmodel4262:PivotTo(CFrame.new(-24.519246349786414, 3.801999999999999, 35.83748806420128) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4262.Parent = workspace.devices.mtkcorners
newmodel4263 = workspace.prefabs.mtkc_l:clone()
newmodel4263:PivotTo(CFrame.new(-22.780273782559572, 3.685199999999999, 34.88003758939803) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4263.Parent = workspace.devices.mtkcorners
newmodel4264 = workspace.prefabs.mtkc_b:clone()
newmodel4264:PivotTo(CFrame.new(-22.780273782559572, 3.685199999999999, 34.88003758939803) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4264.Parent = workspace.devices.mtkcorners
newmodel4265 = workspace.prefabs.mtkc_b:clone()
newmodel4265:PivotTo(CFrame.new(-22.88126207196735, 3.685199999999999, 34.938719830344425) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4265.Parent = workspace.devices.mtkcorners
newmodel4266 = workspace.prefabs.mtkc_b:clone()
newmodel4266:PivotTo(CFrame.new(-22.982250361375122, 3.685199999999999, 34.99740207129083) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4266.Parent = workspace.devices.mtkcorners
newmodel4267 = workspace.prefabs.mtkc_b:clone()
newmodel4267:PivotTo(CFrame.new(-23.0832386507829, 3.685199999999999, 35.05608431223723) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4267.Parent = workspace.devices.mtkcorners
newmodel4268 = workspace.prefabs.mtkc_b:clone()
newmodel4268:PivotTo(CFrame.new(-23.184226940190676, 3.685199999999999, 35.11476655318363) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4268.Parent = workspace.devices.mtkcorners
newmodel4269 = workspace.prefabs.mtkc_b:clone()
newmodel4269:PivotTo(CFrame.new(-23.28521522959845, 3.685199999999999, 35.173448794130024) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4269.Parent = workspace.devices.mtkcorners
newmodel4270 = workspace.prefabs.mtkc_b:clone()
newmodel4270:PivotTo(CFrame.new(-23.38620351900623, 3.685199999999999, 35.23213103507643) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4270.Parent = workspace.devices.mtkcorners
newmodel4271 = workspace.prefabs.mtkc_b:clone()
newmodel4271:PivotTo(CFrame.new(-23.487191808414003, 3.685199999999999, 35.290813276022824) * CFrame.fromEulerAngles(0, math.rad(-59.839999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4271.Parent = workspace.devices.mtkcorners
newmodel4272 = workspace.prefabs.mtkc_b:clone()
newmodel4272:PivotTo(CFrame.new(-23.588179660791752, 3.685199999999999, 35.3494959939332) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4272.Parent = workspace.devices.mtkcorners
newmodel4273 = workspace.prefabs.mtkc_b:clone()
newmodel4273:PivotTo(CFrame.new(-23.691631515124495, 3.685199999999999, 35.403717335074106) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4273.Parent = workspace.devices.mtkcorners
newmodel4274 = workspace.prefabs.mtkc_b:clone()
newmodel4274:PivotTo(CFrame.new(-23.795083369457235, 3.685199999999999, 35.457938676215) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4274.Parent = workspace.devices.mtkcorners
newmodel4275 = workspace.prefabs.mtkc_b:clone()
newmodel4275:PivotTo(CFrame.new(-23.898535223789978, 3.685199999999999, 35.512160017355896) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4275.Parent = workspace.devices.mtkcorners
newmodel4276 = workspace.prefabs.mtkc_b:clone()
newmodel4276:PivotTo(CFrame.new(-24.001987078122717, 3.685199999999999, 35.5663813584968) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4276.Parent = workspace.devices.mtkcorners
newmodel4277 = workspace.prefabs.mtkc_b:clone()
newmodel4277:PivotTo(CFrame.new(-24.105438932455453, 3.685199999999999, 35.62060269963769) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4277.Parent = workspace.devices.mtkcorners
newmodel4278 = workspace.prefabs.mtkc_r:clone()
newmodel4278:PivotTo(CFrame.new(-24.208890786788196, 3.685199999999999, 35.67482404077859) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4278.Parent = workspace.devices.mtkcorners
newmodel4279 = workspace.prefabs.mtkc_b:clone()
newmodel4279:PivotTo(CFrame.new(-24.208890786788196, 3.685199999999999, 35.67482404077859) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4279.Parent = workspace.devices.mtkcorners
newmodel4280 = workspace.prefabs.mtkc_t:clone()
newmodel4280:PivotTo(CFrame.new(-9.646017459736195, 9.1748, 21.85978012103792) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4280.Parent = workspace.devices.mtkcorners
newmodel4281 = workspace.prefabs.mtkc_l:clone()
newmodel4281:PivotTo(CFrame.new(-9.646017459736195, 9.1748, 21.85978012103792) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4281.Parent = workspace.devices.mtkcorners
newmodel4282 = workspace.prefabs.mtkc_t:clone()
newmodel4282:PivotTo(CFrame.new(-9.70615643223211, 9.1748, 21.959907759515694) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4282.Parent = workspace.devices.mtkcorners
newmodel4283 = workspace.prefabs.mtkc_t:clone()
newmodel4283:PivotTo(CFrame.new(-9.766295404728025, 9.1748, 22.060035397993467) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4283.Parent = workspace.devices.mtkcorners
newmodel4284 = workspace.prefabs.mtkc_t:clone()
newmodel4284:PivotTo(CFrame.new(-9.82643437722394, 9.1748, 22.16016303647124) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4284.Parent = workspace.devices.mtkcorners
newmodel4285 = workspace.prefabs.mtkc_t:clone()
newmodel4285:PivotTo(CFrame.new(-9.886573349719855, 9.1748, 22.26029067494901) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4285.Parent = workspace.devices.mtkcorners
newmodel4286 = workspace.prefabs.mtkc_t:clone()
newmodel4286:PivotTo(CFrame.new(-9.94671232221577, 9.1748, 22.360418313426784) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4286.Parent = workspace.devices.mtkcorners
newmodel4287 = workspace.prefabs.mtkc_t:clone()
newmodel4287:PivotTo(CFrame.new(-10.006851294711685, 9.1748, 22.460545951904557) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4287.Parent = workspace.devices.mtkcorners
newmodel4288 = workspace.prefabs.mtkc_t:clone()
newmodel4288:PivotTo(CFrame.new(-10.06679481554699, 9.1748, 22.560348175557277) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4288.Parent = workspace.devices.mtkcorners
newmodel4289 = workspace.prefabs.mtkc_t:clone()
newmodel4289:PivotTo(CFrame.new(-10.13124405701564, 9.1748, 22.657757288447783) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4289.Parent = workspace.devices.mtkcorners
newmodel4290 = workspace.prefabs.mtkc_t:clone()
newmodel4290:PivotTo(CFrame.new(-10.195693298484294, 9.1748, 22.75516640133829) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4290.Parent = workspace.devices.mtkcorners
newmodel4291 = workspace.prefabs.mtkc_t:clone()
newmodel4291:PivotTo(CFrame.new(-10.260142539952946, 9.1748, 22.852575514228796) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4291.Parent = workspace.devices.mtkcorners
newmodel4292 = workspace.prefabs.mtkc_t:clone()
newmodel4292:PivotTo(CFrame.new(-10.3245917814216, 9.1748, 22.949984627119303) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4292.Parent = workspace.devices.mtkcorners
newmodel4293 = workspace.prefabs.mtkc_t:clone()
newmodel4293:PivotTo(CFrame.new(-10.38904102289025, 9.1748, 23.04739374000981) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4293.Parent = workspace.devices.mtkcorners
newmodel4294 = workspace.prefabs.mtkc_t:clone()
newmodel4294:PivotTo(CFrame.new(-10.453490264358903, 9.1748, 23.144802852900312) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4294.Parent = workspace.devices.mtkcorners
newmodel4295 = workspace.prefabs.mtkc_t:clone()
newmodel4295:PivotTo(CFrame.new(-10.517939505827556, 9.1748, 23.24221196579082) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4295.Parent = workspace.devices.mtkcorners
newmodel4296 = workspace.prefabs.mtkc_r:clone()
newmodel4296:PivotTo(CFrame.new(-10.517939505827556, 9.1748, 23.24221196579082) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4296.Parent = workspace.devices.mtkcorners
newmodel4297 = workspace.prefabs.mtkc_t:clone()
newmodel4297:PivotTo(CFrame.new(-9.465600542248449, 9.058, 21.559397205604604) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4297.Parent = workspace.devices.mtkcorners
newmodel4298 = workspace.prefabs.mtkc_l:clone()
newmodel4298:PivotTo(CFrame.new(-9.465600542248449, 9.058, 21.559397205604604) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4298.Parent = workspace.devices.mtkcorners
newmodel4299 = workspace.prefabs.mtkc_t:clone()
newmodel4299:PivotTo(CFrame.new(-9.525739514744364, 9.058, 21.659524844082377) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4299.Parent = workspace.devices.mtkcorners
newmodel4300 = workspace.prefabs.mtkc_t:clone()
newmodel4300:PivotTo(CFrame.new(-9.58587848724028, 9.058, 21.75965248256015) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4300.Parent = workspace.devices.mtkcorners
newmodel4301 = workspace.prefabs.mtkc_t:clone()
newmodel4301:PivotTo(CFrame.new(-10.582388747296209, 9.058, 23.339621078681326) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4301.Parent = workspace.devices.mtkcorners
newmodel4302 = workspace.prefabs.mtkc_t:clone()
newmodel4302:PivotTo(CFrame.new(-10.64683798876486, 9.058, 23.437030191571832) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4302.Parent = workspace.devices.mtkcorners
newmodel4303 = workspace.prefabs.mtkc_r:clone()
newmodel4303:PivotTo(CFrame.new(-10.64683798876486, 9.058, 23.437030191571832) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4303.Parent = workspace.devices.mtkcorners
newmodel4304 = workspace.prefabs.mtkc_t:clone()
newmodel4304:PivotTo(CFrame.new(-9.345322597256619, 8.941199999999998, 21.35914192864906) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4304.Parent = workspace.devices.mtkcorners
newmodel4305 = workspace.prefabs.mtkc_l:clone()
newmodel4305:PivotTo(CFrame.new(-9.345322597256619, 8.941199999999998, 21.35914192864906) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4305.Parent = workspace.devices.mtkcorners
newmodel4306 = workspace.prefabs.mtkc_t:clone()
newmodel4306:PivotTo(CFrame.new(-9.405461569752534, 8.941199999999998, 21.45926956712683) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4306.Parent = workspace.devices.mtkcorners
newmodel4307 = workspace.prefabs.mtkc_t:clone()
newmodel4307:PivotTo(CFrame.new(-10.711287230233513, 8.941199999999998, 23.53443930446234) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4307.Parent = workspace.devices.mtkcorners
newmodel4308 = workspace.prefabs.mtkc_t:clone()
newmodel4308:PivotTo(CFrame.new(-10.775736471702166, 8.941199999999998, 23.631848417352845) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4308.Parent = workspace.devices.mtkcorners
newmodel4309 = workspace.prefabs.mtkc_r:clone()
newmodel4309:PivotTo(CFrame.new(-10.775736471702166, 8.941199999999998, 23.631848417352845) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4309.Parent = workspace.devices.mtkcorners
newmodel4310 = workspace.prefabs.mtkc_t:clone()
newmodel4310:PivotTo(CFrame.new(-9.225044652264788, 8.824399999999999, 21.15888665169351) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4310.Parent = workspace.devices.mtkcorners
newmodel4311 = workspace.prefabs.mtkc_l:clone()
newmodel4311:PivotTo(CFrame.new(-9.225044652264788, 8.824399999999999, 21.15888665169351) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4311.Parent = workspace.devices.mtkcorners
newmodel4312 = workspace.prefabs.mtkc_t:clone()
newmodel4312:PivotTo(CFrame.new(-9.285183624760704, 8.824399999999999, 21.259014290171287) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4312.Parent = workspace.devices.mtkcorners
newmodel4313 = workspace.prefabs.mtkc_t:clone()
newmodel4313:PivotTo(CFrame.new(-10.840185713170818, 8.824399999999999, 23.729257530243352) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4313.Parent = workspace.devices.mtkcorners
newmodel4314 = workspace.prefabs.mtkc_t:clone()
newmodel4314:PivotTo(CFrame.new(-10.90463495463947, 8.824399999999999, 23.826666643133855) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4314.Parent = workspace.devices.mtkcorners
newmodel4315 = workspace.prefabs.mtkc_r:clone()
newmodel4315:PivotTo(CFrame.new(-10.90463495463947, 8.824399999999999, 23.826666643133855) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4315.Parent = workspace.devices.mtkcorners
newmodel4316 = workspace.prefabs.mtkc_t:clone()
newmodel4316:PivotTo(CFrame.new(-9.164905679768873, 8.7076, 21.058759013215738) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4316.Parent = workspace.devices.mtkcorners
newmodel4317 = workspace.prefabs.mtkc_l:clone()
newmodel4317:PivotTo(CFrame.new(-9.164905679768873, 8.7076, 21.058759013215738) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4317.Parent = workspace.devices.mtkcorners
newmodel4318 = workspace.prefabs.mtkc_t:clone()
newmodel4318:PivotTo(CFrame.new(-10.969084196108122, 8.7076, 23.92407575602436) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4318.Parent = workspace.devices.mtkcorners
newmodel4319 = workspace.prefabs.mtkc_r:clone()
newmodel4319:PivotTo(CFrame.new(-10.969084196108122, 8.7076, 23.92407575602436) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4319.Parent = workspace.devices.mtkcorners
newmodel4320 = workspace.prefabs.mtkc_t:clone()
newmodel4320:PivotTo(CFrame.new(-9.104766707272958, 8.5908, 20.958631374737966) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4320.Parent = workspace.devices.mtkcorners
newmodel4321 = workspace.prefabs.mtkc_l:clone()
newmodel4321:PivotTo(CFrame.new(-9.104766707272958, 8.5908, 20.958631374737966) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4321.Parent = workspace.devices.mtkcorners
newmodel4322 = workspace.prefabs.mtkc_t:clone()
newmodel4322:PivotTo(CFrame.new(-11.033533437576775, 8.5908, 24.021484868914868) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4322.Parent = workspace.devices.mtkcorners
newmodel4323 = workspace.prefabs.mtkc_r:clone()
newmodel4323:PivotTo(CFrame.new(-11.033533437576775, 8.5908, 24.021484868914868) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4323.Parent = workspace.devices.mtkcorners
newmodel4324 = workspace.prefabs.mtkc_t:clone()
newmodel4324:PivotTo(CFrame.new(-9.044627734777043, 8.474, 20.858503736260193) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4324.Parent = workspace.devices.mtkcorners
newmodel4325 = workspace.prefabs.mtkc_l:clone()
newmodel4325:PivotTo(CFrame.new(-9.044627734777043, 8.474, 20.858503736260193) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4325.Parent = workspace.devices.mtkcorners
newmodel4326 = workspace.prefabs.mtkc_t:clone()
newmodel4326:PivotTo(CFrame.new(-11.097982679045426, 8.474, 24.118893981805375) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4326.Parent = workspace.devices.mtkcorners
newmodel4327 = workspace.prefabs.mtkc_r:clone()
newmodel4327:PivotTo(CFrame.new(-11.097982679045426, 8.474, 24.118893981805375) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4327.Parent = workspace.devices.mtkcorners
newmodel4328 = workspace.prefabs.mtkc_t:clone()
newmodel4328:PivotTo(CFrame.new(-8.984488762281128, 8.357199999999999, 20.75837609778242) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4328.Parent = workspace.devices.mtkcorners
newmodel4329 = workspace.prefabs.mtkc_l:clone()
newmodel4329:PivotTo(CFrame.new(-8.984488762281128, 8.357199999999999, 20.75837609778242) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4329.Parent = workspace.devices.mtkcorners
newmodel4330 = workspace.prefabs.mtkc_t:clone()
newmodel4330:PivotTo(CFrame.new(-11.162431920514079, 8.357199999999999, 24.21630309469588) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4330.Parent = workspace.devices.mtkcorners
newmodel4331 = workspace.prefabs.mtkc_r:clone()
newmodel4331:PivotTo(CFrame.new(-11.162431920514079, 8.357199999999999, 24.21630309469588) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4331.Parent = workspace.devices.mtkcorners
newmodel4332 = workspace.prefabs.mtkc_t:clone()
newmodel4332:PivotTo(CFrame.new(-8.924349789785213, 8.2404, 20.658248459304648) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4332.Parent = workspace.devices.mtkcorners
newmodel4333 = workspace.prefabs.mtkc_l:clone()
newmodel4333:PivotTo(CFrame.new(-8.924349789785213, 8.2404, 20.658248459304648) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4333.Parent = workspace.devices.mtkcorners
newmodel4334 = workspace.prefabs.mtkc_t:clone()
newmodel4334:PivotTo(CFrame.new(-11.226881161982732, 8.2404, 24.313712207586384) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4334.Parent = workspace.devices.mtkcorners
newmodel4335 = workspace.prefabs.mtkc_r:clone()
newmodel4335:PivotTo(CFrame.new(-11.226881161982732, 8.2404, 24.313712207586384) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4335.Parent = workspace.devices.mtkcorners
newmodel4336 = workspace.prefabs.mtkc_t:clone()
newmodel4336:PivotTo(CFrame.new(-8.864210817289297, 8.1236, 20.558120820826876) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4336.Parent = workspace.devices.mtkcorners
newmodel4337 = workspace.prefabs.mtkc_l:clone()
newmodel4337:PivotTo(CFrame.new(-8.864210817289297, 8.1236, 20.558120820826876) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4337.Parent = workspace.devices.mtkcorners
newmodel4338 = workspace.prefabs.mtkc_t:clone()
newmodel4338:PivotTo(CFrame.new(-11.291330403451383, 8.1236, 24.41112132047689) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4338.Parent = workspace.devices.mtkcorners
newmodel4339 = workspace.prefabs.mtkc_r:clone()
newmodel4339:PivotTo(CFrame.new(-11.291330403451383, 8.1236, 24.41112132047689) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4339.Parent = workspace.devices.mtkcorners
newmodel4340 = workspace.prefabs.mtkc_t:clone()
newmodel4340:PivotTo(CFrame.new(-8.804071844793382, 8.0068, 20.457993182349103) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4340.Parent = workspace.devices.mtkcorners
newmodel4341 = workspace.prefabs.mtkc_l:clone()
newmodel4341:PivotTo(CFrame.new(-8.804071844793382, 8.0068, 20.457993182349103) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4341.Parent = workspace.devices.mtkcorners
newmodel4342 = workspace.prefabs.mtkc_t:clone()
newmodel4342:PivotTo(CFrame.new(-11.355779644920037, 8.0068, 24.508530433367397) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4342.Parent = workspace.devices.mtkcorners
newmodel4343 = workspace.prefabs.mtkc_r:clone()
newmodel4343:PivotTo(CFrame.new(-11.355779644920037, 8.0068, 24.508530433367397) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4343.Parent = workspace.devices.mtkcorners
newmodel4344 = workspace.prefabs.mtkc_l:clone()
newmodel4344:PivotTo(CFrame.new(-8.804071844793382, 7.89, 20.457993182349103) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4344.Parent = workspace.devices.mtkcorners
newmodel4345 = workspace.prefabs.mtkc_r:clone()
newmodel4345:PivotTo(CFrame.new(-11.355779644920037, 7.89, 24.508530433367397) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4345.Parent = workspace.devices.mtkcorners
newmodel4346 = workspace.prefabs.mtkc_t:clone()
newmodel4346:PivotTo(CFrame.new(-8.743932872297467, 7.773199999999999, 20.35786554387133) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4346.Parent = workspace.devices.mtkcorners
newmodel4347 = workspace.prefabs.mtkc_l:clone()
newmodel4347:PivotTo(CFrame.new(-8.743932872297467, 7.773199999999999, 20.35786554387133) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4347.Parent = workspace.devices.mtkcorners
newmodel4348 = workspace.prefabs.mtkc_t:clone()
newmodel4348:PivotTo(CFrame.new(-11.420228886388688, 7.773199999999999, 24.605939546257904) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4348.Parent = workspace.devices.mtkcorners
newmodel4349 = workspace.prefabs.mtkc_r:clone()
newmodel4349:PivotTo(CFrame.new(-11.420228886388688, 7.773199999999999, 24.605939546257904) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4349.Parent = workspace.devices.mtkcorners
newmodel4350 = workspace.prefabs.mtkc_l:clone()
newmodel4350:PivotTo(CFrame.new(-8.743932872297467, 7.656399999999999, 20.35786554387133) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4350.Parent = workspace.devices.mtkcorners
newmodel4351 = workspace.prefabs.mtkc_r:clone()
newmodel4351:PivotTo(CFrame.new(-11.420228886388688, 7.656399999999999, 24.605939546257904) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4351.Parent = workspace.devices.mtkcorners
newmodel4352 = workspace.prefabs.mtkc_t:clone()
newmodel4352:PivotTo(CFrame.new(-8.683793899801552, 7.5396, 20.257737905393558) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4352.Parent = workspace.devices.mtkcorners
newmodel4353 = workspace.prefabs.mtkc_l:clone()
newmodel4353:PivotTo(CFrame.new(-8.683793899801552, 7.5396, 20.257737905393558) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4353.Parent = workspace.devices.mtkcorners
newmodel4354 = workspace.prefabs.mtkc_t:clone()
newmodel4354:PivotTo(CFrame.new(-11.484678127857341, 7.5396, 24.70334865914841) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4354.Parent = workspace.devices.mtkcorners
newmodel4355 = workspace.prefabs.mtkc_r:clone()
newmodel4355:PivotTo(CFrame.new(-11.484678127857341, 7.5396, 24.70334865914841) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4355.Parent = workspace.devices.mtkcorners
newmodel4356 = workspace.prefabs.mtkc_t:clone()
newmodel4356:PivotTo(CFrame.new(-8.623654927305637, 7.4228000000000005, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4356.Parent = workspace.devices.mtkcorners
newmodel4357 = workspace.prefabs.mtkc_l:clone()
newmodel4357:PivotTo(CFrame.new(-8.623654927305637, 7.4228000000000005, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4357.Parent = workspace.devices.mtkcorners
newmodel4358 = workspace.prefabs.mtkc_r:clone()
newmodel4358:PivotTo(CFrame.new(-11.484678127857341, 7.4228000000000005, 24.70334865914841) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4358.Parent = workspace.devices.mtkcorners
newmodel4359 = workspace.prefabs.mtkc_l:clone()
newmodel4359:PivotTo(CFrame.new(-8.623654927305637, 7.306, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4359.Parent = workspace.devices.mtkcorners
newmodel4360 = workspace.prefabs.mtkc_r:clone()
newmodel4360:PivotTo(CFrame.new(-11.484678127857341, 7.306, 24.70334865914841) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4360.Parent = workspace.devices.mtkcorners
newmodel4361 = workspace.prefabs.mtkc_l:clone()
newmodel4361:PivotTo(CFrame.new(-8.623654927305637, 7.1892, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4361.Parent = workspace.devices.mtkcorners
newmodel4362 = workspace.prefabs.mtkc_t:clone()
newmodel4362:PivotTo(CFrame.new(-11.549127369325994, 7.1892, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4362.Parent = workspace.devices.mtkcorners
newmodel4363 = workspace.prefabs.mtkc_r:clone()
newmodel4363:PivotTo(CFrame.new(-11.549127369325994, 7.1892, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4363.Parent = workspace.devices.mtkcorners
newmodel4364 = workspace.prefabs.mtkc_l:clone()
newmodel4364:PivotTo(CFrame.new(-8.623654927305637, 7.0724, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4364.Parent = workspace.devices.mtkcorners
newmodel4365 = workspace.prefabs.mtkc_r:clone()
newmodel4365:PivotTo(CFrame.new(-11.549127369325994, 7.0724, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4365.Parent = workspace.devices.mtkcorners
newmodel4366 = workspace.prefabs.mtkc_l:clone()
newmodel4366:PivotTo(CFrame.new(-8.623654927305637, 6.9556, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4366.Parent = workspace.devices.mtkcorners
newmodel4367 = workspace.prefabs.mtkc_r:clone()
newmodel4367:PivotTo(CFrame.new(-11.549127369325994, 6.9556, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4367.Parent = workspace.devices.mtkcorners
newmodel4368 = workspace.prefabs.mtkc_l:clone()
newmodel4368:PivotTo(CFrame.new(-8.623654927305637, 6.8388, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4368.Parent = workspace.devices.mtkcorners
newmodel4369 = workspace.prefabs.mtkc_r:clone()
newmodel4369:PivotTo(CFrame.new(-11.549127369325994, 6.8388, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4369.Parent = workspace.devices.mtkcorners
newmodel4370 = workspace.prefabs.mtkc_l:clone()
newmodel4370:PivotTo(CFrame.new(-8.623654927305637, 6.7219999999999995, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4370.Parent = workspace.devices.mtkcorners
newmodel4371 = workspace.prefabs.mtkc_r:clone()
newmodel4371:PivotTo(CFrame.new(-11.549127369325994, 6.7219999999999995, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4371.Parent = workspace.devices.mtkcorners
newmodel4372 = workspace.prefabs.mtkc_l:clone()
newmodel4372:PivotTo(CFrame.new(-8.623654927305637, 6.605199999999999, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4372.Parent = workspace.devices.mtkcorners
newmodel4373 = workspace.prefabs.mtkc_r:clone()
newmodel4373:PivotTo(CFrame.new(-11.549127369325994, 6.605199999999999, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4373.Parent = workspace.devices.mtkcorners
newmodel4374 = workspace.prefabs.mtkc_l:clone()
newmodel4374:PivotTo(CFrame.new(-8.623654927305637, 6.4883999999999995, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4374.Parent = workspace.devices.mtkcorners
newmodel4375 = workspace.prefabs.mtkc_r:clone()
newmodel4375:PivotTo(CFrame.new(-11.549127369325994, 6.4883999999999995, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4375.Parent = workspace.devices.mtkcorners
newmodel4376 = workspace.prefabs.mtkc_l:clone()
newmodel4376:PivotTo(CFrame.new(-8.623654927305637, 6.371599999999999, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4376.Parent = workspace.devices.mtkcorners
newmodel4377 = workspace.prefabs.mtkc_r:clone()
newmodel4377:PivotTo(CFrame.new(-11.549127369325994, 6.371599999999999, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4377.Parent = workspace.devices.mtkcorners
newmodel4378 = workspace.prefabs.mtkc_l:clone()
newmodel4378:PivotTo(CFrame.new(-8.623654927305637, 6.2547999999999995, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4378.Parent = workspace.devices.mtkcorners
newmodel4379 = workspace.prefabs.mtkc_r:clone()
newmodel4379:PivotTo(CFrame.new(-11.549127369325994, 6.2547999999999995, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4379.Parent = workspace.devices.mtkcorners
newmodel4380 = workspace.prefabs.mtkc_l:clone()
newmodel4380:PivotTo(CFrame.new(-8.623654927305637, 6.137999999999999, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4380.Parent = workspace.devices.mtkcorners
newmodel4381 = workspace.prefabs.mtkc_r:clone()
newmodel4381:PivotTo(CFrame.new(-11.549127369325994, 6.137999999999999, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4381.Parent = workspace.devices.mtkcorners
newmodel4382 = workspace.prefabs.mtkc_l:clone()
newmodel4382:PivotTo(CFrame.new(-8.623654927305637, 6.0211999999999986, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4382.Parent = workspace.devices.mtkcorners
newmodel4383 = workspace.prefabs.mtkc_r:clone()
newmodel4383:PivotTo(CFrame.new(-11.549127369325994, 6.0211999999999986, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4383.Parent = workspace.devices.mtkcorners
newmodel4384 = workspace.prefabs.mtkc_l:clone()
newmodel4384:PivotTo(CFrame.new(-8.623654927305637, 5.904399999999999, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4384.Parent = workspace.devices.mtkcorners
newmodel4385 = workspace.prefabs.mtkc_r:clone()
newmodel4385:PivotTo(CFrame.new(-11.549127369325994, 5.904399999999999, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4385.Parent = workspace.devices.mtkcorners
newmodel4386 = workspace.prefabs.mtkc_l:clone()
newmodel4386:PivotTo(CFrame.new(-8.623654927305637, 5.787599999999999, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4386.Parent = workspace.devices.mtkcorners
newmodel4387 = workspace.prefabs.mtkc_r:clone()
newmodel4387:PivotTo(CFrame.new(-11.549127369325994, 5.787599999999999, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4387.Parent = workspace.devices.mtkcorners
newmodel4388 = workspace.prefabs.mtkc_l:clone()
newmodel4388:PivotTo(CFrame.new(-8.623654927305637, 5.670799999999999, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4388.Parent = workspace.devices.mtkcorners
newmodel4389 = workspace.prefabs.mtkc_b:clone()
newmodel4389:PivotTo(CFrame.new(-8.623654927305637, 5.670799999999999, 20.157610266915786) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4389.Parent = workspace.devices.mtkcorners
newmodel4390 = workspace.prefabs.mtkc_r:clone()
newmodel4390:PivotTo(CFrame.new(-11.549127369325994, 5.670799999999999, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4390.Parent = workspace.devices.mtkcorners
newmodel4391 = workspace.prefabs.mtkc_l:clone()
newmodel4391:PivotTo(CFrame.new(-8.683793899801552, 5.554, 20.257737905393558) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4391.Parent = workspace.devices.mtkcorners
newmodel4392 = workspace.prefabs.mtkc_r:clone()
newmodel4392:PivotTo(CFrame.new(-11.549127369325994, 5.554, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4392.Parent = workspace.devices.mtkcorners
newmodel4393 = workspace.prefabs.mtkc_b:clone()
newmodel4393:PivotTo(CFrame.new(-11.549127369325994, 5.554, 24.800757772038917) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4393.Parent = workspace.devices.mtkcorners
newmodel4394 = workspace.prefabs.mtkc_l:clone()
newmodel4394:PivotTo(CFrame.new(-8.683793899801552, 5.4372, 20.257737905393558) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4394.Parent = workspace.devices.mtkcorners
newmodel4395 = workspace.prefabs.mtkc_r:clone()
newmodel4395:PivotTo(CFrame.new(-11.484678127857341, 5.4372, 24.70334865914841) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4395.Parent = workspace.devices.mtkcorners
newmodel4396 = workspace.prefabs.mtkc_l:clone()
newmodel4396:PivotTo(CFrame.new(-8.683793899801552, 5.320399999999999, 20.257737905393558) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4396.Parent = workspace.devices.mtkcorners
newmodel4397 = workspace.prefabs.mtkc_b:clone()
newmodel4397:PivotTo(CFrame.new(-8.683793899801552, 5.320399999999999, 20.257737905393558) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4397.Parent = workspace.devices.mtkcorners
newmodel4398 = workspace.prefabs.mtkc_r:clone()
newmodel4398:PivotTo(CFrame.new(-11.484678127857341, 5.320399999999999, 24.70334865914841) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4398.Parent = workspace.devices.mtkcorners
newmodel4399 = workspace.prefabs.mtkc_b:clone()
newmodel4399:PivotTo(CFrame.new(-11.484678127857341, 5.320399999999999, 24.70334865914841) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4399.Parent = workspace.devices.mtkcorners
newmodel4400 = workspace.prefabs.mtkc_l:clone()
newmodel4400:PivotTo(CFrame.new(-8.743932872297467, 5.2036, 20.35786554387133) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4400.Parent = workspace.devices.mtkcorners
newmodel4401 = workspace.prefabs.mtkc_r:clone()
newmodel4401:PivotTo(CFrame.new(-11.420228886388688, 5.2036, 24.605939546257904) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4401.Parent = workspace.devices.mtkcorners
newmodel4402 = workspace.prefabs.mtkc_l:clone()
newmodel4402:PivotTo(CFrame.new(-8.743932872297467, 5.086799999999999, 20.35786554387133) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4402.Parent = workspace.devices.mtkcorners
newmodel4403 = workspace.prefabs.mtkc_b:clone()
newmodel4403:PivotTo(CFrame.new(-8.743932872297467, 5.086799999999999, 20.35786554387133) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4403.Parent = workspace.devices.mtkcorners
newmodel4404 = workspace.prefabs.mtkc_r:clone()
newmodel4404:PivotTo(CFrame.new(-11.420228886388688, 5.086799999999999, 24.605939546257904) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4404.Parent = workspace.devices.mtkcorners
newmodel4405 = workspace.prefabs.mtkc_b:clone()
newmodel4405:PivotTo(CFrame.new(-11.420228886388688, 5.086799999999999, 24.605939546257904) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4405.Parent = workspace.devices.mtkcorners
newmodel4406 = workspace.prefabs.mtkc_l:clone()
newmodel4406:PivotTo(CFrame.new(-8.804071844793382, 4.97, 20.457993182349103) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4406.Parent = workspace.devices.mtkcorners
newmodel4407 = workspace.prefabs.mtkc_r:clone()
newmodel4407:PivotTo(CFrame.new(-11.355779644920037, 4.97, 24.508530433367397) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4407.Parent = workspace.devices.mtkcorners
newmodel4408 = workspace.prefabs.mtkc_l:clone()
newmodel4408:PivotTo(CFrame.new(-8.804071844793382, 4.8532, 20.457993182349103) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4408.Parent = workspace.devices.mtkcorners
newmodel4409 = workspace.prefabs.mtkc_b:clone()
newmodel4409:PivotTo(CFrame.new(-8.804071844793382, 4.8532, 20.457993182349103) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4409.Parent = workspace.devices.mtkcorners
newmodel4410 = workspace.prefabs.mtkc_r:clone()
newmodel4410:PivotTo(CFrame.new(-11.355779644920037, 4.8532, 24.508530433367397) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4410.Parent = workspace.devices.mtkcorners
newmodel4411 = workspace.prefabs.mtkc_b:clone()
newmodel4411:PivotTo(CFrame.new(-11.355779644920037, 4.8532, 24.508530433367397) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4411.Parent = workspace.devices.mtkcorners
newmodel4412 = workspace.prefabs.mtkc_l:clone()
newmodel4412:PivotTo(CFrame.new(-8.864210817289297, 4.7364, 20.558120820826876) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4412.Parent = workspace.devices.mtkcorners
newmodel4413 = workspace.prefabs.mtkc_b:clone()
newmodel4413:PivotTo(CFrame.new(-8.864210817289297, 4.7364, 20.558120820826876) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4413.Parent = workspace.devices.mtkcorners
newmodel4414 = workspace.prefabs.mtkc_r:clone()
newmodel4414:PivotTo(CFrame.new(-11.291330403451383, 4.7364, 24.41112132047689) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4414.Parent = workspace.devices.mtkcorners
newmodel4415 = workspace.prefabs.mtkc_b:clone()
newmodel4415:PivotTo(CFrame.new(-11.291330403451383, 4.7364, 24.41112132047689) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4415.Parent = workspace.devices.mtkcorners
newmodel4416 = workspace.prefabs.mtkc_l:clone()
newmodel4416:PivotTo(CFrame.new(-8.924349789785213, 4.619599999999999, 20.658248459304648) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4416.Parent = workspace.devices.mtkcorners
newmodel4417 = workspace.prefabs.mtkc_b:clone()
newmodel4417:PivotTo(CFrame.new(-8.924349789785213, 4.619599999999999, 20.658248459304648) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4417.Parent = workspace.devices.mtkcorners
newmodel4418 = workspace.prefabs.mtkc_r:clone()
newmodel4418:PivotTo(CFrame.new(-11.226881161982732, 4.619599999999999, 24.313712207586384) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4418.Parent = workspace.devices.mtkcorners
newmodel4419 = workspace.prefabs.mtkc_b:clone()
newmodel4419:PivotTo(CFrame.new(-11.226881161982732, 4.619599999999999, 24.313712207586384) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4419.Parent = workspace.devices.mtkcorners
newmodel4420 = workspace.prefabs.mtkc_l:clone()
newmodel4420:PivotTo(CFrame.new(-8.984488762281128, 4.5028, 20.75837609778242) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4420.Parent = workspace.devices.mtkcorners
newmodel4421 = workspace.prefabs.mtkc_b:clone()
newmodel4421:PivotTo(CFrame.new(-8.984488762281128, 4.5028, 20.75837609778242) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4421.Parent = workspace.devices.mtkcorners
newmodel4422 = workspace.prefabs.mtkc_r:clone()
newmodel4422:PivotTo(CFrame.new(-11.162431920514079, 4.5028, 24.21630309469588) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4422.Parent = workspace.devices.mtkcorners
newmodel4423 = workspace.prefabs.mtkc_b:clone()
newmodel4423:PivotTo(CFrame.new(-11.162431920514079, 4.5028, 24.21630309469588) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4423.Parent = workspace.devices.mtkcorners
newmodel4424 = workspace.prefabs.mtkc_l:clone()
newmodel4424:PivotTo(CFrame.new(-9.044627734777043, 4.385999999999999, 20.858503736260193) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4424.Parent = workspace.devices.mtkcorners
newmodel4425 = workspace.prefabs.mtkc_b:clone()
newmodel4425:PivotTo(CFrame.new(-9.044627734777043, 4.385999999999999, 20.858503736260193) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4425.Parent = workspace.devices.mtkcorners
newmodel4426 = workspace.prefabs.mtkc_r:clone()
newmodel4426:PivotTo(CFrame.new(-11.097982679045426, 4.385999999999999, 24.118893981805375) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4426.Parent = workspace.devices.mtkcorners
newmodel4427 = workspace.prefabs.mtkc_b:clone()
newmodel4427:PivotTo(CFrame.new(-11.097982679045426, 4.385999999999999, 24.118893981805375) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4427.Parent = workspace.devices.mtkcorners
newmodel4428 = workspace.prefabs.mtkc_l:clone()
newmodel4428:PivotTo(CFrame.new(-9.104766707272958, 4.2692, 20.958631374737966) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4428.Parent = workspace.devices.mtkcorners
newmodel4429 = workspace.prefabs.mtkc_b:clone()
newmodel4429:PivotTo(CFrame.new(-9.104766707272958, 4.2692, 20.958631374737966) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4429.Parent = workspace.devices.mtkcorners
newmodel4430 = workspace.prefabs.mtkc_r:clone()
newmodel4430:PivotTo(CFrame.new(-11.033533437576775, 4.2692, 24.021484868914868) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4430.Parent = workspace.devices.mtkcorners
newmodel4431 = workspace.prefabs.mtkc_b:clone()
newmodel4431:PivotTo(CFrame.new(-11.033533437576775, 4.2692, 24.021484868914868) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4431.Parent = workspace.devices.mtkcorners
newmodel4432 = workspace.prefabs.mtkc_l:clone()
newmodel4432:PivotTo(CFrame.new(-9.164905679768873, 4.1524, 21.058759013215738) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4432.Parent = workspace.devices.mtkcorners
newmodel4433 = workspace.prefabs.mtkc_b:clone()
newmodel4433:PivotTo(CFrame.new(-9.164905679768873, 4.1524, 21.058759013215738) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4433.Parent = workspace.devices.mtkcorners
newmodel4434 = workspace.prefabs.mtkc_r:clone()
newmodel4434:PivotTo(CFrame.new(-10.969084196108122, 4.1524, 23.92407575602436) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4434.Parent = workspace.devices.mtkcorners
newmodel4435 = workspace.prefabs.mtkc_b:clone()
newmodel4435:PivotTo(CFrame.new(-10.969084196108122, 4.1524, 23.92407575602436) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4435.Parent = workspace.devices.mtkcorners
newmodel4436 = workspace.prefabs.mtkc_l:clone()
newmodel4436:PivotTo(CFrame.new(-9.225044652264788, 4.0356, 21.15888665169351) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4436.Parent = workspace.devices.mtkcorners
newmodel4437 = workspace.prefabs.mtkc_b:clone()
newmodel4437:PivotTo(CFrame.new(-9.225044652264788, 4.0356, 21.15888665169351) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4437.Parent = workspace.devices.mtkcorners
newmodel4438 = workspace.prefabs.mtkc_b:clone()
newmodel4438:PivotTo(CFrame.new(-9.285183624760704, 4.0356, 21.259014290171287) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4438.Parent = workspace.devices.mtkcorners
newmodel4439 = workspace.prefabs.mtkc_b:clone()
newmodel4439:PivotTo(CFrame.new(-10.840185713170818, 4.0356, 23.729257530243352) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4439.Parent = workspace.devices.mtkcorners
newmodel4440 = workspace.prefabs.mtkc_r:clone()
newmodel4440:PivotTo(CFrame.new(-10.90463495463947, 4.0356, 23.826666643133855) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4440.Parent = workspace.devices.mtkcorners
newmodel4441 = workspace.prefabs.mtkc_b:clone()
newmodel4441:PivotTo(CFrame.new(-10.90463495463947, 4.0356, 23.826666643133855) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4441.Parent = workspace.devices.mtkcorners
newmodel4442 = workspace.prefabs.mtkc_l:clone()
newmodel4442:PivotTo(CFrame.new(-9.345322597256619, 3.918799999999999, 21.35914192864906) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4442.Parent = workspace.devices.mtkcorners
newmodel4443 = workspace.prefabs.mtkc_b:clone()
newmodel4443:PivotTo(CFrame.new(-9.345322597256619, 3.918799999999999, 21.35914192864906) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4443.Parent = workspace.devices.mtkcorners
newmodel4444 = workspace.prefabs.mtkc_b:clone()
newmodel4444:PivotTo(CFrame.new(-9.405461569752534, 3.918799999999999, 21.45926956712683) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4444.Parent = workspace.devices.mtkcorners
newmodel4445 = workspace.prefabs.mtkc_b:clone()
newmodel4445:PivotTo(CFrame.new(-10.711287230233513, 3.918799999999999, 23.53443930446234) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4445.Parent = workspace.devices.mtkcorners
newmodel4446 = workspace.prefabs.mtkc_r:clone()
newmodel4446:PivotTo(CFrame.new(-10.775736471702166, 3.918799999999999, 23.631848417352845) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4446.Parent = workspace.devices.mtkcorners
newmodel4447 = workspace.prefabs.mtkc_b:clone()
newmodel4447:PivotTo(CFrame.new(-10.775736471702166, 3.918799999999999, 23.631848417352845) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4447.Parent = workspace.devices.mtkcorners
newmodel4448 = workspace.prefabs.mtkc_l:clone()
newmodel4448:PivotTo(CFrame.new(-9.465600542248449, 3.801999999999999, 21.559397205604604) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4448.Parent = workspace.devices.mtkcorners
newmodel4449 = workspace.prefabs.mtkc_b:clone()
newmodel4449:PivotTo(CFrame.new(-9.465600542248449, 3.801999999999999, 21.559397205604604) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4449.Parent = workspace.devices.mtkcorners
newmodel4450 = workspace.prefabs.mtkc_b:clone()
newmodel4450:PivotTo(CFrame.new(-9.525739514744364, 3.801999999999999, 21.659524844082377) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4450.Parent = workspace.devices.mtkcorners
newmodel4451 = workspace.prefabs.mtkc_b:clone()
newmodel4451:PivotTo(CFrame.new(-10.517939505827556, 3.801999999999999, 23.24221196579082) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4451.Parent = workspace.devices.mtkcorners
newmodel4452 = workspace.prefabs.mtkc_b:clone()
newmodel4452:PivotTo(CFrame.new(-10.582388747296209, 3.801999999999999, 23.339621078681326) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4452.Parent = workspace.devices.mtkcorners
newmodel4453 = workspace.prefabs.mtkc_r:clone()
newmodel4453:PivotTo(CFrame.new(-10.64683798876486, 3.801999999999999, 23.437030191571832) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4453.Parent = workspace.devices.mtkcorners
newmodel4454 = workspace.prefabs.mtkc_b:clone()
newmodel4454:PivotTo(CFrame.new(-10.64683798876486, 3.801999999999999, 23.437030191571832) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4454.Parent = workspace.devices.mtkcorners
newmodel4455 = workspace.prefabs.mtkc_l:clone()
newmodel4455:PivotTo(CFrame.new(-9.58587848724028, 3.685199999999999, 21.75965248256015) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4455.Parent = workspace.devices.mtkcorners
newmodel4456 = workspace.prefabs.mtkc_b:clone()
newmodel4456:PivotTo(CFrame.new(-9.58587848724028, 3.685199999999999, 21.75965248256015) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4456.Parent = workspace.devices.mtkcorners
newmodel4457 = workspace.prefabs.mtkc_b:clone()
newmodel4457:PivotTo(CFrame.new(-9.646017459736195, 3.685199999999999, 21.85978012103792) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4457.Parent = workspace.devices.mtkcorners
newmodel4458 = workspace.prefabs.mtkc_b:clone()
newmodel4458:PivotTo(CFrame.new(-9.70615643223211, 3.685199999999999, 21.959907759515694) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4458.Parent = workspace.devices.mtkcorners
newmodel4459 = workspace.prefabs.mtkc_b:clone()
newmodel4459:PivotTo(CFrame.new(-9.766295404728025, 3.685199999999999, 22.060035397993467) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4459.Parent = workspace.devices.mtkcorners
newmodel4460 = workspace.prefabs.mtkc_b:clone()
newmodel4460:PivotTo(CFrame.new(-9.82643437722394, 3.685199999999999, 22.16016303647124) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4460.Parent = workspace.devices.mtkcorners
newmodel4461 = workspace.prefabs.mtkc_b:clone()
newmodel4461:PivotTo(CFrame.new(-9.886573349719855, 3.685199999999999, 22.26029067494901) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4461.Parent = workspace.devices.mtkcorners
newmodel4462 = workspace.prefabs.mtkc_b:clone()
newmodel4462:PivotTo(CFrame.new(-9.94671232221577, 3.685199999999999, 22.360418313426784) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4462.Parent = workspace.devices.mtkcorners
newmodel4463 = workspace.prefabs.mtkc_b:clone()
newmodel4463:PivotTo(CFrame.new(-10.006851294711685, 3.685199999999999, 22.460545951904557) * CFrame.fromEulerAngles(0, math.rad(-30.990000000000002), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4463.Parent = workspace.devices.mtkcorners
newmodel4464 = workspace.prefabs.mtkc_b:clone()
newmodel4464:PivotTo(CFrame.new(-10.06679481554699, 3.685199999999999, 22.560348175557277) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4464.Parent = workspace.devices.mtkcorners
newmodel4465 = workspace.prefabs.mtkc_b:clone()
newmodel4465:PivotTo(CFrame.new(-10.13124405701564, 3.685199999999999, 22.657757288447783) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4465.Parent = workspace.devices.mtkcorners
newmodel4466 = workspace.prefabs.mtkc_b:clone()
newmodel4466:PivotTo(CFrame.new(-10.195693298484294, 3.685199999999999, 22.75516640133829) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4466.Parent = workspace.devices.mtkcorners
newmodel4467 = workspace.prefabs.mtkc_b:clone()
newmodel4467:PivotTo(CFrame.new(-10.260142539952946, 3.685199999999999, 22.852575514228796) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4467.Parent = workspace.devices.mtkcorners
newmodel4468 = workspace.prefabs.mtkc_b:clone()
newmodel4468:PivotTo(CFrame.new(-10.3245917814216, 3.685199999999999, 22.949984627119303) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4468.Parent = workspace.devices.mtkcorners
newmodel4469 = workspace.prefabs.mtkc_b:clone()
newmodel4469:PivotTo(CFrame.new(-10.38904102289025, 3.685199999999999, 23.04739374000981) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4469.Parent = workspace.devices.mtkcorners
newmodel4470 = workspace.prefabs.mtkc_r:clone()
newmodel4470:PivotTo(CFrame.new(-10.453490264358903, 3.685199999999999, 23.144802852900312) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4470.Parent = workspace.devices.mtkcorners
newmodel4471 = workspace.prefabs.mtkc_b:clone()
newmodel4471:PivotTo(CFrame.new(-10.453490264358903, 3.685199999999999, 23.144802852900312) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(0, math.rad(180), math.rad(-90)))
newmodel4471.Parent = workspace.devices.mtkcorners
