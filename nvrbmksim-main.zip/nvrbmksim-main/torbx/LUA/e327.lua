newmodel0 = workspace.prefabs.e327:clone()
newmodel0:PivotTo(CFrame.new(-68.16121717422666, 4.356800000000001, 27.071537535078875) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel0.Parent = workspace.devices.e327
newmodel1 = workspace.prefabs.e327:clone()
newmodel1:PivotTo(CFrame.new(-67.5156320243497, 3.8428800000000005, 27.87133430917736) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel1.Parent = workspace.devices.e327
