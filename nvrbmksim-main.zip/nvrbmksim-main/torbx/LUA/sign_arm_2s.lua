newmodel0 = workspace.prefabs.sign_arm_2s:clone()
newmodel0:PivotTo(CFrame.new(-49.05720506981505, 2.7393257871070857, 33.92130454928956) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.sign_arm_2s
newmodel1 = workspace.prefabs.sign_arm_2s:clone()
newmodel1:PivotTo(CFrame.new(-48.452739150794564, 2.684609217293657, 33.42869096802174) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.devices.sign_arm_2s
newmodel2 = workspace.prefabs.sign_arm_2s:clone()
newmodel2:PivotTo(CFrame.new(-48.567406199093, 2.6846093647103415, 33.399787720575546) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.sign_arm_2s
newmodel3 = workspace.prefabs.sign_arm_2s:clone()
newmodel3:PivotTo(CFrame.new(-48.55460673314372, 2.6800284873939506, 33.34901684234909) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.sign_arm_2s
newmodel4 = workspace.prefabs.sign_arm_2s:clone()
newmodel4:PivotTo(CFrame.new(-48.43993307040882, 2.6800285403605155, 33.37792504212149) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.sign_arm_2s
newmodel5 = workspace.prefabs.sign_arm_2s:clone()
newmodel5:PivotTo(CFrame.new(-48.541811937211925, 2.6754474573807254, 33.29824298710056) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.sign_arm_2s
newmodel6 = workspace.prefabs.sign_arm_2s:clone()
newmodel6:PivotTo(CFrame.new(-48.42713659055638, 2.6754476213355916, 33.32714867911331) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.devices.sign_arm_2s
newmodel7 = workspace.prefabs.sign_arm_2s:clone()
newmodel7:PivotTo(CFrame.new(-48.52901576123716, 2.6708671027981756, 33.247476691352816) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.devices.sign_arm_2s
newmodel8 = workspace.prefabs.sign_arm_2s:clone()
newmodel8:PivotTo(CFrame.new(-48.41434172352828, 2.6708665658728896, 33.276374541798035) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.devices.sign_arm_2s
newmodel9 = workspace.prefabs.sign_arm_2s:clone()
newmodel9:PivotTo(CFrame.new(-48.7358833754883, 2.6846092199194644, 33.35732190428305) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.devices.sign_arm_2s
newmodel10 = workspace.prefabs.sign_arm_2s:clone()
newmodel10:PivotTo(CFrame.new(-48.85055143045851, 2.6846093537313545, 33.32841781003151) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.devices.sign_arm_2s
newmodel11 = workspace.prefabs.sign_arm_2s:clone()
newmodel11:PivotTo(CFrame.new(-48.837749665849806, 2.6800284986519824, 33.27764869641033) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.devices.sign_arm_2s
newmodel12 = workspace.prefabs.sign_arm_2s:clone()
newmodel12:PivotTo(CFrame.new(-48.72307662054185, 2.6800285091837743, 33.30655289412618) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.sign_arm_2s
newmodel13 = workspace.prefabs.sign_arm_2s:clone()
newmodel13:PivotTo(CFrame.new(-48.824955083051734, 2.675447445675552, 33.22687448791383) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.sign_arm_2s
newmodel14 = workspace.prefabs.sign_arm_2s:clone()
newmodel14:PivotTo(CFrame.new(-48.71027938267218, 2.675447448022299, 33.25578023916282) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.sign_arm_2s
newmodel15 = workspace.prefabs.sign_arm_2s:clone()
newmodel15:PivotTo(CFrame.new(-48.81216099260268, 2.6708670918192157, 33.17610678080878) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.sign_arm_2s
newmodel16 = workspace.prefabs.sign_arm_2s:clone()
newmodel16:PivotTo(CFrame.new(-48.69748695489379, 2.670866554893929, 33.205004631254) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.sign_arm_2s
newmodel17 = workspace.prefabs.sign_arm_2s:clone()
newmodel17:PivotTo(CFrame.new(-47.9108382134862, 2.653306555244857, 33.196296187916715) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel17.Parent = workspace.devices.sign_arm_2s
newmodel18 = workspace.prefabs.sign_arm_2s:clone()
newmodel18:PivotTo(CFrame.new(-49.05765019563152, 2.6016441171737554, 32.29826322744117) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel18.Parent = workspace.devices.sign_arm_2s
newmodel19 = workspace.prefabs.sign_arm_2s:clone()
newmodel19:PivotTo(CFrame.new(-17.78731145695143, 2.7133673206871234, 23.3233943625455) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel19.Parent = workspace.devices.sign_arm_2s
newmodel20 = workspace.prefabs.sign_arm_2s:clone()
newmodel20:PivotTo(CFrame.new(-18.758773130637785, 2.7133673206871234, 24.458942225435656) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel20.Parent = workspace.devices.sign_arm_2s
newmodel21 = workspace.prefabs.sign_arm_2s:clone()
newmodel21:PivotTo(CFrame.new(-20.153263930577612, 2.674938610594826, 25.272668397139007) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel21.Parent = workspace.devices.sign_arm_2s
newmodel22 = workspace.prefabs.sign_arm_2s:clone()
newmodel22:PivotTo(CFrame.new(-53.18993614840384, 2.746197145865311, 32.531989709329984) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.sign_arm_2s
newmodel23 = workspace.prefabs.sign_arm_2s:clone()
newmodel23:PivotTo(CFrame.new(-53.30926904169668, 2.746197145865311, 32.47698406799785) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel23.Parent = workspace.devices.sign_arm_2s
newmodel24 = workspace.prefabs.sign_arm_2s:clone()
newmodel24:PivotTo(CFrame.new(-36.54200868601842, 2.7278734432390936, 34.33511099214972) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.sign_arm_2s
newmodel25 = workspace.prefabs.sign_arm_2s:clone()
newmodel25:PivotTo(CFrame.new(-36.724574304761674, 2.727873443920145, 34.35769574418633) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.sign_arm_2s
newmodel26 = workspace.prefabs.sign_arm_2s:clone()
newmodel26:PivotTo(CFrame.new(-36.572369447443954, 2.706241505478292, 34.08972480439643) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.sign_arm_2s
newmodel27 = workspace.prefabs.sign_arm_2s:clone()
newmodel27:PivotTo(CFrame.new(-36.75493674930965, 2.706241502473824, 34.112311816015605) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel27.Parent = workspace.devices.sign_arm_2s
newmodel28 = workspace.prefabs.sign_arm_2s:clone()
newmodel28:PivotTo(CFrame.new(-36.69621543393899, 2.6861364716300087, 33.873488718745655) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel28.Parent = workspace.devices.sign_arm_2s
newmodel29 = workspace.prefabs.sign_arm_2s:clone()
newmodel29:PivotTo(CFrame.new(-36.7213972287022, 2.6681944567594273, 33.669967822683816) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel29.Parent = workspace.devices.sign_arm_2s
newmodel30 = workspace.prefabs.sign_arm_2s:clone()
newmodel30:PivotTo(CFrame.new(-36.74657727334086, 2.6502526416028855, 33.46643997039125) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel30.Parent = workspace.devices.sign_arm_2s
newmodel31 = workspace.prefabs.sign_arm_2s:clone()
newmodel31:PivotTo(CFrame.new(-58.387514030906566, 2.7393257871070857, 29.478861478036777) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel31.Parent = workspace.devices.sign_arm_2s
newmodel32 = workspace.prefabs.sign_arm_2s:clone()
newmodel32:PivotTo(CFrame.new(-57.64581600739414, 2.6846092822675236, 29.238175998983696) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel32.Parent = workspace.devices.sign_arm_2s
newmodel33 = workspace.prefabs.sign_arm_2s:clone()
newmodel33:PivotTo(CFrame.new(-57.74227027423671, 2.68460935509279, 29.169761102816047) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel33.Parent = workspace.devices.sign_arm_2s
newmodel34 = workspace.prefabs.sign_arm_2s:clone()
newmodel34:PivotTo(CFrame.new(-57.71197803982396, 2.680028592966859, 29.127058523771858) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel34.Parent = workspace.devices.sign_arm_2s
newmodel35 = workspace.prefabs.sign_arm_2s:clone()
newmodel35:PivotTo(CFrame.new(-57.61551674782952, 2.680028501142512, 29.195472031566055) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel35.Parent = workspace.devices.sign_arm_2s
newmodel36 = workspace.prefabs.sign_arm_2s:clone()
newmodel36:PivotTo(CFrame.new(-57.681689797508916, 2.675447536845569, 29.084346168032337) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel36.Parent = workspace.devices.sign_arm_2s
newmodel37 = workspace.prefabs.sign_arm_2s:clone()
newmodel37:PivotTo(CFrame.new(-57.58522386733937, 2.6754475717142188, 29.152763075960674) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel37.Parent = workspace.devices.sign_arm_2s
newmodel38 = workspace.prefabs.sign_arm_2s:clone()
newmodel38:PivotTo(CFrame.new(-57.65140165305953, 2.670867199563274, 29.04164406838025) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel38.Parent = workspace.devices.sign_arm_2s
newmodel39 = workspace.prefabs.sign_arm_2s:clone()
newmodel39:PivotTo(CFrame.new(-57.55493841466493, 2.670866682895353, 29.110055576413636) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel39.Parent = workspace.devices.sign_arm_2s
newmodel40 = workspace.prefabs.sign_arm_2s:clone()
newmodel40:PivotTo(CFrame.new(-57.88399239275877, 2.684609363999016, 29.069247639502166) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel40.Parent = workspace.devices.sign_arm_2s
newmodel41 = workspace.prefabs.sign_arm_2s:clone()
newmodel41:PivotTo(CFrame.new(-57.98044276585598, 2.68460935509279, 29.000832089328124) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel41.Parent = workspace.devices.sign_arm_2s
newmodel42 = workspace.prefabs.sign_arm_2s:clone()
newmodel42:PivotTo(CFrame.new(-57.95015076961691, 2.680028592966859, 28.958129341354088) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel42.Parent = workspace.devices.sign_arm_2s
newmodel43 = workspace.prefabs.sign_arm_2s:clone()
newmodel43:PivotTo(CFrame.new(-57.853692098975934, 2.6800286429953557, 29.026547468073375) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel43.Parent = workspace.devices.sign_arm_2s
newmodel44 = workspace.prefabs.sign_arm_2s:clone()
newmodel44:PivotTo(CFrame.new(-57.91986467086501, 2.675447536845569, 28.915415465245836) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel44.Parent = workspace.devices.sign_arm_2s
newmodel45 = workspace.prefabs.sign_arm_2s:clone()
newmodel45:PivotTo(CFrame.new(-57.82339945665951, 2.675447713567104, 28.983838343538146) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel45.Parent = workspace.devices.sign_arm_2s
newmodel46 = workspace.prefabs.sign_arm_2s:clone()
newmodel46:PivotTo(CFrame.new(-57.88957652641562, 2.670867199563274, 28.872713365593754) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel46.Parent = workspace.devices.sign_arm_2s
newmodel47 = workspace.prefabs.sign_arm_2s:clone()
newmodel47:PivotTo(CFrame.new(-57.79311043229072, 2.670866544881598, 28.94112042428452) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel47.Parent = workspace.devices.sign_arm_2s
newmodel48 = workspace.prefabs.sign_arm_2s:clone()
newmodel48:PivotTo(CFrame.new(-57.05654808883919, 2.653306555244857, 29.217473348224893) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel48.Parent = workspace.devices.sign_arm_2s
newmodel49 = workspace.prefabs.sign_arm_2s:clone()
newmodel49:PivotTo(CFrame.new(-57.8009974120609, 2.6016441171737554, 27.965500454889217) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel49.Parent = workspace.devices.sign_arm_2s
newmodel50 = workspace.prefabs.sign_arm_2s:clone()
newmodel50:PivotTo(CFrame.new(-61.73820976507054, 2.746197145865311, 26.689136862409065) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel50.Parent = workspace.devices.sign_arm_2s
newmodel51 = workspace.prefabs.sign_arm_2s:clone()
newmodel51:PivotTo(CFrame.new(-61.82957527035654, 2.746197145865311, 26.594700087560312) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel51.Parent = workspace.devices.sign_arm_2s
newmodel52 = workspace.prefabs.sign_arm_2s:clone()
newmodel52:PivotTo(CFrame.new(-62.69354655966969, 2.6713757918218413, 24.39674694132636) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel52.Parent = workspace.devices.sign_arm_2s
newmodel53 = workspace.prefabs.sign_arm_2s:clone()
newmodel53:PivotTo(CFrame.new(-63.43015907503058, 2.6713759101197527, 23.479049110886272) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel53.Parent = workspace.devices.sign_arm_2s
newmodel54 = workspace.prefabs.sign_arm_2s:clone()
newmodel54:PivotTo(CFrame.new(-69.52438302052063, 3.40488, 25.318512202707243) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel54.Parent = workspace.devices.sign_arm_2s
newmodel55 = workspace.prefabs.sign_arm_2s:clone()
newmodel55:PivotTo(CFrame.new(-69.7024123502696, 3.40488, 25.051166925752053) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel55.Parent = workspace.devices.sign_arm_2s
newmodel56 = workspace.prefabs.sign_arm_2s:clone()
newmodel56:PivotTo(CFrame.new(-70.04875832634104, 3.40488, 24.53104784471864) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel56.Parent = workspace.devices.sign_arm_2s
newmodel57 = workspace.prefabs.sign_arm_2s:clone()
newmodel57:PivotTo(CFrame.new(-70.22679132532821, 3.40488, 24.263697293153847) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel57.Parent = workspace.devices.sign_arm_2s
newmodel58 = workspace.prefabs.sign_arm_2s:clone()
newmodel58:PivotTo(CFrame.new(-70.57313918121098, 3.40488, 23.74358402453285) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel58.Parent = workspace.devices.sign_arm_2s
newmodel59 = workspace.prefabs.sign_arm_2s:clone()
newmodel59:PivotTo(CFrame.new(-70.75117160181256, 3.40488, 23.476239051715798) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel59.Parent = workspace.devices.sign_arm_2s
newmodel60 = workspace.prefabs.sign_arm_2s:clone()
newmodel60:PivotTo(CFrame.new(-69.52438302052063, 2.7383374400000005, 25.318512202707243) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel60.Parent = workspace.devices.sign_arm_2s
newmodel61 = workspace.prefabs.sign_arm_2s:clone()
newmodel61:PivotTo(CFrame.new(-69.7024123502696, 2.7383374400000005, 25.051166925752053) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel61.Parent = workspace.devices.sign_arm_2s
newmodel62 = workspace.prefabs.sign_arm_2s:clone()
newmodel62:PivotTo(CFrame.new(-70.04875847120647, 2.7383374400000005, 24.531047941185832) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel62.Parent = workspace.devices.sign_arm_2s
newmodel63 = workspace.prefabs.sign_arm_2s:clone()
newmodel63:PivotTo(CFrame.new(-70.22679147019355, 2.7383374400000005, 24.26369738962097) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel63.Parent = workspace.devices.sign_arm_2s
newmodel64 = workspace.prefabs.sign_arm_2s:clone()
newmodel64:PivotTo(CFrame.new(-70.57313918121098, 2.7383374400000005, 23.74358402453285) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel64.Parent = workspace.devices.sign_arm_2s
newmodel65 = workspace.prefabs.sign_arm_2s:clone()
newmodel65:PivotTo(CFrame.new(-70.75117160181256, 2.7383374400000005, 23.476239051715798) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel65.Parent = workspace.devices.sign_arm_2s
newmodel66 = workspace.prefabs.sign_arm_2s:clone()
newmodel66:PivotTo(CFrame.new(-71.23377122998873, 4.894080000000001, 22.691321137934587) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel66.Parent = workspace.devices.sign_arm_2s
newmodel67 = workspace.prefabs.sign_arm_2s:clone()
newmodel67:PivotTo(CFrame.new(-71.23377122998873, 4.246937920000001, 22.691321137934587) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel67.Parent = workspace.devices.sign_arm_2s
newmodel68 = workspace.prefabs.sign_arm_2s:clone()
newmodel68:PivotTo(CFrame.new(-71.4874019060226, 4.246937920000001, 22.222424562732762) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel68.Parent = workspace.devices.sign_arm_2s
newmodel69 = workspace.prefabs.sign_arm_2s:clone()
newmodel69:PivotTo(CFrame.new(-72.1147480936165, 4.246937920000001, 21.062665977017524) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel69.Parent = workspace.devices.sign_arm_2s
newmodel70 = workspace.prefabs.sign_arm_2s:clone()
newmodel70:PivotTo(CFrame.new(-71.4874019060226, 2.9650579200000005, 22.222424562732762) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel70.Parent = workspace.devices.sign_arm_2s
newmodel71 = workspace.prefabs.sign_arm_2s:clone()
newmodel71:PivotTo(CFrame.new(-71.99466963848752, 2.9650579200000005, 21.284653454632757) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel71.Parent = workspace.devices.sign_arm_2s
newmodel72 = workspace.prefabs.sign_arm_2s:clone()
newmodel72:PivotTo(CFrame.new(-72.1147480936165, 2.9650579200000005, 21.062665977017524) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel72.Parent = workspace.devices.sign_arm_2s
newmodel73 = workspace.prefabs.sign_arm_2s:clone()
newmodel73:PivotTo(CFrame.new(-71.60679373693478, 2.9650579200000005, 22.001728572139157) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel73.Parent = workspace.devices.sign_arm_2s
newmodel74 = workspace.prefabs.sign_arm_2s:clone()
newmodel74:PivotTo(CFrame.new(-71.86033657915671, 2.9650579200000005, 21.533007909498764) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel74.Parent = workspace.devices.sign_arm_2s
newmodel75 = workspace.prefabs.sign_arm_2s:clone()
newmodel75:PivotTo(CFrame.new(-71.74085640695444, 2.9650579200000005, 21.75388020211106) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel75.Parent = workspace.devices.sign_arm_2s
newmodel76 = workspace.prefabs.sign_arm_2s:clone()
newmodel76:PivotTo(CFrame.new(-71.4874019060226, 4.894080000000001, 22.222424562732762) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel76.Parent = workspace.devices.sign_arm_2s
newmodel77 = workspace.prefabs.sign_arm_2s:clone()
newmodel77:PivotTo(CFrame.new(-71.7410331992261, 4.894080000000001, 21.753544588494446) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel77.Parent = workspace.devices.sign_arm_2s
newmodel78 = workspace.prefabs.sign_arm_2s:clone()
newmodel78:PivotTo(CFrame.new(-71.99466963848752, 4.894080000000001, 21.284653454632757) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel78.Parent = workspace.devices.sign_arm_2s
newmodel79 = workspace.prefabs.sign_arm_2s:clone()
newmodel79:PivotTo(CFrame.new(-72.24829815625752, 4.894080000000001, 20.815773307025406) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel79.Parent = workspace.devices.sign_arm_2s
newmodel80 = workspace.prefabs.sign_arm_2s:clone()
newmodel80:PivotTo(CFrame.new(-71.23377122998873, 3.6122, 22.691321137934587) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel80.Parent = workspace.devices.sign_arm_2s
newmodel81 = workspace.prefabs.sign_arm_2s:clone()
newmodel81:PivotTo(CFrame.new(-71.4874019060226, 3.6122, 22.222424562732762) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel81.Parent = workspace.devices.sign_arm_2s
newmodel82 = workspace.prefabs.sign_arm_2s:clone()
newmodel82:PivotTo(CFrame.new(-71.7410331992261, 3.6122, 21.753544588494446) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel82.Parent = workspace.devices.sign_arm_2s
newmodel83 = workspace.prefabs.sign_arm_2s:clone()
newmodel83:PivotTo(CFrame.new(-71.99466963848752, 3.6122, 21.284653454632757) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel83.Parent = workspace.devices.sign_arm_2s
newmodel84 = workspace.prefabs.sign_arm_2s:clone()
newmodel84:PivotTo(CFrame.new(-72.24829815625752, 3.6122, 20.815773307025406) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel84.Parent = workspace.devices.sign_arm_2s
newmodel85 = workspace.prefabs.sign_arm_2s:clone()
newmodel85:PivotTo(CFrame.new(-71.99466963848752, 4.246937920000001, 21.284653454632757) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel85.Parent = workspace.devices.sign_arm_2s
newmodel86 = workspace.prefabs.sign_arm_2s:clone()
newmodel86:PivotTo(CFrame.new(-72.36742167164063, 4.246937920000001, 20.595555972568423) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel86.Parent = workspace.devices.sign_arm_2s
newmodel87 = workspace.prefabs.sign_arm_2s:clone()
newmodel87:PivotTo(CFrame.new(-72.24793888813805, 4.246937920000001, 20.81643382429052) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel87.Parent = workspace.devices.sign_arm_2s
newmodel88 = workspace.prefabs.sign_arm_2s:clone()
newmodel88:PivotTo(CFrame.new(-71.60679373693478, 4.246937920000001, 22.001728572139157) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel88.Parent = workspace.devices.sign_arm_2s
newmodel89 = workspace.prefabs.sign_arm_2s:clone()
newmodel89:PivotTo(CFrame.new(-71.35324550003688, 4.246937920000001, 22.470443660815576) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel89.Parent = workspace.devices.sign_arm_2s
