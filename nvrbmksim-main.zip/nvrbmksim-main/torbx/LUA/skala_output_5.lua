newmodel0 = workspace.prefabs.skala_output_5:clone()
newmodel0:PivotTo(CFrame.new(-11.957798279250024, 6.935160000000001, 25.344372923246283) * CFrame.fromEulerAngles(0, math.rad(51.260000999999995), 0))
newmodel0.Parent = workspace.devices.skala_output_5
newmodel1 = workspace.prefabs.skala_output_5:clone()
newmodel1:PivotTo(CFrame.new(-11.957798279250024, 6.71320788, 25.344372923246283) * CFrame.fromEulerAngles(0, math.rad(51.260000999999995), 0))
newmodel1.Parent = workspace.devices.skala_output_5
newmodel2 = workspace.prefabs.skala_output_5:clone()
newmodel2:PivotTo(CFrame.new(-20.185843266876834, 6.62272, 33.25735585131555) * CFrame.fromEulerAngles(0, math.rad(35.46), 0))
newmodel2.Parent = workspace.devices.skala_output_5
newmodel3 = workspace.prefabs.skala_output_5:clone()
newmodel3:PivotTo(CFrame.new(-20.185843266876834, 6.413939999999999, 33.25735585131555) * CFrame.fromEulerAngles(0, math.rad(35.46), 0))
newmodel3.Parent = workspace.devices.skala_output_5
newmodel4 = workspace.prefabs.skala_output_5:clone()
newmodel4:PivotTo(CFrame.new(-35.63710244096301, 4.826920000000001, 39.57293530846158) * CFrame.fromEulerAngles(0, math.rad(6.659989999999993), 0))
newmodel4.Parent = workspace.devices.skala_output_5
newmodel5 = workspace.prefabs.skala_output_5:clone()
newmodel5:PivotTo(CFrame.new(-35.63710244096301, 4.619600000000001, 39.57293530846158) * CFrame.fromEulerAngles(0, math.rad(6.659989999999993), 0))
newmodel5.Parent = workspace.devices.skala_output_5
newmodel6 = workspace.prefabs.skala_output_5:clone()
newmodel6:PivotTo(CFrame.new(-37.48169037101926, 4.619600000000001, 39.78831883311187) * CFrame.fromEulerAngles(0, math.rad(6.659989999999993), 0))
newmodel6.Parent = workspace.devices.skala_output_5
newmodel7 = workspace.prefabs.skala_output_5:clone()
newmodel7:PivotTo(CFrame.new(-37.48169037101926, 4.826920000000001, 39.78831883311187) * CFrame.fromEulerAngles(0, math.rad(6.659989999999993), 0))
newmodel7.Parent = workspace.devices.skala_output_5
newmodel8 = workspace.prefabs.skala_output_5:clone()
newmodel8:PivotTo(CFrame.new(-57.43906743716327, 4.7977194160000005, 35.90091168780331) * CFrame.fromEulerAngles(0, math.rad(-30.090000000000003), 0))
newmodel8.Parent = workspace.devices.skala_output_5
newmodel9 = workspace.prefabs.skala_output_5:clone()
newmodel9:PivotTo(CFrame.new(-57.43906743716327, 4.59332, 35.90091168780331) * CFrame.fromEulerAngles(0, math.rad(-30.090000000000003), 0))
newmodel9.Parent = workspace.devices.skala_output_5
newmodel10 = workspace.prefabs.skala_output_5:clone()
newmodel10:PivotTo(CFrame.new(-59.030760716075136, 4.7977194160000005, 34.97861166316013) * CFrame.fromEulerAngles(0, math.rad(-30.090000000000003), 0))
newmodel10.Parent = workspace.devices.skala_output_5
newmodel11 = workspace.prefabs.skala_output_5:clone()
newmodel11:PivotTo(CFrame.new(-59.030760716075136, 4.59332, 34.97861166316013) * CFrame.fromEulerAngles(0, math.rad(-30.090000000000003), 0))
newmodel11.Parent = workspace.devices.skala_output_5
