newmodel0 = workspace.prefabs.sign_arm_1s:clone()
newmodel0:PivotTo(CFrame.new(-19.939531655724718, 3.652466790782626, 26.770373177787228) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel0.Parent = workspace.devices.sign_arm_1s
newmodel1 = workspace.prefabs.sign_arm_1s:clone()
newmodel1:PivotTo(CFrame.new(-19.947302080450395, 3.5892027407291214, 26.762369549209495) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel1.Parent = workspace.devices.sign_arm_1s
newmodel2 = workspace.prefabs.sign_arm_1s:clone()
newmodel2:PivotTo(CFrame.new(-19.971319756875218, 3.3936593132910176, 26.737631060878325) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel2.Parent = workspace.devices.sign_arm_1s
newmodel3 = workspace.prefabs.sign_arm_1s:clone()
newmodel3:PivotTo(CFrame.new(-19.99533743330004, 3.1981158858529137, 26.71289257254715) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel3.Parent = workspace.devices.sign_arm_1s
newmodel4 = workspace.prefabs.sign_arm_1s:clone()
newmodel4:PivotTo(CFrame.new(-20.144236609590386, 3.5892027407291214, 26.95356594465776) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel4.Parent = workspace.devices.sign_arm_1s
newmodel5 = workspace.prefabs.sign_arm_1s:clone()
newmodel5:PivotTo(CFrame.new(-20.19227196244003, 3.1981158858529137, 26.904088967995417) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel5.Parent = workspace.devices.sign_arm_1s
newmodel6 = workspace.prefabs.sign_arm_1s:clone()
newmodel6:PivotTo(CFrame.new(-20.13646618486471, 3.652466790782626, 26.961569573235494) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel6.Parent = workspace.devices.sign_arm_1s
newmodel7 = workspace.prefabs.sign_arm_1s:clone()
newmodel7:PivotTo(CFrame.new(-20.16825428601521, 3.3936593132910176, 26.928827456326587) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel7.Parent = workspace.devices.sign_arm_1s
newmodel8 = workspace.prefabs.sign_arm_1s:clone()
newmodel8:PivotTo(CFrame.new(-20.184501537714354, 3.2613799359064175, 26.91209259657315) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel8.Parent = workspace.devices.sign_arm_1s
newmodel9 = workspace.prefabs.sign_arm_1s:clone()
newmodel9:PivotTo(CFrame.new(-20.160483861289535, 3.4569233633445213, 26.936831084904323) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel9.Parent = workspace.devices.sign_arm_1s
newmodel10 = workspace.prefabs.sign_arm_1s:clone()
newmodel10:PivotTo(CFrame.new(-19.987567008574363, 3.2613799359064175, 26.720896201124884) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel10.Parent = workspace.devices.sign_arm_1s
newmodel11 = workspace.prefabs.sign_arm_1s:clone()
newmodel11:PivotTo(CFrame.new(-19.96354933214954, 3.4569233633445213, 26.745634689456054) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel11.Parent = workspace.devices.sign_arm_1s
newmodel12 = workspace.prefabs.sign_arm_1s:clone()
newmodel12:PivotTo(CFrame.new(-63.272250210759175, 2.670612199524832, 23.66183184327246) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.sign_arm_1s
newmodel13 = workspace.prefabs.sign_arm_1s:clone()
newmodel13:PivotTo(CFrame.new(-64.97328626942993, 2.731945438811214, 22.576694664149727) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.sign_arm_1s
newmodel14 = workspace.prefabs.sign_arm_1s:clone()
newmodel14:PivotTo(CFrame.new(-65.84894025234826, 2.731945438811214, 21.251364964565777) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.sign_arm_1s
