newmodel0 = workspace.prefabs.pmo_shifted:clone()
newmodel0:PivotTo(CFrame.new(-48.41144244423351, 2.6652678737437583, 33.211112666239934) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.pmo_shifted
newmodel1 = workspace.prefabs.pmo_shifted:clone()
newmodel1:PivotTo(CFrame.new(-48.69458767885654, 2.665267870223614, 33.139742756255814) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.devices.pmo_shifted
newmodel2 = workspace.prefabs.pmo_shifted:clone()
newmodel2:PivotTo(CFrame.new(-50.88247476397087, 2.7423896862764545, 33.33165989769854) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.pmo_shifted
newmodel3 = workspace.prefabs.pmo_shifted:clone()
newmodel3:PivotTo(CFrame.new(-53.17673071729046, 2.739834776644732, 32.45800067468964) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.pmo_shifted
newmodel4 = workspace.prefabs.pmo_shifted:clone()
newmodel4:PivotTo(CFrame.new(-54.05183860143795, 2.739834776644732, 32.05462597158728) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.pmo_shifted
newmodel5 = workspace.prefabs.pmo_shifted:clone()
newmodel5:PivotTo(CFrame.new(-57.52863224520421, 2.6652679131566446, 29.050255608957734) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.pmo_shifted
newmodel6 = workspace.prefabs.pmo_shifted:clone()
newmodel6:PivotTo(CFrame.new(-57.7668049051105, 2.6652679386061213, 28.881326832737177) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.devices.pmo_shifted
newmodel7 = workspace.prefabs.pmo_shifted:clone()
newmodel7:PivotTo(CFrame.new(-42.268930608168745, 3.6237105352731516, 35.34487584354331) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel7.Parent = workspace.devices.pmo_shifted
newmodel8 = workspace.prefabs.pmo_shifted:clone()
newmodel8:PivotTo(CFrame.new(-42.54385270703154, 3.6237105609953475, 35.32783478839854) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel8.Parent = workspace.devices.pmo_shifted
newmodel9 = workspace.prefabs.pmo_shifted:clone()
newmodel9:PivotTo(CFrame.new(-42.81878258389396, 3.6237107204890684, 35.310793705957586) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel9.Parent = workspace.devices.pmo_shifted
newmodel10 = workspace.prefabs.pmo_shifted:clone()
newmodel10:PivotTo(CFrame.new(-43.09370707583373, 3.6237105362657247, 35.29375121624335) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel10.Parent = workspace.devices.pmo_shifted
newmodel11 = workspace.prefabs.pmo_shifted:clone()
newmodel11:PivotTo(CFrame.new(-42.26365775913163, 3.140603227933151, 35.259855054744506) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel11.Parent = workspace.devices.pmo_shifted
newmodel12 = workspace.prefabs.pmo_shifted:clone()
newmodel12:PivotTo(CFrame.new(-42.81361055063907, 3.1406031130770002, 35.2257648679552) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel12.Parent = workspace.devices.pmo_shifted
newmodel13 = workspace.prefabs.pmo_shifted:clone()
newmodel13:PivotTo(CFrame.new(-42.5384901392437, 3.1406028813794418, 35.242816912396) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel13.Parent = workspace.devices.pmo_shifted
newmodel14 = workspace.prefabs.pmo_shifted:clone()
newmodel14:PivotTo(CFrame.new(-43.088435401362794, 3.1406033705813137, 35.20873103312939) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel14.Parent = workspace.devices.pmo_shifted
newmodel15 = workspace.prefabs.pmo_shifted:clone()
newmodel15:PivotTo(CFrame.new(-42.24575622532589, 2.741616245642012, 34.8891763137373) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.pmo_shifted
newmodel16 = workspace.prefabs.pmo_shifted:clone()
newmodel16:PivotTo(CFrame.new(-42.52359312534366, 2.741616250763556, 34.87195520538233) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.pmo_shifted
newmodel17 = workspace.prefabs.pmo_shifted:clone()
newmodel17:PivotTo(CFrame.new(-42.801438722941626, 2.7416162539840547, 34.854734573007065) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel17.Parent = workspace.devices.pmo_shifted
newmodel18 = workspace.prefabs.pmo_shifted:clone()
newmodel18:PivotTo(CFrame.new(-43.0792773839335, 2.741616249580137, 34.83750880102718) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel18.Parent = workspace.devices.pmo_shifted
newmodel19 = workspace.prefabs.pmo_shifted:clone()
newmodel19:PivotTo(CFrame.new(-42.2202024865957, 2.705477952297521, 34.476903850690846) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel19.Parent = workspace.devices.pmo_shifted
newmodel20 = workspace.prefabs.pmo_shifted:clone()
newmodel20:PivotTo(CFrame.new(-42.77685705593287, 2.705477969220251, 34.44240252269554) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel20.Parent = workspace.devices.pmo_shifted
newmodel21 = workspace.prefabs.pmo_shifted:clone()
newmodel21:PivotTo(CFrame.new(-42.49707032587135, 2.7054779650084795, 34.459740171431804) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel21.Parent = workspace.devices.pmo_shifted
newmodel22 = workspace.prefabs.pmo_shifted:clone()
newmodel22:PivotTo(CFrame.new(-43.05372004284264, 2.705477971699112, 34.42523885359739) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.pmo_shifted
newmodel23 = workspace.prefabs.pmo_shifted:clone()
newmodel23:PivotTo(CFrame.new(-43.0254688086726, 2.6655223534165513, 33.96941945957998) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel23.Parent = workspace.devices.pmo_shifted
newmodel24 = workspace.prefabs.pmo_shifted:clone()
newmodel24:PivotTo(CFrame.new(-42.191945727089646, 2.6655223299708064, 34.02108160828108) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.pmo_shifted
newmodel25 = workspace.prefabs.pmo_shifted:clone()
newmodel25:PivotTo(CFrame.new(-42.748599298196474, 2.665522336922405, 33.98658092173986) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.pmo_shifted
newmodel26 = workspace.prefabs.pmo_shifted:clone()
newmodel26:PivotTo(CFrame.new(-42.46881412275919, 2.6655223364939262, 34.0039207948014) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.pmo_shifted
newmodel27 = workspace.prefabs.pmo_shifted:clone()
newmodel27:PivotTo(CFrame.new(-59.878065347711576, 2.7406705502375504, 28.27070241746617) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel27.Parent = workspace.devices.pmo_shifted
newmodel28 = workspace.prefabs.pmo_shifted:clone()
newmodel28:PivotTo(CFrame.new(-61.69914177449564, 2.739834776644732, 26.62493053273403) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel28.Parent = workspace.devices.pmo_shifted
newmodel29 = workspace.prefabs.pmo_shifted:clone()
newmodel29:PivotTo(CFrame.new(-62.369155479926285, 2.739834776644732, 25.932394183843176) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel29.Parent = workspace.devices.pmo_shifted
newmodel30 = workspace.prefabs.pmo_shifted:clone()
newmodel30:PivotTo(CFrame.new(-62.338167710669964, 2.6431268908203682, 24.32367082288175) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel30.Parent = workspace.devices.pmo_shifted
newmodel31 = workspace.prefabs.pmo_shifted:clone()
newmodel31:PivotTo(CFrame.new(-62.13400101174528, 2.620222311646277, 24.159793988829986) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel31.Parent = workspace.devices.pmo_shifted
newmodel32 = workspace.prefabs.pmo_shifted:clone()
newmodel32:PivotTo(CFrame.new(-61.929835890515655, 2.5973180089806402, 23.99591949120779) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel32.Parent = workspace.devices.pmo_shifted
newmodel33 = workspace.prefabs.pmo_shifted:clone()
newmodel33:PivotTo(CFrame.new(-61.69618384386404, 2.5711050360855263, 23.808369128062992) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel33.Parent = workspace.devices.pmo_shifted
newmodel34 = workspace.prefabs.pmo_shifted:clone()
newmodel34:PivotTo(CFrame.new(-63.07477537327992, 2.6431267330898334, 23.40596993075721) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel34.Parent = workspace.devices.pmo_shifted
newmodel35 = workspace.prefabs.pmo_shifted:clone()
newmodel35:PivotTo(CFrame.new(-62.870614814130434, 2.6202225429683725, 23.242098444857405) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel35.Parent = workspace.devices.pmo_shifted
newmodel36 = workspace.prefabs.pmo_shifted:clone()
newmodel36:PivotTo(CFrame.new(-62.666445822451585, 2.5973178959564986, 23.078217086221024) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel36.Parent = workspace.devices.pmo_shifted
newmodel37 = workspace.prefabs.pmo_shifted:clone()
newmodel37:PivotTo(CFrame.new(-62.43279173332416, 2.571104903804469, 22.89066841802449) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel37.Parent = workspace.devices.pmo_shifted
newmodel38 = workspace.prefabs.pmo_centered:clone()
newmodel38:PivotTo(CFrame.new(-68.20523434353645, 3.6650695200000003, 27.01700593684489) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel38.Parent = workspace.devices.pmo_centered
newmodel39 = workspace.prefabs.pmo_centered:clone()
newmodel39:PivotTo(CFrame.new(-68.13370644340804, 3.22384, 27.10561978397512) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel39.Parent = workspace.devices.pmo_centered
newmodel40 = workspace.prefabs.pmo_centered:clone()
newmodel40:PivotTo(CFrame.new(-67.87693962243424, 2.68072, 27.423720773673374) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel40.Parent = workspace.devices.pmo_centered
newmodel41 = workspace.prefabs.pmo_centered:clone()
newmodel41:PivotTo(CFrame.new(-68.13370644340804, 2.68072, 27.10561978397512) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel41.Parent = workspace.devices.pmo_centered
newmodel42 = workspace.prefabs.pmo_centered:clone()
newmodel42:PivotTo(CFrame.new(-68.32169643733528, 3.22384, 26.872724416517464) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel42.Parent = workspace.devices.pmo_centered
newmodel43 = workspace.prefabs.pmo_centered:clone()
newmodel43:PivotTo(CFrame.new(-68.50968643126252, 3.22384, 26.63982904905981) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel43.Parent = workspace.devices.pmo_centered
newmodel44 = workspace.prefabs.pmo_centered:clone()
newmodel44:PivotTo(CFrame.new(-68.75544895990886, 3.7319200000000006, 26.335360958920045) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel44.Parent = workspace.devices.pmo_centered
newmodel45 = workspace.prefabs.pmo_shifted:clone()
newmodel45:PivotTo(CFrame.new(-67.53397251156211, 3.1946400000000006, 27.848612809913195) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel45.Parent = workspace.devices.pmo_shifted
newmodel46 = workspace.prefabs.pmo_shifted:clone()
newmodel46:PivotTo(CFrame.new(-68.8764961755108, 3.1946400000000006, 26.185399063776575) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel46.Parent = workspace.devices.pmo_shifted
