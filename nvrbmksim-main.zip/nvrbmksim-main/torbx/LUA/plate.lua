newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-29.36423041291382, 2.7138358271787952, 31.972557041493218) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.11387997079999998, 0.7913199999999999, 0.011679997079999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-29.377224389182693, 2.6030342129465494, 30.629041648273937) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.8643197079999999, 0.99572, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-30.203112575914894, 2.5872555969793694, 30.782953129552297) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.68328, 0.43507999999999997, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-30.802564691790963, 2.6041794384530244, 31.246901316098608) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.7241599999999999, 0.8234399999999998, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-49.45892003452809, 2.6449225985093356, 32.66855286176248) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.4088, 0.45843999999999996, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-31.870053961942393, 2.7009975218399718, 32.78366566607924) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.9928002920000001, 0.1314000292, 0.010220002919999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-32.9413166045145, 2.7009973737919997, 33.12457711092486) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.876000292, 0.1314000292, 0.010220002919999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-31.96875816359187, 2.6330012019582063, 32.016782051116934) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(1.112520292, 0.30367999999999995, 0.00730000292)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-31.956045024264505, 2.5877006477844846, 31.46936680874132) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.756280292, 0.7358399999999999, 0.00730000292)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-33.05451874626052, 2.584265872542425, 31.77773062665694) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(1.4132802919999998, 0.65116, 0.00730000292)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-50.72475497533804, 2.6519118094917324, 32.32831466804733) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(1.734480584, 2.213360292, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-34.309411132903165, 2.6917157029159724, 33.40023032138116) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(1.18844, 1.4272962919999999, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-52.41958118407995, 2.6448623412469554, 31.57512194383729) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(1.0190799999999998, 1.2205599999999999, 0.00730000292)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-52.068163613162014, 2.5716949724122733, 30.816229325291836) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(1.0044799999999998, 0.40003999999999995, 0.00730000292)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-53.46933186037516, 2.6021072487368127, 30.553140014736044) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.7212399999999999, 1.11544, 0.00730000292)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-52.87945492928311, 2.620430840306412, 31.055653423906193) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.2511200292, 0.40296, 0.00730000292)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-37.22461656254112, 2.5849305052188094, 32.73127465623006) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.7562800000000001, 0.65992, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-38.35624971962485, 2.5849303545727933, 32.871286185321594) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(1.4132799999999999, 0.65992, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-38.491455239087905, 2.5999258257527305, 32.993546979743435) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.13432, 0.39128, 0.004379999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-37.51301474292292, 2.624122784203571, 33.21834078886201) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.49640000000000006, 0.1518399708, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-38.17518686554564, 2.624122777857343, 33.30026625372297) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.49640000000000006, 0.1518399708, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-38.83735807791179, 2.6241228022168324, 33.382194243480825) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.49640000000000006, 0.1518399708, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-23.624404385635856, 2.717184742219471, 28.864883466062068) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(-2.92, 2.92, 2.92)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-58.30944336235455, 2.6450670604014173, 28.179515372816205) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.4088, 0.45843999999999996, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-44.10118150337152, 2.6353538881121175, 33.51676374567672) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.77088, 1.813320292, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-59.36715798748459, 2.651052275568271, 27.39146397006487) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(1.734480292, 2.213360292, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-60.67491027979775, 2.6439112605445763, 26.076529030961748) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(1.0190799999999998, 1.2205599999999999, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-60.07284511021542, 2.5707440928231824, 25.496079982542096) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(1.0044799999999998, 0.40003999999999995, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-61.28404105073813, 2.6011561597838493, 24.744094704199597) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.7212399999999999, 1.11544, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-60.915808573369304, 2.6194797144739788, 25.425914561116265) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(85), 0, 0))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(121, 148, 158)
newmodel0.Size = Vector3.new(0.2511200292, 0.40296, 0.007299999999999999)
newmodel0.Anchored = true
newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-55.72715194382025, 5.308720000000001, 36.71797807247841) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel0.Parent = workspace.devices.plate
newmodel0.Material = Enum.Material.Metal
newmodel0.Color = Color3.fromRGB(204, 204, 204)
newmodel0.Size = Vector3.new(2.502440292, 0.008759999999999999, 0.6423999999999999)
newmodel0.Anchored = true
newmodel1 = Instance.new('Part')
newmodel1:PivotTo(CFrame.new(-63.80242994338507, 5.308720000000001, 31.530756239459798) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel1.Parent = workspace.devices.plate
newmodel1.Material = Enum.Material.Metal
newmodel1.Color = Color3.fromRGB(204, 204, 204)
newmodel1.Size = Vector3.new(2.5024399999999996, 0.008759999999999999, 0.6423999999999999)
newmodel1.Anchored = true
