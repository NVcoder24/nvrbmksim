newmodel0 = workspace.prefabs.e365:clone()
newmodel0:PivotTo(CFrame.new(-67.99248469187246, 5.437200000000001, 27.280575328309162) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel0.Parent = workspace.devices.e365
newmodel1 = workspace.prefabs.e365:clone()
newmodel1:PivotTo(CFrame.new(-67.5156320243497, 4.937880000000001, 27.87133430917736) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1.Parent = workspace.devices.e365
newmodel2 = workspace.prefabs.e365:clone()
newmodel2:PivotTo(CFrame.new(-67.99248469187246, 4.937880000000001, 27.280575328309162) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel2.Parent = workspace.devices.e365
newmodel3 = workspace.prefabs.e365:clone()
newmodel3:PivotTo(CFrame.new(-68.32994965658088, 4.937880000000001, 26.86249974184859) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel3.Parent = workspace.devices.e365
newmodel4 = workspace.prefabs.e365:clone()
newmodel4:PivotTo(CFrame.new(-68.80680232410361, 4.937880000000001, 26.271740760980386) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel4.Parent = workspace.devices.e365
newmodel5 = workspace.prefabs.e365:clone()
newmodel5:PivotTo(CFrame.new(-68.32994965658088, 5.437200000000001, 26.86249974184859) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel5.Parent = workspace.devices.e365
