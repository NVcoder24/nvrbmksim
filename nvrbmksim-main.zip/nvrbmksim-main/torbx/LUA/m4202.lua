newmodel0 = workspace.prefabs.m4202:clone()
newmodel0:PivotTo(CFrame.new(-48.128516978379814, 2.741361745257671, 34.17938386519997) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.m4202
newmodel1 = workspace.prefabs.m4202:clone()
newmodel1:PivotTo(CFrame.new(-48.03535601104192, 2.7059869723912517, 33.78588375133809) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.devices.m4202
newmodel2 = workspace.prefabs.m4202:clone()
newmodel2:PivotTo(CFrame.new(-48.28877005243665, 2.7059869723912517, 33.72200950594927) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.m4202
newmodel3 = workspace.prefabs.m4202:clone()
newmodel3:PivotTo(CFrame.new(-48.54218409383139, 2.7059869723912517, 33.65813526056048) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.m4202
newmodel4 = workspace.prefabs.m4202:clone()
newmodel4:PivotTo(CFrame.new(-31.222074110551034, 2.7433977812606996, 33.14666854406947) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.m4202
newmodel5 = workspace.prefabs.m4202:clone()
newmodel5:PivotTo(CFrame.new(-31.491050052912303, 2.7433977842687365, 33.23226720523155) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.m4202
newmodel6 = workspace.prefabs.m4202:clone()
newmodel6:PivotTo(CFrame.new(-31.760023206449034, 2.7433977915552643, 33.31786299806902) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.devices.m4202
newmodel7 = workspace.prefabs.m4202:clone()
newmodel7:PivotTo(CFrame.new(-32.02899928659337, 2.7433977883815794, 33.403460209659514) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.devices.m4202
newmodel8 = workspace.prefabs.m4202:clone()
newmodel8:PivotTo(CFrame.new(-31.672016808758947, 2.6256714908226066, 31.79115657730534) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.devices.m4202
newmodel9 = workspace.prefabs.m4202:clone()
newmodel9:PivotTo(CFrame.new(-32.008142649546194, 2.6256714908226066, 31.8981243521306) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.devices.m4202
newmodel10 = workspace.prefabs.m4202:clone()
newmodel10:PivotTo(CFrame.new(-33.62985005416344, 2.748654199717006, 33.874972117637185) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.devices.m4202
newmodel11 = workspace.prefabs.m4202:clone()
newmodel11:PivotTo(CFrame.new(-33.833317207826354, 2.7486542024994614, 33.9195314451523) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.devices.m4202
newmodel12 = workspace.prefabs.m4202:clone()
newmodel12:PivotTo(CFrame.new(-34.03679228094954, 2.748654208274073, 33.96409366821708) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.m4202
newmodel13 = workspace.prefabs.m4202:clone()
newmodel13:PivotTo(CFrame.new(-34.240261341825374, 2.7486542067107247, 34.00865329431973) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.m4202
newmodel14 = workspace.prefabs.m4202:clone()
newmodel14:PivotTo(CFrame.new(-34.12276263449437, 2.713533902672852, 33.5719800513257) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.m4202
newmodel15 = workspace.prefabs.m4202:clone()
newmodel15:PivotTo(CFrame.new(-33.71572597473509, 2.7135339023759677, 33.4828383256441) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.m4202
newmodel16 = workspace.prefabs.m4202:clone()
newmodel16:PivotTo(CFrame.new(-33.919103920247096, 2.713533894428455, 33.52737874136956) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.m4202
newmodel17 = workspace.prefabs.m4202:clone()
newmodel17:PivotTo(CFrame.new(-34.326140836591506, 2.7135338976423333, 33.61652052325064) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel17.Parent = workspace.devices.m4202
newmodel18 = workspace.prefabs.m4202:clone()
newmodel18:PivotTo(CFrame.new(-52.474858366723524, 2.737798818494147, 32.75589938630827) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel18.Parent = workspace.devices.m4202
newmodel19 = workspace.prefabs.m4202:clone()
newmodel19:PivotTo(CFrame.new(-52.20587197639858, 2.6906255329870468, 32.21303029144734) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel19.Parent = workspace.devices.m4202
newmodel20 = workspace.prefabs.m4202:clone()
newmodel20:PivotTo(CFrame.new(-52.69628717983356, 2.737798818494147, 32.65383336294752) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel20.Parent = workspace.devices.m4202
newmodel21 = workspace.prefabs.m4202:clone()
newmodel21:PivotTo(CFrame.new(-36.85098018515461, 2.7451791370256866, 34.57264896005276) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel21.Parent = workspace.devices.m4202
newmodel22 = workspace.prefabs.m4202:clone()
newmodel22:PivotTo(CFrame.new(-37.112756283400216, 2.7451791423210126, 34.605039195692086) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.m4202
newmodel23 = workspace.prefabs.m4202:clone()
newmodel23:PivotTo(CFrame.new(-37.374536621129465, 2.7451791451200513, 34.6374262048124) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel23.Parent = workspace.devices.m4202
newmodel24 = workspace.prefabs.m4202:clone()
newmodel24:PivotTo(CFrame.new(-37.636310952516396, 2.7451791435765736, 34.66981414118048) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.m4202
newmodel25 = workspace.prefabs.m4202:clone()
newmodel25:PivotTo(CFrame.new(-57.615003841019266, 2.741361745257671, 30.0553113986671) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.m4202
newmodel26 = workspace.prefabs.m4202:clone()
newmodel26:PivotTo(CFrame.new(-57.385848344323335, 2.7059869723912517, 29.72213117149465) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.m4202
newmodel27 = workspace.prefabs.m4202:clone()
newmodel27:PivotTo(CFrame.new(-57.599013790149804, 2.7059869723912517, 29.570938948461844) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel27.Parent = workspace.devices.m4202
newmodel28 = workspace.prefabs.m4202:clone()
newmodel28:PivotTo(CFrame.new(-57.812179235976274, 2.7059869723912517, 29.419746725429043) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel28.Parent = workspace.devices.m4202
newmodel29 = workspace.prefabs.m4202:clone()
newmodel29:PivotTo(CFrame.new(-61.15249697016409, 2.737798818494147, 27.1564828789538) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel29.Parent = workspace.devices.m4202
newmodel30 = workspace.prefabs.m4202:clone()
newmodel30:PivotTo(CFrame.new(-60.707290593159165, 2.6887231519673502, 26.74946735631434) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel30.Parent = workspace.devices.m4202
newmodel31 = workspace.prefabs.m4202:clone()
newmodel31:PivotTo(CFrame.new(-61.32203074108366, 2.737798818494147, 26.981250196734443) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel31.Parent = workspace.devices.m4202
