newmodel0 = workspace.prefabs.ke011:clone()
newmodel0:PivotTo(CFrame.new(-16.23562787801074, 2.7250740800529885, 21.48567301133677) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.ke011
newmodel0.Trigger.DragDetector.Orientation = newmodel0.Body1.Orientation
newmodel1 = workspace.prefabs.ke011:clone()
newmodel1:PivotTo(CFrame.new(-16.454695960436567, 2.7250740800529885, 21.79568161647907) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.devices.ke011
newmodel1.Trigger.DragDetector.Orientation = newmodel1.Body1.Orientation
newmodel2 = workspace.prefabs.ke011:clone()
newmodel2:PivotTo(CFrame.new(-30.907079275576596, 2.5841567120833484, 31.01140966582858) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.ke011
newmodel2.Trigger.DragDetector.Orientation = newmodel2.Body1.Orientation
newmodel3 = workspace.prefabs.ke011:clone()
newmodel3:PivotTo(CFrame.new(-17.412882177531614, 2.7288915015853363, 23.15867946808451) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.ke011
newmodel3.Trigger.DragDetector.Orientation = newmodel3.Body1.Orientation
newmodel4 = workspace.prefabs.ke011:clone()
newmodel4:PivotTo(CFrame.new(-17.690442113382247, 2.7288915015853363, 23.483121080673417) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.ke011
newmodel4.Trigger.DragDetector.Orientation = newmodel4.Body1.Orientation
newmodel5 = workspace.prefabs.ke011:clone()
newmodel5:PivotTo(CFrame.new(-18.24556388329265, 2.7288915015853363, 24.132006524680218) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.ke011
newmodel5.Trigger.DragDetector.Orientation = newmodel5.Body1.Orientation
newmodel6 = workspace.prefabs.ke011:clone()
newmodel6:PivotTo(CFrame.new(-18.523123819143287, 2.7288915015853363, 24.456448137269124) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.devices.ke011
newmodel6.Trigger.DragDetector.Orientation = newmodel6.Body1.Orientation
newmodel7 = workspace.prefabs.ke011:clone()
newmodel7:PivotTo(CFrame.new(-18.60096164745614, 2.7039510142406664, 24.108910715303196) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.devices.ke011
newmodel7.Trigger.DragDetector.Orientation = newmodel7.Body1.Orientation
newmodel8 = workspace.prefabs.ke011:clone()
newmodel8:PivotTo(CFrame.new(-18.323401711605502, 2.7039510142406664, 23.78446910271429) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.devices.ke011
newmodel8.Trigger.DragDetector.Orientation = newmodel8.Body1.Orientation
newmodel9 = workspace.prefabs.ke011:clone()
newmodel9:PivotTo(CFrame.new(-18.18461984547105, 2.7039510142406664, 23.622246077590848) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.devices.ke011
newmodel9.Trigger.DragDetector.Orientation = newmodel9.Body1.Orientation
newmodel10 = workspace.prefabs.ke011:clone()
newmodel10:PivotTo(CFrame.new(-18.045839877545735, 2.7039510142406664, 23.460025271296395) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.devices.ke011
newmodel10.Trigger.DragDetector.Orientation = newmodel10.Body1.Orientation
newmodel11 = workspace.prefabs.ke011:clone()
newmodel11:PivotTo(CFrame.new(-32.952851299448156, 2.933557131083714, 34.02719806374131) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel11.Parent = workspace.devices.ke011
newmodel11.Trigger.DragDetector.Orientation = newmodel11.Body1.Orientation
newmodel12 = workspace.prefabs.ke011:clone()
newmodel12:PivotTo(CFrame.new(-33.144843708507096, 2.933557131083714, 34.088297206646466) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel12.Parent = workspace.devices.ke011
newmodel12.Trigger.DragDetector.Orientation = newmodel12.Body1.Orientation
newmodel13 = workspace.prefabs.ke011:clone()
newmodel13:PivotTo(CFrame.new(-19.213567450792915, 2.7250740800529885, 25.159049262384084) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.ke011
newmodel13.Trigger.DragDetector.Orientation = newmodel13.Body1.Orientation
newmodel14 = workspace.prefabs.ke011:clone()
newmodel14:PivotTo(CFrame.new(-19.504779148138223, 2.7250740800529885, 25.44177584714269) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.ke011
newmodel14.Trigger.DragDetector.Orientation = newmodel14.Body1.Orientation
newmodel15 = workspace.prefabs.ke011:clone()
newmodel15:PivotTo(CFrame.new(-19.79599084548353, 2.7250740800529885, 25.724502431901296) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.ke011
newmodel15.Trigger.DragDetector.Orientation = newmodel15.Body1.Orientation
newmodel16 = workspace.prefabs.ke011:clone()
newmodel16:PivotTo(CFrame.new(-20.125007996859942, 2.7021695508589043, 25.679045896149567) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.ke011
newmodel16.Trigger.DragDetector.Orientation = newmodel16.Body1.Orientation
newmodel17 = workspace.prefabs.ke011:clone()
newmodel17:PivotTo(CFrame.new(-20.521204258022316, 2.679774011202466, 25.70691965521531) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel17.Parent = workspace.devices.ke011
newmodel17.Trigger.DragDetector.Orientation = newmodel17.Body1.Orientation
newmodel18 = workspace.prefabs.ke011:clone()
newmodel18:PivotTo(CFrame.new(-20.701541772428097, 2.657123976777205, 25.521169900872327) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel18.Parent = workspace.devices.ke011
newmodel18.Trigger.DragDetector.Orientation = newmodel18.Body1.Orientation
newmodel19 = workspace.prefabs.ke011:clone()
newmodel19:PivotTo(CFrame.new(-21.03265397198685, 2.6342194475831198, 25.477747369327496) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel19.Parent = workspace.devices.ke011
newmodel19.Trigger.DragDetector.Orientation = newmodel19.Body1.Orientation
newmodel20 = workspace.prefabs.ke011:clone()
newmodel20:PivotTo(CFrame.new(-20.374620288395572, 2.6342194475831198, 24.838886987983393) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel20.Parent = workspace.devices.ke011
newmodel20.Trigger.DragDetector.Orientation = newmodel20.Body1.Orientation
newmodel21 = workspace.prefabs.ke011:clone()
newmodel21:PivotTo(CFrame.new(-20.51936716731347, 2.6342194475831198, 24.97941633863787) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel21.Parent = workspace.devices.ke011
newmodel21.Trigger.DragDetector.Orientation = newmodel21.Body1.Orientation
newmodel22 = workspace.prefabs.ke011:clone()
newmodel22:PivotTo(CFrame.new(-20.66602054007729, 2.6342194475831198, 25.121796633120617) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.ke011
newmodel22.Trigger.DragDetector.Orientation = newmodel22.Body1.Orientation
newmodel23 = workspace.prefabs.ke011:clone()
newmodel23:PivotTo(CFrame.new(-21.33015081387918, 2.6342194475831198, 25.76657596670679) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel23.Parent = workspace.devices.ke011
newmodel23.Trigger.DragDetector.Orientation = newmodel23.Body1.Orientation
newmodel24 = workspace.prefabs.ke011:clone()
newmodel24:PivotTo(CFrame.new(-19.97835462409612, 2.7021695508589043, 25.53666560166682) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.ke011
newmodel24.Trigger.DragDetector.Orientation = newmodel24.Body1.Orientation
newmodel25 = workspace.prefabs.ke011:clone()
newmodel25:PivotTo(CFrame.new(-19.942644218247356, 2.7250740800529885, 25.866882726384045) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.ke011
newmodel25.Trigger.DragDetector.Orientation = newmodel25.Body1.Orientation
newmodel26 = workspace.prefabs.ke011:clone()
newmodel26:PivotTo(CFrame.new(-20.458026071103077, 2.7250740800529885, 26.36724776128057) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.ke011
newmodel26.Trigger.DragDetector.Orientation = newmodel26.Body1.Orientation
newmodel27 = workspace.prefabs.ke011:clone()
newmodel27:PivotTo(CFrame.new(-35.3358383562454, 2.933557131083714, 34.5940469435154) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel27.Parent = workspace.devices.ke011
newmodel27.Trigger.DragDetector.Orientation = newmodel27.Body1.Orientation
newmodel28 = workspace.prefabs.ke011:clone()
newmodel28:PivotTo(CFrame.new(-33.61869576107847, 2.933557131083714, 34.21798474990456) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel28.Parent = workspace.devices.ke011
newmodel28.Trigger.DragDetector.Orientation = newmodel28.Body1.Orientation
newmodel29 = workspace.prefabs.ke011:clone()
newmodel29:PivotTo(CFrame.new(-35.50698213649459, 2.933557131083714, 34.63152822527064) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel29.Parent = workspace.devices.ke011
newmodel29.Trigger.DragDetector.Orientation = newmodel29.Body1.Orientation
newmodel30 = workspace.prefabs.ke011:clone()
newmodel30:PivotTo(CFrame.new(-34.745302880798455, 2.6443487112702617, 32.92416707884299) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel30.Parent = workspace.devices.ke011
newmodel30.Trigger.DragDetector.Orientation = newmodel30.Body1.Orientation
newmodel31 = workspace.prefabs.ke011:clone()
newmodel31:PivotTo(CFrame.new(-34.89933228302273, 2.6443487112702617, 32.9579002324227) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel31.Parent = workspace.devices.ke011
newmodel31.Trigger.DragDetector.Orientation = newmodel31.Body1.Orientation
newmodel32 = workspace.prefabs.ke011:clone()
newmodel32:PivotTo(CFrame.new(-22.41357579685628, 2.5952817479531762, 26.139292541176488) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel32.Parent = workspace.devices.ke011
newmodel32.Trigger.DragDetector.Orientation = newmodel32.Body1.Orientation
newmodel33 = workspace.prefabs.ke011:clone()
newmodel33:PivotTo(CFrame.new(-21.191483905211847, 2.7416162400264943, 27.302635616630408) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel33.Parent = workspace.devices.ke011
newmodel33.Trigger.DragDetector.Orientation = newmodel33.Body1.Orientation
newmodel34 = workspace.prefabs.ke011:clone()
newmodel34:PivotTo(CFrame.new(-21.337469288011423, 2.7212566585206415, 27.121410023929577) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel34.Parent = workspace.devices.ke011
newmodel34.Trigger.DragDetector.Orientation = newmodel34.Body1.Orientation
newmodel35 = workspace.prefabs.ke011:clone()
newmodel35:PivotTo(CFrame.new(-56.681103750101066, 2.736526344650031, 30.57590256667749) * CFrame.fromEulerAngles(0, math.rad(-30.046980000000005), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel35.Parent = workspace.devices.ke011
newmodel35.Trigger.DragDetector.Orientation = newmodel35.Body1.Orientation
newmodel36 = workspace.prefabs.ke011:clone()
newmodel36:PivotTo(CFrame.new(-55.63248109199219, 2.6301475312819496, 29.7777884965302) * CFrame.fromEulerAngles(0, math.rad(-30.046980000000005), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel36.Parent = workspace.devices.ke011
newmodel36.Trigger.DragDetector.Orientation = newmodel36.Body1.Orientation
newmodel37 = workspace.prefabs.ke011:clone()
newmodel37:PivotTo(CFrame.new(-55.81446801794575, 2.6301475312819496, 29.67251923994514) * CFrame.fromEulerAngles(0, math.rad(-30.046980000000005), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel37.Parent = workspace.devices.ke011
newmodel37.Trigger.DragDetector.Orientation = newmodel37.Body1.Orientation
newmodel38 = workspace.prefabs.ke011:clone()
newmodel38:PivotTo(CFrame.new(-56.88331144560503, 2.736526344650031, 30.458936726027417) * CFrame.fromEulerAngles(0, math.rad(-30.046980000000005), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel38.Parent = workspace.devices.ke011
newmodel38.Trigger.DragDetector.Orientation = newmodel38.Body1.Orientation
newmodel39 = workspace.prefabs.ke011:clone()
newmodel39:PivotTo(CFrame.new(-24.602394439705364, 2.726855543434751, 29.646141449666057) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel39.Parent = workspace.devices.ke011
newmodel39.Trigger.DragDetector.Orientation = newmodel39.Body1.Orientation
newmodel40 = workspace.prefabs.ke011:clone()
newmodel40:PivotTo(CFrame.new(-24.767869361862466, 2.726855543434751, 29.755887172758587) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel40.Parent = workspace.devices.ke011
newmodel40.Trigger.DragDetector.Orientation = newmodel40.Body1.Orientation
newmodel41 = workspace.prefabs.ke011:clone()
newmodel41:PivotTo(CFrame.new(-62.28501994616922, 2.5881559333773563, 23.3861195595559) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel41.Parent = workspace.devices.ke011
newmodel41.Trigger.DragDetector.Orientation = newmodel41.Body1.Orientation
newmodel42 = workspace.prefabs.ke011:clone()
newmodel42:PivotTo(CFrame.new(-62.05135986871855, 2.561942737169416, 23.198572277608832) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel42.Parent = workspace.devices.ke011
newmodel42.Trigger.DragDetector.Orientation = newmodel42.Body1.Orientation
newmodel43 = workspace.prefabs.ke011:clone()
newmodel43:PivotTo(CFrame.new(-62.62121735514512, 2.659160407831917, 24.26380471321793) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel43.Parent = workspace.devices.ke011
newmodel43.Trigger.DragDetector.Orientation = newmodel43.Body1.Orientation
newmodel44 = workspace.prefabs.ke011:clone()
newmodel44:PivotTo(CFrame.new(-63.021630451129674, 2.5881561593145954, 22.468423320881417) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel44.Parent = workspace.devices.ke011
newmodel44.Trigger.DragDetector.Orientation = newmodel44.Body1.Orientation
newmodel45 = workspace.prefabs.ke011:clone()
newmodel45:PivotTo(CFrame.new(-62.78797104361006, 2.561942711719939, 22.280871749286813) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel45.Parent = workspace.devices.ke011
newmodel45.Trigger.DragDetector.Orientation = newmodel45.Body1.Orientation
newmodel46 = workspace.prefabs.ke011:clone()
newmodel46:PivotTo(CFrame.new(-63.357826516085176, 2.659160339011368, 23.346106327736088) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel46.Parent = workspace.devices.ke011
newmodel46.Trigger.DragDetector.Orientation = newmodel46.Body1.Orientation
newmodel47 = workspace.prefabs.ke011:clone()
newmodel47:PivotTo(CFrame.new(-63.60246662756959, 2.564233386156751, 21.174016502601493) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel47.Parent = workspace.devices.ke011
newmodel47.Trigger.DragDetector.Orientation = newmodel47.Body1.Orientation
newmodel48 = workspace.prefabs.ke011:clone()
newmodel48:PivotTo(CFrame.new(-63.752164826855264, 2.564233386156751, 20.94744359440056) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel48.Parent = workspace.devices.ke011
newmodel48.Trigger.DragDetector.Orientation = newmodel48.Body1.Orientation
newmodel49 = workspace.prefabs.ke011:clone()
newmodel49:PivotTo(CFrame.new(-37.124954026055555, 2.3128000000000006, 39.74666447221252) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel49.Parent = workspace.devices.ke011
newmodel50 = workspace.prefabs.ke011:clone()
newmodel50:PivotTo(CFrame.new(-56.08141807822647, 2.2836000000000003, 36.558807692811484) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel50.Parent = workspace.devices.ke011
newmodel51 = workspace.prefabs.ke011:clone()
newmodel51:PivotTo(CFrame.new(-64.10019514244992, 2.2836000000000003, 31.281404418489075) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel51.Parent = workspace.devices.ke011
newmodel52 = workspace.prefabs.ke011:clone()
newmodel52:PivotTo(CFrame.new(-68.94619002691796, 2.5756, 26.09905736657276) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel52.Parent = workspace.devices.ke011
newmodel53 = workspace.prefabs.ke011:clone()
newmodel53:PivotTo(CFrame.new(-68.3978094592668, 2.5756, 26.778430194571193) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel53.Parent = workspace.devices.ke011
newmodel54 = workspace.prefabs.ke011:clone()
newmodel54:PivotTo(CFrame.new(-67.59633016808432, 2.5756, 27.77135971241505) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel54.Parent = workspace.devices.ke011
newmodel55 = workspace.prefabs.ke011:clone()
newmodel55:PivotTo(CFrame.new(-68.01082517908486, 3.1304000000000007, 27.257853829045004) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel55.Parent = workspace.devices.ke011
newmodel56 = workspace.prefabs.ke011:clone()
newmodel56:PivotTo(CFrame.new(-69.07824153484734, 3.6268000000000002, 25.935462571870797) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel56.Parent = workspace.devices.ke011
