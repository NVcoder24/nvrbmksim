newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-12.778706184605507, 7.415499416, 26.362902672863886) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel0.Parent = workspace.devices.label
newmodel0.Material = Enum.Material.SmoothPlastic
newmodel0.Color = Color3.fromRGB(255, 255, 255)
newmodel0.Size = Vector3.new(0.438, 0.00584, 0.04379999999999999)
newmodel0.Anchored = true
newmodel1 = Instance.new('Part')
newmodel1:PivotTo(CFrame.new(-12.778706184605507, 6.728047319999999, 26.362902672863886) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel1.Parent = workspace.devices.label
newmodel1.Material = Enum.Material.SmoothPlastic
newmodel1.Color = Color3.fromRGB(255, 255, 255)
newmodel1.Size = Vector3.new(0.438, 0.00584, 0.04379999999999999)
newmodel1.Anchored = true
newmodel2 = Instance.new('Part')
newmodel2:PivotTo(CFrame.new(-12.988846119390482, 7.354180584, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel2.Parent = workspace.devices.label
newmodel2.Material = Enum.Material.SmoothPlastic
newmodel2.Color = Color3.fromRGB(255, 255, 255)
newmodel2.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel2.Anchored = true
newmodel3 = Instance.new('Part')
newmodel3:PivotTo(CFrame.new(-12.988846119390482, 7.309317119999999, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel3.Parent = workspace.devices.label
newmodel3.Material = Enum.Material.SmoothPlastic
newmodel3.Color = Color3.fromRGB(255, 255, 255)
newmodel3.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel3.Anchored = true
newmodel4 = Instance.new('Part')
newmodel4:PivotTo(CFrame.new(-12.988846119390482, 7.264455116, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel4.Parent = workspace.devices.label
newmodel4.Material = Enum.Material.SmoothPlastic
newmodel4.Color = Color3.fromRGB(255, 255, 255)
newmodel4.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel4.Anchored = true
newmodel5 = Instance.new('Part')
newmodel5:PivotTo(CFrame.new(-12.988846119390482, 7.219594572, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel5.Parent = workspace.devices.label
newmodel5.Material = Enum.Material.SmoothPlastic
newmodel5.Color = Color3.fromRGB(255, 255, 255)
newmodel5.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel5.Anchored = true
newmodel6 = Instance.new('Part')
newmodel6:PivotTo(CFrame.new(-12.988846119390482, 7.174731108, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel6.Parent = workspace.devices.label
newmodel6.Material = Enum.Material.SmoothPlastic
newmodel6.Color = Color3.fromRGB(255, 255, 255)
newmodel6.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel6.Anchored = true
newmodel7 = Instance.new('Part')
newmodel7:PivotTo(CFrame.new(-12.988846119390482, 7.129870564, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel7.Parent = workspace.devices.label
newmodel7.Material = Enum.Material.SmoothPlastic
newmodel7.Color = Color3.fromRGB(255, 255, 255)
newmodel7.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel7.Anchored = true
newmodel8 = Instance.new('Part')
newmodel8:PivotTo(CFrame.new(-12.988846119390482, 7.08500856, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel8.Parent = workspace.devices.label
newmodel8.Material = Enum.Material.SmoothPlastic
newmodel8.Color = Color3.fromRGB(255, 255, 255)
newmodel8.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel8.Anchored = true
newmodel9 = Instance.new('Part')
newmodel9:PivotTo(CFrame.new(-12.988846119390482, 7.040146556, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel9.Parent = workspace.devices.label
newmodel9.Material = Enum.Material.SmoothPlastic
newmodel9.Color = Color3.fromRGB(255, 255, 255)
newmodel9.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel9.Anchored = true
newmodel10 = Instance.new('Part')
newmodel10:PivotTo(CFrame.new(-12.988846119390482, 6.995284552, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel10.Parent = workspace.devices.label
newmodel10.Material = Enum.Material.SmoothPlastic
newmodel10.Color = Color3.fromRGB(255, 255, 255)
newmodel10.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel10.Anchored = true
newmodel11 = Instance.new('Part')
newmodel11:PivotTo(CFrame.new(-12.988846119390482, 6.950421088, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel11.Parent = workspace.devices.label
newmodel11.Material = Enum.Material.SmoothPlastic
newmodel11.Color = Color3.fromRGB(255, 255, 255)
newmodel11.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel11.Anchored = true
newmodel12 = Instance.new('Part')
newmodel12:PivotTo(CFrame.new(-12.988846119390482, 6.905560544, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel12.Parent = workspace.devices.label
newmodel12.Material = Enum.Material.SmoothPlastic
newmodel12.Color = Color3.fromRGB(255, 255, 255)
newmodel12.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel12.Anchored = true
newmodel13 = Instance.new('Part')
newmodel13:PivotTo(CFrame.new(-12.988846119390482, 6.860699416, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel13.Parent = workspace.devices.label
newmodel13.Material = Enum.Material.SmoothPlastic
newmodel13.Color = Color3.fromRGB(255, 255, 255)
newmodel13.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel13.Anchored = true
newmodel14 = Instance.new('Part')
newmodel14:PivotTo(CFrame.new(-12.988846119390482, 6.66672732, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel14.Parent = workspace.devices.label
newmodel14.Material = Enum.Material.SmoothPlastic
newmodel14.Color = Color3.fromRGB(255, 255, 255)
newmodel14.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel14.Anchored = true
newmodel15 = Instance.new('Part')
newmodel15:PivotTo(CFrame.new(-12.988846119390482, 6.6218644399999995, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel15.Parent = workspace.devices.label
newmodel15.Material = Enum.Material.SmoothPlastic
newmodel15.Color = Color3.fromRGB(255, 255, 255)
newmodel15.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel15.Anchored = true
newmodel16 = Instance.new('Part')
newmodel16:PivotTo(CFrame.new(-12.988846119390482, 6.57700156, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel16.Parent = workspace.devices.label
newmodel16.Material = Enum.Material.SmoothPlastic
newmodel16.Color = Color3.fromRGB(255, 255, 255)
newmodel16.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel16.Anchored = true
newmodel17 = Instance.new('Part')
newmodel17:PivotTo(CFrame.new(-12.988846119390482, 6.532141600000001, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel17.Parent = workspace.devices.label
newmodel17.Material = Enum.Material.SmoothPlastic
newmodel17.Color = Color3.fromRGB(255, 255, 255)
newmodel17.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel17.Anchored = true
newmodel18 = Instance.new('Part')
newmodel18:PivotTo(CFrame.new(-12.988846119390482, 6.487278720000001, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel18.Parent = workspace.devices.label
newmodel18.Material = Enum.Material.SmoothPlastic
newmodel18.Color = Color3.fromRGB(255, 255, 255)
newmodel18.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel18.Anchored = true
newmodel19 = Instance.new('Part')
newmodel19:PivotTo(CFrame.new(-12.988846119390482, 6.44241876, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel19.Parent = workspace.devices.label
newmodel19.Material = Enum.Material.SmoothPlastic
newmodel19.Color = Color3.fromRGB(255, 255, 255)
newmodel19.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel19.Anchored = true
newmodel20 = Instance.new('Part')
newmodel20:PivotTo(CFrame.new(-12.988846119390482, 6.397555879999999, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel20.Parent = workspace.devices.label
newmodel20.Material = Enum.Material.SmoothPlastic
newmodel20.Color = Color3.fromRGB(255, 255, 255)
newmodel20.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel20.Anchored = true
newmodel21 = Instance.new('Part')
newmodel21:PivotTo(CFrame.new(-12.988846119390482, 6.3526929999999995, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel21.Parent = workspace.devices.label
newmodel21.Material = Enum.Material.SmoothPlastic
newmodel21.Color = Color3.fromRGB(255, 255, 255)
newmodel21.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel21.Anchored = true
newmodel22 = Instance.new('Part')
newmodel22:PivotTo(CFrame.new(-12.988846119390482, 6.30783304, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel22.Parent = workspace.devices.label
newmodel22.Material = Enum.Material.SmoothPlastic
newmodel22.Color = Color3.fromRGB(255, 255, 255)
newmodel22.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel22.Anchored = true
newmodel23 = Instance.new('Part')
newmodel23:PivotTo(CFrame.new(-12.988846119390482, 6.26296724, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel23.Parent = workspace.devices.label
newmodel23.Material = Enum.Material.SmoothPlastic
newmodel23.Color = Color3.fromRGB(255, 255, 255)
newmodel23.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel23.Anchored = true
newmodel24 = Instance.new('Part')
newmodel24:PivotTo(CFrame.new(-12.988846119390482, 6.21810728, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel24.Parent = workspace.devices.label
newmodel24.Material = Enum.Material.SmoothPlastic
newmodel24.Color = Color3.fromRGB(255, 255, 255)
newmodel24.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel24.Anchored = true
newmodel25 = Instance.new('Part')
newmodel25:PivotTo(CFrame.new(-12.988846119390482, 6.173247320000001, 26.624825249460354) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel25.Parent = workspace.devices.label
newmodel25.Material = Enum.Material.SmoothPlastic
newmodel25.Color = Color3.fromRGB(255, 255, 255)
newmodel25.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel25.Anchored = true
newmodel26 = Instance.new('Part')
newmodel26:PivotTo(CFrame.new(-13.352476795851981, 7.053419416, 27.07806172640973) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel26.Parent = workspace.devices.label
newmodel26.Material = Enum.Material.SmoothPlastic
newmodel26.Color = Color3.fromRGB(255, 255, 255)
newmodel26.Size = Vector3.new(0.3796, 0.00584, 0.04379999999999999)
newmodel26.Anchored = true
newmodel27 = Instance.new('Part')
newmodel27:PivotTo(CFrame.new(-13.546169212213094, 7.408199416, 27.319483790294974) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel27.Parent = workspace.devices.label
newmodel27.Material = Enum.Material.SmoothPlastic
newmodel27.Color = Color3.fromRGB(255, 255, 255)
newmodel27.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel27.Anchored = true
newmodel28 = Instance.new('Part')
newmodel28:PivotTo(CFrame.new(-13.546169212213094, 7.315733236, 27.319483790294974) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel28.Parent = workspace.devices.label
newmodel28.Material = Enum.Material.SmoothPlastic
newmodel28.Color = Color3.fromRGB(255, 255, 255)
newmodel28.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel28.Anchored = true
newmodel29 = Instance.new('Part')
newmodel29:PivotTo(CFrame.new(-13.546169212213094, 7.22326618, 27.319483790294974) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel29.Parent = workspace.devices.label
newmodel29.Material = Enum.Material.SmoothPlastic
newmodel29.Color = Color3.fromRGB(255, 255, 255)
newmodel29.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel29.Anchored = true
newmodel30 = Instance.new('Part')
newmodel30:PivotTo(CFrame.new(-13.546169212213094, 7.1308, 27.319483790294974) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel30.Parent = workspace.devices.label
newmodel30.Material = Enum.Material.SmoothPlastic
newmodel30.Color = Color3.fromRGB(255, 255, 255)
newmodel30.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel30.Anchored = true
newmodel31 = Instance.new('Part')
newmodel31:PivotTo(CFrame.new(-13.352476795851981, 6.59556984, 27.07806172640973) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel31.Parent = workspace.devices.label
newmodel31.Material = Enum.Material.SmoothPlastic
newmodel31.Color = Color3.fromRGB(255, 255, 255)
newmodel31.Size = Vector3.new(0.3796, 0.00584, 0.04379999999999999)
newmodel31.Anchored = true
newmodel32 = Instance.new('Part')
newmodel32:PivotTo(CFrame.new(-13.546169212213094, 6.950350132, 27.319483790294974) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel32.Parent = workspace.devices.label
newmodel32.Material = Enum.Material.SmoothPlastic
newmodel32.Color = Color3.fromRGB(255, 255, 255)
newmodel32.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel32.Anchored = true
newmodel33 = Instance.new('Part')
newmodel33:PivotTo(CFrame.new(-13.546169212213094, 6.857883368, 27.319483790294974) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel33.Parent = workspace.devices.label
newmodel33.Material = Enum.Material.SmoothPlastic
newmodel33.Color = Color3.fromRGB(255, 255, 255)
newmodel33.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel33.Anchored = true
newmodel34 = Instance.new('Part')
newmodel34:PivotTo(CFrame.new(-13.546169212213094, 6.765416312, 27.319483790294974) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel34.Parent = workspace.devices.label
newmodel34.Material = Enum.Material.SmoothPlastic
newmodel34.Color = Color3.fromRGB(255, 255, 255)
newmodel34.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel34.Anchored = true
newmodel35 = Instance.new('Part')
newmodel35:PivotTo(CFrame.new(-13.546169212213094, 6.67294984, 27.319483790294974) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel35.Parent = workspace.devices.label
newmodel35.Material = Enum.Material.SmoothPlastic
newmodel35.Color = Color3.fromRGB(255, 255, 255)
newmodel35.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel35.Anchored = true
newmodel36 = Instance.new('Part')
newmodel36:PivotTo(CFrame.new(-13.352476795851981, 6.137722599999999, 27.07806172640973) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel36.Parent = workspace.devices.label
newmodel36.Material = Enum.Material.SmoothPlastic
newmodel36.Color = Color3.fromRGB(255, 255, 255)
newmodel36.Size = Vector3.new(0.3796, 0.00584, 0.04379999999999999)
newmodel36.Anchored = true
newmodel37 = Instance.new('Part')
newmodel37:PivotTo(CFrame.new(-13.546169212213094, 6.4925026, 27.319483790294974) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel37.Parent = workspace.devices.label
newmodel37.Material = Enum.Material.SmoothPlastic
newmodel37.Color = Color3.fromRGB(255, 255, 255)
newmodel37.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel37.Anchored = true
newmodel38 = Instance.new('Part')
newmodel38:PivotTo(CFrame.new(-13.546169212213094, 6.400034960000001, 27.319483790294974) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel38.Parent = workspace.devices.label
newmodel38.Material = Enum.Material.SmoothPlastic
newmodel38.Color = Color3.fromRGB(255, 255, 255)
newmodel38.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel38.Anchored = true
newmodel39 = Instance.new('Part')
newmodel39:PivotTo(CFrame.new(-13.546169212213094, 6.307567319999999, 27.319483790294974) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel39.Parent = workspace.devices.label
newmodel39.Material = Enum.Material.SmoothPlastic
newmodel39.Color = Color3.fromRGB(255, 255, 255)
newmodel39.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel39.Anchored = true
newmodel40 = Instance.new('Part')
newmodel40:PivotTo(CFrame.new(-13.546169212213094, 6.215102600000001, 27.319483790294974) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel40.Parent = workspace.devices.label
newmodel40.Material = Enum.Material.SmoothPlastic
newmodel40.Color = Color3.fromRGB(255, 255, 255)
newmodel40.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel40.Anchored = true
newmodel41 = Instance.new('Part')
newmodel41:PivotTo(CFrame.new(-12.2067619587234, 5.99397392, 25.650020062208263) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel41.Parent = workspace.devices.label
newmodel41.Material = Enum.Material.SmoothPlastic
newmodel41.Color = Color3.fromRGB(255, 255, 255)
newmodel41.Size = Vector3.new(0.1898000292, 0.00584, 0.04379999999999999)
newmodel41.Anchored = true
newmodel42 = Instance.new('Part')
newmodel42:PivotTo(CFrame.new(-12.784971079274566, 5.99397392, 26.370711361657403) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel42.Parent = workspace.devices.label
newmodel42.Material = Enum.Material.SmoothPlastic
newmodel42.Color = Color3.fromRGB(255, 255, 255)
newmodel42.Size = Vector3.new(0.32119999999999993, 0.00584, 0.04379999999999999)
newmodel42.Anchored = true
newmodel43 = Instance.new('Part')
newmodel43:PivotTo(CFrame.new(-12.358426315035558, 4.89846, 25.839057519670945) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel43.Parent = workspace.devices.label
newmodel43.Material = Enum.Material.SmoothPlastic
newmodel43.Color = Color3.fromRGB(255, 255, 255)
newmodel43.Size = Vector3.new(0.32119999999999993, 0.00584, 0.04379999999999999)
newmodel43.Anchored = true
newmodel44 = Instance.new('Part')
newmodel44:PivotTo(CFrame.new(-13.353283548366605, 4.89846, 27.07906727872192) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel44.Parent = workspace.devices.label
newmodel44.Material = Enum.Material.SmoothPlastic
newmodel44.Color = Color3.fromRGB(255, 255, 255)
newmodel44.Size = Vector3.new(0.32119999999999993, 0.00584, 0.04379999999999999)
newmodel44.Anchored = true
newmodel45 = Instance.new('Part')
newmodel45:PivotTo(CFrame.new(-11.898862403799804, 7.030059708, 25.266247958914256) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel45.Parent = workspace.devices.label
newmodel45.Material = Enum.Material.SmoothPlastic
newmodel45.Color = Color3.fromRGB(255, 255, 255)
newmodel45.Size = Vector3.new(0.1898000292, 0.00584, 0.04379999999999999)
newmodel45.Anchored = true
newmodel46 = Instance.new('Part')
newmodel46:PivotTo(CFrame.new(-11.898862403799804, 6.808108463999999, 25.266247958914256) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel46.Parent = workspace.devices.label
newmodel46.Material = Enum.Material.SmoothPlastic
newmodel46.Color = Color3.fromRGB(255, 255, 255)
newmodel46.Size = Vector3.new(0.1898000292, 0.00584, 0.04379999999999999)
newmodel46.Anchored = true
newmodel47 = Instance.new('Part')
newmodel47:PivotTo(CFrame.new(-11.898862403799804, 6.58615576, 25.266247958914256) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel47.Parent = workspace.devices.label
newmodel47.Material = Enum.Material.SmoothPlastic
newmodel47.Color = Color3.fromRGB(255, 255, 255)
newmodel47.Size = Vector3.new(0.1898000292, 0.00584, 0.04379999999999999)
newmodel47.Anchored = true
newmodel48 = Instance.new('Part')
newmodel48:PivotTo(CFrame.new(-11.898862403799804, 6.235755760000001, 25.266247958914256) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel48.Parent = workspace.devices.label
newmodel48.Material = Enum.Material.SmoothPlastic
newmodel48.Color = Color3.fromRGB(255, 255, 255)
newmodel48.Size = Vector3.new(0.1898000292, 0.00584, 0.04379999999999999)
newmodel48.Anchored = true
newmodel49 = Instance.new('Part')
newmodel49:PivotTo(CFrame.new(-12.851797231510877, 4.84298, 26.45400480131547) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel49.Parent = workspace.devices.label
newmodel49.Material = Enum.Material.SmoothPlastic
newmodel49.Color = Color3.fromRGB(255, 255, 255)
newmodel49.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel49.Anchored = true
newmodel50 = Instance.new('Part')
newmodel50:PivotTo(CFrame.new(-12.820734427384366, 4.48966, 26.415287507044617) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel50.Parent = workspace.devices.label
newmodel50.Material = Enum.Material.SmoothPlastic
newmodel50.Color = Color3.fromRGB(255, 255, 255)
newmodel50.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel50.Anchored = true
newmodel51 = Instance.new('Part')
newmodel51:PivotTo(CFrame.new(-12.820734427384366, 4.23124, 26.415287507044617) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel51.Parent = workspace.devices.label
newmodel51.Material = Enum.Material.SmoothPlastic
newmodel51.Color = Color3.fromRGB(255, 255, 255)
newmodel51.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel51.Anchored = true
newmodel52 = Instance.new('Part')
newmodel52:PivotTo(CFrame.new(-12.943161999474572, 4.84298, 26.56788365761033) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel52.Parent = workspace.devices.label
newmodel52.Material = Enum.Material.SmoothPlastic
newmodel52.Color = Color3.fromRGB(255, 255, 255)
newmodel52.Size = Vector3.new(0.1168000292, 0.00584, 0.04379999999999999)
newmodel52.Anchored = true
