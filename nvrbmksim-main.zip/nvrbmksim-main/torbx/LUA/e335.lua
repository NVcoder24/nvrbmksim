newmodel0 = workspace.prefabs.e335:clone()
newmodel0:PivotTo(CFrame.new(-54.71041370793043, 5.483920000000001, 37.18380454993192) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel0.Parent = workspace.devices.e335
newmodel1 = workspace.prefabs.e335:clone()
newmodel1:PivotTo(CFrame.new(-55.1377048429728, 5.483920000000001, 36.98601518317893) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel1.Parent = workspace.devices.e335
newmodel2 = workspace.prefabs.e335:clone()
newmodel2:PivotTo(CFrame.new(-55.566318181000575, 5.483920000000001, 36.78760382580114) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel2.Parent = workspace.devices.e335
newmodel3 = workspace.prefabs.e335:clone()
newmodel3:PivotTo(CFrame.new(-55.99360606068688, 5.483920000000001, 36.5898032561326) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel3.Parent = workspace.devices.e335
newmodel4 = workspace.prefabs.e335:clone()
newmodel4:PivotTo(CFrame.new(-56.420899982997604, 5.483920000000001, 36.392012264479376) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel4.Parent = workspace.devices.e335
newmodel5 = workspace.prefabs.e335:clone()
newmodel5:PivotTo(CFrame.new(-54.74854436165481, 4.8444400000000005, 37.175812567770926) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel5.Parent = workspace.devices.e335
newmodel6 = workspace.prefabs.e335:clone()
newmodel6:PivotTo(CFrame.new(-57.62855697322711, 6.079599708000001, 35.79111486444989) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel6.Parent = workspace.devices.e335
newmodel7 = workspace.prefabs.e335:clone()
newmodel7:PivotTo(CFrame.new(-59.220245383994005, 6.079599708000001, 34.868812204356544) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel7.Parent = workspace.devices.e335
newmodel8 = workspace.prefabs.e335:clone()
newmodel8:PivotTo(CFrame.new(-62.95031438518514, 5.483920000000001, 32.255077644350195) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel8.Parent = workspace.devices.e335
newmodel9 = workspace.prefabs.e335:clone()
newmodel9:PivotTo(CFrame.new(-63.30787320170457, 5.483920000000001, 31.94872720723137) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel9.Parent = workspace.devices.e335
newmodel10 = workspace.prefabs.e335:clone()
newmodel10:PivotTo(CFrame.new(-63.66653855282075, 5.483920000000001, 31.641422957327755) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel10.Parent = workspace.devices.e335
newmodel11 = workspace.prefabs.e335:clone()
newmodel11:PivotTo(CFrame.new(-64.02409156385839, 5.483920000000001, 31.335063051714858) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel11.Parent = workspace.devices.e335
newmodel12 = workspace.prefabs.e335:clone()
newmodel12:PivotTo(CFrame.new(-64.38165300248222, 5.483920000000001, 31.028717470090882) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel12.Parent = workspace.devices.e335
newmodel13 = workspace.prefabs.e335:clone()
newmodel13:PivotTo(CFrame.new(-62.98484355604355, 4.8444400000000005, 32.23703804362444) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel13.Parent = workspace.devices.e335
