newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-11.298941192537702, 9.057999123999998, 24.406086459180678) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel0.Parent = workspace.devices.lplace
newmodel0.Material = Enum.Material.SmoothPlastic
newmodel0.Color = Color3.fromRGB(255, 255, 255)
newmodel0.Size = Vector3.new(0.9343999999999999, 0.01825000292, 0.46719999999999995)
newmodel0.Anchored = true
newmodel1 = Instance.new('Part')
newmodel1:PivotTo(CFrame.new(-25.558001062810597, 9.058, 36.37161905637866) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel1.Parent = workspace.devices.lplace
newmodel1.Material = Enum.Material.SmoothPlastic
newmodel1.Color = Color3.fromRGB(255, 255, 255)
newmodel1.Size = Vector3.new(0.934400292, 0.01825, 0.46719999999999995)
newmodel1.Anchored = true
