newmodel0 = workspace.prefabs.sign_arm_2l:clone()
newmodel0:PivotTo(CFrame.new(-42.28128292636478, 3.6869743334671896, 35.35528666564785) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel0.Parent = workspace.devices.sign_arm_2l
newmodel1 = workspace.prefabs.sign_arm_2l:clone()
newmodel1:PivotTo(CFrame.new(-42.55620854394536, 3.6869742631356544, 35.33824477530075) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel1.Parent = workspace.devices.sign_arm_2l
newmodel2 = workspace.prefabs.sign_arm_2l:clone()
newmodel2:PivotTo(CFrame.new(-42.831132992057405, 3.6869745691914386, 35.32120494432782) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel2.Parent = workspace.devices.sign_arm_2l
newmodel3 = workspace.prefabs.sign_arm_2l:clone()
newmodel3:PivotTo(CFrame.new(-43.10606110930111, 3.6869742591653787, 35.30416161199426) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel3.Parent = workspace.devices.sign_arm_2l
newmodel4 = workspace.prefabs.sign_arm_2l:clone()
newmodel4:PivotTo(CFrame.new(-42.27601252078328, 3.203866990705125, 35.270264461098336) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel4.Parent = workspace.devices.sign_arm_2l
newmodel5 = workspace.prefabs.sign_arm_2l:clone()
newmodel5:PivotTo(CFrame.new(-42.82595919468765, 3.2038670440217443, 35.23617650581683) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel5.Parent = workspace.devices.sign_arm_2l
newmodel6 = workspace.prefabs.sign_arm_2l:clone()
newmodel6:PivotTo(CFrame.new(-42.55084295639752, 3.203867157175067, 35.253229383826216) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel6.Parent = workspace.devices.sign_arm_2l
newmodel7 = workspace.prefabs.sign_arm_2l:clone()
newmodel7:PivotTo(CFrame.new(-43.10079031852676, 3.2038671313681633, 35.21914043838351) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel7.Parent = workspace.devices.sign_arm_2l
newmodel8 = workspace.prefabs.sign_arm_2l:clone()
newmodel8:PivotTo(CFrame.new(-42.26047485878583, 2.745943015682533, 34.93781356725532) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.devices.sign_arm_2l
newmodel9 = workspace.prefabs.sign_arm_2l:clone()
newmodel9:PivotTo(CFrame.new(-42.26353042618191, 2.7502694368720957, 34.987170326273585) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.devices.sign_arm_2l
newmodel10 = workspace.prefabs.sign_arm_2l:clone()
newmodel10:PivotTo(CFrame.new(-42.538319206510295, 2.7459430235813884, 34.920593766767006) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.devices.sign_arm_2l
newmodel11 = workspace.prefabs.sign_arm_2l:clone()
newmodel11:PivotTo(CFrame.new(-42.541372857014, 2.750269435834096, 34.969945248993284) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.devices.sign_arm_2l
newmodel12 = workspace.prefabs.sign_arm_2l:clone()
newmodel12:PivotTo(CFrame.new(-42.816159715058404, 2.7459430241824823, 34.90337023002732) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.sign_arm_2l
newmodel13 = workspace.prefabs.sign_arm_2l:clone()
newmodel13:PivotTo(CFrame.new(-42.81921618784405, 2.7502694476669305, 34.95272626590992) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.sign_arm_2l
newmodel14 = workspace.prefabs.sign_arm_2l:clone()
newmodel14:PivotTo(CFrame.new(-43.093998926011196, 2.7459430313261413, 34.88615057386966) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.sign_arm_2l
newmodel15 = workspace.prefabs.sign_arm_2l:clone()
newmodel15:PivotTo(CFrame.new(-43.09705413232222, 2.750269447260602, 34.9355043093484) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.sign_arm_2l
newmodel16 = workspace.prefabs.sign_arm_2l:clone()
newmodel16:PivotTo(CFrame.new(-42.23492654134553, 2.70980474390748, 34.52554416304787) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.sign_arm_2l
newmodel17 = workspace.prefabs.sign_arm_2l:clone()
newmodel17:PivotTo(CFrame.new(-42.23798209942545, 2.7141311510077006, 34.57490077684567) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel17.Parent = workspace.devices.sign_arm_2l
newmodel18 = workspace.prefabs.sign_arm_2l:clone()
newmodel18:PivotTo(CFrame.new(-42.79157578950927, 2.7098047574476083, 34.49103997404101) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel18.Parent = workspace.devices.sign_arm_2l
newmodel19 = workspace.prefabs.sign_arm_2l:clone()
newmodel19:PivotTo(CFrame.new(-42.794631405906216, 2.714131164671868, 34.540396584230734) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel19.Parent = workspace.devices.sign_arm_2l
newmodel20 = workspace.prefabs.sign_arm_2l:clone()
newmodel20:PivotTo(CFrame.new(-42.511794848966304, 2.7098047477840277, 34.508383354881786) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel20.Parent = workspace.devices.sign_arm_2l
newmodel21 = workspace.prefabs.sign_arm_2l:clone()
newmodel21:PivotTo(CFrame.new(-42.514851609901555, 2.7141311675018382, 34.557739314685804) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel21.Parent = workspace.devices.sign_arm_2l
newmodel22 = workspace.prefabs.sign_arm_2l:clone()
newmodel22:PivotTo(CFrame.new(-43.06844413711338, 2.709804734551421, 34.47387887187727) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.sign_arm_2l
newmodel23 = workspace.prefabs.sign_arm_2l:clone()
newmodel23:PivotTo(CFrame.new(-43.07150091666172, 2.7141311823652248, 34.52323512211889) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel23.Parent = workspace.devices.sign_arm_2l
newmodel24 = workspace.prefabs.sign_arm_2l:clone()
newmodel24:PivotTo(CFrame.new(-43.04018723404498, 2.669849121487455, 34.01805663887105) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.sign_arm_2l
newmodel25 = workspace.prefabs.sign_arm_2l:clone()
newmodel25:PivotTo(CFrame.new(-43.04324550952746, 2.6741753729646205, 34.0674148161117) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.sign_arm_2l
newmodel26 = workspace.prefabs.sign_arm_2l:clone()
newmodel26:PivotTo(CFrame.new(-42.20667016306071, 2.669849114069698, 34.06972479720363) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.sign_arm_2l
newmodel27 = workspace.prefabs.sign_arm_2l:clone()
newmodel27:PivotTo(CFrame.new(-42.20972415743313, 2.674175353302149, 34.11907917829892) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel27.Parent = workspace.devices.sign_arm_2l
newmodel28 = workspace.prefabs.sign_arm_2l:clone()
newmodel28:PivotTo(CFrame.new(-42.763321566094405, 2.669849128718788, 34.03521902438276) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel28.Parent = workspace.devices.sign_arm_2l
newmodel29 = workspace.prefabs.sign_arm_2l:clone()
newmodel29:PivotTo(CFrame.new(-42.766377143926846, 2.6741753704113305, 34.08457562794382) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel29.Parent = workspace.devices.sign_arm_2l
newmodel30 = workspace.prefabs.sign_arm_2l:clone()
newmodel30:PivotTo(CFrame.new(-42.483536372660566, 2.6698491028406335, 34.05255860711269) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel30.Parent = workspace.devices.sign_arm_2l
newmodel31 = workspace.prefabs.sign_arm_2l:clone()
newmodel31:PivotTo(CFrame.new(-42.48659651189617, 2.674175382227453, 34.101919280892) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel31.Parent = workspace.devices.sign_arm_2l
