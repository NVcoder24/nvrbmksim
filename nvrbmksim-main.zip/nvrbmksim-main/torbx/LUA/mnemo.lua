newmodel0 = workspace.prefabs.mnemo300200:clone()
newmodel0:PivotTo(CFrame.new(-26.733343615438223, 10.20531311411716, 36.06977039402354) * CFrame.fromEulerAngles(0, math.rad(-67.58998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel0.Parent = workspace.devices.mnemo
newmodel1 = workspace.prefabs.mnemo300200:clone()
newmodel1:PivotTo(CFrame.new(-27.559384428490063, 10.20531311411716, 36.410408861570374) * CFrame.fromEulerAngles(0, math.rad(-67.58998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel1.Parent = workspace.devices.mnemo
newmodel2 = workspace.prefabs.mnemo300300:clone()
newmodel2:PivotTo(CFrame.new(-26.58582784379582, 8.761215366781952, 36.427492904998346) * CFrame.fromEulerAngles(0, math.rad(-67.58998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel2.Parent = workspace.devices.mnemo
newmodel3 = workspace.prefabs.mnemo300300:clone()
newmodel3:PivotTo(CFrame.new(-27.50003237974331, 9.62428941108776, 36.554336278095384) * CFrame.fromEulerAngles(0, math.rad(-67.58998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel3.Parent = workspace.devices.mnemo
newmodel4 = workspace.prefabs.mnemo300300:clone()
newmodel4:PivotTo(CFrame.new(-26.673991566691477, 9.62428941108776, 36.21369781054857) * CFrame.fromEulerAngles(0, math.rad(-67.58998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel4.Parent = workspace.devices.mnemo
newmodel5 = workspace.prefabs.mnemo300300:clone()
newmodel5:PivotTo(CFrame.new(-27.41186865684766, 8.761215366781952, 36.76813137254518) * CFrame.fromEulerAngles(0, math.rad(-67.58998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel5.Parent = workspace.devices.mnemo
newmodel6 = workspace.prefabs.mnemo300200:clone()
newmodel6:PivotTo(CFrame.new(-29.45990291010886, 7.898141322476144, 37.83649955846721) * CFrame.fromEulerAngles(0, math.rad(-72.83998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel6.Parent = workspace.devices.mnemo
newmodel7 = workspace.prefabs.mnemo300300:clone()
newmodel7:PivotTo(CFrame.new(-29.528134182597228, 8.761215366781952, 37.615534226570475) * CFrame.fromEulerAngles(0, math.rad(-72.83998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel7.Parent = workspace.devices.mnemo
newmodel8 = workspace.prefabs.mnemo300300:clone()
newmodel8:PivotTo(CFrame.new(-30.381878665771588, 8.761215366781952, 37.879159619598816) * CFrame.fromEulerAngles(0, math.rad(-72.83998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel8.Parent = workspace.devices.mnemo
newmodel9 = workspace.prefabs.mnemo300200:clone()
newmodel9:PivotTo(CFrame.new(-32.64665957073463, 10.20531311411716, 38.1507469601936) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel9.Parent = workspace.devices.mnemo
newmodel10 = workspace.prefabs.mnemo300200:clone()
newmodel10:PivotTo(CFrame.new(-33.52094474852005, 10.20531311411716, 38.335147118286535) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel10.Parent = workspace.devices.mnemo
newmodel11 = workspace.prefabs.mnemo300300:clone()
newmodel11:PivotTo(CFrame.new(-32.56680384625359, 8.761215366781952, 38.52936201669425) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel11.Parent = workspace.devices.mnemo
newmodel12 = workspace.prefabs.mnemo300300:clone()
newmodel12:PivotTo(CFrame.new(-33.4888152968734, 9.62428941108776, 38.48748051992547) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel12.Parent = workspace.devices.mnemo
newmodel13 = workspace.prefabs.mnemo300300:clone()
newmodel13:PivotTo(CFrame.new(-32.614530119087966, 9.62428941108776, 38.30308036183254) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel13.Parent = workspace.devices.mnemo
newmodel14 = workspace.prefabs.mnemo300300:clone()
newmodel14:PivotTo(CFrame.new(-33.44108902403902, 8.761215366781952, 38.71376217478718) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel14.Parent = workspace.devices.mnemo
newmodel15 = workspace.prefabs.mnemo300200:clone()
newmodel15:PivotTo(CFrame.new(-35.721222968054825, 10.20531311411716, 38.776979252823146) * CFrame.fromEulerAngles(0, math.rad(-83.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel15.Parent = workspace.devices.mnemo
newmodel16 = workspace.prefabs.mnemo300200:clone()
newmodel16:PivotTo(CFrame.new(-36.608713369146336, 10.20531311411716, 38.88060732995685) * CFrame.fromEulerAngles(0, math.rad(-83.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel16.Parent = workspace.devices.mnemo
newmodel17 = workspace.prefabs.mnemo300200:clone()
newmodel17:PivotTo(CFrame.new(-36.53701561576367, 7.898141322476144, 39.49464041507186) * CFrame.fromEulerAngles(0, math.rad(-83.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel17.Parent = workspace.devices.mnemo
newmodel18 = workspace.prefabs.mnemo300200:clone()
newmodel18:PivotTo(CFrame.new(-35.64952521467215, 7.898141322476144, 39.39101233793816) * CFrame.fromEulerAngles(0, math.rad(-83.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel18.Parent = workspace.devices.mnemo
newmodel19 = workspace.prefabs.mnemo300200:clone()
newmodel19:PivotTo(CFrame.new(-37.424506016855176, 7.898141322476144, 39.59826849220556) * CFrame.fromEulerAngles(0, math.rad(-83.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel19.Parent = workspace.devices.mnemo
newmodel20 = workspace.prefabs.mnemo300200:clone()
newmodel20:PivotTo(CFrame.new(-37.49620377023784, 10.20531311411716, 38.98423540709055) * CFrame.fromEulerAngles(0, math.rad(-83.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel20.Parent = workspace.devices.mnemo
newmodel21 = workspace.prefabs.mnemo300300:clone()
newmodel21:PivotTo(CFrame.new(-36.590657455702775, 9.62428941108776, 39.03524157877555) * CFrame.fromEulerAngles(0, math.rad(-83.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel21.Parent = workspace.devices.mnemo
newmodel22 = workspace.prefabs.mnemo300300:clone()
newmodel22:PivotTo(CFrame.new(-36.563836535733216, 8.761215366781952, 39.264940996923706) * CFrame.fromEulerAngles(0, math.rad(-83.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel22.Parent = workspace.devices.mnemo
newmodel23 = workspace.prefabs.mnemo300200:clone()
newmodel23:PivotTo(CFrame.new(-38.84018823344267, 10.20531311411716, 39.11926163221453) * CFrame.fromEulerAngles(0, math.rad(-88.58998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel23.Parent = workspace.devices.mnemo
newmodel24 = workspace.prefabs.mnemo300200:clone()
newmodel24:PivotTo(CFrame.new(-39.73343767714671, 10.20531311411716, 39.14124848561413) * CFrame.fromEulerAngles(0, math.rad(-88.58998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel24.Parent = workspace.devices.mnemo
newmodel25 = workspace.prefabs.mnemo300300:clone()
newmodel25:PivotTo(CFrame.new(-38.83066667920193, 8.761215366781952, 39.50608929118712) * CFrame.fromEulerAngles(0, math.rad(-88.58998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel25.Parent = workspace.devices.mnemo
newmodel26 = workspace.prefabs.mnemo300300:clone()
newmodel26:PivotTo(CFrame.new(-39.72960673930767, 9.62428941108776, 39.296886176528886) * CFrame.fromEulerAngles(0, math.rad(-88.58998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel26.Parent = workspace.devices.mnemo
newmodel27 = workspace.prefabs.mnemo300300:clone()
newmodel27:PivotTo(CFrame.new(-38.83635729560363, 9.62428941108776, 39.27489932312928) * CFrame.fromEulerAngles(0, math.rad(-88.58998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel27.Parent = workspace.devices.mnemo
newmodel28 = workspace.prefabs.mnemo300300:clone()
newmodel28:PivotTo(CFrame.new(-39.723916122905976, 8.761215366781952, 39.528076144586734) * CFrame.fromEulerAngles(0, math.rad(-88.58998), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel28.Parent = workspace.devices.mnemo
newmodel29 = workspace.prefabs.mnemo300200:clone()
newmodel29:PivotTo(CFrame.new(-41.97739084680206, 10.20531311411716, 39.174717380004594) * CFrame.fromEulerAngles(0, math.rad(-93.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel29.Parent = workspace.devices.mnemo
newmodel30 = workspace.prefabs.mnemo300200:clone()
newmodel30:PivotTo(CFrame.new(-42.868904856183384, 10.20531311411716, 39.114877915795574) * CFrame.fromEulerAngles(0, math.rad(-93.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel30.Parent = workspace.devices.mnemo
newmodel31 = workspace.prefabs.mnemo300200:clone()
newmodel31:PivotTo(CFrame.new(-42.91030633024407, 7.898141322476144, 39.73169483790584) * CFrame.fromEulerAngles(0, math.rad(-93.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel31.Parent = workspace.devices.mnemo
newmodel32 = workspace.prefabs.mnemo300200:clone()
newmodel32:PivotTo(CFrame.new(-42.01879232086274, 7.898141322476144, 39.791534302114854) * CFrame.fromEulerAngles(0, math.rad(-93.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel32.Parent = workspace.devices.mnemo
newmodel33 = workspace.prefabs.mnemo300200:clone()
newmodel33:PivotTo(CFrame.new(-43.8018203396254, 7.898141322476144, 39.67185537369682) * CFrame.fromEulerAngles(0, math.rad(-93.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel33.Parent = workspace.devices.mnemo
newmodel34 = workspace.prefabs.mnemo300200:clone()
newmodel34:PivotTo(CFrame.new(-43.76041886556472, 10.20531311411716, 39.055038451586555) * CFrame.fromEulerAngles(0, math.rad(-93.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel34.Parent = workspace.devices.mnemo
newmodel35 = workspace.prefabs.mnemo300300:clone()
newmodel35:PivotTo(CFrame.new(-42.00330472787672, 8.761215366781952, 39.56079349751127) * CFrame.fromEulerAngles(0, math.rad(-93.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel35.Parent = workspace.devices.mnemo
newmodel36 = workspace.prefabs.mnemo300300:clone()
newmodel36:PivotTo(CFrame.new(-42.87933114427202, 9.62428941108776, 39.27021322869865) * CFrame.fromEulerAngles(0, math.rad(-93.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel36.Parent = workspace.devices.mnemo
newmodel37 = workspace.prefabs.mnemo300300:clone()
newmodel37:PivotTo(CFrame.new(-41.98781713489069, 9.62428941108776, 39.33005269290767) * CFrame.fromEulerAngles(0, math.rad(-93.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel37.Parent = workspace.devices.mnemo
newmodel38 = workspace.prefabs.mnemo300300:clone()
newmodel38:PivotTo(CFrame.new(-43.770845153653354, 9.62428941108776, 39.21037376448963) * CFrame.fromEulerAngles(0, math.rad(-93.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel38.Parent = workspace.devices.mnemo
newmodel39 = workspace.prefabs.mnemo300300:clone()
newmodel39:PivotTo(CFrame.new(-42.89481873725805, 8.761215366781952, 39.50095403330225) * CFrame.fromEulerAngles(0, math.rad(-93.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel39.Parent = workspace.devices.mnemo
newmodel40 = workspace.prefabs.mnemo300300:clone()
newmodel40:PivotTo(CFrame.new(-43.786332746639374, 8.761215366781952, 39.44111456909323) * CFrame.fromEulerAngles(0, math.rad(-93.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel40.Parent = workspace.devices.mnemo
newmodel41 = workspace.prefabs.mnemo300200:clone()
newmodel41:PivotTo(CFrame.new(-45.10651401667367, 10.20531311411716, 38.94289697288282) * CFrame.fromEulerAngles(0, math.rad(-99.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel41.Parent = workspace.devices.mnemo
newmodel42 = workspace.prefabs.mnemo300300:clone()
newmodel42:PivotTo(CFrame.new(-45.16764577681954, 8.761215366781952, 39.324982311050675) * CFrame.fromEulerAngles(0, math.rad(-99.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel42.Parent = workspace.devices.mnemo
newmodel43 = workspace.prefabs.mnemo300300:clone()
newmodel43:PivotTo(CFrame.new(-45.13110999829486, 9.62428941108776, 39.0966266206613) * CFrame.fromEulerAngles(0, math.rad(-99.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel43.Parent = workspace.devices.mnemo
newmodel44 = workspace.prefabs.mnemo300200:clone()
newmodel44:PivotTo(CFrame.new(-50.08575181817328, 7.898141322476144, 38.582035851585616) * CFrame.fromEulerAngles(0, math.rad(-104.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel44.Parent = workspace.devices.mnemo
newmodel45 = workspace.prefabs.mnemo300200:clone()
newmodel45:PivotTo(CFrame.new(-49.932637555154166, 10.20531311411716, 37.983092431957274) * CFrame.fromEulerAngles(0, math.rad(-104.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel45.Parent = workspace.devices.mnemo
newmodel46 = workspace.prefabs.mnemo300300:clone()
newmodel46:PivotTo(CFrame.new(-49.971196892784896, 9.62428941108776, 38.133926593868566) * CFrame.fromEulerAngles(0, math.rad(-104.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel46.Parent = workspace.devices.mnemo
newmodel47 = workspace.prefabs.mnemo300300:clone()
newmodel47:PivotTo(CFrame.new(-50.02847435547909, 8.761215366781952, 38.35798122272709) * CFrame.fromEulerAngles(0, math.rad(-104.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel47.Parent = workspace.devices.mnemo
newmodel48 = workspace.prefabs.mnemo300200:clone()
newmodel48:PivotTo(CFrame.new(-51.235754289393384, 10.20531311411716, 37.62751301101473) * CFrame.fromEulerAngles(0, math.rad(-109.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel48.Parent = workspace.devices.mnemo
newmodel49 = workspace.prefabs.mnemo300200:clone()
newmodel49:PivotTo(CFrame.new(-52.07755381729722, 10.20531311411716, 37.327927388494416) * CFrame.fromEulerAngles(0, math.rad(-109.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel49.Parent = workspace.devices.mnemo
newmodel50 = workspace.prefabs.mnemo300200:clone()
newmodel50:PivotTo(CFrame.new(-52.28482984397425, 7.898141322476144, 37.910348066545055) * CFrame.fromEulerAngles(0, math.rad(-109.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel50.Parent = workspace.devices.mnemo
newmodel51 = workspace.prefabs.mnemo300200:clone()
newmodel51:PivotTo(CFrame.new(-51.443030316070406, 7.898141322476144, 38.209933689065366) * CFrame.fromEulerAngles(0, math.rad(-109.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel51.Parent = workspace.devices.mnemo
newmodel52 = workspace.prefabs.mnemo300200:clone()
newmodel52:PivotTo(CFrame.new(-53.12662937187808, 7.898141322476144, 37.61076244402474) * CFrame.fromEulerAngles(0, math.rad(-109.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel52.Parent = workspace.devices.mnemo
newmodel53 = workspace.prefabs.mnemo300200:clone()
newmodel53:PivotTo(CFrame.new(-52.91935334520105, 10.20531311411716, 37.028341765974105) * CFrame.fromEulerAngles(0, math.rad(-109.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel53.Parent = workspace.devices.mnemo
newmodel54 = workspace.prefabs.mnemo300300:clone()
newmodel54:PivotTo(CFrame.new(-51.365491851323256, 8.761215366781952, 37.99205993908555) * CFrame.fromEulerAngles(0, math.rad(-109.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel54.Parent = workspace.devices.mnemo
newmodel55 = workspace.prefabs.mnemo300300:clone()
newmodel55:PivotTo(CFrame.new(-52.129752914479944, 9.62428941108776, 37.47460056658541) * CFrame.fromEulerAngles(0, math.rad(-109.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel55.Parent = workspace.devices.mnemo
newmodel56 = workspace.prefabs.mnemo300300:clone()
newmodel56:PivotTo(CFrame.new(-51.287953386576106, 9.62428941108776, 37.77418618910572) * CFrame.fromEulerAngles(0, math.rad(-109.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel56.Parent = workspace.devices.mnemo
newmodel57 = workspace.prefabs.mnemo300300:clone()
newmodel57:PivotTo(CFrame.new(-52.97155244238378, 9.62428941108776, 37.175014944065104) * CFrame.fromEulerAngles(0, math.rad(-109.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel57.Parent = workspace.devices.mnemo
newmodel58 = workspace.prefabs.mnemo300300:clone()
newmodel58:PivotTo(CFrame.new(-52.207291379227094, 8.761215366781952, 37.69247431656523) * CFrame.fromEulerAngles(0, math.rad(-109.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel58.Parent = workspace.devices.mnemo
newmodel59 = workspace.prefabs.mnemo300300:clone()
newmodel59:PivotTo(CFrame.new(-53.04909090713093, 8.761215366781952, 37.39288869404493) * CFrame.fromEulerAngles(0, math.rad(-109.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel59.Parent = workspace.devices.mnemo
newmodel60 = workspace.prefabs.mnemo300200:clone()
newmodel60:PivotTo(CFrame.new(-54.18444687760047, 10.20531311411716, 36.55500799607529) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel60.Parent = workspace.devices.mnemo
newmodel61 = workspace.prefabs.mnemo300200:clone()
newmodel61:PivotTo(CFrame.new(-54.99530236061645, 10.20531311411716, 36.179652996024785) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel61.Parent = workspace.devices.mnemo
newmodel62 = workspace.prefabs.mnemo300200:clone()
newmodel62:PivotTo(CFrame.new(-55.25500138204914, 7.898141322476144, 36.7406642398719) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel62.Parent = workspace.devices.mnemo
newmodel63 = workspace.prefabs.mnemo300200:clone()
newmodel63:PivotTo(CFrame.new(-54.44414589903316, 7.898141322476144, 37.11601923992241) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel63.Parent = workspace.devices.mnemo
newmodel64 = workspace.prefabs.mnemo300200:clone()
newmodel64:PivotTo(CFrame.new(-56.06585686506511, 7.898141322476144, 36.365309239821386) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel64.Parent = workspace.devices.mnemo
newmodel65 = workspace.prefabs.mnemo300200:clone()
newmodel65:PivotTo(CFrame.new(-55.80615784363243, 10.20531311411716, 35.80429799597426) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel65.Parent = workspace.devices.mnemo
newmodel66 = workspace.prefabs.mnemo300300:clone()
newmodel66:PivotTo(CFrame.new(-54.34699687634562, 8.761215366781952, 36.90615439809207) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel66.Parent = workspace.devices.mnemo
newmodel67 = workspace.prefabs.mnemo300300:clone()
newmodel67:PivotTo(CFrame.new(-55.06070333667407, 9.62428941108776, 36.32093455621123) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel67.Parent = workspace.devices.mnemo
newmodel68 = workspace.prefabs.mnemo300300:clone()
newmodel68:PivotTo(CFrame.new(-54.24984785365809, 9.62428941108776, 36.69628955626173) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel68.Parent = workspace.devices.mnemo
newmodel69 = workspace.prefabs.mnemo300300:clone()
newmodel69:PivotTo(CFrame.new(-55.871558819690044, 9.62428941108776, 35.9455795561607) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel69.Parent = workspace.devices.mnemo
newmodel70 = workspace.prefabs.mnemo300300:clone()
newmodel70:PivotTo(CFrame.new(-55.157852359361605, 8.761215366781952, 36.53079939804155) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel70.Parent = workspace.devices.mnemo
newmodel71 = workspace.prefabs.mnemo300300:clone()
newmodel71:PivotTo(CFrame.new(-55.96870784237758, 8.761215366781952, 36.15544439799103) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel71.Parent = workspace.devices.mnemo
newmodel72 = workspace.prefabs.mnemo300200:clone()
newmodel72:PivotTo(CFrame.new(-57.02265358462641, 10.20531311411716, 35.217207033243035) * CFrame.fromEulerAngles(0, math.rad(-120.09001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel72.Parent = workspace.devices.mnemo
newmodel73 = workspace.prefabs.mnemo300200:clone()
newmodel73:PivotTo(CFrame.new(-57.33259668011254, 7.898141322476144, 35.75210185936912) * CFrame.fromEulerAngles(0, math.rad(-120.09001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel73.Parent = workspace.devices.mnemo
newmodel74 = workspace.prefabs.mnemo300200:clone()
newmodel74:PivotTo(CFrame.new(-58.878813114660204, 7.898141322476144, 34.85615169382713) * CFrame.fromEulerAngles(0, math.rad(-120.09001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel74.Parent = workspace.devices.mnemo
newmodel75 = workspace.prefabs.mnemo300200:clone()
newmodel75:PivotTo(CFrame.new(-58.56887001917407, 10.20531311411716, 34.321256867701045) * CFrame.fromEulerAngles(0, math.rad(-120.09001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel75.Parent = workspace.devices.mnemo
newmodel76 = workspace.prefabs.mnemo300300:clone()
newmodel76:PivotTo(CFrame.new(-57.21665219696002, 8.761215366781952, 35.552006728813396) * CFrame.fromEulerAngles(0, math.rad(-120.09001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel76.Parent = workspace.devices.mnemo
newmodel77 = workspace.prefabs.mnemo300300:clone()
newmodel77:PivotTo(CFrame.new(-57.100707713807516, 9.62428941108776, 35.35191159825767) * CFrame.fromEulerAngles(0, math.rad(-120.09001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel77.Parent = workspace.devices.mnemo
newmodel78 = workspace.prefabs.mnemo300300:clone()
newmodel78:PivotTo(CFrame.new(-58.64692414835518, 9.62428941108776, 34.45596143271568) * CFrame.fromEulerAngles(0, math.rad(-120.09001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel78.Parent = workspace.devices.mnemo
newmodel79 = workspace.prefabs.mnemo300300:clone()
newmodel79:PivotTo(CFrame.new(-58.762868631507686, 8.761215366781952, 34.656056563271406) * CFrame.fromEulerAngles(0, math.rad(-120.09001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel79.Parent = workspace.devices.mnemo
newmodel80 = workspace.prefabs.mnemo300200:clone()
newmodel80:PivotTo(CFrame.new(-59.72654999055098, 10.20531311411716, 33.625303211490426) * CFrame.fromEulerAngles(0, math.rad(-125.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel80.Parent = workspace.devices.mnemo
newmodel81 = workspace.prefabs.mnemo300200:clone()
newmodel81:PivotTo(CFrame.new(-60.45542460787127, 10.20531311411716, 33.10846689056648) * CFrame.fromEulerAngles(0, math.rad(-125.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel81.Parent = workspace.devices.mnemo
newmodel82 = workspace.prefabs.mnemo300200:clone()
newmodel82:PivotTo(CFrame.new(-60.813011124014, 7.898141322476144, 33.61275756163714) * CFrame.fromEulerAngles(0, math.rad(-125.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel82.Parent = workspace.devices.mnemo
newmodel83 = workspace.prefabs.mnemo300200:clone()
newmodel83:PivotTo(CFrame.new(-60.08413650669371, 7.898141322476144, 34.12959388256108) * CFrame.fromEulerAngles(0, math.rad(-125.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel83.Parent = workspace.devices.mnemo
newmodel84 = workspace.prefabs.mnemo300200:clone()
newmodel84:PivotTo(CFrame.new(-61.54188574133429, 7.898141322476144, 33.095921240713196) * CFrame.fromEulerAngles(0, math.rad(-125.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel84.Parent = workspace.devices.mnemo
newmodel85 = workspace.prefabs.mnemo300200:clone()
newmodel85:PivotTo(CFrame.new(-61.184299225191566, 10.20531311411716, 32.59163056964254) * CFrame.fromEulerAngles(0, math.rad(-125.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel85.Parent = workspace.devices.mnemo
newmodel86 = workspace.prefabs.mnemo300300:clone()
newmodel86:PivotTo(CFrame.new(-59.950369423637866, 8.761215366781952, 33.94094725010678) * CFrame.fromEulerAngles(0, math.rad(-125.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel86.Parent = workspace.devices.mnemo
newmodel87 = workspace.prefabs.mnemo300300:clone()
newmodel87:PivotTo(CFrame.new(-60.54547695790232, 9.62428941108776, 33.23546429672854) * CFrame.fromEulerAngles(0, math.rad(-125.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel87.Parent = workspace.devices.mnemo
newmodel88 = workspace.prefabs.mnemo300300:clone()
newmodel88:PivotTo(CFrame.new(-59.81660234058204, 9.62428941108776, 33.75230061765248) * CFrame.fromEulerAngles(0, math.rad(-125.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel88.Parent = workspace.devices.mnemo
newmodel89 = workspace.prefabs.mnemo300300:clone()
newmodel89:PivotTo(CFrame.new(-61.27435157522261, 9.62428941108776, 32.71862797580459) * CFrame.fromEulerAngles(0, math.rad(-125.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel89.Parent = workspace.devices.mnemo
newmodel90 = workspace.prefabs.mnemo300300:clone()
newmodel90:PivotTo(CFrame.new(-60.67924404095815, 8.761215366781952, 33.42411092918283) * CFrame.fromEulerAngles(0, math.rad(-125.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel90.Parent = workspace.devices.mnemo
newmodel91 = workspace.prefabs.mnemo300300:clone()
newmodel91:PivotTo(CFrame.new(-61.40811865827845, 8.761215366781952, 32.90727460825889) * CFrame.fromEulerAngles(0, math.rad(-125.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel91.Parent = workspace.devices.mnemo
newmodel92 = workspace.prefabs.mnemo300200:clone()
newmodel92:PivotTo(CFrame.new(-62.2734121680329, 10.20531311411716, 31.792658296751597) * CFrame.fromEulerAngles(0, math.rad(-130.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel92.Parent = workspace.devices.mnemo
newmodel93 = workspace.prefabs.mnemo300200:clone()
newmodel93:PivotTo(CFrame.new(-62.95193774359597, 10.20531311411716, 31.2112969343385) * CFrame.fromEulerAngles(0, math.rad(-130.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel93.Parent = workspace.devices.mnemo
newmodel94 = workspace.prefabs.mnemo300200:clone()
newmodel94:PivotTo(CFrame.new(-63.35416757108496, 7.898141322476144, 31.68075232448132) * CFrame.fromEulerAngles(0, math.rad(-130.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel94.Parent = workspace.devices.mnemo
newmodel95 = workspace.prefabs.mnemo300200:clone()
newmodel95:PivotTo(CFrame.new(-62.675641995521886, 7.898141322476144, 32.262113686894416) * CFrame.fromEulerAngles(0, math.rad(-130.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel95.Parent = workspace.devices.mnemo
newmodel96 = workspace.prefabs.mnemo300200:clone()
newmodel96:PivotTo(CFrame.new(-64.03269314664801, 7.898141322476144, 31.09939096206822) * CFrame.fromEulerAngles(0, math.rad(-130.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel96.Parent = workspace.devices.mnemo
newmodel97 = workspace.prefabs.mnemo300200:clone()
newmodel97:PivotTo(CFrame.new(-63.63046331915903, 10.20531311411716, 30.6299355719254) * CFrame.fromEulerAngles(0, math.rad(-130.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel97.Parent = workspace.devices.mnemo
newmodel98 = workspace.prefabs.mnemo300300:clone()
newmodel98:PivotTo(CFrame.new(-62.52517460284264, 8.761215366781952, 32.08649834534955) * CFrame.fromEulerAngles(0, math.rad(-130.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel98.Parent = workspace.devices.mnemo
newmodel99 = workspace.prefabs.mnemo300300:clone()
newmodel99:PivotTo(CFrame.new(-63.05323278572644, 9.62428941108776, 31.329521641391576) * CFrame.fromEulerAngles(0, math.rad(-130.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel99.Parent = workspace.devices.mnemo
newmodel100 = workspace.prefabs.mnemo300300:clone()
newmodel100:PivotTo(CFrame.new(-62.37470721016337, 9.62428941108776, 31.910883003804678) * CFrame.fromEulerAngles(0, math.rad(-130.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel100.Parent = workspace.devices.mnemo
newmodel101 = workspace.prefabs.mnemo300300:clone()
newmodel101:PivotTo(CFrame.new(-63.731758361289494, 9.62428941108776, 30.74816027897848) * CFrame.fromEulerAngles(0, math.rad(-130.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel101.Parent = workspace.devices.mnemo
newmodel102 = workspace.prefabs.mnemo300300:clone()
newmodel102:PivotTo(CFrame.new(-63.203700178405704, 8.761215366781952, 31.50513698293645) * CFrame.fromEulerAngles(0, math.rad(-130.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel102.Parent = workspace.devices.mnemo
newmodel103 = workspace.prefabs.mnemo300300:clone()
newmodel103:PivotTo(CFrame.new(-63.88222575396876, 8.761215366781952, 30.923775620523347) * CFrame.fromEulerAngles(0, math.rad(-130.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel103.Parent = workspace.devices.mnemo
newmodel104 = workspace.prefabs.mnemo300200:clone()
newmodel104:PivotTo(CFrame.new(-64.64190809268727, 10.20531311411716, 29.734694443338356) * CFrame.fromEulerAngles(0, math.rad(-135.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel104.Parent = workspace.devices.mnemo
newmodel105 = workspace.prefabs.mnemo300200:clone()
newmodel105:PivotTo(CFrame.new(-65.08540646500666, 7.898141322476144, 30.16537575382911) * CFrame.fromEulerAngles(0, math.rad(-135.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel105.Parent = workspace.devices.mnemo
newmodel106 = workspace.prefabs.mnemo300300:clone()
newmodel106:PivotTo(CFrame.new(-64.91950120592385, 8.761215366781952, 30.004265141347236) * CFrame.fromEulerAngles(0, math.rad(-135.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel106.Parent = workspace.devices.mnemo
newmodel107 = workspace.prefabs.mnemo300300:clone()
newmodel107:PivotTo(CFrame.new(-64.75359594684105, 9.62428941108776, 29.843154528865366) * CFrame.fromEulerAngles(0, math.rad(-135.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel107.Parent = workspace.devices.mnemo
newmodel108 = workspace.prefabs.mnemo300300:clone()
newmodel108:PivotTo(CFrame.new(-67.21391796847266, 9.624289975188443, 27.21875799427696) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel108.Parent = workspace.devices.mnemo
newmodel109 = workspace.prefabs.mnemo300300:clone()
newmodel109:PivotTo(CFrame.new(-67.77513724398224, 9.624289975188443, 26.523479662363634) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel109.Parent = workspace.devices.mnemo
newmodel110 = workspace.prefabs.mnemo300300:clone()
newmodel110:PivotTo(CFrame.new(-67.39386782700534, 8.761214238580587, 27.36401446606711) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel110.Parent = workspace.devices.mnemo
newmodel111 = workspace.prefabs.mnemo300300:clone()
newmodel111:PivotTo(CFrame.new(-67.95508122657687, 8.761213392429564, 26.668743774654576) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel111.Parent = workspace.devices.mnemo
newmodel112 = workspace.prefabs.mnemo300300:clone()
newmodel112:PivotTo(CFrame.new(-69.33566829268622, 8.76121254627854, 24.8560562394673) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel112.Parent = workspace.devices.mnemo
newmodel113 = workspace.prefabs.mnemo300300:clone()
newmodel113:PivotTo(CFrame.new(-69.83091173742739, 8.761214520630928, 24.11234480168185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel113.Parent = workspace.devices.mnemo
newmodel114 = workspace.prefabs.mnemo300300:clone()
newmodel114:PivotTo(CFrame.new(-71.0398361840795, 8.761212828328881, 22.180962075848864) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel114.Parent = workspace.devices.mnemo
newmodel115 = workspace.prefabs.mnemo300300:clone()
newmodel115:PivotTo(CFrame.new(-71.46495534168507, 8.761214520630928, 21.39504757237815) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(0, 0, math.rad(15)))
newmodel115.Parent = workspace.devices.mnemo
