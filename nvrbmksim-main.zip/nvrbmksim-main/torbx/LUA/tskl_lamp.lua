newmodel0 = workspace.prefabs.tskl_lamp:clone()
newmodel0:PivotTo(CFrame.new(-48.31826318714934, 3.039955760719153, 34.498917916264176) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel0.Parent = workspace.devices.tskl_lamp
newmodel1 = workspace.prefabs.tskl_lamp:clone()
newmodel1:PivotTo(CFrame.new(-48.60140736747864, 3.039955760719153, 34.42755004432137) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel1.Parent = workspace.devices.tskl_lamp
newmodel2 = workspace.prefabs.tskl_lamp:clone()
newmodel2:PivotTo(CFrame.new(-48.88455154780795, 3.039955760719153, 34.35618217237857) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel2.Parent = workspace.devices.tskl_lamp
newmodel3 = workspace.prefabs.tskl_lamp:clone()
newmodel3:PivotTo(CFrame.new(-49.748141297812346, 3.039955760719153, 34.138510162953025) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel3.Parent = workspace.devices.tskl_lamp
newmodel4 = workspace.prefabs.tskl_lamp:clone()
newmodel4:PivotTo(CFrame.new(-50.32378559772744, 3.3045145154883517, 34.019108488672) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel4.Parent = workspace.devices.tskl_lamp
newmodel5 = workspace.prefabs.tskl_lamp:clone()
newmodel5:PivotTo(CFrame.new(-50.313319039400724, 3.1262249198830223, 33.98946472278976) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel5.Parent = workspace.devices.tskl_lamp
newmodel6 = workspace.prefabs.tskl_lamp:clone()
newmodel6:PivotTo(CFrame.new(-50.302852481074, 2.9479353242776924, 33.95982095690752) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel6.Parent = workspace.devices.tskl_lamp
newmodel7 = workspace.prefabs.tskl_lamp:clone()
newmodel7:PivotTo(CFrame.new(-50.50536963886907, 3.1262249198830223, 33.92165590224372) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel7.Parent = workspace.devices.tskl_lamp
newmodel8 = workspace.prefabs.tskl_lamp:clone()
newmodel8:PivotTo(CFrame.new(-50.515836197195796, 3.3045145154883517, 33.95129966812596) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel8.Parent = workspace.devices.tskl_lamp
newmodel9 = workspace.prefabs.tskl_lamp:clone()
newmodel9:PivotTo(CFrame.new(-50.49490308054234, 2.9479353242776924, 33.89201213636148) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel9.Parent = workspace.devices.tskl_lamp
newmodel10 = workspace.prefabs.tskl_lamp:clone()
newmodel10:PivotTo(CFrame.new(-50.6869536800107, 2.9479353242776924, 33.82420331581544) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel10.Parent = workspace.devices.tskl_lamp
newmodel11 = workspace.prefabs.tskl_lamp:clone()
newmodel11:PivotTo(CFrame.new(-50.69742023833743, 3.1262249198830223, 33.85384708169768) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel11.Parent = workspace.devices.tskl_lamp
newmodel12 = workspace.prefabs.tskl_lamp:clone()
newmodel12:PivotTo(CFrame.new(-50.87900427947906, 2.9479353242776924, 33.75639449526939) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel12.Parent = workspace.devices.tskl_lamp
newmodel13 = workspace.prefabs.tskl_lamp:clone()
newmodel13:PivotTo(CFrame.new(-51.071054878947415, 2.9479353242776924, 33.688585674723356) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel13.Parent = workspace.devices.tskl_lamp
newmodel14 = workspace.prefabs.tskl_lamp:clone()
newmodel14:PivotTo(CFrame.new(-51.08152143727414, 3.1262249198830223, 33.7182294406056) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel14.Parent = workspace.devices.tskl_lamp
newmodel15 = workspace.prefabs.tskl_lamp:clone()
newmodel15:PivotTo(CFrame.new(-50.88947083780578, 3.1262249198830223, 33.78603826115163) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel15.Parent = workspace.devices.tskl_lamp
newmodel16 = workspace.prefabs.tskl_lamp:clone()
newmodel16:PivotTo(CFrame.new(-50.707886796664155, 3.3045145154883517, 33.88349084757992) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel16.Parent = workspace.devices.tskl_lamp
newmodel17 = workspace.prefabs.tskl_lamp:clone()
newmodel17:PivotTo(CFrame.new(-57.907477378739664, 3.039955760719153, 30.28459561714507) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel17.Parent = workspace.devices.tskl_lamp
newmodel18 = workspace.prefabs.tskl_lamp:clone()
newmodel18:PivotTo(CFrame.new(-58.14565109071116, 3.039955760719153, 30.115665800577013) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel18.Parent = workspace.devices.tskl_lamp
newmodel19 = workspace.prefabs.tskl_lamp:clone()
newmodel19:PivotTo(CFrame.new(-58.38382480268267, 3.039955760719153, 29.94673598400896) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel19.Parent = workspace.devices.tskl_lamp
newmodel20 = workspace.prefabs.tskl_lamp:clone()
newmodel20:PivotTo(CFrame.new(-59.11025462419574, 3.039955760719153, 29.43150004347639) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel20.Parent = workspace.devices.tskl_lamp
newmodel21 = workspace.prefabs.tskl_lamp:clone()
newmodel21:PivotTo(CFrame.new(-59.60373883979229, 3.3045145154883517, 29.1120186257721) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel21.Parent = workspace.devices.tskl_lamp
newmodel22 = workspace.prefabs.tskl_lamp:clone()
newmodel22:PivotTo(CFrame.new(-59.5832607042547, 3.1262249198830223, 29.088166001937573) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel22.Parent = workspace.devices.tskl_lamp
newmodel23 = workspace.prefabs.tskl_lamp:clone()
newmodel23:PivotTo(CFrame.new(-59.562782568717104, 2.9479353242776924, 29.064313378103037) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel23.Parent = workspace.devices.tskl_lamp
newmodel24 = workspace.prefabs.tskl_lamp:clone()
newmodel24:PivotTo(CFrame.new(-59.737792713599006, 3.1262249198830223, 28.955496009143392) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel24.Parent = workspace.devices.tskl_lamp
newmodel25 = workspace.prefabs.tskl_lamp:clone()
newmodel25:PivotTo(CFrame.new(-59.7582708491366, 3.3045145154883517, 28.979348632977924) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel25.Parent = workspace.devices.tskl_lamp
newmodel26 = workspace.prefabs.tskl_lamp:clone()
newmodel26:PivotTo(CFrame.new(-59.71731457806141, 2.9479353242776924, 28.93164338530886) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel26.Parent = workspace.devices.tskl_lamp
newmodel27 = workspace.prefabs.tskl_lamp:clone()
newmodel27:PivotTo(CFrame.new(-59.871846587405734, 2.9479353242776924, 28.798973392514682) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel27.Parent = workspace.devices.tskl_lamp
newmodel28 = workspace.prefabs.tskl_lamp:clone()
newmodel28:PivotTo(CFrame.new(-59.892324722943336, 3.1262249198830223, 28.822826016349218) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel28.Parent = workspace.devices.tskl_lamp
newmodel29 = workspace.prefabs.tskl_lamp:clone()
newmodel29:PivotTo(CFrame.new(-60.02637859675006, 2.9479353242776924, 28.666303399720498) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel29.Parent = workspace.devices.tskl_lamp
newmodel30 = workspace.prefabs.tskl_lamp:clone()
newmodel30:PivotTo(CFrame.new(-60.18091060609437, 2.9479353242776924, 28.533633406926324) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel30.Parent = workspace.devices.tskl_lamp
newmodel31 = workspace.prefabs.tskl_lamp:clone()
newmodel31:PivotTo(CFrame.new(-60.201388741631966, 3.1262249198830223, 28.557486030760856) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel31.Parent = workspace.devices.tskl_lamp
newmodel32 = workspace.prefabs.tskl_lamp:clone()
newmodel32:PivotTo(CFrame.new(-60.04685673228765, 3.1262249198830223, 28.690156023555037) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel32.Parent = workspace.devices.tskl_lamp
newmodel33 = workspace.prefabs.tskl_lamp:clone()
newmodel33:PivotTo(CFrame.new(-59.91280285848092, 3.3045145154883517, 28.846678640183747) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel33.Parent = workspace.devices.tskl_lamp
newmodel34 = workspace.prefabs.tskl_lamp:clone()
newmodel34:PivotTo(CFrame.new(-36.60000211646475, 5.729199416000001, 39.68536984693413) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel34.Parent = workspace.devices.tskl_lamp
newmodel35 = workspace.prefabs.tskl_lamp:clone()
newmodel35:PivotTo(CFrame.new(-36.60000211646475, 5.616293236000001, 39.68536984693413) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel35.Parent = workspace.devices.tskl_lamp
newmodel36 = workspace.prefabs.tskl_lamp:clone()
newmodel36:PivotTo(CFrame.new(-36.60000211646475, 5.503386472000001, 39.68536984693413) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel36.Parent = workspace.devices.tskl_lamp
newmodel37 = workspace.prefabs.tskl_lamp:clone()
newmodel37:PivotTo(CFrame.new(-36.60000211646475, 5.390479416000001, 39.68536984693413) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel37.Parent = workspace.devices.tskl_lamp
newmodel38 = workspace.prefabs.tskl_lamp:clone()
newmodel38:PivotTo(CFrame.new(-36.60000211646475, 5.277572944000001, 39.68536984693413) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel38.Parent = workspace.devices.tskl_lamp
newmodel39 = workspace.prefabs.tskl_lamp:clone()
newmodel39:PivotTo(CFrame.new(-36.60000211646475, 5.164666472, 39.68536984693413) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel39.Parent = workspace.devices.tskl_lamp
newmodel40 = workspace.prefabs.tskl_lamp:clone()
newmodel40:PivotTo(CFrame.new(-36.60000211646475, 5.051759416, 39.68536984693413) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel40.Parent = workspace.devices.tskl_lamp
newmodel41 = workspace.prefabs.tskl_lamp:clone()
newmodel41:PivotTo(CFrame.new(-36.74210947316105, 5.729199416000001, 39.70196443082651) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel41.Parent = workspace.devices.tskl_lamp
newmodel42 = workspace.prefabs.tskl_lamp:clone()
newmodel42:PivotTo(CFrame.new(-36.74210947316105, 5.616293236000001, 39.70196443082651) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel42.Parent = workspace.devices.tskl_lamp
newmodel43 = workspace.prefabs.tskl_lamp:clone()
newmodel43:PivotTo(CFrame.new(-36.74210947316105, 5.503386472000001, 39.70196443082651) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel43.Parent = workspace.devices.tskl_lamp
newmodel44 = workspace.prefabs.tskl_lamp:clone()
newmodel44:PivotTo(CFrame.new(-36.74210947316105, 5.390479416000001, 39.70196443082651) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel44.Parent = workspace.devices.tskl_lamp
newmodel45 = workspace.prefabs.tskl_lamp:clone()
newmodel45:PivotTo(CFrame.new(-36.74210947316105, 5.277572944000001, 39.70196443082651) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel45.Parent = workspace.devices.tskl_lamp
newmodel46 = workspace.prefabs.tskl_lamp:clone()
newmodel46:PivotTo(CFrame.new(-36.74210947316105, 5.164666472, 39.70196443082651) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel46.Parent = workspace.devices.tskl_lamp
newmodel47 = workspace.prefabs.tskl_lamp:clone()
newmodel47:PivotTo(CFrame.new(-36.74210947316105, 5.051759416, 39.70196443082651) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel47.Parent = workspace.devices.tskl_lamp
newmodel48 = workspace.prefabs.tskl_lamp:clone()
newmodel48:PivotTo(CFrame.new(-36.88422983099242, 5.729199416000001, 39.71855593306212) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel48.Parent = workspace.devices.tskl_lamp
newmodel49 = workspace.prefabs.tskl_lamp:clone()
newmodel49:PivotTo(CFrame.new(-36.88422983099242, 5.616293236000001, 39.71855593306212) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel49.Parent = workspace.devices.tskl_lamp
newmodel50 = workspace.prefabs.tskl_lamp:clone()
newmodel50:PivotTo(CFrame.new(-36.88422983099242, 5.503386472000001, 39.71855593306212) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel50.Parent = workspace.devices.tskl_lamp
newmodel51 = workspace.prefabs.tskl_lamp:clone()
newmodel51:PivotTo(CFrame.new(-36.88422983099242, 5.390479416000001, 39.71855593306212) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel51.Parent = workspace.devices.tskl_lamp
newmodel52 = workspace.prefabs.tskl_lamp:clone()
newmodel52:PivotTo(CFrame.new(-36.88422983099242, 5.277572944000001, 39.71855593306212) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel52.Parent = workspace.devices.tskl_lamp
newmodel53 = workspace.prefabs.tskl_lamp:clone()
newmodel53:PivotTo(CFrame.new(-36.88422983099242, 5.164666472, 39.71855593306212) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel53.Parent = workspace.devices.tskl_lamp
newmodel54 = workspace.prefabs.tskl_lamp:clone()
newmodel54:PivotTo(CFrame.new(-36.88422983099242, 5.051759416, 39.71855593306212) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel54.Parent = workspace.devices.tskl_lamp
newmodel55 = workspace.prefabs.tskl_lamp:clone()
newmodel55:PivotTo(CFrame.new(-37.0263382519267, 5.729199416000001, 39.73515147355328) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel55.Parent = workspace.devices.tskl_lamp
newmodel56 = workspace.prefabs.tskl_lamp:clone()
newmodel56:PivotTo(CFrame.new(-37.0263382519267, 5.616293236000001, 39.73515147355328) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel56.Parent = workspace.devices.tskl_lamp
newmodel57 = workspace.prefabs.tskl_lamp:clone()
newmodel57:PivotTo(CFrame.new(-37.0263382519267, 5.503386472000001, 39.73515147355328) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel57.Parent = workspace.devices.tskl_lamp
newmodel58 = workspace.prefabs.tskl_lamp:clone()
newmodel58:PivotTo(CFrame.new(-37.0263382519267, 5.390479416000001, 39.73515147355328) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel58.Parent = workspace.devices.tskl_lamp
newmodel59 = workspace.prefabs.tskl_lamp:clone()
newmodel59:PivotTo(CFrame.new(-37.0263382519267, 5.277572944000001, 39.73515147355328) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel59.Parent = workspace.devices.tskl_lamp
newmodel60 = workspace.prefabs.tskl_lamp:clone()
newmodel60:PivotTo(CFrame.new(-37.0263382519267, 5.164666472, 39.73515147355328) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel60.Parent = workspace.devices.tskl_lamp
newmodel61 = workspace.prefabs.tskl_lamp:clone()
newmodel61:PivotTo(CFrame.new(-37.0263382519267, 5.051759416, 39.73515147355328) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel61.Parent = workspace.devices.tskl_lamp
newmodel62 = workspace.prefabs.tskl_lamp:clone()
newmodel62:PivotTo(CFrame.new(-37.16845831972848, 5.729199416000001, 39.75174294192385) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel62.Parent = workspace.devices.tskl_lamp
newmodel63 = workspace.prefabs.tskl_lamp:clone()
newmodel63:PivotTo(CFrame.new(-37.16845831972848, 5.616293236000001, 39.75174294192385) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel63.Parent = workspace.devices.tskl_lamp
newmodel64 = workspace.prefabs.tskl_lamp:clone()
newmodel64:PivotTo(CFrame.new(-37.16845831972848, 5.503386472000001, 39.75174294192385) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel64.Parent = workspace.devices.tskl_lamp
newmodel65 = workspace.prefabs.tskl_lamp:clone()
newmodel65:PivotTo(CFrame.new(-37.16845831972848, 5.390479416000001, 39.75174294192385) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel65.Parent = workspace.devices.tskl_lamp
newmodel66 = workspace.prefabs.tskl_lamp:clone()
newmodel66:PivotTo(CFrame.new(-37.16845831972848, 5.277572944000001, 39.75174294192385) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel66.Parent = workspace.devices.tskl_lamp
newmodel67 = workspace.prefabs.tskl_lamp:clone()
newmodel67:PivotTo(CFrame.new(-37.16845831972848, 5.164666472, 39.75174294192385) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel67.Parent = workspace.devices.tskl_lamp
newmodel68 = workspace.prefabs.tskl_lamp:clone()
newmodel68:PivotTo(CFrame.new(-37.16845831972848, 5.051759416, 39.75174294192385) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel68.Parent = workspace.devices.tskl_lamp
newmodel69 = workspace.prefabs.tskl_lamp:clone()
newmodel69:PivotTo(CFrame.new(-55.03579646835351, 6.313200292000001, 37.042844005697944) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel69.Parent = workspace.devices.tskl_lamp
newmodel70 = workspace.prefabs.tskl_lamp:clone()
newmodel70:PivotTo(CFrame.new(-55.1622478453225, 6.313200292000001, 36.98430129578052) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel70.Parent = workspace.devices.tskl_lamp
newmodel71 = workspace.prefabs.tskl_lamp:clone()
newmodel71:PivotTo(CFrame.new(-55.288701215392486, 6.313200292000001, 36.925772622779135) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel71.Parent = workspace.devices.tskl_lamp
newmodel72 = workspace.prefabs.tskl_lamp:clone()
newmodel72:PivotTo(CFrame.new(-55.41514291595499, 6.313200292000001, 36.86723611828991) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel72.Parent = workspace.devices.tskl_lamp
newmodel73 = workspace.prefabs.tskl_lamp:clone()
newmodel73:PivotTo(CFrame.new(-55.54159878056454, 6.313200292000001, 36.80870657821745) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel73.Parent = workspace.devices.tskl_lamp
newmodel74 = workspace.prefabs.tskl_lamp:clone()
newmodel74:PivotTo(CFrame.new(-55.66804694157466, 6.313200292000001, 36.750170822993354) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel74.Parent = workspace.devices.tskl_lamp
newmodel75 = workspace.prefabs.tskl_lamp:clone()
newmodel75:PivotTo(CFrame.new(-55.79449922338357, 6.313200292000001, 36.69163076284017) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel75.Parent = workspace.devices.tskl_lamp
newmodel76 = workspace.prefabs.tskl_lamp:clone()
newmodel76:PivotTo(CFrame.new(-55.920939900985935, 6.313200292000001, 36.63310038966991) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel76.Parent = workspace.devices.tskl_lamp
newmodel77 = workspace.prefabs.tskl_lamp:clone()
newmodel77:PivotTo(CFrame.new(-56.04739494232012, 6.313200292000001, 36.57455933978116) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel77.Parent = workspace.devices.tskl_lamp
newmodel78 = workspace.prefabs.tskl_lamp:clone()
newmodel78:PivotTo(CFrame.new(-56.17383875410446, 6.313200292000001, 36.5160280911261) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel78.Parent = workspace.devices.tskl_lamp
newmodel79 = workspace.prefabs.tskl_lamp:clone()
newmodel79:PivotTo(CFrame.new(-56.300292544049555, 6.313200292000001, 36.457493374192026) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel79.Parent = workspace.devices.tskl_lamp
newmodel80 = workspace.prefabs.tskl_lamp:clone()
newmodel80:PivotTo(CFrame.new(-63.22521858033869, 6.313200292000001, 32.03108319039207) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel80.Parent = workspace.devices.tskl_lamp
newmodel81 = workspace.prefabs.tskl_lamp:clone()
newmodel81:PivotTo(CFrame.new(-63.331036863134976, 6.313200292000001, 31.94042202733847) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel81.Parent = workspace.devices.tskl_lamp
newmodel82 = workspace.prefabs.tskl_lamp:clone()
newmodel82:PivotTo(CFrame.new(-63.43684726674677, 6.313200292000001, 31.84976154156339) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel82.Parent = workspace.devices.tskl_lamp
newmodel83 = workspace.prefabs.tskl_lamp:clone()
newmodel83:PivotTo(CFrame.new(-63.54265435847951, 6.313200292000001, 31.75910526856682) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel83.Parent = workspace.devices.tskl_lamp
newmodel84 = workspace.prefabs.tskl_lamp:clone()
newmodel84:PivotTo(CFrame.new(-63.64846927277507, 6.313200292000001, 31.668448252206698) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel84.Parent = workspace.devices.tskl_lamp
newmodel85 = workspace.prefabs.tskl_lamp:clone()
newmodel85:PivotTo(CFrame.new(-63.754282945587654, 6.313200292000001, 31.577779464751632) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel85.Parent = workspace.devices.tskl_lamp
newmodel86 = workspace.prefabs.tskl_lamp:clone()
newmodel86:PivotTo(CFrame.new(-63.86009549604237, 6.313200292000001, 31.487121035839188) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel86.Parent = workspace.devices.tskl_lamp
newmodel87 = workspace.prefabs.tskl_lamp:clone()
newmodel87:PivotTo(CFrame.new(-63.965906499056146, 6.313200292000001, 31.396464391160396) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel87.Parent = workspace.devices.tskl_lamp
newmodel88 = workspace.prefabs.tskl_lamp:clone()
newmodel88:PivotTo(CFrame.new(-64.07172017186986, 6.313200292000001, 31.305795603706663) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel88.Parent = workspace.devices.tskl_lamp
newmodel89 = workspace.prefabs.tskl_lamp:clone()
newmodel89:PivotTo(CFrame.new(-64.1775353505837, 6.313200292000001, 31.215142486260245) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel89.Parent = workspace.devices.tskl_lamp
newmodel90 = workspace.prefabs.tskl_lamp:clone()
newmodel90:PivotTo(CFrame.new(-64.28334763187685, 6.313200292000001, 31.124479704110236) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel90.Parent = workspace.devices.tskl_lamp
newmodel91 = workspace.prefabs.tskl_lamp:clone()
newmodel91:PivotTo(CFrame.new(-68.14195966265362, 5.66788, 27.09539510930625) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel91.Parent = workspace.devices.tskl_lamp
newmodel92 = workspace.prefabs.tskl_lamp:clone()
newmodel92:PivotTo(CFrame.new(-68.22907697691258, 5.66788, 26.987467987801477) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel92.Parent = workspace.devices.tskl_lamp
newmodel93 = workspace.prefabs.tskl_lamp:clone()
newmodel93:PivotTo(CFrame.new(-68.31619429117156, 5.66788, 26.879540866296708) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(0, 0, math.rad(0)))
newmodel93.Parent = workspace.devices.tskl_lamp
