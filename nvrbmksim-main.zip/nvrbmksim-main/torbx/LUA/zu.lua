newmodel0 = workspace.prefabs.zu05:clone()
newmodel0:PivotTo(CFrame.new(-49.11687263009234, 3.108971088050249, 34.310174389128385) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel0.Parent = workspace.devices.zu05
newmodel1 = workspace.prefabs.zu11:clone()
newmodel1:PivotTo(CFrame.new(-49.50230157696212, 3.0514583152743353, 34.202566910380504) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel1.Parent = workspace.devices.zu11
newmodel2 = workspace.prefabs.zu11:clone()
newmodel2:PivotTo(CFrame.new(-49.4308724912725, 2.6627177146445957, 32.86215059375027) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.zu11
newmodel3 = workspace.prefabs.zu11:clone()
newmodel3:PivotTo(CFrame.new(-49.37680770420589, 2.6467064307588553, 32.687044129196146) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.zu11
newmodel4 = workspace.prefabs.zu05:clone()
newmodel4:PivotTo(CFrame.new(-51.98219638625638, 3.4597990019833174, 33.46259773985862) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel4.Parent = workspace.devices.zu05
newmodel5 = workspace.prefabs.zu11:clone()
newmodel5:PivotTo(CFrame.new(-51.95530236230971, 3.04858267663554, 33.395197997697196) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel5.Parent = workspace.devices.zu11
newmodel6 = workspace.prefabs.zu11:clone()
newmodel6:PivotTo(CFrame.new(-51.737782686926195, 3.04858267663554, 33.47199938584254) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel6.Parent = workspace.devices.zu11
newmodel7 = workspace.prefabs.zu11:clone()
newmodel7:PivotTo(CFrame.new(-51.52026301154268, 3.04858267663554, 33.54880077398788) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel7.Parent = workspace.devices.zu11
newmodel8 = workspace.prefabs.zu11:clone()
newmodel8:PivotTo(CFrame.new(-54.61025053747794, 3.0514583152743353, 32.210936053615434) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel8.Parent = workspace.devices.zu11
newmodel9 = workspace.prefabs.zu05:clone()
newmodel9:PivotTo(CFrame.new(-58.589711294201464, 3.1670589885539204, 29.82818325911382) * CFrame.fromEulerAngles(0, math.rad(-35.346990000000005), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel9.Parent = workspace.devices.zu05
newmodel10 = workspace.prefabs.zu11:clone()
newmodel10:PivotTo(CFrame.new(-58.90421686897256, 3.0514583152743353, 29.58012332113268) * CFrame.fromEulerAngles(0, math.rad(-35.346990000000005), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel10.Parent = workspace.devices.zu11
newmodel11 = workspace.prefabs.zu11:clone()
newmodel11:PivotTo(CFrame.new(-58.32618267216021, 2.6597192981370292, 28.35264641772759) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.devices.zu11
newmodel12 = workspace.prefabs.zu11:clone()
newmodel12:PivotTo(CFrame.new(-58.220161843874024, 2.64368612770117, 28.203167981104492) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.zu11
newmodel13 = workspace.prefabs.zu05:clone()
newmodel13:PivotTo(CFrame.new(-60.9486667298447, 3.4597990019833174, 27.993448320599843) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel13.Parent = workspace.devices.zu05
newmodel14 = workspace.prefabs.zu11:clone()
newmodel14:PivotTo(CFrame.new(-60.89921938842599, 3.04858267663554, 27.940335476634452) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel14.Parent = workspace.devices.zu11
newmodel15 = workspace.prefabs.zu11:clone()
newmodel15:PivotTo(CFrame.new(-60.724193886803036, 3.04858267663554, 28.090599697863695) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel15.Parent = workspace.devices.zu11
newmodel16 = workspace.prefabs.zu11:clone()
newmodel16:PivotTo(CFrame.new(-60.54916838518008, 3.04858267663554, 28.240863919092945) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel16.Parent = workspace.devices.zu11
newmodel17 = workspace.prefabs.zu11:clone()
newmodel17:PivotTo(CFrame.new(-62.94626853604243, 3.0514583152743353, 25.87612100171188) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel17.Parent = workspace.devices.zu11
