newmodel0 = workspace.prefabs.np_lamp:clone()
newmodel0:PivotTo(CFrame.new(-48.30674633813386, 3.232623549518461, 34.536855872824056) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel0.Parent = workspace.devices.np_lamp
newmodel1 = workspace.prefabs.np_lamp:clone()
newmodel1:PivotTo(CFrame.new(-49.06787061637288, 3.0888416175786793, 34.318865204393475) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel1.Parent = workspace.devices.np_lamp
newmodel2 = workspace.prefabs.np_lamp:clone()
newmodel2:PivotTo(CFrame.new(-49.33119470407913, 3.0888416175786793, 34.25249308348667) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel2.Parent = workspace.devices.np_lamp
newmodel3 = workspace.prefabs.np_lamp:clone()
newmodel3:PivotTo(CFrame.new(-47.697487276443425, 2.5718682292214456, 32.290114254352886) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.np_lamp
newmodel4 = workspace.prefabs.np_lamp:clone()
newmodel4:PivotTo(CFrame.new(-47.77393620513234, 2.5718682292214456, 32.27084492892833) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.np_lamp
newmodel5 = workspace.prefabs.np_lamp:clone()
newmodel5:PivotTo(CFrame.new(-47.747630575744246, 2.5624519227749882, 32.16648023836968) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.np_lamp
newmodel6 = workspace.prefabs.np_lamp:clone()
newmodel6:PivotTo(CFrame.new(-47.671181647055334, 2.5624519227749882, 32.18574956379424) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.devices.np_lamp
newmodel7 = workspace.prefabs.np_lamp:clone()
newmodel7:PivotTo(CFrame.new(-47.72132494635615, 2.5530356163285313, 32.06211554781103) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.devices.np_lamp
newmodel8 = workspace.prefabs.np_lamp:clone()
newmodel8:PivotTo(CFrame.new(-47.64487601766724, 2.5530356163285313, 32.081384873235585) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.devices.np_lamp
newmodel9 = workspace.prefabs.np_lamp:clone()
newmodel9:PivotTo(CFrame.new(-32.805880330413146, 2.6032759511661685, 31.883362294532883) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.devices.np_lamp
newmodel10 = workspace.prefabs.np_lamp:clone()
newmodel10:PivotTo(CFrame.new(-33.547043228011646, 2.603784940703815, 32.12533323360003) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.devices.np_lamp
newmodel11 = workspace.prefabs.np_lamp:clone()
newmodel11:PivotTo(CFrame.new(-33.58585673899256, 2.5925871708755954, 32.00336917448338) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.devices.np_lamp
newmodel12 = workspace.prefabs.np_lamp:clone()
newmodel12:PivotTo(CFrame.new(-32.844693841394054, 2.5920781813379494, 31.76139823541623) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.np_lamp
newmodel13 = workspace.prefabs.np_lamp:clone()
newmodel13:PivotTo(CFrame.new(-32.88350735237497, 2.58088041150973, 31.639434176299588) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.np_lamp
newmodel14 = workspace.prefabs.np_lamp:clone()
newmodel14:PivotTo(CFrame.new(-38.146062340738354, 2.593920821900411, 32.906841332956155) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.np_lamp
newmodel15 = workspace.prefabs.np_lamp:clone()
newmodel15:PivotTo(CFrame.new(-38.9187312761141, 2.5946843062068803, 33.01123194842051) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.np_lamp
newmodel16 = workspace.prefabs.np_lamp:clone()
newmodel16:PivotTo(CFrame.new(-38.90444427938918, 2.604864096959807, 33.1267070261854) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.np_lamp
newmodel17 = workspace.prefabs.np_lamp:clone()
newmodel17:PivotTo(CFrame.new(-38.161778037135754, 2.582723052072192, 32.779818747414765) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel17.Parent = workspace.devices.np_lamp
newmodel18 = workspace.prefabs.np_lamp:clone()
newmodel18:PivotTo(CFrame.new(-38.13034664434095, 2.60511859172863, 33.033863918497545) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel18.Parent = workspace.devices.np_lamp
newmodel19 = workspace.prefabs.np_lamp:clone()
newmodel19:PivotTo(CFrame.new(-57.91045923661809, 3.232623549518461, 30.324130853109686) * CFrame.fromEulerAngles(0, math.rad(-35.346990000000005), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel19.Parent = workspace.devices.np_lamp
newmodel20 = workspace.prefabs.np_lamp:clone()
newmodel20:PivotTo(CFrame.new(-58.54716835833027, 3.146929518082351, 29.854006237756757) * CFrame.fromEulerAngles(0, math.rad(-35.346990000000005), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel20.Parent = workspace.devices.np_lamp
newmodel21 = workspace.prefabs.np_lamp:clone()
newmodel21:PivotTo(CFrame.new(-58.76866991046376, 3.146929518082351, 29.696901508348468) * CFrame.fromEulerAngles(0, math.rad(-35.346990000000005), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel21.Parent = workspace.devices.np_lamp
newmodel22 = workspace.prefabs.np_lamp:clone()
newmodel22:PivotTo(CFrame.new(-56.52993828008142, 2.5718682292214456, 28.449771304216544) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.np_lamp
newmodel23 = workspace.prefabs.np_lamp:clone()
newmodel23:PivotTo(CFrame.new(-56.594245174353084, 2.5718682292214456, 28.4041602425195) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel23.Parent = workspace.devices.np_lamp
newmodel24 = workspace.prefabs.np_lamp:clone()
newmodel24:PivotTo(CFrame.new(-56.53197897361358, 2.5624519227749882, 28.31637131942339) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.np_lamp
newmodel25 = workspace.prefabs.np_lamp:clone()
newmodel25:PivotTo(CFrame.new(-56.46767207934191, 2.5624519227749882, 28.361982381120434) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.np_lamp
newmodel26 = workspace.prefabs.np_lamp:clone()
newmodel26:PivotTo(CFrame.new(-56.46971277287408, 2.5530356163285313, 28.228582396327283) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.np_lamp
newmodel27 = workspace.prefabs.np_lamp:clone()
newmodel27:PivotTo(CFrame.new(-56.405405878602416, 2.5530356163285313, 28.274193458024325) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel27.Parent = workspace.devices.np_lamp
