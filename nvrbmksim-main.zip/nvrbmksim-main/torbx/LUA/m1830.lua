newmodel0 = workspace.prefabs.m1830:clone()
newmodel0:PivotTo(CFrame.new(-23.366038958017832, 3.6582180680602168, 29.583405305015923) * CFrame.fromEulerAngles(0, math.rad(-56.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel0.Parent = workspace.devices.m1830
newmodel1 = workspace.prefabs.m1830:clone()
newmodel1:PivotTo(CFrame.new(-14.041468292504977, 6.57162, 27.885898438078616) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel1.Parent = workspace.devices.m1830
newmodel2 = workspace.prefabs.m1830:clone()
newmodel2:PivotTo(CFrame.new(-14.035380607173659, 6.05624, 27.8796018519965) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel2.Parent = workspace.devices.m1830
newmodel3 = workspace.prefabs.m1830:clone()
newmodel3:PivotTo(CFrame.new(-14.035380607173659, 5.96766764, 27.8796018519965) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel3.Parent = workspace.devices.m1830
newmodel4 = workspace.prefabs.m1830:clone()
newmodel4:PivotTo(CFrame.new(-14.035380607173659, 5.876172360000001, 27.8796018519965) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel4.Parent = workspace.devices.m1830
newmodel5 = workspace.prefabs.m1830:clone()
newmodel5:PivotTo(CFrame.new(-14.035380607173659, 5.78468, 27.8796018519965) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel5.Parent = workspace.devices.m1830
newmodel6 = workspace.prefabs.m1830:clone()
newmodel6:PivotTo(CFrame.new(-14.035380607173659, 5.6931876400000005, 27.8796018519965) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel6.Parent = workspace.devices.m1830
newmodel7 = workspace.prefabs.m1830:clone()
newmodel7:PivotTo(CFrame.new(-14.035380607173659, 5.6016923599999995, 27.8796018519965) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel7.Parent = workspace.devices.m1830
newmodel8 = workspace.prefabs.m1830:clone()
newmodel8:PivotTo(CFrame.new(-14.035380607173659, 5.5102, 27.8796018519965) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel8.Parent = workspace.devices.m1830
newmodel9 = workspace.prefabs.m1830:clone()
newmodel9:PivotTo(CFrame.new(-14.035380607173659, 5.335, 27.8796018519965) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel9.Parent = workspace.devices.m1830
newmodel10 = workspace.prefabs.m1830:clone()
newmodel10:PivotTo(CFrame.new(-14.035380607173659, 5.242532359999999, 27.8796018519965) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel10.Parent = workspace.devices.m1830
newmodel11 = workspace.prefabs.m1830:clone()
newmodel11:PivotTo(CFrame.new(-14.035380607173659, 5.15006764, 27.8796018519965) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel11.Parent = workspace.devices.m1830
newmodel12 = workspace.prefabs.m1830:clone()
newmodel12:PivotTo(CFrame.new(-14.035380607173659, 5.0576, 27.8796018519965) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel12.Parent = workspace.devices.m1830
newmodel13 = workspace.prefabs.m1830:clone()
newmodel13:PivotTo(CFrame.new(-34.36148445928558, 5.0167202920000005, 39.330380896546956) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel13.Parent = workspace.devices.m1830
newmodel14 = workspace.prefabs.m1830:clone()
newmodel14:PivotTo(CFrame.new(-34.36148445928558, 4.92766, 39.330380896546956) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel14.Parent = workspace.devices.m1830
newmodel15 = workspace.prefabs.m1830:clone()
newmodel15:PivotTo(CFrame.new(-34.36148445928558, 4.838599708, 39.330380896546956) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel15.Parent = workspace.devices.m1830
newmodel16 = workspace.prefabs.m1830:clone()
newmodel16:PivotTo(CFrame.new(-34.36148767805238, 3.8913023600000005, 39.33038544420931) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel16.Parent = workspace.devices.m1830
newmodel17 = workspace.prefabs.m1830:clone()
newmodel17:PivotTo(CFrame.new(-34.36148767805238, 3.80224236, 39.33038544420931) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel17.Parent = workspace.devices.m1830
newmodel18 = workspace.prefabs.m1830:clone()
newmodel18:PivotTo(CFrame.new(-34.36148767805238, 3.7131823600000002, 39.33038544420931) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel18.Parent = workspace.devices.m1830
newmodel19 = workspace.prefabs.m1830:clone()
newmodel19:PivotTo(CFrame.new(-34.36148958418024, 4.216640000000001, 39.3303820664032) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel19.Parent = workspace.devices.m1830
newmodel20 = workspace.prefabs.m1830:clone()
newmodel20:PivotTo(CFrame.new(-34.36148958418024, 4.126120000000001, 39.3303820664032) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel20.Parent = workspace.devices.m1830
newmodel21 = workspace.prefabs.m1830:clone()
newmodel21:PivotTo(CFrame.new(-40.74126955530874, 5.0167202920000005, 39.96663822539845) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel21.Parent = workspace.devices.m1830
newmodel22 = workspace.prefabs.m1830:clone()
newmodel22:PivotTo(CFrame.new(-40.74126955530874, 4.92766, 39.96663822539845) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel22.Parent = workspace.devices.m1830
newmodel23 = workspace.prefabs.m1830:clone()
newmodel23:PivotTo(CFrame.new(-40.74126955530874, 4.838599708, 39.96663822539845) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel23.Parent = workspace.devices.m1830
newmodel24 = workspace.prefabs.m1830:clone()
newmodel24:PivotTo(CFrame.new(-40.74127415308748, 3.8913023600000005, 39.966641298240866) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel24.Parent = workspace.devices.m1830
newmodel25 = workspace.prefabs.m1830:clone()
newmodel25:PivotTo(CFrame.new(-40.74127415308748, 3.80224236, 39.966641298240866) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel25.Parent = workspace.devices.m1830
newmodel26 = workspace.prefabs.m1830:clone()
newmodel26:PivotTo(CFrame.new(-40.74127415308748, 3.7131823600000002, 39.966641298240866) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel26.Parent = workspace.devices.m1830
newmodel27 = workspace.prefabs.m1830:clone()
newmodel27:PivotTo(CFrame.new(-40.741272453010865, 4.216640000000001, 39.96663916721515) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel27.Parent = workspace.devices.m1830
newmodel28 = workspace.prefabs.m1830:clone()
newmodel28:PivotTo(CFrame.new(-40.741272453010865, 4.126120000000001, 39.96663916721515) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel28.Parent = workspace.devices.m1830
newmodel29 = workspace.prefabs.m1830:clone()
newmodel29:PivotTo(CFrame.new(-43.00990742397599, 5.545240000000001, 39.90755567741752) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel29.Parent = workspace.devices.m1830
newmodel30 = workspace.prefabs.m1830:clone()
newmodel30:PivotTo(CFrame.new(-43.00990742397599, 5.226960000000001, 39.90755567741752) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel30.Parent = workspace.devices.m1830
newmodel31 = workspace.prefabs.m1830:clone()
newmodel31:PivotTo(CFrame.new(-42.06012451396606, 5.226960000000001, 39.971306051950236) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel31.Parent = workspace.devices.m1830
newmodel32 = workspace.prefabs.m1830:clone()
newmodel32:PivotTo(CFrame.new(-43.95969033398592, 5.226960000000001, 39.843805302884796) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel32.Parent = workspace.devices.m1830
newmodel33 = workspace.prefabs.m1830:clone()
newmodel33:PivotTo(CFrame.new(-43.95969033398592, 5.320400000000001, 39.843805302884796) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel33.Parent = workspace.devices.m1830
newmodel34 = workspace.prefabs.m1830:clone()
newmodel34:PivotTo(CFrame.new(-54.576304640251095, 3.5567200000000003, 37.25554453025741) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel34.Parent = workspace.devices.m1830
newmodel35 = workspace.prefabs.m1830:clone()
newmodel35:PivotTo(CFrame.new(-54.576304640251095, 4.213720000000001, 37.25554453025741) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel35.Parent = workspace.devices.m1830
newmodel36 = workspace.prefabs.m1830:clone()
newmodel36:PivotTo(CFrame.new(-55.41100745240668, 3.5567200000000003, 36.86914951640675) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel36.Parent = workspace.devices.m1830
newmodel37 = workspace.prefabs.m1830:clone()
newmodel37:PivotTo(CFrame.new(-56.24571367308117, 4.213720000000001, 36.48275630499253) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel37.Parent = workspace.devices.m1830
newmodel38 = workspace.prefabs.m1830:clone()
newmodel38:PivotTo(CFrame.new(-56.24571367308117, 4.12466, 36.48275630499253) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel38.Parent = workspace.devices.m1830
newmodel39 = workspace.prefabs.m1830:clone()
newmodel39:PivotTo(CFrame.new(-56.24571367308117, 4.0356000000000005, 36.48275630499253) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel39.Parent = workspace.devices.m1830
newmodel40 = workspace.prefabs.m1830:clone()
newmodel40:PivotTo(CFrame.new(-56.24571367308117, 3.8166, 36.48275630499253) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel40.Parent = workspace.devices.m1830
newmodel41 = workspace.prefabs.m1830:clone()
newmodel41:PivotTo(CFrame.new(-58.27281568358937, 3.948, 35.41779910340179) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel41.Parent = workspace.devices.m1830
newmodel42 = workspace.prefabs.m1830:clone()
newmodel42:PivotTo(CFrame.new(-58.27281568358937, 3.7085600000000003, 35.41779910340179) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel42.Parent = workspace.devices.m1830
newmodel43 = workspace.prefabs.m1830:clone()
newmodel43:PivotTo(CFrame.new(-62.84071003432234, 3.5567200000000003, 32.36053122364706) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel43.Parent = workspace.devices.m1830
newmodel44 = workspace.prefabs.m1830:clone()
newmodel44:PivotTo(CFrame.new(-62.84071003432234, 4.213720000000001, 32.36053122364706) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel44.Parent = workspace.devices.m1830
newmodel45 = workspace.prefabs.m1830:clone()
newmodel45:PivotTo(CFrame.new(-63.53919700114562, 3.5567200000000003, 31.762074754164388) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel45.Parent = workspace.devices.m1830
newmodel46 = workspace.prefabs.m1830:clone()
newmodel46:PivotTo(CFrame.new(-64.23767354071522, 4.213720000000001, 31.16361329529869) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel46.Parent = workspace.devices.m1830
newmodel47 = workspace.prefabs.m1830:clone()
newmodel47:PivotTo(CFrame.new(-64.23767354071522, 4.12466, 31.16361329529869) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel47.Parent = workspace.devices.m1830
newmodel48 = workspace.prefabs.m1830:clone()
newmodel48:PivotTo(CFrame.new(-64.23767354071522, 4.0356000000000005, 31.16361329529869) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel48.Parent = workspace.devices.m1830
newmodel49 = workspace.prefabs.m1830:clone()
newmodel49:PivotTo(CFrame.new(-64.23767354071522, 3.8166, 31.16361329529869) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel49.Parent = workspace.devices.m1830
