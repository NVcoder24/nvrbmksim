newmodel0 = Instance.new('Part')
newmodel0:PivotTo(CFrame.new(-52.05535909486285, 6.627099708000001, 38.17565573075531) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel0.Parent = workspace.devices.lplace
newmodel0.Material = Enum.Material.SmoothPlastic
newmodel0.Color = Color3.fromRGB(255, 255, 255)
newmodel0.Size = Vector3.new(1.2702, 0.01825, 0.5402)
newmodel0.Anchored = true
newmodel1 = Instance.new('Part')
newmodel1:PivotTo(CFrame.new(-52.05535909486285, 5.91316, 38.17565573075531) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel1.Parent = workspace.devices.lplace
newmodel1.Material = Enum.Material.SmoothPlastic
newmodel1.Color = Color3.fromRGB(255, 255, 255)
newmodel1.Size = Vector3.new(1.2702, 0.01825, 0.6482399999999999)
newmodel1.Anchored = true
newmodel2 = Instance.new('Part')
newmodel2:PivotTo(CFrame.new(-53.45560534097848, 5.91316, 37.677324165724485) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel2.Parent = workspace.devices.lplace
newmodel2.Material = Enum.Material.SmoothPlastic
newmodel2.Color = Color3.fromRGB(255, 255, 255)
newmodel2.Size = Vector3.new(1.2702, 0.01825, 0.6482399999999999)
newmodel2.Anchored = true
newmodel3 = Instance.new('Part')
newmodel3:PivotTo(CFrame.new(-53.45560534097848, 6.627099708000001, 37.677324165724485) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel3.Parent = workspace.devices.lplace
newmodel3.Material = Enum.Material.SmoothPlastic
newmodel3.Color = Color3.fromRGB(255, 255, 255)
newmodel3.Size = Vector3.new(1.2702, 0.01825, 0.5402)
newmodel3.Anchored = true
newmodel4 = Instance.new('Part')
newmodel4:PivotTo(CFrame.new(-55.06666904675099, 6.686960292, 37.01849375700576) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel4.Parent = workspace.devices.lplace
newmodel4.Material = Enum.Material.SmoothPlastic
newmodel4.Color = Color3.fromRGB(255, 255, 255)
newmodel4.Size = Vector3.new(1.2351599999999998, 0.01825000292, 0.42047999999999996)
newmodel4.Anchored = true
newmodel5 = Instance.new('Part')
newmodel5:PivotTo(CFrame.new(-56.38364681662106, 6.686960292, 36.40884870349669) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel5.Parent = workspace.devices.lplace
newmodel5.Material = Enum.Material.SmoothPlastic
newmodel5.Color = Color3.fromRGB(255, 255, 255)
newmodel5.Size = Vector3.new(1.2351599999999998, 0.01825000292, 0.42047999999999996)
newmodel5.Anchored = true
newmodel6 = Instance.new('Part')
newmodel6:PivotTo(CFrame.new(-58.12423034578488, 6.653380000000001, 35.49335000579694) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel6.Parent = workspace.devices.lplace
newmodel6.Material = Enum.Material.SmoothPlastic
newmodel6.Color = Color3.fromRGB(255, 255, 255)
newmodel6.Size = Vector3.new(0.8351199999999999, 0.01825000292, 0.42923999999999995)
newmodel6.Anchored = true
newmodel7 = Instance.new('Part')
newmodel7:PivotTo(CFrame.new(-59.01860788803271, 6.653380000000001, 34.97510108201318) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel7.Parent = workspace.devices.lplace
newmodel7.Material = Enum.Material.SmoothPlastic
newmodel7.Color = Color3.fromRGB(255, 255, 255)
newmodel7.Size = Vector3.new(0.8351199999999999, 0.01825000292, 0.42923999999999995)
newmodel7.Anchored = true
newmodel8 = Instance.new('Part')
newmodel8:PivotTo(CFrame.new(-60.664175486359916, 6.627099708000001, 33.930389698005634) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel8.Parent = workspace.devices.lplace
newmodel8.Material = Enum.Material.SmoothPlastic
newmodel8.Color = Color3.fromRGB(255, 255, 255)
newmodel8.Size = Vector3.new(1.2702, 0.01825000584, 0.5402)
newmodel8.Anchored = true
newmodel9 = Instance.new('Part')
newmodel9:PivotTo(CFrame.new(-60.664175486359916, 5.91316, 33.930389698005634) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel9.Parent = workspace.devices.lplace
newmodel9.Material = Enum.Material.SmoothPlastic
newmodel9.Color = Color3.fromRGB(255, 255, 255)
newmodel9.Size = Vector3.new(1.2702, 0.01825000584, 0.6482399999999999)
newmodel9.Anchored = true
newmodel10 = Instance.new('Part')
newmodel10:PivotTo(CFrame.new(-61.87658136362434, 5.91316, 33.07068838976142) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel10.Parent = workspace.devices.lplace
newmodel10.Material = Enum.Material.SmoothPlastic
newmodel10.Color = Color3.fromRGB(255, 255, 255)
newmodel10.Size = Vector3.new(1.2702, 0.01825000584, 0.6482399999999999)
newmodel10.Anchored = true
newmodel11 = Instance.new('Part')
newmodel11:PivotTo(CFrame.new(-61.87658136362434, 6.627099708000001, 33.07068838976142) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel11.Parent = workspace.devices.lplace
newmodel11.Material = Enum.Material.SmoothPlastic
newmodel11.Color = Color3.fromRGB(255, 255, 255)
newmodel11.Size = Vector3.new(1.2702, 0.01825000584, 0.5402)
newmodel11.Anchored = true
newmodel12 = Instance.new('Part')
newmodel12:PivotTo(CFrame.new(-63.24831587496829, 6.686960292, 31.99927248155089) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel12.Parent = workspace.devices.lplace
newmodel12.Material = Enum.Material.SmoothPlastic
newmodel12.Color = Color3.fromRGB(255, 255, 255)
newmodel12.Size = Vector3.new(1.2351599999999998, 0.01825, 0.42047999999999996)
newmodel12.Anchored = true
newmodel13 = Instance.new('Part')
newmodel13:PivotTo(CFrame.new(-64.35036877719003, 6.686960292, 31.055030884410982) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel13.Parent = workspace.devices.lplace
newmodel13.Material = Enum.Material.SmoothPlastic
newmodel13.Color = Color3.fromRGB(255, 255, 255)
newmodel13.Size = Vector3.new(1.2351599999999998, 0.01825, 0.42047999999999996)
newmodel13.Anchored = true
newmodel14 = Instance.new('Part')
newmodel14:PivotTo(CFrame.new(-67.80839797749962, 6.473800292000001, 27.494102577328448) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel14.Parent = workspace.devices.lplace
newmodel14.Material = Enum.Material.SmoothPlastic
newmodel14.Color = Color3.fromRGB(255, 255, 255)
newmodel14.Size = Vector3.new(1.2409999999999999, 0.01825000292, 0.8467999999999999)
newmodel14.Anchored = true
newmodel15 = Instance.new('Part')
newmodel15:PivotTo(CFrame.new(-68.71992159550598, 6.473800292000001, 26.364844821568788) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel15.Parent = workspace.devices.lplace
newmodel15.Material = Enum.Material.SmoothPlastic
newmodel15.Color = Color3.fromRGB(255, 255, 255)
newmodel15.Size = Vector3.new(1.2409999999999999, 0.01825000292, 0.8467999999999999)
newmodel15.Anchored = true
newmodel16 = Instance.new('Part')
newmodel16:PivotTo(CFrame.new(-70.16255164914956, 6.790619708000001, 24.34371095545968) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel16.Parent = workspace.devices.lplace
newmodel16.Material = Enum.Material.SmoothPlastic
newmodel16.Color = Color3.fromRGB(255, 255, 255)
newmodel16.Size = Vector3.new(1.6848399999999997, 0.01825000876, 0.2131600292)
newmodel16.Anchored = true
newmodel17 = Instance.new('Part')
newmodel17:PivotTo(CFrame.new(-70.16336099899463, 6.411020000000001, 24.342484243567043) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel17.Parent = workspace.devices.lplace
newmodel17.Material = Enum.Material.SmoothPlastic
newmodel17.Color = Color3.fromRGB(255, 255, 255)
newmodel17.Size = Vector3.new(1.6848399999999997, 0.01825000876, 0.32411999999999996)
newmodel17.Anchored = true
newmodel18 = Instance.new('Part')
newmodel18:PivotTo(CFrame.new(-70.16336099899463, 6.0139002920000015, 24.342484243567043) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel18.Parent = workspace.devices.lplace
newmodel18.Material = Enum.Material.SmoothPlastic
newmodel18.Color = Color3.fromRGB(255, 255, 255)
newmodel18.Size = Vector3.new(1.6848399999999997, 0.01825000876, 0.2131600292)
newmodel18.Anchored = true
newmodel19 = Instance.new('Part')
newmodel19:PivotTo(CFrame.new(-70.16336099899463, 5.570059416000001, 24.342484243567043) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel19.Parent = workspace.devices.lplace
newmodel19.Material = Enum.Material.SmoothPlastic
newmodel19.Color = Color3.fromRGB(255, 255, 255)
newmodel19.Size = Vector3.new(1.6848399999999997, 0.01825000876, 0.43507999999999997)
newmodel19.Anchored = true
newmodel20 = Instance.new('Part')
newmodel20:PivotTo(CFrame.new(-71.81636282130141, 6.7351402920000005, 21.595103903929207) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel20.Parent = workspace.devices.lplace
newmodel20.Material = Enum.Material.SmoothPlastic
newmodel20.Color = Color3.fromRGB(255, 255, 255)
newmodel20.Size = Vector3.new(1.6848399999999997, 0.01825, 0.32411999999999996)
newmodel20.Anchored = true
