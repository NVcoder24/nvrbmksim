newmodel0 = workspace.prefabs.mk12_2pos:clone()
newmodel0:PivotTo(CFrame.new(-15.782884196191535, 2.999696819776014, 21.772592587358588) * CFrame.fromEulerAngles(0, math.rad(54.752996411877), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel0.Parent = workspace.devices.mk12_2pos
newmodel1 = workspace.prefabs.mk12_2pos:clone()
newmodel1:PivotTo(CFrame.new(-15.968249496705697, 2.999696819776014, 22.034907560940532) * CFrame.fromEulerAngles(0, math.rad(54.752996411877), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel1.Parent = workspace.devices.mk12_2pos
newmodel2 = workspace.prefabs.mk12_2pos:clone()
newmodel2:PivotTo(CFrame.new(-29.25320109910528, 2.9939455424984227, 32.715510063390184) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel2.Parent = workspace.devices.mk12_2pos
newmodel3 = workspace.prefabs.mk12_2pos:clone()
newmodel3:PivotTo(CFrame.new(-28.35729571031957, 2.7416162507681845, 31.96119269372037) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.mk12_2pos
newmodel4 = workspace.prefabs.mk12_2pos:clone()
newmodel4:PivotTo(CFrame.new(-28.560751036164355, 2.74161624583503, 32.047355361427314) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.mk12_2pos
newmodel5 = workspace.prefabs.mk12_2pos:clone()
newmodel5:PivotTo(CFrame.new(-28.764201790844286, 2.741616241712354, 32.13351625046993) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.mk12_2pos
newmodel6 = workspace.prefabs.mk12_2pos:clone()
newmodel6:PivotTo(CFrame.new(-28.967657372020845, 2.741616248563681, 32.219683931949184) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.devices.mk12_2pos
newmodel7 = workspace.prefabs.mk12_2pos:clone()
newmodel7:PivotTo(CFrame.new(-28.653532083065528, 2.7210021298596856, 31.83077101252625) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.devices.mk12_2pos
newmodel8 = workspace.prefabs.mk12_2pos:clone()
newmodel8:PivotTo(CFrame.new(-29.05954277658647, 2.7210021330071203, 32.00271791389774) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.devices.mk12_2pos
newmodel9 = workspace.prefabs.mk12_2pos:clone()
newmodel9:PivotTo(CFrame.new(-28.44918230532113, 2.7210021267190454, 31.744225827327213) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.devices.mk12_2pos
newmodel10 = workspace.prefabs.mk12_2pos:clone()
newmodel10:PivotTo(CFrame.new(-28.857881567778346, 2.7210021212549464, 31.917314500841123) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.devices.mk12_2pos
newmodel11 = workspace.prefabs.mk12_2pos:clone()
newmodel11:PivotTo(CFrame.new(-28.541068865485933, 2.700388013573658, 31.527262499760656) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.devices.mk12_2pos
newmodel12 = workspace.prefabs.mk12_2pos:clone()
newmodel12:PivotTo(CFrame.new(-28.745417971992612, 2.7003880127159254, 31.613804570673082) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.mk12_2pos
newmodel13 = workspace.prefabs.mk12_2pos:clone()
newmodel13:PivotTo(CFrame.new(-29.15142990628729, 2.700387998782175, 31.785753883047732) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.mk12_2pos
newmodel14 = workspace.prefabs.mk12_2pos:clone()
newmodel14:PivotTo(CFrame.new(-28.949767725662834, 2.7003880037802213, 31.700348172874115) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.mk12_2pos
newmodel15 = workspace.prefabs.mk12_2pos:clone()
newmodel15:PivotTo(CFrame.new(-29.51617288600145, 2.7416162575925607, 32.451985519862056) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.mk12_2pos
newmodel16 = workspace.prefabs.mk12_2pos:clone()
newmodel16:PivotTo(CFrame.new(-29.608059270174955, 2.7210021383023415, 32.23501862734249) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.mk12_2pos
newmodel17 = workspace.prefabs.mk12_2pos:clone()
newmodel17:PivotTo(CFrame.new(-29.698811647117044, 2.7006426425466636, 32.020732402552305) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel17.Parent = workspace.devices.mk12_2pos
newmodel18 = workspace.prefabs.mk12_2pos:clone()
newmodel18:PivotTo(CFrame.new(-29.77368069165321, 2.6838458464543473, 31.8439461228307) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel18.Parent = workspace.devices.mk12_2pos
newmodel19 = workspace.prefabs.mk12_2pos:clone()
newmodel19:PivotTo(CFrame.new(-29.22062762932613, 2.6848638328781096, 31.622359521777824) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel19.Parent = workspace.devices.mk12_2pos
newmodel20 = workspace.prefabs.mk12_2pos:clone()
newmodel20:PivotTo(CFrame.new(-28.676062240717926, 2.670103206907289, 31.208511872133375) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel20.Parent = workspace.devices.mk12_2pos
newmodel21 = workspace.prefabs.mk12_2pos:clone()
newmodel21:PivotTo(CFrame.new(-28.879516777741813, 2.670103217761143, 31.2946769735832) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel21.Parent = workspace.devices.mk12_2pos
newmodel22 = workspace.prefabs.mk12_2pos:clone()
newmodel22:PivotTo(CFrame.new(-31.108030343827366, 2.5576165720396715, 30.84218887109164) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.mk12_2pos
newmodel23 = workspace.prefabs.mk12_2pos:clone()
newmodel23:PivotTo(CFrame.new(-48.046940490069474, 3.0514583152743353, 34.56939777216651) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel23.Parent = workspace.devices.mk12_2pos
newmodel24 = workspace.prefabs.mk12_2pos:clone()
newmodel24:PivotTo(CFrame.new(-48.40876766679359, 2.736271849881208, 34.04874793213155) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.mk12_2pos
newmodel25 = workspace.prefabs.mk12_2pos:clone()
newmodel25:PivotTo(CFrame.new(-48.613581167693916, 2.6283660679001875, 32.72517923664195) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.mk12_2pos
newmodel26 = workspace.prefabs.mk12_2pos:clone()
newmodel26:PivotTo(CFrame.new(-48.52457853356619, 2.5973177061037616, 32.3816287675052) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.mk12_2pos
newmodel27 = workspace.prefabs.mk12_2pos:clone()
newmodel27:PivotTo(CFrame.new(-48.45269681483157, 2.5655058600008664, 32.024763281139144) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel27.Parent = workspace.devices.mk12_2pos
newmodel28 = workspace.prefabs.mk12_2pos:clone()
newmodel28:PivotTo(CFrame.new(-48.008123548645536, 2.5973177061037616, 32.51180376592887) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel28.Parent = workspace.devices.mk12_2pos
newmodel29 = workspace.prefabs.mk12_2pos:clone()
newmodel29:PivotTo(CFrame.new(-48.786203756190474, 2.5973177061037616, 32.31568485383005) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel29.Parent = workspace.devices.mk12_2pos
newmodel30 = workspace.prefabs.mk12_2pos:clone()
newmodel30:PivotTo(CFrame.new(-49.04556382537212, 2.5973177061037616, 32.250311883130436) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel30.Parent = workspace.devices.mk12_2pos
newmodel31 = workspace.prefabs.mk12_2pos:clone()
newmodel31:PivotTo(CFrame.new(-48.872941236875555, 2.6283660679001875, 32.659806265942336) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel31.Parent = workspace.devices.mk12_2pos
newmodel32 = workspace.prefabs.mk12_2pos:clone()
newmodel32:PivotTo(CFrame.new(-49.45646318412427, 2.741361745257671, 33.84466854578824) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel32.Parent = workspace.devices.mk12_2pos
newmodel33 = workspace.prefabs.mk12_2pos:clone()
newmodel33:PivotTo(CFrame.new(-17.686108045516406, 2.7090409096171295, 23.129026796389667) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel33.Parent = workspace.devices.mk12_2pos
newmodel34 = workspace.prefabs.mk12_2pos:clone()
newmodel34:PivotTo(CFrame.new(-18.02461201918864, 2.7339813969617994, 23.963228856067943) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel34.Parent = workspace.devices.mk12_2pos
newmodel35 = workspace.prefabs.mk12_2pos:clone()
newmodel35:PivotTo(CFrame.new(-31.96755397344445, 2.991069903859627, 33.724281907127676) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel35.Parent = workspace.devices.mk12_2pos
newmodel36 = workspace.prefabs.mk12_2pos:clone()
newmodel36:PivotTo(CFrame.new(-31.010332019230482, 2.7418707347953175, 33.06096734281642) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel36.Parent = workspace.devices.mk12_2pos
newmodel37 = workspace.prefabs.mk12_2pos:clone()
newmodel37:PivotTo(CFrame.new(-31.152354184410637, 2.7008970770147886, 32.61468976286687) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel37.Parent = workspace.devices.mk12_2pos
newmodel38 = workspace.prefabs.mk12_2pos:clone()
newmodel38:PivotTo(CFrame.new(-31.516234010636836, 2.6661583210322606, 32.31380330125981) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel38.Parent = workspace.devices.mk12_2pos
newmodel39 = workspace.prefabs.mk12_2pos:clone()
newmodel39:PivotTo(CFrame.new(-31.785210284198513, 2.666158308602228, 32.3994018846607) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel39.Parent = workspace.devices.mk12_2pos
newmodel40 = workspace.prefabs.mk12_2pos:clone()
newmodel40:PivotTo(CFrame.new(-32.05418344598091, 2.6661583175526653, 32.48499764968013) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel40.Parent = workspace.devices.mk12_2pos
newmodel41 = workspace.prefabs.mk12_2pos:clone()
newmodel41:PivotTo(CFrame.new(-32.323159352872985, 2.666158332087307, 32.57059642168697) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel41.Parent = workspace.devices.mk12_2pos
newmodel42 = workspace.prefabs.mk12_2pos:clone()
newmodel42:PivotTo(CFrame.new(-33.16996602016393, 2.66615833152642, 32.84008309499488) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel42.Parent = workspace.devices.mk12_2pos
newmodel43 = workspace.prefabs.mk12_2pos:clone()
newmodel43:PivotTo(CFrame.new(-33.43893908708647, 2.6661583226041032, 32.925682181764834) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel43.Parent = workspace.devices.mk12_2pos
newmodel44 = workspace.prefabs.mk12_2pos:clone()
newmodel44:PivotTo(CFrame.new(-32.63201807537257, 2.6661583203865504, 32.66888586833522) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel44.Parent = workspace.devices.mk12_2pos
newmodel45 = workspace.prefabs.mk12_2pos:clone()
newmodel45:PivotTo(CFrame.new(-32.70434839119278, 2.645289914021105, 32.44159009076884) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel45.Parent = workspace.devices.mk12_2pos
newmodel46 = workspace.prefabs.mk12_2pos:clone()
newmodel46:PivotTo(CFrame.new(-32.90099222842083, 2.666158332087307, 32.75448438690104) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel46.Parent = workspace.devices.mk12_2pos
newmodel47 = workspace.prefabs.mk12_2pos:clone()
newmodel47:PivotTo(CFrame.new(-32.97341728231527, 2.6452899236739413, 32.52722028225215) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel47.Parent = workspace.devices.mk12_2pos
newmodel48 = workspace.prefabs.mk12_2pos:clone()
newmodel48:PivotTo(CFrame.new(-32.546568808886576, 2.61065629946204, 31.889366131856647) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel48.Parent = workspace.devices.mk12_2pos
newmodel49 = workspace.prefabs.mk12_2pos:clone()
newmodel49:PivotTo(CFrame.new(-49.849910919810206, 2.608525437875471, 32.07358773874573) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel49.Parent = workspace.devices.mk12_2pos
newmodel50 = workspace.prefabs.mk12_2pos:clone()
newmodel50:PivotTo(CFrame.new(-50.425374364812164, 2.608525437875471, 31.87040431947515) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel50.Parent = workspace.devices.mk12_2pos
newmodel51 = workspace.prefabs.mk12_2pos:clone()
newmodel51:PivotTo(CFrame.new(-50.91548198782817, 2.608525437875471, 31.697358153780584) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel51.Parent = workspace.devices.mk12_2pos
newmodel52 = workspace.prefabs.mk12_2pos:clone()
newmodel52:PivotTo(CFrame.new(-20.524348244266307, 2.730163975429452, 26.512723493662175) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel52.Parent = workspace.devices.mk12_2pos
newmodel53 = workspace.prefabs.mk12_2pos:clone()
newmodel53:PivotTo(CFrame.new(-19.604716678967876, 2.7072594462353674, 25.255000450600168) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel53.Parent = workspace.devices.mk12_2pos
newmodel54 = workspace.prefabs.mk12_2pos:clone()
newmodel54:PivotTo(CFrame.new(-20.107923768154116, 2.662213872153668, 25.02593430808155) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel54.Parent = workspace.devices.mk12_2pos
newmodel55 = workspace.prefabs.mk12_2pos:clone()
newmodel55:PivotTo(CFrame.new(-21.42999375795985, 2.6393093429595833, 25.944595766398734) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel55.Parent = workspace.devices.mk12_2pos
newmodel56 = workspace.prefabs.mk12_2pos:clone()
newmodel56:PivotTo(CFrame.new(-21.098976145150075, 2.6393093429595833, 25.623223101709097) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel56.Parent = workspace.devices.mk12_2pos
newmodel57 = workspace.prefabs.mk12_2pos:clone()
newmodel57:PivotTo(CFrame.new(-34.763189569990274, 2.991069903859627, 34.47901560618439) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel57.Parent = workspace.devices.mk12_2pos
newmodel58 = workspace.prefabs.mk12_2pos:clone()
newmodel58:PivotTo(CFrame.new(-34.93718574657696, 2.991069903859627, 34.51712157596888) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel58.Parent = workspace.devices.mk12_2pos
newmodel59 = workspace.prefabs.mk12_2pos:clone()
newmodel59:PivotTo(CFrame.new(-35.11118192316364, 2.991069903859627, 34.55522754575337) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel59.Parent = workspace.devices.mk12_2pos
newmodel60 = workspace.prefabs.mk12_2pos:clone()
newmodel60:PivotTo(CFrame.new(-35.66739920897352, 2.991069903859627, 34.677041711457875) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel60.Parent = workspace.devices.mk12_2pos
newmodel61 = workspace.prefabs.mk12_2pos:clone()
newmodel61:PivotTo(CFrame.new(-34.24811374528203, 2.6731201829726325, 33.126552950230945) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel61.Parent = workspace.devices.mk12_2pos
newmodel62 = workspace.prefabs.mk12_2pos:clone()
newmodel62:PivotTo(CFrame.new(-34.30132132746323, 2.651360880238252, 32.88360109997468) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel62.Parent = workspace.devices.mk12_2pos
newmodel63 = workspace.prefabs.mk12_2pos:clone()
newmodel63:PivotTo(CFrame.new(-34.50098907108729, 2.651360880238252, 32.927329262022454) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel63.Parent = workspace.devices.mk12_2pos
newmodel64 = workspace.prefabs.mk12_2pos:clone()
newmodel64:PivotTo(CFrame.new(-34.63349923449463, 2.6799915417308577, 33.29135559927878) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel64.Parent = workspace.devices.mk12_2pos
newmodel65 = workspace.prefabs.mk12_2pos:clone()
newmodel65:PivotTo(CFrame.new(-35.72440459449183, 2.746960681273219, 34.39918475472656) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel65.Parent = workspace.devices.mk12_2pos
newmodel66 = workspace.prefabs.mk12_2pos:clone()
newmodel66:PivotTo(CFrame.new(-35.92692384236847, 2.74696067480961, 34.44353758805689) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel66.Parent = workspace.devices.mk12_2pos
newmodel67 = workspace.prefabs.mk12_2pos:clone()
newmodel67:PivotTo(CFrame.new(-53.630493163562065, 2.7360173551123848, 32.20079653932931) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel67.Parent = workspace.devices.mk12_2pos
newmodel68 = workspace.prefabs.mk12_2pos:clone()
newmodel68:PivotTo(CFrame.new(-51.84351241516248, 2.6104596808077507, 31.371099941522154) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel68.Parent = workspace.devices.mk12_2pos
newmodel69 = workspace.prefabs.mk12_2pos:clone()
newmodel69:PivotTo(CFrame.new(-53.04835338576748, 2.6176772876096144, 30.979716403575424) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel69.Parent = workspace.devices.mk12_2pos
newmodel70 = workspace.prefabs.mk12_2pos:clone()
newmodel70:PivotTo(CFrame.new(-53.473311372296074, 2.7034420937732437, 31.863266160001793) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel70.Parent = workspace.devices.mk12_2pos
newmodel71 = workspace.prefabs.mk12_2pos:clone()
newmodel71:PivotTo(CFrame.new(-53.69738917485569, 2.7034419889924584, 31.75997318053073) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel71.Parent = workspace.devices.mk12_2pos
newmodel72 = workspace.prefabs.mk12_2pos:clone()
newmodel72:PivotTo(CFrame.new(-53.92146871366047, 2.703441966932209, 31.65668283955425) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel72.Parent = workspace.devices.mk12_2pos
newmodel73 = workspace.prefabs.mk12_2pos:clone()
newmodel73:PivotTo(CFrame.new(-54.145547191568745, 2.703441967404618, 31.553396091200405) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel73.Parent = workspace.devices.mk12_2pos
newmodel74 = workspace.prefabs.mk12_2pos:clone()
newmodel74:PivotTo(CFrame.new(-53.335706537531244, 2.6746841054166057, 31.56474414535376) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel74.Parent = workspace.devices.mk12_2pos
newmodel75 = workspace.prefabs.mk12_2pos:clone()
newmodel75:PivotTo(CFrame.new(-53.55979096548915, 2.6746841342003997, 31.46145652287363) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel75.Parent = workspace.devices.mk12_2pos
newmodel76 = workspace.prefabs.mk12_2pos:clone()
newmodel76:PivotTo(CFrame.new(-53.78386821359868, 2.674684099489556, 31.358167541749243) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel76.Parent = workspace.devices.mk12_2pos
newmodel77 = workspace.prefabs.mk12_2pos:clone()
newmodel77:PivotTo(CFrame.new(-54.00794898144318, 2.6746841114919677, 31.254879433412842) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel77.Parent = workspace.devices.mk12_2pos
newmodel78 = workspace.prefabs.mk12_2pos:clone()
newmodel78:PivotTo(CFrame.new(-21.280056077965707, 2.7467061354029574, 27.44869034328695) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel78.Parent = workspace.devices.mk12_2pos
newmodel79 = workspace.prefabs.mk12_2pos:clone()
newmodel79:PivotTo(CFrame.new(-21.426041460765283, 2.7263465538971046, 27.267464750586118) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel79.Parent = workspace.devices.mk12_2pos
newmodel80 = workspace.prefabs.mk12_2pos:clone()
newmodel80:PivotTo(CFrame.new(-21.450604057675374, 2.7467061354029574, 27.586074427579675) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel80.Parent = workspace.devices.mk12_2pos
newmodel81 = workspace.prefabs.mk12_2pos:clone()
newmodel81:PivotTo(CFrame.new(-37.16725949586918, 2.9939455424984227, 34.91774974306375) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel81.Parent = workspace.devices.mk12_2pos
newmodel82 = workspace.prefabs.mk12_2pos:clone()
newmodel82:PivotTo(CFrame.new(-37.877636131485, 2.611735455718032, 33.078805420508814) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel82.Parent = workspace.devices.mk12_2pos
newmodel83 = workspace.prefabs.mk12_2pos:clone()
newmodel83:PivotTo(CFrame.new(-36.6031877779744, 2.7441611877147256, 34.530266001870345) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel83.Parent = workspace.devices.mk12_2pos
newmodel84 = workspace.prefabs.mk12_2pos:clone()
newmodel84:PivotTo(CFrame.new(-36.99667590601471, 2.6671766641172074, 33.692301737787716) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel84.Parent = workspace.devices.mk12_2pos
newmodel85 = workspace.prefabs.mk12_2pos:clone()
newmodel85:PivotTo(CFrame.new(-37.25748965123702, 2.667176641384166, 33.72457027009875) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel85.Parent = workspace.devices.mk12_2pos
newmodel86 = workspace.prefabs.mk12_2pos:clone()
newmodel86:PivotTo(CFrame.new(-37.518298324208715, 2.667176657121948, 33.7568393471379) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel86.Parent = workspace.devices.mk12_2pos
newmodel87 = workspace.prefabs.mk12_2pos:clone()
newmodel87:PivotTo(CFrame.new(-37.77910993658368, 2.667176655357448, 33.789106150363104) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel87.Parent = workspace.devices.mk12_2pos
newmodel88 = workspace.prefabs.mk12_2pos:clone()
newmodel88:PivotTo(CFrame.new(-38.03992201258343, 2.667176656969371, 33.8213762345053) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel88.Parent = workspace.devices.mk12_2pos
newmodel89 = workspace.prefabs.mk12_2pos:clone()
newmodel89:PivotTo(CFrame.new(-38.30073326176817, 2.667176663829174, 33.85364357891425) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel89.Parent = workspace.devices.mk12_2pos
newmodel90 = workspace.prefabs.mk12_2pos:clone()
newmodel90:PivotTo(CFrame.new(-38.561546201373574, 2.6671766578334424, 33.88591611428645) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel90.Parent = workspace.devices.mk12_2pos
newmodel91 = workspace.prefabs.mk12_2pos:clone()
newmodel91:PivotTo(CFrame.new(-38.82235567974912, 2.667176652249937, 33.918181188227805) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel91.Parent = workspace.devices.mk12_2pos
newmodel92 = workspace.prefabs.mk12_2pos:clone()
newmodel92:PivotTo(CFrame.new(-37.25688600840623, 2.645926204232542, 33.4797517062956) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel92.Parent = workspace.devices.mk12_2pos
newmodel93 = workspace.prefabs.mk12_2pos:clone()
newmodel93:PivotTo(CFrame.new(-37.58144955725685, 2.6459262246058657, 33.51990788938268) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel93.Parent = workspace.devices.mk12_2pos
newmodel94 = workspace.prefabs.mk12_2pos:clone()
newmodel94:PivotTo(CFrame.new(-37.91905732553579, 2.6459262172862528, 33.561681174239) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel94.Parent = workspace.devices.mk12_2pos
newmodel95 = workspace.prefabs.mk12_2pos:clone()
newmodel95:PivotTo(CFrame.new(-38.24362432563383, 2.6459262341821126, 33.601833388571784) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel95.Parent = workspace.devices.mk12_2pos
newmodel96 = workspace.prefabs.mk12_2pos:clone()
newmodel96:PivotTo(CFrame.new(-38.58122659296578, 2.6459262195297217, 33.64360364841592) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel96.Parent = workspace.devices.mk12_2pos
newmodel97 = workspace.prefabs.mk12_2pos:clone()
newmodel97:PivotTo(CFrame.new(-38.905797518178844, 2.645926244992405, 33.683766605141294) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel97.Parent = workspace.devices.mk12_2pos
newmodel98 = workspace.prefabs.mk12_2pos:clone()
newmodel98:PivotTo(CFrame.new(-40.51201287624479, 3.5173117747592304, 35.29459756884241) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel98.Parent = workspace.devices.mk12_2pos
newmodel99 = workspace.prefabs.mk12_2pos:clone()
newmodel99:PivotTo(CFrame.new(-39.4520764596722, 2.7372898228459652, 34.77498182038876) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel99.Parent = workspace.devices.mk12_2pos
newmodel100 = workspace.prefabs.mk12_2pos:clone()
newmodel100:PivotTo(CFrame.new(-39.47919757279466, 2.6680672413325963, 33.98422200523205) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel100.Parent = workspace.devices.mk12_2pos
newmodel101 = workspace.prefabs.mk12_2pos:clone()
newmodel101:PivotTo(CFrame.new(-39.93803082914365, 2.737289823351274, 34.789857760113364) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel101.Parent = workspace.devices.mk12_2pos
newmodel102 = workspace.prefabs.mk12_2pos:clone()
newmodel102:PivotTo(CFrame.new(-39.96515057916817, 2.668067236891128, 33.99909563703081) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel102.Parent = workspace.devices.mk12_2pos
newmodel103 = workspace.prefabs.mk12_2pos:clone()
newmodel103:PivotTo(CFrame.new(-40.423980225442776, 2.737289829901039, 34.80472701089208) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel103.Parent = workspace.devices.mk12_2pos
newmodel104 = workspace.prefabs.mk12_2pos:clone()
newmodel104:PivotTo(CFrame.new(-40.45110329391147, 2.668067234132792, 34.01396925993708) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel104.Parent = workspace.devices.mk12_2pos
newmodel105 = workspace.prefabs.mk12_2pos:clone()
newmodel105:PivotTo(CFrame.new(-40.90993397747727, 2.7372898285479232, 34.81959688872091) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel105.Parent = workspace.devices.mk12_2pos
newmodel106 = workspace.prefabs.mk12_2pos:clone()
newmodel106:PivotTo(CFrame.new(-40.937056299678844, 2.6680672253152022, 34.028842891631655) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel106.Parent = workspace.devices.mk12_2pos
newmodel107 = workspace.prefabs.mk12_2pos:clone()
newmodel107:PivotTo(CFrame.new(-41.39588532626654, 2.737289827131014, 34.83446829089509) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel107.Parent = workspace.devices.mk12_2pos
newmodel108 = workspace.prefabs.mk12_2pos:clone()
newmodel108:PivotTo(CFrame.new(-41.42300855674876, 2.6680672356786235, 34.04371359551699) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel108.Parent = workspace.devices.mk12_2pos
newmodel109 = workspace.prefabs.mk12_2pos:clone()
newmodel109:PivotTo(CFrame.new(-39.49461031011131, 2.615641235472137, 33.38518210062563) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel109.Parent = workspace.devices.mk12_2pos
newmodel110 = workspace.prefabs.mk12_2pos:clone()
newmodel110:PivotTo(CFrame.new(-39.97910375992978, 2.6156412477246063, 33.40000990040831) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel110.Parent = workspace.devices.mk12_2pos
newmodel111 = workspace.prefabs.mk12_2pos:clone()
newmodel111:PivotTo(CFrame.new(-40.46359737681718, 2.615641255944185, 33.414840610495716) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel111.Parent = workspace.devices.mk12_2pos
newmodel112 = workspace.prefabs.mk12_2pos:clone()
newmodel112:PivotTo(CFrame.new(-57.680003989439044, 3.0514583152743353, 30.448422578292487) * CFrame.fromEulerAngles(0, math.rad(-35.346990000000005), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel112.Parent = workspace.devices.mk12_2pos
newmodel113 = workspace.prefabs.mk12_2pos:clone()
newmodel113:PivotTo(CFrame.new(-57.82904706500132, 2.736271849881208, 29.832170874260555) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel113.Parent = workspace.devices.mk12_2pos
newmodel114 = workspace.prefabs.mk12_2pos:clone()
newmodel114:PivotTo(CFrame.new(-57.54136460622043, 2.6283660679001875, 28.524110682701767) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel114.Parent = workspace.devices.mk12_2pos
newmodel115 = workspace.prefabs.mk12_2pos:clone()
newmodel115:PivotTo(CFrame.new(-57.33414904134921, 2.5973177061037616, 28.235995942709415) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel115.Parent = workspace.devices.mk12_2pos
newmodel116 = workspace.prefabs.mk12_2pos:clone()
newmodel116:PivotTo(CFrame.new(-57.138080676016365, 2.5655058600008664, 27.929275951572166) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel116.Parent = workspace.devices.mk12_2pos
newmodel117 = workspace.prefabs.mk12_2pos:clone()
newmodel117:PivotTo(CFrame.new(-56.89972024449167, 2.5973177061037616, 28.544124003951683) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel117.Parent = workspace.devices.mk12_2pos
newmodel118 = workspace.prefabs.mk12_2pos:clone()
newmodel118:PivotTo(CFrame.new(-57.55422152396782, 2.5973177061037616, 28.079904753790636) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel118.Parent = workspace.devices.mk12_2pos
newmodel119 = workspace.prefabs.mk12_2pos:clone()
newmodel119:PivotTo(CFrame.new(-57.77238861712653, 2.5973177061037616, 27.92516500373695) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel119.Parent = workspace.devices.mk12_2pos
newmodel120 = workspace.prefabs.mk12_2pos:clone()
newmodel120:PivotTo(CFrame.new(-57.759531699379146, 2.6283660679001875, 28.369370932648078) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel120.Parent = workspace.devices.mk12_2pos
newmodel121 = workspace.prefabs.mk12_2pos:clone()
newmodel121:PivotTo(CFrame.new(-58.73203841188649, 2.741361745257671, 29.263030364003598) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel121.Parent = workspace.devices.mk12_2pos
newmodel122 = workspace.prefabs.mk12_2pos:clone()
newmodel122:PivotTo(CFrame.new(-43.812900403322246, 2.675171561996135, 33.95014294425405) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel122.Parent = workspace.devices.mk12_2pos
newmodel123 = workspace.prefabs.mk12_2pos:clone()
newmodel123:PivotTo(CFrame.new(-44.1363955888081, 2.6751715463283445, 33.93008756882988) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel123.Parent = workspace.devices.mk12_2pos
newmodel124 = workspace.prefabs.mk12_2pos:clone()
newmodel124:PivotTo(CFrame.new(-43.94836174909911, 2.736271849881208, 34.722435776952004) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel124.Parent = workspace.devices.mk12_2pos
newmodel125 = workspace.prefabs.mk12_2pos:clone()
newmodel125:PivotTo(CFrame.new(-44.360750254962134, 2.736271849881208, 34.69687344857493) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel125.Parent = workspace.devices.mk12_2pos
newmodel126 = workspace.prefabs.mk12_2pos:clone()
newmodel126:PivotTo(CFrame.new(-58.46043169591245, 2.606806301836567, 27.471172256254782) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel126.Parent = workspace.devices.mk12_2pos
newmodel127 = workspace.prefabs.mk12_2pos:clone()
newmodel127:PivotTo(CFrame.new(-58.92347384577572, 2.606806301836567, 27.073637797559677) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel127.Parent = workspace.devices.mk12_2pos
newmodel128 = workspace.prefabs.mk12_2pos:clone()
newmodel128:PivotTo(CFrame.new(-59.31783510259705, 2.606806301836567, 26.73506778010643) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel128.Parent = workspace.devices.mk12_2pos
newmodel129 = workspace.prefabs.mk12_2pos:clone()
newmodel129:PivotTo(CFrame.new(-62.0291839683794, 2.7360173551123848, 26.221041346014164) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel129.Parent = workspace.devices.mk12_2pos
newmodel130 = workspace.prefabs.mk12_2pos:clone()
newmodel130:PivotTo(CFrame.new(-60.06499144878997, 2.608557299788054, 26.095553772660523) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel130.Parent = workspace.devices.mk12_2pos
newmodel131 = workspace.prefabs.mk12_2pos:clone()
newmodel131:PivotTo(CFrame.new(-61.04486861877942, 2.6176772876096144, 25.293115319132013) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel131.Parent = workspace.devices.mk12_2pos
newmodel132 = workspace.prefabs.mk12_2pos:clone()
newmodel132:PivotTo(CFrame.new(-61.760574402702616, 2.7034419980479134, 25.96319209877554) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel132.Parent = workspace.devices.mk12_2pos
newmodel133 = workspace.prefabs.mk12_2pos:clone()
newmodel133:PivotTo(CFrame.new(-61.93213940887041, 2.7034420821097442, 25.785863039548634) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel133.Parent = workspace.devices.mk12_2pos
newmodel134 = workspace.prefabs.mk12_2pos:clone()
newmodel134:PivotTo(CFrame.new(-62.10370313439719, 2.703442071985101, 25.60853177373595) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel134.Parent = workspace.devices.mk12_2pos
newmodel135 = workspace.prefabs.mk12_2pos:clone()
newmodel135:PivotTo(CFrame.new(-62.2752714741157, 2.703442108488832, 25.43119731593977) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel135.Parent = workspace.devices.mk12_2pos
newmodel136 = workspace.prefabs.mk12_2pos:clone()
newmodel136:PivotTo(CFrame.new(-61.52434346948163, 2.674684438883485, 25.73463986629354) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel136.Parent = workspace.devices.mk12_2pos
newmodel137 = workspace.prefabs.mk12_2pos:clone()
newmodel137:PivotTo(CFrame.new(-61.6958961035077, 2.674684038547895, 25.557306668322237) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel137.Parent = workspace.devices.mk12_2pos
newmodel138 = workspace.prefabs.mk12_2pos:clone()
newmodel138:PivotTo(CFrame.new(-61.867471631984046, 2.6746843192476497, 25.37997343399746) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel138.Parent = workspace.devices.mk12_2pos
newmodel139 = workspace.prefabs.mk12_2pos:clone()
newmodel139:PivotTo(CFrame.new(-62.03903462675141, 2.6746843738653765, 25.202645654450794) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel139.Parent = workspace.devices.mk12_2pos
newmodel140 = workspace.prefabs.mk12_2pos:clone()
newmodel140:PivotTo(CFrame.new(-64.10214277000699, 3.1894889699365265, 24.53102348959084) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel140.Parent = workspace.devices.mk12_2pos
newmodel141 = workspace.prefabs.mk12_2pos:clone()
newmodel141:PivotTo(CFrame.new(-61.875569111817434, 2.567033084946468, 23.5105275689104) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel141.Parent = workspace.devices.mk12_2pos
newmodel142 = workspace.prefabs.mk12_2pos:clone()
newmodel142:PivotTo(CFrame.new(-62.47893343698988, 2.6642503855979953, 24.534013961957182) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel142.Parent = workspace.devices.mk12_2pos
newmodel143 = workspace.prefabs.mk12_2pos:clone()
newmodel143:PivotTo(CFrame.new(-62.6121778786701, 2.567033040240146, 22.592829190970065) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel143.Parent = workspace.devices.mk12_2pos
newmodel144 = workspace.prefabs.mk12_2pos:clone()
newmodel144:PivotTo(CFrame.new(-63.21554238662413, 2.664250340891673, 23.61631535630015) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel144.Parent = workspace.devices.mk12_2pos
newmodel145 = workspace.prefabs.mk12_2pos:clone()
newmodel145:PivotTo(CFrame.new(-66.2857145503445, 2.959437878832875, 21.406014330457662) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel145.Parent = workspace.devices.mk12_2pos
newmodel146 = workspace.prefabs.mk12_2pos:clone()
newmodel146:PivotTo(CFrame.new(-64.91904338478635, 2.7090409313114754, 22.183876146082355) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel146.Parent = workspace.devices.mk12_2pos
newmodel147 = workspace.prefabs.mk12_2pos:clone()
newmodel147:PivotTo(CFrame.new(-65.46310810538705, 2.709040920380665, 21.360417128030782) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel147.Parent = workspace.devices.mk12_2pos
newmodel148 = workspace.prefabs.mk12_2pos:clone()
newmodel148:PivotTo(CFrame.new(-63.95789398905461, 2.6398184848594717, 22.2033018751045) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel148.Parent = workspace.devices.mk12_2pos
newmodel149 = workspace.prefabs.mk12_2pos:clone()
newmodel149:PivotTo(CFrame.new(-65.09592065415579, 2.6398181929173474, 20.480854042568332) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel149.Parent = workspace.devices.mk12_2pos
newmodel150 = workspace.prefabs.mk12_2pos:clone()
newmodel150:PivotTo(CFrame.new(-64.48353312737176, 2.6059934813184418, 20.706378541079438) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel150.Parent = workspace.devices.mk12_2pos
newmodel151 = workspace.prefabs.mk12_2pos:clone()
newmodel151:PivotTo(CFrame.new(-64.37947113516155, 2.6398184347450697, 21.565230190868025) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel151.Parent = workspace.devices.mk12_2pos
newmodel152 = workspace.prefabs.mk12_2pos:clone()
newmodel152:PivotTo(CFrame.new(-64.67403908492767, 2.6398184427051943, 21.11939284430698) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel152.Parent = workspace.devices.mk12_2pos
newmodel153 = workspace.prefabs.mk12_2pos:clone()
newmodel153:PivotTo(CFrame.new(-12.858656693088882, 4.80648, 26.467220692009146) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel153.Parent = workspace.devices.mk12_2pos
newmodel154 = workspace.prefabs.mk12_2pos:clone()
newmodel154:PivotTo(CFrame.new(-12.858656693088882, 4.5480599999999995, 26.467220692009146) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel154.Parent = workspace.devices.mk12_2pos
newmodel155 = workspace.prefabs.mk12_2pos:clone()
newmodel155:PivotTo(CFrame.new(-12.858656693088882, 4.2896399999999995, 26.467220692009146) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel155.Parent = workspace.devices.mk12_2pos
newmodel156 = workspace.prefabs.mk12_2pos:clone()
newmodel156:PivotTo(CFrame.new(-19.722055164882885, 3.5275199999999995, 32.92702729298483) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel156.Parent = workspace.devices.mk12_2pos
newmodel157 = workspace.prefabs.mk12_2pos:clone()
newmodel157:PivotTo(CFrame.new(-20.66865857305515, 3.5275199999999995, 33.60123635050086) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel157.Parent = workspace.devices.mk12_2pos
newmodel158 = workspace.prefabs.mk12_2pos:clone()
newmodel158:PivotTo(CFrame.new(-20.804227402868765, 3.5275199999999995, 33.69779392908984) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel158.Parent = workspace.devices.mk12_2pos
newmodel159 = workspace.prefabs.mk12_2pos:clone()
newmodel159:PivotTo(CFrame.new(-34.62720370684052, 2.3712000000000004, 39.38642525170596) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel159.Parent = workspace.devices.mk12_2pos
newmodel160 = workspace.prefabs.mk12_2pos:clone()
newmodel160:PivotTo(CFrame.new(-36.71746251006042, 2.3712000000000004, 39.69908367785188) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel160.Parent = workspace.devices.mk12_2pos
newmodel161 = workspace.prefabs.mk12_2pos:clone()
newmodel161:PivotTo(CFrame.new(-41.012750225117, 2.3712000000000004, 39.97332144618953) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel161.Parent = workspace.devices.mk12_2pos
newmodel162 = workspace.prefabs.mk12_2pos:clone()
newmodel162:PivotTo(CFrame.new(-44.21898689530765, 2.3712000000000004, 39.82640105953077) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel162.Parent = workspace.devices.mk12_2pos
newmodel163 = workspace.prefabs.mk12_2pos:clone()
newmodel163:PivotTo(CFrame.new(-56.510695625294815, 2.3420000000000005, 36.3600913580627) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel163.Parent = workspace.devices.mk12_2pos
newmodel164 = workspace.prefabs.mk12_2pos:clone()
newmodel164:PivotTo(CFrame.new(-59.32131222808608, 2.3712000000000004, 34.81025138002653) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel164.Parent = workspace.devices.mk12_2pos
newmodel165 = workspace.prefabs.mk12_2pos:clone()
newmodel165:PivotTo(CFrame.new(-64.45941749640777, 2.3420000000000005, 30.97362201221987) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel165.Parent = workspace.devices.mk12_2pos
newmodel166 = workspace.prefabs.mk12_2pos:clone()
newmodel166:PivotTo(CFrame.new(-70.7649234879842, 2.25069744, 23.455580213482325) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel166.Parent = workspace.devices.mk12_2pos
newmodel167 = workspace.prefabs.mk12_2pos:clone()
newmodel167:PivotTo(CFrame.new(-71.344914361894, 4.8444400000000005, 22.485855412731997) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel167.Parent = workspace.devices.mk12_2pos
newmodel168 = workspace.prefabs.mk12_2pos:clone()
newmodel168:PivotTo(CFrame.new(-71.344914361894, 3.5625600000000004, 22.485855412731997) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel168.Parent = workspace.devices.mk12_2pos
newmodel169 = workspace.prefabs.mk12_2pos:clone()
newmodel169:PivotTo(CFrame.new(-71.59855094008124, 3.5625600000000004, 22.01696402203648) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel169.Parent = workspace.devices.mk12_2pos
newmodel170 = workspace.prefabs.mk12_2pos:clone()
newmodel170:PivotTo(CFrame.new(-71.85217348226413, 3.5625600000000004, 21.54807333848751) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel170.Parent = workspace.devices.mk12_2pos
newmodel171 = workspace.prefabs.mk12_2pos:clone()
newmodel171:PivotTo(CFrame.new(-72.10581283277769, 3.5625600000000004, 21.079187431193574) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel171.Parent = workspace.devices.mk12_2pos
newmodel172 = workspace.prefabs.mk12_2pos:clone()
newmodel172:PivotTo(CFrame.new(-72.35943830036923, 3.5625600000000004, 20.610302313852024) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel172.Parent = workspace.devices.mk12_2pos
newmodel173 = workspace.prefabs.mk12_2pos:clone()
newmodel173:PivotTo(CFrame.new(-71.59855094008124, 4.8444400000000005, 22.01696402203648) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel173.Parent = workspace.devices.mk12_2pos
newmodel174 = workspace.prefabs.mk12_2pos:clone()
newmodel174:PivotTo(CFrame.new(-71.85217348226413, 4.8444400000000005, 21.54807333848751) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel174.Parent = workspace.devices.mk12_2pos
newmodel175 = workspace.prefabs.mk12_2pos:clone()
newmodel175:PivotTo(CFrame.new(-72.10581283277769, 4.8444400000000005, 21.079187431193574) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel175.Parent = workspace.devices.mk12_2pos
newmodel176 = workspace.prefabs.mk12_2pos:clone()
newmodel176:PivotTo(CFrame.new(-72.35943830036923, 4.8444400000000005, 20.610302313852024) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel176.Parent = workspace.devices.mk12_2pos
newmodel177 = workspace.prefabs.mk12_2pos:clone()
newmodel177:PivotTo(CFrame.new(-72.368985265156, 2.5172, 20.59266098306476) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel177.Parent = workspace.devices.mk12_2pos
