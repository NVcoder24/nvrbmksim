newmodel0 = workspace.prefabs.p2p1t:clone()
newmodel0:PivotTo(CFrame.new(-28.650366098184463, 2.680407983674239, 31.325574815726824) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.p2p1t
newmodel1 = workspace.prefabs.p2p1t:clone()
newmodel1:PivotTo(CFrame.new(-28.722882978928812, 2.6804102017913234, 31.356279452424474) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.devices.p2p1t
newmodel2 = workspace.prefabs.p2p1t:clone()
newmodel2:PivotTo(CFrame.new(-28.85740422670682, 2.6804079918198767, 31.413255078648625) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.p2p1t
newmodel3 = workspace.prefabs.p2p1t:clone()
newmodel3:PivotTo(CFrame.new(-28.929920736146908, 2.6804101877293225, 31.443959871224532) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.p2p1t
newmodel4 = workspace.prefabs.p2p1t:clone()
newmodel4:PivotTo(CFrame.new(-29.383349312136524, 2.7361424094863174, 32.327819899939655) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.p2p1t
newmodel5 = workspace.prefabs.p2p1t:clone()
newmodel5:PivotTo(CFrame.new(-29.455865057372822, 2.736144607873045, 32.358525029295805) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.p2p1t
newmodel6 = workspace.prefabs.p2p1t:clone()
newmodel6:PivotTo(CFrame.new(-29.472965770789344, 2.7160371971011656, 32.11621147001653) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.devices.p2p1t
newmodel7 = workspace.prefabs.p2p1t:clone()
newmodel7:PivotTo(CFrame.new(-29.54548223748142, 2.7160395778435107, 32.14691782733905) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.devices.p2p1t
newmodel8 = workspace.prefabs.p2p1t:clone()
newmodel8:PivotTo(CFrame.new(-29.562585747056378, 2.695932168017146, 31.90460435183814) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.devices.p2p1t
newmodel9 = workspace.prefabs.p2p1t:clone()
newmodel9:PivotTo(CFrame.new(-29.63510150547266, 2.695934355916258, 31.935309454724113) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.devices.p2p1t
newmodel10 = workspace.prefabs.p2p1t:clone()
newmodel10:PivotTo(CFrame.new(-29.63631966037168, 2.6793900189581645, 31.73049917701304) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.devices.p2p1t
newmodel11 = workspace.prefabs.p2p1t:clone()
newmodel11:PivotTo(CFrame.new(-29.708835150519057, 2.6793922042097584, 31.761204166131186) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.devices.p2p1t
newmodel12 = workspace.prefabs.p2p1t:clone()
newmodel12:PivotTo(CFrame.new(-28.92640855193418, 2.6348369626362156, 30.788973234152973) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.p2p1t
newmodel13 = workspace.prefabs.p2p1t_red:clone()
newmodel13:PivotTo(CFrame.new(-29.00991250926285, 2.634836804117478, 30.824336184371845) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.p2p1t
newmodel14 = workspace.prefabs.p2p1t:clone()
newmodel14:PivotTo(CFrame.new(-29.114626951456746, 2.6348369795571416, 30.86868540680417) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.p2p1t
newmodel15 = workspace.prefabs.p2p1t_red:clone()
newmodel15:PivotTo(CFrame.new(-29.198128923693805, 2.6348368010022765, 30.904047829576957) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.p2p1t
newmodel16 = workspace.prefabs.p2p1t:clone()
newmodel16:PivotTo(CFrame.new(-29.302841371461003, 2.6348369968865946, 30.948394950864262) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.p2p1t
newmodel17 = workspace.prefabs.p2p1t_red:clone()
newmodel17:PivotTo(CFrame.new(-29.386345444857955, 2.634836801546979, 30.98375763367722) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel17.Parent = workspace.devices.p2p1t
newmodel18 = workspace.prefabs.p2p1t:clone()
newmodel18:PivotTo(CFrame.new(-29.49105778589196, 2.634836993771393, 31.028106596069374) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel18.Parent = workspace.devices.p2p1t
newmodel19 = workspace.prefabs.p2p1t_red:clone()
newmodel19:PivotTo(CFrame.new(-29.574560621230496, 2.6348368035727754, 31.06347001253465) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel19.Parent = workspace.devices.p2p1t
newmodel20 = workspace.prefabs.p2p1t:clone()
newmodel20:PivotTo(CFrame.new(-29.20467135311836, 2.615983568996084, 30.655236483954702) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel20.Parent = workspace.devices.p2p1t
newmodel21 = workspace.prefabs.p2p1t_red:clone()
newmodel21:PivotTo(CFrame.new(-29.288174417251756, 2.6159835522113335, 30.690600007402782) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel21.Parent = workspace.devices.p2p1t
newmodel22 = workspace.prefabs.p2p1t:clone()
newmodel22:PivotTo(CFrame.new(-29.58110574168758, 2.6159835622378167, 30.814655089741567) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.p2p1t
newmodel23 = workspace.prefabs.p2p1t_red:clone()
newmodel23:PivotTo(CFrame.new(-29.664607081994518, 2.6159835581693853, 30.85002134249629) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel23.Parent = workspace.devices.p2p1t
newmodel24 = workspace.prefabs.p2p1t:clone()
newmodel24:PivotTo(CFrame.new(-29.016453925131877, 2.6159835369245155, 30.575520319994837) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.p2p1t
newmodel25 = workspace.prefabs.p2p1t_red:clone()
newmodel25:PivotTo(CFrame.new(-29.09995822036509, 2.6159835449083633, 30.610886252783274) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.p2p1t
newmodel26 = workspace.prefabs.p2p1t:clone()
newmodel26:PivotTo(CFrame.new(-29.392887121992132, 2.6159835671064635, 30.734945026052944) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.p2p1t
newmodel27 = workspace.prefabs.p2p1t_red:clone()
newmodel27:PivotTo(CFrame.new(-29.476391905621977, 2.615983556143589, 30.77030896363886) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel27.Parent = workspace.devices.p2p1t
newmodel28 = workspace.prefabs.p2p1t:clone()
newmodel28:PivotTo(CFrame.new(-29.106828714424193, 2.595708997680096, 30.36213337581077) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel28.Parent = workspace.devices.p2p1t
newmodel29 = workspace.prefabs.p2p1t_red:clone()
newmodel29:PivotTo(CFrame.new(-29.190331436323035, 2.5957088329309554, 30.397497060133766) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel29.Parent = workspace.devices.p2p1t
newmodel30 = workspace.prefabs.p2p1t:clone()
newmodel30:PivotTo(CFrame.new(-29.29504362019649, 2.5957090074342277, 30.441840924216525) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel30.Parent = workspace.devices.p2p1t
newmodel31 = workspace.prefabs.p2p1t_red:clone()
newmodel31:PivotTo(CFrame.new(-29.378547097941485, 2.595708829543402, 30.477209015341483) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel31.Parent = workspace.devices.p2p1t
newmodel32 = workspace.prefabs.p2p1t:clone()
newmodel32:PivotTo(CFrame.new(-29.671476560661663, 2.59570898360202, 30.60126551854775) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel32.Parent = workspace.devices.p2p1t
newmodel33 = workspace.prefabs.p2p1t_red:clone()
newmodel33:PivotTo(CFrame.new(-29.75497928190336, 2.59570882169573, 30.636629202757796) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel33.Parent = workspace.devices.p2p1t
newmodel34 = workspace.prefabs.p2p1t:clone()
newmodel34:PivotTo(CFrame.new(-29.483261379166954, 2.595709003638148, 30.521554710904276) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel34.Parent = workspace.devices.p2p1t
newmodel35 = workspace.prefabs.p2p1t_red:clone()
newmodel35:PivotTo(CFrame.new(-29.56676361897062, 2.595708830768983, 30.556917247324165) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel35.Parent = workspace.devices.p2p1t
newmodel36 = workspace.prefabs.p2p1t:clone()
newmodel36:PivotTo(CFrame.new(-29.385417312643348, 2.575434095520908, 30.228447519854342) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel36.Parent = workspace.devices.p2p1t
newmodel37 = workspace.prefabs.p2p1t_red:clone()
newmodel37:PivotTo(CFrame.new(-29.468921347268562, 2.5754340679094594, 30.263810196003007) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel37.Parent = workspace.devices.p2p1t
newmodel38 = workspace.prefabs.p2p1t:clone()
newmodel38:PivotTo(CFrame.new(-29.761851004606736, 2.5754340776467526, 30.387871803957054) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel38.Parent = workspace.devices.p2p1t
newmodel39 = workspace.prefabs.p2p1t_red:clone()
newmodel39:PivotTo(CFrame.new(-29.845354811695415, 2.575434103777108, 30.423235015708215) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel39.Parent = workspace.devices.p2p1t
newmodel40 = workspace.prefabs.p2p1t:clone()
newmodel40:PivotTo(CFrame.new(-29.197201057866522, 2.5754341056667287, 30.148739401292854) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel40.Parent = workspace.devices.p2p1t
newmodel41 = workspace.prefabs.p2p1t_red:clone()
newmodel41:PivotTo(CFrame.new(-29.280704608560118, 2.575434077782928, 30.18410250131713) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel41.Parent = workspace.devices.p2p1t
newmodel42 = workspace.prefabs.p2p1t:clone()
newmodel42:PivotTo(CFrame.new(-29.57363447673609, 2.5754341062114308, 30.308160426609664) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel42.Parent = workspace.devices.p2p1t
newmodel43 = workspace.prefabs.p2p1t_red:clone()
newmodel43:PivotTo(CFrame.new(-29.65713776104237, 2.575434067637108, 30.34352184109517) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel43.Parent = workspace.devices.p2p1t
newmodel44 = workspace.prefabs.p2p1t:clone()
newmodel44:PivotTo(CFrame.new(-29.952694102225728, 2.594626910315313, 30.72449272500343) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel44.Parent = workspace.devices.p2p1t
newmodel45 = workspace.prefabs.p2p1t:clone()
newmodel45:PivotTo(CFrame.new(-30.033356811474583, 2.59462691356669, 30.75865302430369) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel45.Parent = workspace.devices.p2p1t
newmodel46 = workspace.prefabs.p2p1t:clone()
newmodel46:PivotTo(CFrame.new(-30.144943404134665, 2.594626921686714, 30.80591169930649) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel46.Parent = workspace.devices.p2p1t
newmodel47 = workspace.prefabs.p2p1t:clone()
newmodel47:PivotTo(CFrame.new(-30.225606715876992, 2.5946268776990413, 30.840069735659462) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel47.Parent = workspace.devices.p2p1t
newmodel48 = workspace.prefabs.p2p1t:clone()
newmodel48:PivotTo(CFrame.new(-30.337194698498863, 2.5946269211420114, 30.887332774415707) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel48.Parent = workspace.devices.p2p1t
newmodel49 = workspace.prefabs.p2p1t:clone()
newmodel49:PivotTo(CFrame.new(-30.417856655592356, 2.594626921278187, 30.921493383831532) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel49.Parent = workspace.devices.p2p1t
newmodel50 = workspace.prefabs.p2p1t:clone()
newmodel50:PivotTo(CFrame.new(-30.001262441731093, 2.583428995229378, 30.60606627657112) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel50.Parent = workspace.devices.p2p1t
newmodel51 = workspace.prefabs.p2p1t:clone()
newmodel51:PivotTo(CFrame.new(-30.081922517045417, 2.5834289938844597, 30.640222944753656) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel51.Parent = workspace.devices.p2p1t
newmodel52 = workspace.prefabs.p2p1t:clone()
newmodel52:PivotTo(CFrame.new(-30.194855881744317, 2.5834289959102565, 30.68805293038786) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel52.Parent = workspace.devices.p2p1t
newmodel53 = workspace.prefabs.p2p1t:clone()
newmodel53:PivotTo(CFrame.new(-30.27551633373492, 2.583428993339757, 30.722212587804258) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel53.Parent = workspace.devices.p2p1t
newmodel54 = workspace.prefabs.p2p1t:clone()
newmodel54:PivotTo(CFrame.new(-30.3871071247719, 2.583428984947382, 30.76947178220967) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel54.Parent = workspace.devices.p2p1t
newmodel55 = workspace.prefabs.p2p1t:clone()
newmodel55:PivotTo(CFrame.new(-30.467767628099118, 2.583428992795055, 30.803633662913477) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel55.Parent = workspace.devices.p2p1t
newmodel56 = workspace.prefabs.p2p1t_red:clone()
newmodel56:PivotTo(CFrame.new(-30.59551881048239, 2.635600460884585, 31.505331171173054) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel56.Parent = workspace.devices.p2p1t
newmodel57 = workspace.prefabs.p2p1t_red:clone()
newmodel57:PivotTo(CFrame.new(-30.62955072187442, 2.627965597919938, 31.42497385436615) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel57.Parent = workspace.devices.p2p1t
newmodel58 = workspace.prefabs.p2p1t_red:clone()
newmodel58:PivotTo(CFrame.new(-30.663582628666415, 2.6203307548552432, 31.34461653676857) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel58.Parent = workspace.devices.p2p1t
newmodel59 = workspace.prefabs.p2p1t_red:clone()
newmodel59:PivotTo(CFrame.new(-30.697614535458406, 2.6126959117905484, 31.264259219170988) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel59.Parent = workspace.devices.p2p1t
newmodel60 = workspace.prefabs.p2p1t_red:clone()
newmodel60:PivotTo(CFrame.new(-30.7316464422504, 2.6050610687258535, 31.183901901573407) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel60.Parent = workspace.devices.p2p1t
newmodel61 = workspace.prefabs.p2p1t_red:clone()
newmodel61:PivotTo(CFrame.new(-30.54619764339499, 2.627965597919938, 31.38967322111401) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel61.Parent = workspace.devices.p2p1t
newmodel62 = workspace.prefabs.p2p1t_red:clone()
newmodel62:PivotTo(CFrame.new(-30.614261456978976, 2.6126959117905484, 31.228958585918846) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel62.Parent = workspace.devices.p2p1t
newmodel63 = workspace.prefabs.p2p1t_red:clone()
newmodel63:PivotTo(CFrame.new(-30.58022955018698, 2.6203307548552432, 31.30931590351643) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel63.Parent = workspace.devices.p2p1t
newmodel64 = workspace.prefabs.p2p1t_red:clone()
newmodel64:PivotTo(CFrame.new(-30.648293363770968, 2.6050610687258535, 31.14860126832127) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel64.Parent = workspace.devices.p2p1t
newmodel65 = workspace.prefabs.p2p1t_red:clone()
newmodel65:PivotTo(CFrame.new(-30.563595880799937, 2.6050610687258535, 31.112731270016678) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel65.Parent = workspace.devices.p2p1t
newmodel66 = workspace.prefabs.p2p1t_red:clone()
newmodel66:PivotTo(CFrame.new(-30.529563974007942, 2.6126959117905484, 31.19308858761426) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel66.Parent = workspace.devices.p2p1t
newmodel67 = workspace.prefabs.p2p1t_red:clone()
newmodel67:PivotTo(CFrame.new(-30.49553206721595, 2.6203307548552432, 31.273445905211837) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel67.Parent = workspace.devices.p2p1t
newmodel68 = workspace.prefabs.p2p1t_red:clone()
newmodel68:PivotTo(CFrame.new(-30.765678349042396, 2.5974262256611587, 31.103544583975825) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel68.Parent = workspace.devices.p2p1t
newmodel69 = workspace.prefabs.p2p1t_red:clone()
newmodel69:PivotTo(CFrame.new(-30.793836950748396, 2.627965597919938, 31.494550263776006) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel69.Parent = workspace.devices.p2p1t
newmodel70 = workspace.prefabs.p2p1t_red:clone()
newmodel70:PivotTo(CFrame.new(-30.861900764332383, 2.6126959117905484, 31.33383562858085) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel70.Parent = workspace.devices.p2p1t
newmodel71 = workspace.prefabs.p2p1t_red:clone()
newmodel71:PivotTo(CFrame.new(-30.929964577916373, 2.5974262256611587, 31.173120993385684) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel71.Parent = workspace.devices.p2p1t
newmodel72 = workspace.prefabs.p2p1t_red:clone()
newmodel72:PivotTo(CFrame.new(-30.7598050439564, 2.635600440984633, 31.57490758137359) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel72.Parent = workspace.devices.p2p1t
newmodel73 = workspace.prefabs.p2p1t_red:clone()
newmodel73:PivotTo(CFrame.new(-30.82786885754039, 2.6203307548552432, 31.414192946178428) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel73.Parent = workspace.devices.p2p1t
newmodel74 = workspace.prefabs.p2p1t_red:clone()
newmodel74:PivotTo(CFrame.new(-30.895932671124378, 2.6050610687258535, 31.253478310983265) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel74.Parent = workspace.devices.p2p1t
newmodel75 = workspace.prefabs.p2p1t_red:clone()
newmodel75:PivotTo(CFrame.new(-30.979016868705486, 2.6050610687258535, 31.288665071224912) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel75.Parent = workspace.devices.p2p1t
newmodel76 = workspace.prefabs.p2p1t_red:clone()
newmodel76:PivotTo(CFrame.new(-31.062369947184916, 2.6050610687258535, 31.323965704477047) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel76.Parent = workspace.devices.p2p1t
newmodel77 = workspace.prefabs.p2p1t_red:clone()
newmodel77:PivotTo(CFrame.new(-31.028338040392924, 2.6126959117905484, 31.404323022074628) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel77.Parent = workspace.devices.p2p1t
newmodel78 = workspace.prefabs.p2p1t_red:clone()
newmodel78:PivotTo(CFrame.new(-30.994306133600926, 2.6203307548552432, 31.48468033967221) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel78.Parent = workspace.devices.p2p1t
newmodel79 = workspace.prefabs.p2p1t_red:clone()
newmodel79:PivotTo(CFrame.new(-30.876921148329505, 2.627965597919938, 31.529737024017656) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel79.Parent = workspace.devices.p2p1t
newmodel80 = workspace.prefabs.p2p1t_red:clone()
newmodel80:PivotTo(CFrame.new(-30.94498496191349, 2.6126959117905484, 31.369022388822493) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel80.Parent = workspace.devices.p2p1t
newmodel81 = workspace.prefabs.p2p1t_red:clone()
newmodel81:PivotTo(CFrame.new(-30.9109530551215, 2.6203307548552432, 31.449379706420075) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel81.Parent = workspace.devices.p2p1t
newmodel82 = workspace.prefabs.p2p1t:clone()
newmodel82:PivotTo(CFrame.new(-49.31884841697551, 2.688554080726865, 33.25688220294809) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel82.Parent = workspace.devices.p2p1t
newmodel83 = workspace.prefabs.p2p1t:clone()
newmodel83:PivotTo(CFrame.new(-48.09566294461861, 2.6302747786663607, 32.878222068835214) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel83.Parent = workspace.devices.p2p1t
newmodel84 = workspace.prefabs.p2p1t_red:clone()
newmodel84:PivotTo(CFrame.new(-47.902944956669195, 2.6155140820746174, 32.752805176205655) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel84.Parent = workspace.devices.p2p1t
newmodel85 = workspace.prefabs.p2p1t_red:clone()
newmodel85:PivotTo(CFrame.new(-48.15777471896558, 2.6155140820746174, 32.688574091457134) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel85.Parent = workspace.devices.p2p1t
newmodel86 = workspace.prefabs.p2p1t_red:clone()
newmodel86:PivotTo(CFrame.new(-48.07283146486678, 2.6155140820746174, 32.70998445303997) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel86.Parent = workspace.devices.p2p1t
newmodel87 = workspace.prefabs.p2p1t_red:clone()
newmodel87:PivotTo(CFrame.new(-47.818001702570406, 2.6155140820746174, 32.77421553778849) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel87.Parent = workspace.devices.p2p1t
newmodel88 = workspace.prefabs.p2p1t:clone()
newmodel88:PivotTo(CFrame.new(-47.99373103970006, 2.6302747786663607, 32.90391450273462) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel88.Parent = workspace.devices.p2p1t
newmodel89 = workspace.prefabs.p2p1t:clone()
newmodel89:PivotTo(CFrame.new(-49.40662311287759, 2.688554080726865, 33.23475816264582) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel89.Parent = workspace.devices.p2p1t
newmodel90 = workspace.prefabs.p2p1t:clone()
newmodel90:PivotTo(CFrame.new(-32.40144312070376, 2.7358901644433944, 33.43193379676411) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel90.Parent = workspace.devices.p2p1t
newmodel91 = workspace.prefabs.p2p1t_red:clone()
newmodel91:PivotTo(CFrame.new(-32.51274316794536, 2.735890177002462, 33.46735325611027) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel91.Parent = workspace.devices.p2p1t
newmodel92 = workspace.prefabs.p2p1t:clone()
newmodel92:PivotTo(CFrame.new(-32.65372526148022, 2.7358901683097048, 33.51221858789126) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel92.Parent = workspace.devices.p2p1t
newmodel93 = workspace.prefabs.p2p1t_red:clone()
newmodel93:PivotTo(CFrame.new(-32.765025358761484, 2.73589000084017, 33.547637968132456) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel93.Parent = workspace.devices.p2p1t
newmodel94 = workspace.prefabs.p2p1t:clone()
newmodel94:PivotTo(CFrame.new(-32.90600408245748, 2.7358901357223977, 33.5925042722318) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel94.Parent = workspace.devices.p2p1t
newmodel95 = workspace.prefabs.p2p1t_red:clone()
newmodel95:PivotTo(CFrame.new(-33.01730416205681, 2.7358900975481824, 33.627923649433725) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel95.Parent = workspace.devices.p2p1t
newmodel96 = workspace.prefabs.p2p1t:clone()
newmodel96:PivotTo(CFrame.new(-33.15828449274242, 2.7358900899133394, 33.672788755461156) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel96.Parent = workspace.devices.p2p1t
newmodel97 = workspace.prefabs.p2p1t_red:clone()
newmodel97:PivotTo(CFrame.new(-33.26958473188512, 2.73589016626177, 33.70820955712175) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel97.Parent = workspace.devices.p2p1t
newmodel98 = workspace.prefabs.p2p1t_red:clone()
newmodel98:PivotTo(CFrame.new(-33.082486790284506, 2.717057494835059, 33.422772281335384) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel98.Parent = workspace.devices.p2p1t
newmodel99 = workspace.prefabs.p2p1t:clone()
newmodel99:PivotTo(CFrame.new(-33.2235594734626, 2.717057494835059, 33.4676668689483) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel99.Parent = workspace.devices.p2p1t
newmodel100 = workspace.prefabs.p2p1t:clone()
newmodel100:PivotTo(CFrame.new(-32.83039240969407, 2.717057494835059, 33.34254645021644) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel100.Parent = workspace.devices.p2p1t
newmodel101 = workspace.prefabs.p2p1t:clone()
newmodel101:PivotTo(CFrame.new(-32.97118684300396, 2.717057494835059, 33.387352488346885) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel101.Parent = workspace.devices.p2p1t
newmodel102 = workspace.prefabs.p2p1t_red:clone()
newmodel102:PivotTo(CFrame.new(-33.33485942074314, 2.717057494835059, 33.5030866619368) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel102.Parent = workspace.devices.p2p1t
newmodel103 = workspace.prefabs.p2p1t:clone()
newmodel103:PivotTo(CFrame.new(-31.46639410768107, 2.680537420787778, 32.47041660373019) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel103.Parent = workspace.devices.p2p1t
newmodel104 = workspace.prefabs.p2p1t_red:clone()
newmodel104:PivotTo(CFrame.new(-31.57813583943695, 2.680410203482362, 32.50445006231484) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel104.Parent = workspace.devices.p2p1t
newmodel105 = workspace.prefabs.p2p1t:clone()
newmodel105:PivotTo(CFrame.new(-31.735370293007193, 2.6805374339755943, 32.55601546431817) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel105.Parent = workspace.devices.p2p1t
newmodel106 = workspace.prefabs.p2p1t_red:clone()
newmodel106:PivotTo(CFrame.new(-31.84710877326346, 2.6804101964396487, 32.5900475829953) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel106.Parent = workspace.devices.p2p1t
newmodel107 = workspace.prefabs.p2p1t:clone()
newmodel107:PivotTo(CFrame.new(-32.00434228121111, 2.6805374421967874, 32.641612074863374) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel107.Parent = workspace.devices.p2p1t
newmodel108 = workspace.prefabs.p2p1t_red:clone()
newmodel108:PivotTo(CFrame.new(-32.11608260991308, 2.680410219280289, 32.67564813437363) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel108.Parent = workspace.devices.p2p1t
newmodel109 = workspace.prefabs.p2p1t:clone()
newmodel109:PivotTo(CFrame.new(-32.27331652210352, 2.680537431141718, 32.72721031617483) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel109.Parent = workspace.devices.p2p1t
newmodel110 = workspace.prefabs.p2p1t_red:clone()
newmodel110:PivotTo(CFrame.new(-32.385059111453664, 2.680410222675047, 32.761244962117445) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel110.Parent = workspace.devices.p2p1t
newmodel111 = workspace.prefabs.p2p1t:clone()
newmodel111:PivotTo(CFrame.new(-33.12012602991658, 2.6805374499972863, 32.9966966748146) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel111.Parent = workspace.devices.p2p1t
newmodel112 = workspace.prefabs.p2p1t_red:clone()
newmodel112:PivotTo(CFrame.new(-33.231866168397005, 2.6804102029781496, 33.03073236855268) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel112.Parent = workspace.devices.p2p1t
newmodel113 = workspace.prefabs.p2p1t:clone()
newmodel113:PivotTo(CFrame.new(-33.38910104090444, 2.680537468011524, 33.08229638079776) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel113.Parent = workspace.devices.p2p1t
newmodel114 = workspace.prefabs.p2p1t_red:clone()
newmodel114:PivotTo(CFrame.new(-33.50084343984887, 2.6804102367890126, 33.116330660936526) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel114.Parent = workspace.devices.p2p1t
newmodel115 = workspace.prefabs.p2p1t:clone()
newmodel115:PivotTo(CFrame.new(-32.582178363375085, 2.680537438857402, 32.82549953670443) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel115.Parent = workspace.devices.p2p1t
newmodel116 = workspace.prefabs.p2p1t_red:clone()
newmodel116:PivotTo(CFrame.new(-32.69391638136513, 2.680410215800694, 32.85953516561138) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel116.Parent = workspace.devices.p2p1t
newmodel117 = workspace.prefabs.p2p1t:clone()
newmodel117:PivotTo(CFrame.new(-32.851151151311, 2.6805374353224196, 32.911098534798256) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel117.Parent = workspace.devices.p2p1t
newmodel118 = workspace.prefabs.p2p1t_red:clone()
newmodel118:PivotTo(CFrame.new(-32.96289707929119, 2.6804102295493997, 32.94513424327134) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel118.Parent = workspace.devices.p2p1t
newmodel119 = workspace.prefabs.p2p1t:clone()
newmodel119:PivotTo(CFrame.new(-32.77668373448185, 2.624421368932582, 32.214295910354025) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel119.Parent = workspace.devices.p2p1t
newmodel120 = workspace.prefabs.p2p1t_red:clone()
newmodel120:PivotTo(CFrame.new(-32.88842326988082, 2.624294286646915, 32.24833050120356) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel120.Parent = workspace.devices.p2p1t
newmodel121 = workspace.prefabs.p2p1t:clone()
newmodel121:PivotTo(CFrame.new(-33.04575127563495, 2.6244213445494773, 32.29992353826615) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel121.Parent = workspace.devices.p2p1t
newmodel122 = workspace.prefabs.p2p1t_red:clone()
newmodel122:PivotTo(CFrame.new(-33.157498416470546, 2.6242941201165384, 32.333956280045385) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel122.Parent = workspace.devices.p2p1t
newmodel123 = workspace.prefabs.p2p1t:clone()
newmodel123:PivotTo(CFrame.new(-31.484012209392354, 2.643867876606011, 31.949592386219653) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel123.Parent = workspace.devices.p2p1t
newmodel124 = workspace.prefabs.p2p1t_red:clone()
newmodel124:PivotTo(CFrame.new(-31.564706205060403, 2.6438678968652924, 31.97527070091168) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel124.Parent = workspace.devices.p2p1t
newmodel125 = workspace.prefabs.p2p1t:clone()
newmodel125:PivotTo(CFrame.new(-31.652074887605146, 2.6438678806737896, 32.00307406336334) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel125.Parent = workspace.devices.p2p1t
newmodel126 = workspace.prefabs.p2p1t_red:clone()
newmodel126:PivotTo(CFrame.new(-31.73276893383453, 2.643867882984966, 32.02875422231184) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel126.Parent = workspace.devices.p2p1t
newmodel127 = workspace.prefabs.p2p1t:clone()
newmodel127:PivotTo(CFrame.new(-31.820137844067805, 2.6438678847415678, 32.05655582905651) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel127.Parent = workspace.devices.p2p1t
newmodel128 = workspace.prefabs.p2p1t_red:clone()
newmodel128:PivotTo(CFrame.new(-31.900831612047323, 2.643867887052744, 32.08223589945552) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel128.Parent = workspace.devices.p2p1t
newmodel129 = workspace.prefabs.p2p1t:clone()
newmodel129:PivotTo(CFrame.new(-31.98820070370503, 2.6438678853094104, 32.11004091616235) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel129.Parent = workspace.devices.p2p1t
newmodel130 = workspace.prefabs.p2p1t_red:clone()
newmodel130:PivotTo(CFrame.new(-32.06889415617903, 2.6438678922296712, 32.135723019527376) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel130.Parent = workspace.devices.p2p1t
newmodel131 = workspace.prefabs.p2p1t:clone()
newmodel131:PivotTo(CFrame.new(-32.15626401247964, 2.6438678754703258, 32.16352553648376) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel131.Parent = workspace.devices.p2p1t
newmodel132 = workspace.prefabs.p2p1t_red:clone()
newmodel132:PivotTo(CFrame.new(-32.236955976141466, 2.6438678922562078, 32.18920350920032) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel132.Parent = workspace.devices.p2p1t
newmodel133 = workspace.prefabs.p2p1t:clone()
newmodel133:PivotTo(CFrame.new(-31.521060244117386, 2.63317904140178, 31.833167185478402) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel133.Parent = workspace.devices.p2p1t
newmodel134 = workspace.prefabs.p2p1t_red:clone()
newmodel134:PivotTo(CFrame.new(-31.601753696195843, 2.633179051214328, 31.858849288775442) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel134.Parent = workspace.devices.p2p1t
newmodel135 = workspace.prefabs.p2p1t:clone()
newmodel135:PivotTo(CFrame.new(-31.689125585293755, 2.633179032143806, 31.88665214784326) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel135.Parent = workspace.devices.p2p1t
newmodel136 = workspace.prefabs.p2p1t_red:clone()
newmodel136:PivotTo(CFrame.new(-31.769816058507576, 2.633179062783478, 31.91233299881716) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel136.Parent = workspace.devices.p2p1t
newmodel137 = workspace.prefabs.p2p1t:clone()
newmodel137:PivotTo(CFrame.new(-31.8571863243167, 2.6331790575800142, 31.940137170096694) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel137.Parent = workspace.devices.p2p1t
newmodel138 = workspace.prefabs.p2p1t_red:clone()
newmodel138:PivotTo(CFrame.new(-31.937881399683953, 2.6331790535255046, 31.96581796118202) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel138.Parent = workspace.devices.p2p1t
newmodel139 = workspace.prefabs.p2p1t:clone()
newmodel139:PivotTo(CFrame.new(-31.909232558843154, 2.618163968598467, 31.776595639622187) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel139.Parent = workspace.devices.p2p1t
newmodel140 = workspace.prefabs.p2p1t_red:clone()
newmodel140:PivotTo(CFrame.new(-31.989924970851295, 2.6181639807619965, 31.802273145418347) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel140.Parent = workspace.devices.p2p1t
newmodel141 = workspace.prefabs.p2p1t:clone()
newmodel141:PivotTo(CFrame.new(-31.573104357634026, 2.6181639801808854, 31.6696255900835) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel141.Parent = workspace.devices.p2p1t
newmodel142 = workspace.prefabs.p2p1t_red:clone()
newmodel142:PivotTo(CFrame.new(-31.653801016661188, 2.6181639842221265, 31.69530719006469) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel142.Parent = workspace.devices.p2p1t
newmodel143 = workspace.prefabs.p2p1t:clone()
newmodel143:PivotTo(CFrame.new(-32.025249633091306, 2.6331790477409296, 31.993621790418104) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel143.Parent = workspace.devices.p2p1t
newmodel144 = workspace.prefabs.p2p1t_red:clone()
newmodel144:PivotTo(CFrame.new(-32.105944356542146, 2.6331790547009954, 32.019299726943174) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel144.Parent = workspace.devices.p2p1t
newmodel145 = workspace.prefabs.p2p1t:clone()
newmodel145:PivotTo(CFrame.new(-32.193311993820885, 2.6331790708792298, 32.047105500187875) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel145.Parent = workspace.devices.p2p1t
newmodel146 = workspace.prefabs.p2p1t_red:clone()
newmodel146:PivotTo(CFrame.new(-32.27400518377762, 2.633179054687727, 32.072784472005566) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel146.Parent = workspace.devices.p2p1t
newmodel147 = workspace.prefabs.p2p1t:clone()
newmodel147:PivotTo(CFrame.new(-32.3613748554358, 2.633179056985635, 32.10059058763365) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel147.Parent = workspace.devices.p2p1t
newmodel148 = workspace.prefabs.p2p1t_red:clone()
newmodel148:PivotTo(CFrame.new(-32.442069300241236, 2.633179066837988, 32.12626843554125) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel148.Parent = workspace.devices.p2p1t
newmodel149 = workspace.prefabs.p2p1t:clone()
newmodel149:PivotTo(CFrame.new(-31.77910044576255, 2.607220677928679, 31.603918504878067) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel149.Parent = workspace.devices.p2p1t
newmodel150 = workspace.prefabs.p2p1t_red:clone()
newmodel150:PivotTo(CFrame.new(-31.85979516881785, 2.607220687781032, 31.629596441335153) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel150.Parent = workspace.devices.p2p1t
newmodel151 = workspace.prefabs.p2p1t:clone()
newmodel151:PivotTo(CFrame.new(-32.115226115266736, 2.6072206912278943, 31.710886834969248) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel151.Parent = workspace.devices.p2p1t
newmodel152 = workspace.prefabs.p2p1t_red:clone()
newmodel152:PivotTo(CFrame.new(-32.19591988364179, 2.607220690646783, 31.73656690543625) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel152.Parent = workspace.devices.p2p1t
newmodel153 = workspace.prefabs.p2p1t:clone()
newmodel153:PivotTo(CFrame.new(-31.611035829995743, 2.6072206912411624, 31.55043316393833) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel153.Parent = workspace.devices.p2p1t
newmodel154 = workspace.prefabs.p2p1t_red:clone()
newmodel154:PivotTo(CFrame.new(-31.691730774104354, 2.6072206756307708, 31.57611238924998) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel154.Parent = workspace.devices.p2p1t
newmodel155 = workspace.prefabs.p2p1t:clone()
newmodel155:PivotTo(CFrame.new(-31.94716280649213, 2.6072207010669795, 31.657402214647835) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel155.Parent = workspace.devices.p2p1t
newmodel156 = workspace.prefabs.p2p1t_red:clone()
newmodel156:PivotTo(CFrame.new(-32.02785717060026, 2.607220681415346, 31.683080341038234) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel156.Parent = workspace.devices.p2p1t
newmodel157 = workspace.prefabs.p2p1t:clone()
newmodel157:PivotTo(CFrame.new(-31.646321631375272, 2.597040773795426, 31.43955821489265) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel157.Parent = workspace.devices.p2p1t
newmodel158 = workspace.prefabs.p2p1t_red:clone()
newmodel158:PivotTo(CFrame.new(-31.727016346213205, 2.59704075180608, 31.46523919563935) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel158.Parent = workspace.devices.p2p1t
newmodel159 = workspace.prefabs.p2p1t:clone()
newmodel159:PivotTo(CFrame.new(-31.814386024902156, 2.5970407946225507, 31.493042266773855) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel159.Parent = workspace.devices.p2p1t
newmodel160 = workspace.prefabs.p2p1t_red:clone()
newmodel160:PivotTo(CFrame.new(-31.89507753279138, 2.5970407784045104, 31.518723750836408) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel160.Parent = workspace.devices.p2p1t
newmodel161 = workspace.prefabs.p2p1t:clone()
newmodel161:PivotTo(CFrame.new(-32.15051133545917, 2.597040778417779, 31.600010786798354) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel161.Parent = workspace.devices.p2p1t
newmodel162 = workspace.prefabs.p2p1t_red:clone()
newmodel162:PivotTo(CFrame.new(-32.23120574261342, 2.5970407957715045, 31.625690756153464) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel162.Parent = workspace.devices.p2p1t
newmodel163 = workspace.prefabs.p2p1t:clone()
newmodel163:PivotTo(CFrame.new(-31.98244789542593, 2.597040776700982, 31.54652460070327) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel163.Parent = workspace.devices.p2p1t
newmodel164 = workspace.prefabs.p2p1t_red:clone()
newmodel164:PivotTo(CFrame.new(-32.06314310165628, 2.5970407870946417, 31.57220695749428) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel164.Parent = workspace.devices.p2p1t
newmodel165 = workspace.prefabs.p2p1t:clone()
newmodel165:PivotTo(CFrame.new(-31.681607855786673, 2.5868610368337412, 31.328682794575393) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel165.Parent = workspace.devices.p2p1t
newmodel166 = workspace.prefabs.p2p1t_red:clone()
newmodel166:PivotTo(CFrame.new(-31.76230127343193, 2.5868610385903428, 31.354360010686094) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel166.Parent = workspace.devices.p2p1t
newmodel167 = workspace.prefabs.p2p1t:clone()
newmodel167:PivotTo(CFrame.new(-31.849670584560805, 2.5868610229534146, 31.382166315975546) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel167.Parent = workspace.devices.p2p1t
newmodel168 = workspace.prefabs.p2p1t_red:clone()
newmodel168:PivotTo(CFrame.new(-31.930365527087265, 2.5868610189121726, 31.407845541015256) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel168.Parent = workspace.devices.p2p1t
newmodel169 = workspace.prefabs.p2p1t:clone()
newmodel169:PivotTo(CFrame.new(-32.18579612280635, 2.586861024696748, 31.48913308029306) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel169.Parent = workspace.devices.p2p1t
newmodel170 = workspace.prefabs.p2p1t_red:clone()
newmodel170:PivotTo(CFrame.new(-32.26649043313516, 2.5868610385505377, 31.514816371060846) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel170.Parent = workspace.devices.p2p1t
newmodel171 = workspace.prefabs.p2p1t:clone()
newmodel171:PivotTo(CFrame.new(-32.01773412102395, 2.5868610310624343, 31.435649180589973) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel171.Parent = workspace.devices.p2p1t
newmodel172 = workspace.prefabs.p2p1t_red:clone()
newmodel172:PivotTo(CFrame.new(-32.098427889399, 2.586861030481323, 31.461329251056974) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel172.Parent = workspace.devices.p2p1t
newmodel173 = workspace.prefabs.p2p1t:clone()
newmodel173:PivotTo(CFrame.new(-32.05301728547787, 2.576681288316174, 31.32477278636438) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel173.Parent = workspace.devices.p2p1t
newmodel174 = workspace.prefabs.p2p1t_red:clone()
newmodel174:PivotTo(CFrame.new(-32.13371173028331, 2.576681298168527, 31.35045063427198) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel174.Parent = workspace.devices.p2p1t
newmodel175 = workspace.prefabs.p2p1t:clone()
newmodel175:PivotTo(CFrame.new(-32.088303877142735, 2.5665015201204366, 31.21389717754154) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel175.Parent = workspace.devices.p2p1t
newmodel176 = workspace.prefabs.p2p1t_red:clone()
newmodel176:PivotTo(CFrame.new(-32.168996699054915, 2.5665015409475607, 31.239576337728842) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel176.Parent = workspace.devices.p2p1t
newmodel177 = workspace.prefabs.p2p1t:clone()
newmodel177:PivotTo(CFrame.new(-31.75217698213473, 2.566501534014032, 31.106927848485206) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel177.Parent = workspace.devices.p2p1t
newmodel178 = workspace.prefabs.p2p1t_red:clone()
newmodel178:PivotTo(CFrame.new(-31.832871161204903, 2.5665015363119394, 31.132609573479318) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel178.Parent = workspace.devices.p2p1t
newmodel179 = workspace.prefabs.p2p1t:clone()
newmodel179:PivotTo(CFrame.new(-31.71689120527856, 2.576681272137939, 31.21780280174609) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel179.Parent = workspace.devices.p2p1t
newmodel180 = workspace.prefabs.p2p1t_red:clone()
newmodel180:PivotTo(CFrame.new(-31.79758668936324, 2.5766812854238865, 31.24348524701859) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel180.Parent = workspace.devices.p2p1t
newmodel181 = workspace.prefabs.p2p1t:clone()
newmodel181:PivotTo(CFrame.new(-31.88495528329992, 2.5766812975741478, 31.27128888659331) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel181.Parent = workspace.devices.p2p1t
newmodel182 = workspace.prefabs.p2p1t_red:clone()
newmodel182:PivotTo(CFrame.new(-31.965648193820158, 2.5766812900595077, 31.296967769657556) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel182.Parent = workspace.devices.p2p1t
newmodel183 = workspace.prefabs.p2p1t:clone()
newmodel183:PivotTo(CFrame.new(-32.22108059385694, 2.5766812813693765, 31.378257406617806) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel183.Parent = workspace.devices.p2p1t
newmodel184 = workspace.prefabs.p2p1t_red:clone()
newmodel184:PivotTo(CFrame.new(-32.30177553677894, 2.576681274435847, 31.403936631725507) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel184.Parent = workspace.devices.p2p1t
newmodel185 = workspace.prefabs.p2p1t:clone()
newmodel185:PivotTo(CFrame.new(-32.39478682839977, 2.6046754537696, 31.76932284902869) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel185.Parent = workspace.devices.p2p1t
newmodel186 = workspace.prefabs.p2p1t_red:clone()
newmodel186:PivotTo(CFrame.new(-32.474088026850715, 2.6046756399984217, 31.794563412613847) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel186.Parent = workspace.devices.p2p1t
newmodel187 = workspace.prefabs.p2p1t:clone()
newmodel187:PivotTo(CFrame.new(-32.45565252534358, 2.5871153274521745, 31.578060118974577) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel187.Parent = workspace.devices.p2p1t
newmodel188 = workspace.prefabs.p2p1t_red:clone()
newmodel188:PivotTo(CFrame.new(-32.534953496105985, 2.587115495732891, 31.603302438266724) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel188.Parent = workspace.devices.p2p1t
newmodel189 = workspace.prefabs.p2p1t:clone()
newmodel189:PivotTo(CFrame.new(-32.515636324419745, 2.569809624164226, 31.3895705892973) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel189.Parent = workspace.devices.p2p1t
newmodel190 = workspace.prefabs.p2p1t_red:clone()
newmodel190:PivotTo(CFrame.new(-32.594939422827196, 2.5698098080951395, 31.41480992894828) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel190.Parent = workspace.devices.p2p1t
newmodel191 = workspace.prefabs.p2p1t:clone()
newmodel191:PivotTo(CFrame.new(-32.63492062435914, 2.591187464676349, 31.68395757125733) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel191.Parent = workspace.devices.p2p1t
newmodel192 = workspace.prefabs.p2p1t_red:clone()
newmodel192:PivotTo(CFrame.new(-32.7100491778767, 2.591187463527395, 31.707865363832212) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel192.Parent = workspace.devices.p2p1t
newmodel193 = workspace.prefabs.p2p1t:clone()
newmodel193:PivotTo(CFrame.new(-32.671970955980896, 2.580498638703555, 31.5675358444468) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel193.Parent = workspace.devices.p2p1t
newmodel194 = workspace.prefabs.p2p1t_red:clone()
newmodel194:PivotTo(CFrame.new(-32.747099787748326, 2.5804986375546006, 31.591443725571168) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel194.Parent = workspace.devices.p2p1t
newmodel195 = workspace.prefabs.p2p1t:clone()
newmodel195:PivotTo(CFrame.new(-32.709021601867875, 2.5698098092175568, 31.45111909364404) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel195.Parent = workspace.devices.p2p1t
newmodel196 = workspace.prefabs.p2p1t_red:clone()
newmodel196:PivotTo(CFrame.new(-32.784148048921594, 2.5698098213943545, 31.475023778096713) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel196.Parent = workspace.devices.p2p1t
newmodel197 = workspace.prefabs.p2p1t_red:clone()
newmodel197:PivotTo(CFrame.new(-50.347837025497945, 2.7353910801338177, 33.43559442378403) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel197.Parent = workspace.devices.p2p1t
newmodel198 = workspace.prefabs.p2p1t_red:clone()
newmodel198:PivotTo(CFrame.new(-50.43043943387143, 2.7353910801338177, 33.406429339678205) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel198.Parent = workspace.devices.p2p1t
newmodel199 = workspace.prefabs.p2p1t_red:clone()
newmodel199:PivotTo(CFrame.new(-50.51304184224491, 2.7353910801338177, 33.377264255572385) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel199.Parent = workspace.devices.p2p1t
newmodel200 = workspace.prefabs.p2p1t_red:clone()
newmodel200:PivotTo(CFrame.new(-50.34715100769198, 2.7135045300150256, 33.17053684003388) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel200.Parent = workspace.devices.p2p1t
newmodel201 = workspace.prefabs.p2p1t_red:clone()
newmodel201:PivotTo(CFrame.new(-50.26454859931849, 2.7135045300150256, 33.1997019241397) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel201.Parent = workspace.devices.p2p1t
newmodel202 = workspace.prefabs.p2p1t_red:clone()
newmodel202:PivotTo(CFrame.new(-50.42975341606546, 2.7135045300150256, 33.141371755928056) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel202.Parent = workspace.devices.p2p1t
newmodel203 = workspace.prefabs.p2p1t_red:clone()
newmodel203:PivotTo(CFrame.new(-50.346464989886016, 2.691617979896234, 32.90547925628373) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel203.Parent = workspace.devices.p2p1t
newmodel204 = workspace.prefabs.p2p1t_red:clone()
newmodel204:PivotTo(CFrame.new(-50.4290673982595, 2.691617979896234, 32.87631417217791) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel204.Parent = workspace.devices.p2p1t
newmodel205 = workspace.prefabs.p2p1t_red:clone()
newmodel205:PivotTo(CFrame.new(-50.51166980663299, 2.691617979896234, 32.847149088072086) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel205.Parent = workspace.devices.p2p1t
newmodel206 = workspace.prefabs.p2p1t_red:clone()
newmodel206:PivotTo(CFrame.new(-50.473617021564785, 2.703324739262099, 33.002489230127196) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel206.Parent = workspace.devices.p2p1t
newmodel207 = workspace.prefabs.p2p1t_red:clone()
newmodel207:PivotTo(CFrame.new(-50.30607169913403, 2.659297144255692, 32.52796129479617) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel207.Parent = workspace.devices.p2p1t
newmodel208 = workspace.prefabs.p2p1t_red:clone()
newmodel208:PivotTo(CFrame.new(-50.22346929076054, 2.659297144255692, 32.557126378902) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel208.Parent = workspace.devices.p2p1t
newmodel209 = workspace.prefabs.p2p1t_red:clone()
newmodel209:PivotTo(CFrame.new(-50.38867410750751, 2.659297144255692, 32.498796210690344) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel209.Parent = workspace.devices.p2p1t
newmodel210 = workspace.prefabs.p2p1t_red:clone()
newmodel210:PivotTo(CFrame.new(-50.43128679066909, 2.670494914083911, 32.619485396554886) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel210.Parent = workspace.devices.p2p1t
newmodel211 = workspace.prefabs.p2p1t_red:clone()
newmodel211:PivotTo(CFrame.new(-50.34868438229561, 2.670494914083911, 32.648650480660706) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel211.Parent = workspace.devices.p2p1t
newmodel212 = workspace.prefabs.p2p1t_red:clone()
newmodel212:PivotTo(CFrame.new(-50.26608197392213, 2.670494914083911, 32.67781556476653) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel212.Parent = workspace.devices.p2p1t
newmodel213 = workspace.prefabs.p2p1t_red:clone()
newmodel213:PivotTo(CFrame.new(-50.14086688238706, 2.659297144255692, 32.586291463007825) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel213.Parent = workspace.devices.p2p1t
newmodel214 = workspace.prefabs.p2p1t_red:clone()
newmodel214:PivotTo(CFrame.new(-50.05826447401357, 2.659297144255692, 32.615456547113645) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel214.Parent = workspace.devices.p2p1t
newmodel215 = workspace.prefabs.p2p1t_red:clone()
newmodel215:PivotTo(CFrame.new(-50.23246797367312, 2.639955541825132, 32.31949815557561) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel215.Parent = workspace.devices.p2p1t
newmodel216 = workspace.prefabs.p2p1t_red:clone()
newmodel216:PivotTo(CFrame.new(-50.82237109597078, 2.7124865509397327, 32.990407608050596) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel216.Parent = workspace.devices.p2p1t
newmodel217 = workspace.prefabs.p2p1t_red:clone()
newmodel217:PivotTo(CFrame.new(-51.213281863729016, 2.7305556795261774, 33.07141223904657) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel217.Parent = workspace.devices.p2p1t
newmodel218 = workspace.prefabs.p2p1t_red:clone()
newmodel218:PivotTo(CFrame.new(-50.617207437340824, 2.659297144255692, 32.418106144664236) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel218.Parent = workspace.devices.p2p1t
newmodel219 = workspace.prefabs.p2p1t_red:clone()
newmodel219:PivotTo(CFrame.new(-50.69980984571431, 2.659297144255692, 32.38894106055841) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel219.Parent = workspace.devices.p2p1t
newmodel220 = workspace.prefabs.p2p1t_red:clone()
newmodel220:PivotTo(CFrame.new(-50.7824122540878, 2.659297144255692, 32.35977597645258) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel220.Parent = workspace.devices.p2p1t
newmodel221 = workspace.prefabs.p2p1t_red:clone()
newmodel221:PivotTo(CFrame.new(-50.86226124884884, 2.659297144255692, 32.33158306181696) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel221.Parent = workspace.devices.p2p1t
newmodel222 = workspace.prefabs.p2p1t_red:clone()
newmodel222:PivotTo(CFrame.new(-50.942110243609875, 2.659297144255692, 32.30339014718132) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel222.Parent = workspace.devices.p2p1t
newmodel223 = workspace.prefabs.p2p1t_red:clone()
newmodel223:PivotTo(CFrame.new(-50.53735844257979, 2.659297144255692, 32.44629905929987) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel223.Parent = workspace.devices.p2p1t
newmodel224 = workspace.prefabs.p2p1t_red:clone()
newmodel224:PivotTo(CFrame.new(-51.13343286896799, 2.7305556795261774, 33.0996051536822) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel224.Parent = workspace.devices.p2p1t
newmodel225 = workspace.prefabs.p2p1t_red:clone()
newmodel225:PivotTo(CFrame.new(-50.742522101209744, 2.7124865509397327, 33.01860052268623) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel225.Parent = workspace.devices.p2p1t
newmodel226 = workspace.prefabs.p2p1t_red:clone()
newmodel226:PivotTo(CFrame.new(-50.556219429938274, 2.703324739262099, 32.97332414602137) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel226.Parent = workspace.devices.p2p1t
newmodel227 = workspace.prefabs.p2p1t_red:clone()
newmodel227:PivotTo(CFrame.new(-50.26386258151253, 2.691617979896234, 32.93464434038956) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel227.Parent = workspace.devices.p2p1t
newmodel228 = workspace.prefabs.p2p1t_red:clone()
newmodel228:PivotTo(CFrame.new(-50.18126017313904, 2.691617979896234, 32.96380942449538) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel228.Parent = workspace.devices.p2p1t
newmodel229 = workspace.prefabs.p2p1t_red:clone()
newmodel229:PivotTo(CFrame.new(-50.243968075285814, 2.621631977055463, 32.093326580330384) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel229.Parent = workspace.devices.p2p1t
newmodel230 = workspace.prefabs.p2p1t_red:clone()
newmodel230:PivotTo(CFrame.new(-49.913557362131726, 2.62163201234204, 32.209990319454796) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel230.Parent = workspace.devices.p2p1t
newmodel231 = workspace.prefabs.p2p1t_red:clone()
newmodel231:PivotTo(CFrame.new(-50.16136276637934, 2.6216319619611075, 32.1224911785388) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel231.Parent = workspace.devices.p2p1t
newmodel232 = workspace.prefabs.p2p1t_red:clone()
newmodel232:PivotTo(CFrame.new(-50.07876285918738, 2.6216319997966164, 32.15165840176676) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel232.Parent = workspace.devices.p2p1t
newmodel233 = workspace.prefabs.p2p1t_red:clone()
newmodel233:PivotTo(CFrame.new(-49.996158863077696, 2.62163201493082, 32.18082525536073) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel233.Parent = workspace.devices.p2p1t
newmodel234 = workspace.prefabs.p2p1t_red:clone()
newmodel234:PivotTo(CFrame.new(-49.98536376392621, 2.64123003318864, 32.40711642020392) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel234.Parent = workspace.devices.p2p1t
newmodel235 = workspace.prefabs.p2p1t_red:clone()
newmodel235:PivotTo(CFrame.new(-50.15056806252549, 2.6412300435039135, 32.34878553453329) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel235.Parent = workspace.devices.p2p1t
newmodel236 = workspace.prefabs.p2p1t_red:clone()
newmodel236:PivotTo(CFrame.new(-50.067970075301275, 2.6412300232319974, 32.37794814837926) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel236.Parent = workspace.devices.p2p1t
newmodel237 = workspace.prefabs.p2p1t_red:clone()
newmodel237:PivotTo(CFrame.new(-50.80703959259889, 2.62163198211348, 31.8945187793404) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel237.Parent = workspace.devices.p2p1t
newmodel238 = workspace.prefabs.p2p1t_red:clone()
newmodel238:PivotTo(CFrame.new(-50.476629057939164, 2.6216319919505797, 32.01118214695427) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel238.Parent = workspace.devices.p2p1t
newmodel239 = workspace.prefabs.p2p1t_red:clone()
newmodel239:PivotTo(CFrame.new(-50.72443577638753, 2.6216319743471392, 31.923685261665145) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel239.Parent = workspace.devices.p2p1t
newmodel240 = workspace.prefabs.p2p1t_red:clone()
newmodel240:PivotTo(CFrame.new(-50.64183659491883, 2.621631984582717, 31.952848908252484) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel240.Parent = workspace.devices.p2p1t
newmodel241 = workspace.prefabs.p2p1t_red:clone()
newmodel241:PivotTo(CFrame.new(-50.559230273070156, 2.6216319796442433, 31.98201416817438) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel241.Parent = workspace.devices.p2p1t
newmodel242 = workspace.prefabs.p2p1t_red:clone()
newmodel242:PivotTo(CFrame.new(-50.548436873589324, 2.6412300761220147, 32.20831077810651) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel242.Parent = workspace.devices.p2p1t
newmodel243 = workspace.prefabs.p2p1t_red:clone()
newmodel243:PivotTo(CFrame.new(-50.71364338920302, 2.641230063616439, 32.14997819967027) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel243.Parent = workspace.devices.p2p1t
newmodel244 = workspace.prefabs.p2p1t_red:clone()
newmodel244:PivotTo(CFrame.new(-50.63104569340963, 2.6412300684353696, 32.179143729167336) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel244.Parent = workspace.devices.p2p1t
newmodel245 = workspace.prefabs.p2p1t_red:clone()
newmodel245:PivotTo(CFrame.new(-50.966738383031796, 2.6216320299056326, 31.838137499174522) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel245.Parent = workspace.devices.p2p1t
newmodel246 = workspace.prefabs.p2p1t_red:clone()
newmodel246:PivotTo(CFrame.new(-51.13194228914136, 2.6216319820337843, 31.779803422835233) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel246.Parent = workspace.devices.p2p1t
newmodel247 = workspace.prefabs.p2p1t_red:clone()
newmodel247:PivotTo(CFrame.new(-51.04933754841104, 2.621631994579208, 31.808970839719137) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel247.Parent = workspace.devices.p2p1t
newmodel248 = workspace.prefabs.p2p1t_red:clone()
newmodel248:PivotTo(CFrame.new(-51.03854216765646, 2.6412300055887084, 32.03525909060046) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel248.Parent = workspace.devices.p2p1t
newmodel249 = workspace.prefabs.p2p1t_red:clone()
newmodel249:PivotTo(CFrame.new(-51.20375277564167, 2.641230017934893, 31.97692989249437) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel249.Parent = workspace.devices.p2p1t
newmodel250 = workspace.prefabs.p2p1t_red:clone()
newmodel250:PivotTo(CFrame.new(-51.121152297465635, 2.641230023032758, 32.006094296564214) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel250.Parent = workspace.devices.p2p1t
newmodel251 = workspace.prefabs.p2p1t:clone()
newmodel251:PivotTo(CFrame.new(-49.760279222829254, 2.582439734226979, 31.789034668536097) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel251.Parent = workspace.devices.p2p1t
newmodel252 = workspace.prefabs.p2p1t:clone()
newmodel252:PivotTo(CFrame.new(-49.845635946626864, 2.582439721442469, 31.758897393983034) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel252.Parent = workspace.devices.p2p1t
newmodel253 = workspace.prefabs.p2p1t:clone()
newmodel253:PivotTo(CFrame.new(-49.71282478796973, 2.5699695289081745, 31.65462969878744) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel253.Parent = workspace.devices.p2p1t
newmodel254 = workspace.prefabs.p2p1t:clone()
newmodel254:PivotTo(CFrame.new(-49.79818319113666, 2.569969561605971, 31.624494855731317) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel254.Parent = workspace.devices.p2p1t
newmodel255 = workspace.prefabs.p2p1t:clone()
newmodel255:PivotTo(CFrame.new(-49.878030295498995, 2.569969531257868, 31.596300793002168) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel255.Parent = workspace.devices.p2p1t
newmodel256 = workspace.prefabs.p2p1t:clone()
newmodel256:PivotTo(CFrame.new(-49.96338840723509, 2.569969538864818, 31.566163034294938) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel256.Parent = workspace.devices.p2p1t
newmodel257 = workspace.prefabs.p2p1t:clone()
newmodel257:PivotTo(CFrame.new(-50.04323459409827, 2.5699695415731414, 31.537969907331547) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel257.Parent = workspace.devices.p2p1t
newmodel258 = workspace.prefabs.p2p1t:clone()
newmodel258:PivotTo(CFrame.new(-50.1285881651308, 2.5699695515297845, 31.507835258172683) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel258.Parent = workspace.devices.p2p1t
newmodel259 = workspace.prefabs.p2p1t:clone()
newmodel259:PivotTo(CFrame.new(-50.20844019426265, 2.5699695617255145, 31.479641275115917) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel259.Parent = workspace.devices.p2p1t
newmodel260 = workspace.prefabs.p2p1t:clone()
newmodel260:PivotTo(CFrame.new(-50.29379598932941, 2.569969561605971, 31.44950493439805) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel260.Parent = workspace.devices.p2p1t
newmodel261 = workspace.prefabs.p2p1t:clone()
newmodel261:PivotTo(CFrame.new(-50.45074268095064, 2.5699695539990217, 31.39409022425704) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel261.Parent = workspace.devices.p2p1t
newmodel262 = workspace.prefabs.p2p1t:clone()
newmodel262:PivotTo(CFrame.new(-50.53609689911093, 2.569969544042378, 31.363951727301128) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel262.Parent = workspace.devices.p2p1t
newmodel263 = workspace.prefabs.p2p1t:clone()
newmodel263:PivotTo(CFrame.new(-50.613190267700894, 2.569969526199851, 31.336731758182026) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel263.Parent = workspace.devices.p2p1t
newmodel264 = workspace.prefabs.p2p1t:clone()
newmodel264:PivotTo(CFrame.new(-50.69855099174905, 2.569969574270938, 31.306595497860492) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel264.Parent = workspace.devices.p2p1t
newmodel265 = workspace.prefabs.p2p1t:clone()
newmodel265:PivotTo(CFrame.new(-50.77564666998856, 2.5699695514102414, 31.27937410954543) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel265.Parent = workspace.devices.p2p1t
newmodel266 = workspace.prefabs.p2p1t:clone()
newmodel266:PivotTo(CFrame.new(-50.86099986818683, 2.569969538864818, 31.249236273096372) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel266.Parent = workspace.devices.p2p1t
newmodel267 = workspace.prefabs.p2p1t:clone()
newmodel267:PivotTo(CFrame.new(-50.816321523804085, 2.5806582169988532, 31.394577704116635) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel267.Parent = workspace.devices.p2p1t
newmodel268 = workspace.prefabs.p2p1t:clone()
newmodel268:PivotTo(CFrame.new(-50.90167453789216, 2.5806582197071766, 31.364440238212858) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel268.Parent = workspace.devices.p2p1t
newmodel269 = workspace.prefabs.p2p1t:clone()
newmodel269:PivotTo(CFrame.new(-33.72641350165809, 2.7254953646304045, 33.625138791316374) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel269.Parent = workspace.devices.p2p1t
newmodel270 = workspace.prefabs.p2p1t_red:clone()
newmodel270:PivotTo(CFrame.new(-33.8176915662108, 2.725495349329147, 33.64512613353616) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel270.Parent = workspace.devices.p2p1t
newmodel271 = workspace.prefabs.p2p1t:clone()
newmodel271:PivotTo(CFrame.new(-33.92988210033395, 2.7254953574863614, 33.669698762777486) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel271.Parent = workspace.devices.p2p1t
newmodel272 = workspace.prefabs.p2p1t_red:clone()
newmodel272:PivotTo(CFrame.new(-34.02115990298783, 2.725495367634581, 33.689686345423326) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel272.Parent = workspace.devices.p2p1t
newmodel273 = workspace.prefabs.p2p1t:clone()
newmodel273:PivotTo(CFrame.new(-34.13335622339271, 2.72549537186163, 33.71425845550224) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel273.Parent = workspace.devices.p2p1t
newmodel274 = workspace.prefabs.p2p1t_red:clone()
newmodel274:PivotTo(CFrame.new(-34.22463274412799, 2.725495359303002, 33.734252009672346) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel274.Parent = workspace.devices.p2p1t
newmodel275 = workspace.prefabs.p2p1t:clone()
newmodel275:PivotTo(CFrame.new(-34.33682572299717, 2.7254953533464943, 33.75881743332914) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel275.Parent = workspace.devices.p2p1t
newmodel276 = workspace.prefabs.p2p1t_red:clone()
newmodel276:PivotTo(CFrame.new(-34.42810350523678, 2.7254953773987336, 33.77881066839287) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel276.Parent = workspace.devices.p2p1t
newmodel277 = workspace.prefabs.p2p1t:clone()
newmodel277:PivotTo(CFrame.new(-34.21932805687656, 2.690375061293033, 33.322150462297955) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel277.Parent = workspace.devices.p2p1t
newmodel278 = workspace.prefabs.p2p1t_red:clone()
newmodel278:PivotTo(CFrame.new(-34.310607591009486, 2.6903750754586, 33.342136935507) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel278.Parent = workspace.devices.p2p1t
newmodel279 = workspace.prefabs.p2p1t:clone()
newmodel279:PivotTo(CFrame.new(-33.81229138908216, 2.6903750502188246, 33.2330051620806) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel279.Parent = workspace.devices.p2p1t
newmodel280 = workspace.prefabs.p2p1t_red:clone()
newmodel280:PivotTo(CFrame.new(-33.903569970291194, 2.6903750532230006, 33.252992319759684) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel280.Parent = workspace.devices.p2p1t
newmodel281 = workspace.prefabs.p2p1t:clone()
newmodel281:PivotTo(CFrame.new(-34.01566822064902, 2.6903750712315504, 33.27754324980188) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel281.Parent = workspace.devices.p2p1t
newmodel282 = workspace.prefabs.p2p1t_red:clone()
newmodel282:PivotTo(CFrame.new(-34.10694673780063, 2.690375064506911, 33.29753724120873) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel282.Parent = workspace.devices.p2p1t
newmodel283 = workspace.prefabs.p2p1t:clone()
newmodel283:PivotTo(CFrame.new(-34.42270312027475, 2.690375070428081, 33.36668607865096) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel283.Parent = workspace.devices.p2p1t
newmodel284 = workspace.prefabs.p2p1t_red:clone()
newmodel284:PivotTo(CFrame.new(-34.51398501967867, 2.690375058166337, 33.386679619857304) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel284.Parent = workspace.devices.p2p1t
newmodel285 = workspace.prefabs.p2p1t:clone()
newmodel285:PivotTo(CFrame.new(-33.86804591268272, 2.668157453514449, 32.985250709702505) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel285.Parent = workspace.devices.p2p1t
newmodel286 = workspace.prefabs.p2p1t_red:clone()
newmodel286:PivotTo(CFrame.new(-33.9536179050062, 2.668157633774312, 33.0039937551778) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel286.Parent = workspace.devices.p2p1t
newmodel287 = workspace.prefabs.p2p1t:clone()
newmodel287:PivotTo(CFrame.new(-34.073419867219386, 2.6681574458638204, 33.03022706974606) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel287.Parent = workspace.devices.p2p1t
newmodel288 = workspace.prefabs.p2p1t_red:clone()
newmodel288:PivotTo(CFrame.new(-34.158990200547976, 2.6681576338614943, 33.04896796553346) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel288.Parent = workspace.devices.p2p1t
newmodel289 = workspace.prefabs.p2p1t:clone()
newmodel289:PivotTo(CFrame.new(-33.921565792688426, 2.6462710477256026, 32.74087565931651) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel289.Parent = workspace.devices.p2p1t
newmodel290 = workspace.prefabs.p2p1t_red:clone()
newmodel290:PivotTo(CFrame.new(-34.00713689184148, 2.6462710612102196, 32.75961761564333) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel290.Parent = workspace.devices.p2p1t
newmodel291 = workspace.prefabs.p2p1t:clone()
newmodel291:PivotTo(CFrame.new(-34.126939513663714, 2.6462710744851345, 32.785854350117134) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel291.Parent = workspace.devices.p2p1t
newmodel292 = workspace.prefabs.p2p1t_red:clone()
newmodel292:PivotTo(CFrame.new(-34.21250792077035, 2.6462710532627067, 32.80459452588235) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel292.Parent = workspace.devices.p2p1t
newmodel293 = workspace.prefabs.p2p1t_red:clone()
newmodel293:PivotTo(CFrame.new(-34.50026691817998, 2.74089212959591, 33.974771039988) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel293.Parent = workspace.devices.p2p1t
newmodel294 = workspace.prefabs.p2p1t:clone()
newmodel294:PivotTo(CFrame.new(-34.58584119298746, 2.7408923000638143, 33.99351583578088) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel294.Parent = workspace.devices.p2p1t
newmodel295 = workspace.prefabs.p2p1t_cyan:clone()
newmodel295:PivotTo(CFrame.new(-34.67141387042336, 2.7408919502146794, 34.012251497626245) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel295.Parent = workspace.devices.p2p1t
newmodel296 = workspace.prefabs.p2p1t_red:clone()
newmodel296:PivotTo(CFrame.new(-34.55814174426776, 2.7172240317558214, 33.71050805109353) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel296.Parent = workspace.devices.p2p1t
newmodel297 = workspace.prefabs.p2p1t:clone()
newmodel297:PivotTo(CFrame.new(-34.643716797377735, 2.717224378581229, 33.72925057632875) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel297.Parent = workspace.devices.p2p1t
newmodel298 = workspace.prefabs.p2p1t_cyan:clone()
newmodel298:PivotTo(CFrame.new(-34.729291358993656, 2.717223864177106, 33.74799001481395) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel298.Parent = workspace.devices.p2p1t
newmodel299 = workspace.prefabs.p2p1t_red:clone()
newmodel299:PivotTo(CFrame.new(-34.61601858979358, 2.6935561078786137, 33.44624535596748) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel299.Parent = workspace.devices.p2p1t
newmodel300 = workspace.prefabs.p2p1t:clone()
newmodel300:PivotTo(CFrame.new(-34.701593285051985, 2.693556260278591, 33.464989588798204) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel300.Parent = workspace.devices.p2p1t
newmodel301 = workspace.prefabs.p2p1t_cyan:clone()
newmodel301:PivotTo(CFrame.new(-34.78716484296113, 2.6935559352693796, 33.48372628575098) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel301.Parent = workspace.devices.p2p1t
newmodel302 = workspace.prefabs.p2p1t:clone()
newmodel302:PivotTo(CFrame.new(-52.0801358741148, 2.6230571718644975, 31.420580502276003) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel302.Parent = workspace.devices.p2p1t
newmodel303 = workspace.prefabs.p2p1t:clone()
newmodel303:PivotTo(CFrame.new(-52.00058061191957, 2.6230571718644975, 31.457250929830757) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel303.Parent = workspace.devices.p2p1t
newmodel304 = workspace.prefabs.p2p1t:clone()
newmodel304:PivotTo(CFrame.new(-51.921025349724346, 2.6230571718644975, 31.493921357385517) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel304.Parent = workspace.devices.p2p1t
newmodel305 = workspace.prefabs.p2p1t:clone()
newmodel305:PivotTo(CFrame.new(-52.376211031280974, 2.7094226517703643, 32.44423128211383) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel305.Parent = workspace.devices.p2p1t
newmodel306 = workspace.prefabs.p2p1t:clone()
newmodel306:PivotTo(CFrame.new(-52.46106997762256, 2.7094226517703643, 32.405116159388754) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel306.Parent = workspace.devices.p2p1t
newmodel307 = workspace.prefabs.p2p1t:clone()
newmodel307:PivotTo(CFrame.new(-52.63770693107102, 2.555962306169998, 30.39226390276269) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel307.Parent = workspace.devices.p2p1t
newmodel308 = workspace.prefabs.p2p1t:clone()
newmodel308:PivotTo(CFrame.new(-52.558151668875794, 2.555962306169998, 30.428934330317446) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel308.Parent = workspace.devices.p2p1t
newmodel309 = workspace.prefabs.p2p1t:clone()
newmodel309:PivotTo(CFrame.new(-52.19419430510567, 2.66352184010738, 31.87728934097293) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel309.Parent = workspace.devices.p2p1t
newmodel310 = workspace.prefabs.p2p1t:clone()
newmodel310:PivotTo(CFrame.new(-52.11331312187385, 2.66352184010738, 31.914570942320267) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel310.Parent = workspace.devices.p2p1t
newmodel311 = workspace.prefabs.p2p1t:clone()
newmodel311:PivotTo(CFrame.new(-52.095560914237275, 2.642907763832704, 31.663307508881637) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel311.Parent = workspace.devices.p2p1t
newmodel312 = workspace.prefabs.p2p1t:clone()
newmodel312:PivotTo(CFrame.new(-52.016005652042054, 2.642907763832704, 31.699977936436397) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel312.Parent = workspace.devices.p2p1t
newmodel313 = workspace.prefabs.p2p1t:clone()
newmodel313:PivotTo(CFrame.new(-52.682498790732595, 2.7094226517703643, 32.303050136028006) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel313.Parent = workspace.devices.p2p1t
newmodel314 = workspace.prefabs.p2p1t:clone()
newmodel314:PivotTo(CFrame.new(-52.90392760384264, 2.7094226517703643, 32.20098411266726) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel314.Parent = workspace.devices.p2p1t
newmodel315 = workspace.prefabs.p2p1t:clone()
newmodel315:PivotTo(CFrame.new(-52.81906865750107, 2.7094226517703643, 32.240099235392336) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel315.Parent = workspace.devices.p2p1t
newmodel316 = workspace.prefabs.p2p1t:clone()
newmodel316:PivotTo(CFrame.new(-53.84457529854437, 2.736144602496796, 32.103718434230764) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel316.Parent = workspace.devices.p2p1t
newmodel317 = workspace.prefabs.p2p1t:clone()
newmodel317:PivotTo(CFrame.new(-53.79464975501839, 2.7257103169750465, 31.995406642678383) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel317.Parent = workspace.devices.p2p1t
newmodel318 = workspace.prefabs.p2p1t:clone()
newmodel318:PivotTo(CFrame.new(-54.39832294682513, 2.731054707120333, 31.784411640396726) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel318.Parent = workspace.devices.p2p1t
newmodel319 = workspace.prefabs.p2p1t:clone()
newmodel319:PivotTo(CFrame.new(-54.316115842556734, 2.731054707120333, 31.822304415536642) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel319.Parent = workspace.devices.p2p1t
newmodel320 = workspace.prefabs.p2p1t:clone()
newmodel320:PivotTo(CFrame.new(-53.87420501721362, 2.7257103169750465, 31.958736215123626) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel320.Parent = workspace.devices.p2p1t
newmodel321 = workspace.prefabs.p2p1t:clone()
newmodel321:PivotTo(CFrame.new(-53.9241305607396, 2.736144602496796, 32.067048006676) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel321.Parent = workspace.devices.p2p1t
newmodel322 = workspace.prefabs.p2p1t:clone()
newmodel322:PivotTo(CFrame.new(-52.597639844391026, 2.7094226517703643, 32.342165258753084) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel322.Parent = workspace.devices.p2p1t
newmodel323 = workspace.prefabs.p2p1t:clone()
newmodel323:PivotTo(CFrame.new(-52.37127290960515, 2.6212756228720466, 31.263961352296977) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel323.Parent = workspace.devices.p2p1t
newmodel324 = workspace.prefabs.p2p1t:clone()
newmodel324:PivotTo(CFrame.new(-52.29436678526557, 2.621275639786337, 31.299412851772523) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel324.Parent = workspace.devices.p2p1t
newmodel325 = workspace.prefabs.p2p1t:clone()
newmodel325:PivotTo(CFrame.new(-52.54099123557669, 2.6212756452571546, 31.185732154301505) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel325.Parent = workspace.devices.p2p1t
newmodel326 = workspace.prefabs.p2p1t:clone()
newmodel326:PivotTo(CFrame.new(-52.46408833417348, 2.6212756166741573, 31.221178435943678) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel326.Parent = workspace.devices.p2p1t
newmodel327 = workspace.prefabs.p2p1t:clone()
newmodel327:PivotTo(CFrame.new(-52.30308573255394, 2.6070240812741248, 31.116024704579512) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel327.Parent = workspace.devices.p2p1t
newmodel328 = workspace.prefabs.p2p1t:clone()
newmodel328:PivotTo(CFrame.new(-52.226178237349195, 2.607024091921375, 31.15147435809799) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel328.Parent = workspace.devices.p2p1t
newmodel329 = workspace.prefabs.p2p1t:clone()
newmodel329:PivotTo(CFrame.new(-52.472802570780715, 2.607024079162061, 31.03779339729239) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel329.Parent = workspace.devices.p2p1t
newmodel330 = workspace.prefabs.p2p1t:clone()
newmodel330:PivotTo(CFrame.new(-52.39589644644112, 2.6070240960763513, 31.07324489676794) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel330.Parent = workspace.devices.p2p1t
newmodel331 = workspace.prefabs.p2p1t:clone()
newmodel331:PivotTo(CFrame.new(-52.71071389505556, 2.6212756356313607, 31.107499707505003) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel331.Parent = workspace.devices.p2p1t
newmodel332 = workspace.prefabs.p2p1t:clone()
newmodel332:PivotTo(CFrame.new(-52.633806399850826, 2.621275646278611, 31.14294936102348) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel332.Parent = workspace.devices.p2p1t
newmodel333 = workspace.prefabs.p2p1t:clone()
newmodel333:PivotTo(CFrame.new(-52.88043221939709, 2.6212756556100203, 31.029270509229356) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel333.Parent = workspace.devices.p2p1t
newmodel334 = workspace.prefabs.p2p1t:clone()
newmodel334:PivotTo(CFrame.new(-52.80352366393462, 2.621275689732986, 31.06472375548025) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel334.Parent = workspace.devices.p2p1t
newmodel335 = workspace.prefabs.p2p1t:clone()
newmodel335:PivotTo(CFrame.new(-51.79987664723526, 2.5805565966643678, 31.014855507554305) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel335.Parent = workspace.devices.p2p1t
newmodel336 = workspace.prefabs.p2p1t:clone()
newmodel336:PivotTo(CFrame.new(-51.71767166468006, 2.5805566084022256, 31.05274885671285) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel336.Parent = workspace.devices.p2p1t
newmodel337 = workspace.prefabs.p2p1t:clone()
newmodel337:PivotTo(CFrame.new(-52.02263488700026, 2.580556633920853, 30.912180732618054) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel337.Parent = workspace.devices.p2p1t
newmodel338 = workspace.prefabs.p2p1t:clone()
newmodel338:PivotTo(CFrame.new(-51.94042486522648, 2.5805566104451376, 30.950071748546925) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel338.Parent = workspace.devices.p2p1t
newmodel339 = workspace.prefabs.p2p1t:clone()
newmodel339:PivotTo(CFrame.new(-52.24538498050753, 2.5805565470812546, 30.809499140012704) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel339.Parent = workspace.devices.p2p1t
newmodel340 = workspace.prefabs.p2p1t:clone()
newmodel340:PivotTo(CFrame.new(-52.16318037838615, 2.580556574642795, 30.847392629990892) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel340.Parent = workspace.devices.p2p1t
newmodel341 = workspace.prefabs.p2p1t:clone()
newmodel341:PivotTo(CFrame.new(-51.74142863853854, 2.5683407660799107, 30.888055106367446) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel341.Parent = workspace.devices.p2p1t
newmodel342 = workspace.prefabs.p2p1t:clone()
newmodel342:PivotTo(CFrame.new(-51.659221044627614, 2.5683407205826225, 30.925944374960615) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel342.Parent = workspace.devices.p2p1t
newmodel343 = workspace.prefabs.p2p1t:clone()
newmodel343:PivotTo(CFrame.new(-51.96418401317363, 2.56834076294639, 30.785376375061794) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel343.Parent = workspace.devices.p2p1t
newmodel344 = workspace.prefabs.p2p1t:clone()
newmodel344:PivotTo(CFrame.new(-51.88197630401311, 2.5683407016254196, 30.823265380600557) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel344.Parent = workspace.devices.p2p1t
newmodel345 = workspace.prefabs.p2p1t:clone()
newmodel345:PivotTo(CFrame.new(-52.18693721372004, 2.568340764989303, 30.682699266895874) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel345.Parent = workspace.devices.p2p1t
newmodel346 = workspace.prefabs.p2p1t:clone()
newmodel346:PivotTo(CFrame.new(-52.10473465739773, 2.56834075229914, 30.720590868438542) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel346.Parent = workspace.devices.p2p1t
newmodel347 = workspace.prefabs.p2p1t:clone()
newmodel347:PivotTo(CFrame.new(-52.46813967368871, 2.5805565808406845, 30.70682414197895) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel347.Parent = workspace.devices.p2p1t
newmodel348 = workspace.prefabs.p2p1t:clone()
newmodel348:PivotTo(CFrame.new(-52.385938731770764, 2.580556625316516, 30.74471811782888) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel348.Parent = workspace.devices.p2p1t
newmodel349 = workspace.prefabs.p2p1t:clone()
newmodel349:PivotTo(CFrame.new(-53.37405281159049, 2.6390906030621655, 31.02595592872366) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel349.Parent = workspace.devices.p2p1t
newmodel350 = workspace.prefabs.p2p1t:clone()
newmodel350:PivotTo(CFrame.new(-53.44564920559128, 2.6390902615717162, 30.99295022526386) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel350.Parent = workspace.devices.p2p1t
newmodel351 = workspace.prefabs.p2p1t:clone()
newmodel351:PivotTo(CFrame.new(-53.60343554792569, 2.639090562741311, 30.920220490261386) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel351.Parent = workspace.devices.p2p1t
newmodel352 = workspace.prefabs.p2p1t:clone()
newmodel352:PivotTo(CFrame.new(-53.675033437821256, 2.6390902577802753, 30.8872168974941) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel352.Parent = workspace.devices.p2p1t
newmodel353 = workspace.prefabs.p2p1t:clone()
newmodel353:PivotTo(CFrame.new(-53.83281760932699, 2.6390905689391997, 30.814488786191696) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel353.Parent = workspace.devices.p2p1t
newmodel354 = workspace.prefabs.p2p1t:clone()
newmodel354:PivotTo(CFrame.new(-53.904417786930836, 2.6390902722189664, 30.78148383305892) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel354.Parent = workspace.devices.p2p1t
newmodel355 = workspace.prefabs.p2p1t:clone()
newmodel355:PivotTo(CFrame.new(-53.277856746683284, 2.618985558983288, 30.817257653853634) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel355.Parent = workspace.devices.p2p1t
newmodel356 = workspace.prefabs.p2p1t:clone()
newmodel356:PivotTo(CFrame.new(-53.34945314231408, 2.618985219899287, 30.78425195067402) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel356.Parent = workspace.devices.p2p1t
newmodel357 = workspace.prefabs.p2p1t:clone()
newmodel357:PivotTo(CFrame.new(-53.73662506935864, 2.618985579256332, 30.60579138500414) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel357.Parent = workspace.devices.p2p1t
newmodel358 = workspace.prefabs.p2p1t:clone()
newmodel358:PivotTo(CFrame.new(-53.80821916913114, 2.618985219899287, 30.57278704078915) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel358.Parent = workspace.devices.p2p1t
newmodel359 = workspace.prefabs.p2p1t:clone()
newmodel359:PivotTo(CFrame.new(-53.50724071209905, 2.6189855527853987, 30.711524448038453) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel359.Parent = workspace.devices.p2p1t
newmodel360 = workspace.prefabs.p2p1t:clone()
newmodel360:PivotTo(CFrame.new(-53.578838052737964, 2.618985174401999, 30.678514889072005) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel360.Parent = workspace.devices.p2p1t
newmodel361 = workspace.prefabs.p2p1t:clone()
newmodel361:PivotTo(CFrame.new(-53.08136878837237, 2.5790295348578587, 30.404941691547982) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel361.Parent = workspace.devices.p2p1t
newmodel362 = workspace.prefabs.p2p1t:clone()
newmodel362:PivotTo(CFrame.new(-53.15296593538014, 2.5790295675958324, 30.37194198930905) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel362.Parent = workspace.devices.p2p1t
newmodel363 = workspace.prefabs.p2p1t:clone()
newmodel363:PivotTo(CFrame.new(-53.2325237865433, 2.5790295348578587, 30.335267879193935) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel363.Parent = workspace.devices.p2p1t
newmodel364 = workspace.prefabs.p2p1t:clone()
newmodel364:PivotTo(CFrame.new(-53.30412254306543, 2.579029617542481, 30.302270550421746) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel364.Parent = workspace.devices.p2p1t
newmodel365 = workspace.prefabs.p2p1t:clone()
newmodel365:PivotTo(CFrame.new(-53.383678662944604, 2.5790295094083815, 30.265593802664796) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel365.Parent = workspace.devices.p2p1t
newmodel366 = workspace.prefabs.p2p1t:clone()
newmodel366:PivotTo(CFrame.new(-53.45527592683198, 2.579029560376487, 30.232594363760438) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel366.Parent = workspace.devices.p2p1t
newmodel367 = workspace.prefabs.p2p1t:clone()
newmodel367:PivotTo(CFrame.new(-53.53483527551992, 2.5790295665743757, 30.195922364618006) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel367.Parent = workspace.devices.p2p1t
newmodel368 = workspace.prefabs.p2p1t:clone()
newmodel368:PivotTo(CFrame.new(-53.60643119507713, 2.5790295675958324, 30.16292043001215) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel368.Parent = workspace.devices.p2p1t
newmodel369 = workspace.prefabs.p2p1t:clone()
newmodel369:PivotTo(CFrame.new(-53.02291937669104, 2.5668138049115505, 30.278139195638502) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel369.Parent = workspace.devices.p2p1t
newmodel370 = workspace.prefabs.p2p1t:clone()
newmodel370:PivotTo(CFrame.new(-53.0945200183394, 2.56681380177803, 30.24513415445214) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel370.Parent = workspace.devices.p2p1t
newmodel371 = workspace.prefabs.p2p1t:clone()
newmodel371:PivotTo(CFrame.new(-53.3252268250304, 2.566813803890094, 30.138793054371188) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel371.Parent = workspace.devices.p2p1t
newmodel372 = workspace.prefabs.p2p1t:clone()
newmodel372:PivotTo(CFrame.new(-53.39682895931354, 2.5668138324730907, 30.105790123316986) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel372.Parent = workspace.devices.p2p1t
newmodel373 = workspace.prefabs.p2p1t:clone()
newmodel373:PivotTo(CFrame.new(-53.17407587401674, 2.566813846253861, 30.208467494537317) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel373.Parent = workspace.devices.p2p1t
newmodel374 = workspace.prefabs.p2p1t:clone()
newmodel374:PivotTo(CFrame.new(-53.24567246198784, 2.5668137911307793, 30.17546182441817) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel374.Parent = workspace.devices.p2p1t
newmodel375 = workspace.prefabs.p2p1t:clone()
newmodel375:PivotTo(CFrame.new(-53.4763858768786, 2.566813855879655, 30.06911987094992) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel375.Parent = workspace.devices.p2p1t
newmodel376 = workspace.prefabs.p2p1t:clone()
newmodel376:PivotTo(CFrame.new(-53.547982723513904, 2.5668137911307793, 30.03611407747532) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel376.Parent = workspace.devices.p2p1t
newmodel377 = workspace.prefabs.p2p1t:clone()
newmodel377:PivotTo(CFrame.new(-36.883816350244075, 2.6105902846121745, 32.942659839622074) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel377.Parent = workspace.devices.p2p1t
newmodel378 = workspace.prefabs.p2p1t_red:clone()
newmodel378:PivotTo(CFrame.new(-36.96205767113359, 2.6105902952537856, 32.95233838221305) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel378.Parent = workspace.devices.p2p1t
newmodel379 = workspace.prefabs.p2p1t:clone()
newmodel379:PivotTo(CFrame.new(-37.05962141671861, 2.6105902952537856, 32.96440932375839) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel379.Parent = workspace.devices.p2p1t
newmodel380 = workspace.prefabs.p2p1t_red:clone()
newmodel380:PivotTo(CFrame.new(-37.13786588306203, 2.610590307433531, 32.974090892968235) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel380.Parent = workspace.devices.p2p1t
newmodel381 = workspace.prefabs.p2p1t:clone()
newmodel381:PivotTo(CFrame.new(-37.23542503451211, 2.6105903117289135, 32.98615862867167) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel381.Parent = workspace.devices.p2p1t
newmodel382 = workspace.prefabs.p2p1t_red:clone()
newmodel382:PivotTo(CFrame.new(-37.31366924664702, 2.610590295542423, 32.99583987331659) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel382.Parent = workspace.devices.p2p1t
newmodel383 = workspace.prefabs.p2p1t:clone()
newmodel383:PivotTo(CFrame.new(-37.41123360902159, 2.610590302177289, 33.0079105981384) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel383.Parent = workspace.devices.p2p1t
newmodel384 = workspace.prefabs.p2p1t_red:clone()
newmodel384:PivotTo(CFrame.new(-37.48947728408764, 2.6105902902861815, 33.0175891388964) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel384.Parent = workspace.devices.p2p1t
newmodel385 = workspace.prefabs.p2p1t:clone()
newmodel385:PivotTo(CFrame.new(-36.89881581820781, 2.5999014381020706, 32.821407258795894) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel385.Parent = workspace.devices.p2p1t
newmodel386 = workspace.prefabs.p2p1t_red:clone()
newmodel386:PivotTo(CFrame.new(-36.977061265141884, 2.599901461436138, 32.83108807020347) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel386.Parent = workspace.devices.p2p1t
newmodel387 = workspace.prefabs.p2p1t:clone()
newmodel387:PivotTo(CFrame.new(-37.25033226926141, 2.599901451371802, 32.864897566883904) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel387.Parent = workspace.devices.p2p1t
newmodel388 = workspace.prefabs.p2p1t_red:clone()
newmodel388:PivotTo(CFrame.new(-37.328577130769034, 2.599901465378319, 32.87458065023812) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel388.Parent = workspace.devices.p2p1t
newmodel389 = workspace.prefabs.p2p1t:clone()
newmodel389:PivotTo(CFrame.new(-37.074717090752216, 2.599901471500474, 32.843170990346714) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel389.Parent = workspace.devices.p2p1t
newmodel390 = workspace.prefabs.p2p1t_red:clone()
newmodel390:PivotTo(CFrame.new(-37.15296358535754, 2.5999014778467022, 32.85285281048745) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel390.Parent = workspace.devices.p2p1t
newmodel391 = workspace.prefabs.p2p1t:clone()
newmodel391:PivotTo(CFrame.new(-37.426235569661046, 2.599901470186414, 32.88666154929571) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel391.Parent = workspace.devices.p2p1t
newmodel392 = workspace.prefabs.p2p1t_red:clone()
newmodel392:PivotTo(CFrame.new(-37.50447771618978, 2.599901450281816, 32.896342831417826) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel392.Parent = workspace.devices.p2p1t
newmodel393 = workspace.prefabs.p2p1t:clone()
newmodel393:PivotTo(CFrame.new(-37.44123550230971, 2.5892126498625716, 32.76541224956873) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel393.Parent = workspace.devices.p2p1t
newmodel394 = workspace.prefabs.p2p1t_red:clone()
newmodel394:PivotTo(CFrame.new(-37.519481157686755, 2.589212627265289, 32.775096017161076) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel394.Parent = workspace.devices.p2p1t
newmodel395 = workspace.prefabs.p2p1t:clone()
newmodel395:PivotTo(CFrame.new(-36.91381673131158, 2.589212626015793, 32.70015720124336) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel395.Parent = workspace.devices.p2p1t
newmodel396 = workspace.prefabs.p2p1t_red:clone()
newmodel396:PivotTo(CFrame.new(-36.99206195580693, 2.5892126270412152, 32.70983974337903) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel396.Parent = workspace.devices.p2p1t
newmodel397 = workspace.prefabs.p2p1t:clone()
newmodel397:PivotTo(CFrame.new(-37.26533270217693, 2.589212628867987, 32.74365125954514) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel397.Parent = workspace.devices.p2p1t
newmodel398 = workspace.prefabs.p2p1t_red:clone()
newmodel398:PivotTo(CFrame.new(-37.34357732116722, 2.58921263316337, 32.753329331025455) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel398.Parent = workspace.devices.p2p1t
newmodel399 = workspace.prefabs.p2p1t:clone()
newmodel399:PivotTo(CFrame.new(-37.0897200674287, 2.589212619380927, 32.72192089496746) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel399.Parent = workspace.devices.p2p1t
newmodel400 = workspace.prefabs.p2p1t_red:clone()
newmodel400:PivotTo(CFrame.new(-37.16796315855949, 2.5892126302466116, 32.731601707928405) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel400.Parent = workspace.devices.p2p1t
newmodel401 = workspace.prefabs.p2p1t:clone()
newmodel401:PivotTo(CFrame.new(-37.45623895153376, 2.578523993101276, 32.64416543664016) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel401.Parent = workspace.devices.p2p1t
newmodel402 = workspace.prefabs.p2p1t_red:clone()
newmodel402:PivotTo(CFrame.new(-37.5344813202301, 2.578523989671806, 32.65384498798758) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel402.Parent = workspace.devices.p2p1t
newmodel403 = workspace.prefabs.p2p1t:clone()
newmodel403:PivotTo(CFrame.new(-36.92881717154749, 2.578523961016933, 32.578910895162856) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel403.Parent = workspace.devices.p2p1t
newmodel404 = workspace.prefabs.p2p1t_red:clone()
newmodel404:PivotTo(CFrame.new(-37.007062618481555, 2.5785239843510004, 32.58859170657044) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel404.Parent = workspace.devices.p2p1t
newmodel405 = workspace.prefabs.p2p1t:clone()
newmodel405:PivotTo(CFrame.new(-37.28033417081886, 2.5785239769793495, 32.62239921973561) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel405.Parent = workspace.devices.p2p1t
newmodel406 = workspace.prefabs.p2p1t_red:clone()
newmodel406:PivotTo(CFrame.new(-37.358580770255706, 2.5785239734853156, 32.63208251807358) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel406.Parent = workspace.devices.p2p1t
newmodel407 = workspace.prefabs.p2p1t:clone()
newmodel407:PivotTo(CFrame.new(-37.10471935475515, 2.578523972459893, 32.60067210188667) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel407.Parent = workspace.devices.p2p1t
newmodel408 = workspace.prefabs.p2p1t_red:clone()
newmodel408:PivotTo(CFrame.new(-37.182965454738515, 2.578523988646383, 32.61035240797624) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel408.Parent = workspace.devices.p2p1t
newmodel409 = workspace.prefabs.p2p1t:clone()
newmodel409:PivotTo(CFrame.new(-37.47123685537825, 2.567835166943917, 32.52291588588909) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel409.Parent = workspace.devices.p2p1t
newmodel410 = workspace.prefabs.p2p1t_red:clone()
newmodel410:PivotTo(CFrame.new(-37.54948201089514, 2.5678351552768834, 32.532596661163126) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel410.Parent = workspace.devices.p2p1t
newmodel411 = workspace.prefabs.p2p1t:clone()
newmodel411:PivotTo(CFrame.new(-37.11972279598099, 2.56783514360985, 32.479425287583325) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel411.Parent = workspace.devices.p2p1t
newmodel412 = workspace.prefabs.p2p1t_red:clone()
newmodel412:PivotTo(CFrame.new(-37.197966644992604, 2.5678351374876947, 32.48910707342349) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel412.Parent = workspace.devices.p2p1t
newmodel413 = workspace.prefabs.p2p1t:clone()
newmodel413:PivotTo(CFrame.new(-36.94381945999943, 2.567835153161474, 32.45766159388251) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel413.Parent = workspace.devices.p2p1t
newmodel414 = workspace.prefabs.p2p1t_red:clone()
newmodel414:PivotTo(CFrame.new(-37.02206555930499, 2.5678351547641722, 32.467341899855576) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel414.Parent = workspace.devices.p2p1t
newmodel415 = workspace.prefabs.p2p1t:clone()
newmodel415:PivotTo(CFrame.new(-37.295336305674994, 2.567835156590944, 32.501153416021694) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel415.Parent = workspace.devices.p2p1t
newmodel416 = workspace.prefabs.p2p1t_red:clone()
newmodel416:PivotTo(CFrame.new(-37.373577952614696, 2.5678351534501114, 32.51083170587211) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel416.Parent = workspace.devices.p2p1t
newmodel417 = workspace.prefabs.p2p1t:clone()
newmodel417:PivotTo(CFrame.new(-37.7078109780675, 2.6057547857006607, 32.988913645326356) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel417.Parent = workspace.devices.p2p1t
newmodel418 = workspace.prefabs.p2p1t_red:clone()
newmodel418:PivotTo(CFrame.new(-37.78894972882385, 2.6057547923355266, 32.9989521337216) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel418.Parent = workspace.devices.p2p1t
newmodel419 = workspace.prefabs.p2p1t:clone()
newmodel419:PivotTo(CFrame.new(-37.73227905054459, 2.5883218820806024, 32.79116394361956) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel419.Parent = workspace.devices.p2p1t
newmodel420 = workspace.prefabs.p2p1t_red:clone()
newmodel420:PivotTo(CFrame.new(-37.813418059050484, 2.588321876824361, 32.80120041252911) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel420.Parent = workspace.devices.p2p1t
newmodel421 = workspace.prefabs.p2p1t:clone()
newmodel421:PivotTo(CFrame.new(-37.756742380187596, 2.5708889591332222, 32.59341218981968) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel421.Parent = workspace.devices.p2p1t
newmodel422 = workspace.prefabs.p2p1t_red:clone()
newmodel422:PivotTo(CFrame.new(-37.83788236914858, 2.5708889621145445, 32.603447900903674) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel422.Parent = workspace.devices.p2p1t
newmodel423 = workspace.prefabs.p2p1t:clone()
newmodel423:PivotTo(CFrame.new(-37.92669458537088, 2.592266611736578, 32.86064841469612) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel423.Parent = workspace.devices.p2p1t
newmodel424 = workspace.prefabs.p2p1t_red:clone()
newmodel424:PivotTo(CFrame.new(-38.00493695393165, 2.592266605390349, 32.87032796602024) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel424.Parent = workspace.devices.p2p1t
newmodel425 = workspace.prefabs.p2p1t:clone()
newmodel425:PivotTo(CFrame.new(-37.941700276483985, 2.581577781861111, 32.739400120455755) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel425.Parent = workspace.devices.p2p1t
newmodel426 = workspace.prefabs.p2p1t_red:clone()
newmodel426:PivotTo(CFrame.new(-38.01993887898917, 2.581577801765709, 32.74907920588854) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel426.Parent = workspace.devices.p2p1t
newmodel427 = workspace.prefabs.p2p1t:clone()
newmodel427:PivotTo(CFrame.new(-37.95669622850099, 2.5708891346514395, 32.61815208691701) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel427.Parent = workspace.devices.p2p1t
newmodel428 = workspace.prefabs.p2p1t_red:clone()
newmodel428:PivotTo(CFrame.new(-38.034940335804365, 2.5708891283052115, 32.6278318533647) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel428.Parent = workspace.devices.p2p1t
newmodel429 = workspace.prefabs.p2p1t:clone()
newmodel429:PivotTo(CFrame.new(-36.97632023457946, 2.681682993187512, 33.85685559728829) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel429.Parent = workspace.devices.p2p1t
newmodel430 = workspace.prefabs.p2p1t_red:clone()
newmodel430:PivotTo(CFrame.new(-37.09223371584996, 2.6816826483022873, 33.87119507581889) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel430.Parent = workspace.devices.p2p1t
newmodel431 = workspace.prefabs.p2p1t:clone()
newmodel431:PivotTo(CFrame.new(-37.237130060387, 2.681682989263464, 33.88912716131507) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel431.Parent = workspace.devices.p2p1t
newmodel432 = workspace.prefabs.p2p1t_red:clone()
newmodel432:PivotTo(CFrame.new(-37.353046445138105, 2.6816826479112117, 33.90346465468417) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel432.Parent = workspace.devices.p2p1t
newmodel433 = workspace.prefabs.p2p1t:clone()
newmodel433:PivotTo(CFrame.new(-37.49793953936226, 2.6816829965830564, 33.92139223535952) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel433.Parent = workspace.devices.p2p1t
newmodel434 = workspace.prefabs.p2p1t_red:clone()
newmodel434:PivotTo(CFrame.new(-37.613856751180876, 2.6816826554157958, 33.93573246850526) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel434.Parent = workspace.devices.p2p1t
newmodel435 = workspace.prefabs.p2p1t:clone()
newmodel435:PivotTo(CFrame.new(-37.75875374903789, 2.6816829950530825, 33.953664048729955) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel435.Parent = workspace.devices.p2p1t
newmodel436 = workspace.prefabs.p2p1t_red:clone()
newmodel436:PivotTo(CFrame.new(-37.87466575001559, 2.681682653344112, 33.968001292771675) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel436.Parent = workspace.devices.p2p1t
newmodel437 = workspace.prefabs.p2p1t:clone()
newmodel437:PivotTo(CFrame.new(-38.01956286479925, 2.6816830104876535, 33.98592966395407) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel437.Parent = workspace.devices.p2p1t
newmodel438 = workspace.prefabs.p2p1t_red:clone()
newmodel438:PivotTo(CFrame.new(-38.13547982238711, 2.681682640475342, 34.00026957253105) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel438.Parent = workspace.devices.p2p1t
newmodel439 = workspace.prefabs.p2p1t:clone()
newmodel439:PivotTo(CFrame.new(-38.280377074127685, 2.681683001487453, 34.01820147726481) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel439.Parent = workspace.devices.p2p1t
newmodel440 = workspace.prefabs.p2p1t_red:clone()
newmodel440:PivotTo(CFrame.new(-38.396294286419746, 2.6816826705067083, 34.03254171049193) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel440.Parent = workspace.devices.p2p1t
newmodel441 = workspace.prefabs.p2p1t:clone()
newmodel441:PivotTo(CFrame.new(-38.54118676329394, 2.6816830004859535, 34.05046950779448) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel441.Parent = workspace.devices.p2p1t
newmodel442 = workspace.prefabs.p2p1t_red:clone()
newmodel442:PivotTo(CFrame.new(-38.65710249507228, 2.6816826679278183, 34.06480750649474) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel442.Parent = workspace.devices.p2p1t
newmodel443 = workspace.prefabs.p2p1t:clone()
newmodel443:PivotTo(CFrame.new(-38.80200076271545, 2.681683005918854, 34.082738364668835) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel443.Parent = workspace.devices.p2p1t
newmodel444 = workspace.prefabs.p2p1t_red:clone()
newmodel444:PivotTo(CFrame.new(-38.917914724063365, 2.6816826690667166, 34.09707409296661) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel444.Parent = workspace.devices.p2p1t
newmodel445 = workspace.prefabs.p2p1t:clone()
newmodel445:PivotTo(CFrame.new(-37.997873238801084, 2.7384350606709846, 34.63686977806016) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel445.Parent = workspace.devices.p2p1t
newmodel446 = workspace.prefabs.p2p1t_red:clone()
newmodel446:PivotTo(CFrame.new(-38.1137927516683, 2.738435057076199, 34.651215161282735) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel446.Parent = workspace.devices.p2p1t
newmodel447 = workspace.prefabs.p2p1t:clone()
newmodel447:PivotTo(CFrame.new(-38.26061794191047, 2.738435055738327, 34.66938345750704) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel447.Parent = workspace.devices.p2p1t
newmodel448 = workspace.prefabs.p2p1t_red:clone()
newmodel448:PivotTo(CFrame.new(-38.37653774258597, 2.738435057131158, 34.68372198967856) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel448.Parent = workspace.devices.p2p1t
newmodel449 = workspace.prefabs.p2p1t:clone()
newmodel449:PivotTo(CFrame.new(-38.523358059883236, 2.738435058160126, 34.7018869576463) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel449.Parent = workspace.devices.p2p1t
newmodel450 = workspace.prefabs.p2p1t_red:clone()
newmodel450:PivotTo(CFrame.new(-38.63927888773327, 2.7384350726339184, 34.71623127279451) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel450.Parent = workspace.devices.p2p1t
newmodel451 = workspace.prefabs.p2p1t:clone()
newmodel451:PivotTo(CFrame.new(-38.786102119447335, 2.738435074314766, 34.734394169032406) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel451.Parent = workspace.devices.p2p1t
newmodel452 = workspace.prefabs.p2p1t_red:clone()
newmodel452:PivotTo(CFrame.new(-38.90202388197019, 2.7384350647110423, 34.74873807227816) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel452.Parent = workspace.devices.p2p1t
newmodel453 = workspace.prefabs.p2p1t:clone()
newmodel453:PivotTo(CFrame.new(-38.403058484581734, 2.719602442523291, 34.4701044990015) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel453.Parent = workspace.devices.p2p1t
newmodel454 = workspace.prefabs.p2p1t_red:clone()
newmodel454:PivotTo(CFrame.new(-38.665898408678366, 2.719602442523291, 34.502624010634904) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel454.Parent = workspace.devices.p2p1t
newmodel455 = workspace.prefabs.p2p1t:clone()
newmodel455:PivotTo(CFrame.new(-38.549982234876104, 2.719602442523291, 34.48828243990352) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel455.Parent = workspace.devices.p2p1t
newmodel456 = workspace.prefabs.p2p1t:clone()
newmodel456:PivotTo(CFrame.new(-38.81253236853823, 2.719602442523291, 34.52076609761011) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel456.Parent = workspace.devices.p2p1t
newmodel457 = workspace.prefabs.p2p1t_red:clone()
newmodel457:PivotTo(CFrame.new(-38.9284485423405, 2.719602442523291, 34.53510766834149) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel457.Parent = workspace.devices.p2p1t
newmodel458 = workspace.prefabs.p2p1t:clone()
newmodel458:PivotTo(CFrame.new(-36.68080913470267, 2.676465615523013, 33.7602058237525) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel458.Parent = workspace.devices.p2p1t
newmodel459 = workspace.prefabs.p2p1t_red:clone()
newmodel459:PivotTo(CFrame.new(-36.854684075816365, 2.6764652866827827, 33.78171503974824) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel459.Parent = workspace.devices.p2p1t
newmodel460 = workspace.prefabs.p2p1t:clone()
newmodel460:PivotTo(CFrame.new(-36.70599224525915, 2.6585237949468064, 33.55668391872099) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel460.Parent = workspace.devices.p2p1t
newmodel461 = workspace.prefabs.p2p1t_red:clone()
newmodel461:PivotTo(CFrame.new(-36.87986548347398, 2.658523443373564, 33.57819263092719) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel461.Parent = workspace.devices.p2p1t
newmodel462 = workspace.prefabs.p2p1t:clone()
newmodel462:PivotTo(CFrame.new(-36.73117293460102, 2.6405817930691757, 33.35315555967585) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel462.Parent = workspace.devices.p2p1t
newmodel463 = workspace.prefabs.p2p1t_red:clone()
newmodel463:PivotTo(CFrame.new(-36.90504425801084, 2.6405816230721557, 33.37466550063097) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel463.Parent = workspace.devices.p2p1t
newmodel464 = workspace.prefabs.p2p1t:clone()
newmodel464:PivotTo(CFrame.new(-37.446596531926005, 2.640836076024146, 33.44460026513303) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel464.Parent = workspace.devices.p2p1t
newmodel465 = workspace.prefabs.p2p1t_red:clone()
newmodel465:PivotTo(CFrame.new(-37.52194416098355, 2.640836604810941, 33.453926651799506) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel465.Parent = workspace.devices.p2p1t
newmodel466 = workspace.prefabs.p2p1t:clone()
newmodel466:PivotTo(CFrame.new(-38.10877101048099, 2.640836084921293, 33.52652572846279) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel466.Parent = workspace.devices.p2p1t
newmodel467 = workspace.prefabs.p2p1t_red:clone()
newmodel467:PivotTo(CFrame.new(-38.18411373978083, 2.6408366266931176, 33.53585590468987) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel467.Parent = workspace.devices.p2p1t
newmodel468 = workspace.prefabs.p2p1t:clone()
newmodel468:PivotTo(CFrame.new(-38.770941242408846, 2.6408361014049087, 33.60845447604911) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel468.Parent = workspace.devices.p2p1t
newmodel469 = workspace.prefabs.p2p1t_red:clone()
newmodel469:PivotTo(CFrame.new(-38.84628546762559, 2.6408366268305166, 33.61777985547285) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel469.Parent = workspace.devices.p2p1t
newmodel470 = workspace.prefabs.p2p1t_cyan:clone()
newmodel470:PivotTo(CFrame.new(-39.520072543903936, 2.705605536576278, 34.414739900504884) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel470.Parent = workspace.devices.p2p1t
newmodel471 = workspace.prefabs.p2p1t:clone()
newmodel471:PivotTo(CFrame.new(-39.623686499122286, 2.7056057020548754, 34.41790843003586) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel471.Parent = workspace.devices.p2p1t
newmodel472 = workspace.prefabs.p2p1t_red:clone()
newmodel472:PivotTo(CFrame.new(-39.727295432943315, 2.7056055260623992, 34.42107708973015) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel472.Parent = workspace.devices.p2p1t
newmodel473 = workspace.prefabs.p2p1t_cyan:clone()
newmodel473:PivotTo(CFrame.new(-39.52843416260269, 2.681682636060743, 34.141427311568336) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel473.Parent = workspace.devices.p2p1t
newmodel474 = workspace.prefabs.p2p1t:clone()
newmodel474:PivotTo(CFrame.new(-39.63204977114249, 2.681682812585985, 34.14459821613231) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel474.Parent = workspace.devices.p2p1t
newmodel475 = workspace.prefabs.p2p1t_red:clone()
newmodel475:PivotTo(CFrame.new(-39.735656754988995, 2.6816826364693207, 34.14777146457724) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel475.Parent = workspace.devices.p2p1t
newmodel476 = workspace.prefabs.p2p1t_red:clone()
newmodel476:PivotTo(CFrame.new(-39.65310608577404, 2.6339649244038505, 33.599571831920215) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel476.Parent = workspace.devices.p2p1t
newmodel477 = workspace.prefabs.p2p1t:clone()
newmodel477:PivotTo(CFrame.new(-39.5451163708654, 2.633964925884332, 33.596266478742976) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel477.Parent = workspace.devices.p2p1t
newmodel478 = workspace.prefabs.p2p1t_cyan:clone()
newmodel478:PivotTo(CFrame.new(-40.006025550394014, 2.7056055329763757, 34.42961353232369) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel478.Parent = workspace.devices.p2p1t
newmodel479 = workspace.prefabs.p2p1t:clone()
newmodel479:PivotTo(CFrame.new(-40.10963949641072, 2.7056057217164757, 34.432782352555286) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel479.Parent = workspace.devices.p2p1t
newmodel480 = workspace.prefabs.p2p1t_red:clone()
newmodel480:PivotTo(CFrame.new(-40.21324813874139, 2.7056055484168726, 34.4359510033811) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel480.Parent = workspace.devices.p2p1t
newmodel481 = workspace.prefabs.p2p1t_cyan:clone()
newmodel481:PivotTo(CFrame.new(-40.0143885302478, 2.681682641319338, 34.15630330943548) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel481.Parent = workspace.devices.p2p1t
newmodel482 = workspace.prefabs.p2p1t:clone()
newmodel482:PivotTo(CFrame.new(-40.11800173980517, 2.68168280370967, 34.15947559293638) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel482.Parent = workspace.devices.p2p1t
newmodel483 = workspace.prefabs.p2p1t_red:clone()
newmodel483:PivotTo(CFrame.new(-40.22160809909583, 2.6816826460941336, 34.162643012087706) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel483.Parent = workspace.devices.p2p1t
newmodel484 = workspace.prefabs.p2p1t_red:clone()
newmodel484:PivotTo(CFrame.new(-40.13905909177454, 2.6339649172693935, 33.61444546365487) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel484.Parent = workspace.devices.p2p1t
newmodel485 = workspace.prefabs.p2p1t:clone()
newmodel485:PivotTo(CFrame.new(-40.03106907573097, 2.6339649415063517, 33.61114039223365) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel485.Parent = workspace.devices.p2p1t
newmodel486 = workspace.prefabs.p2p1t_cyan:clone()
newmodel486:PivotTo(CFrame.new(-40.49197539816082, 2.7056055443872933, 34.44448590565423) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel486.Parent = workspace.devices.p2p1t
newmodel487 = workspace.prefabs.p2p1t:clone()
newmodel487:PivotTo(CFrame.new(-40.595592210920884, 2.705605717275007, 34.44765597542147) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel487.Parent = workspace.devices.p2p1t
newmodel488 = workspace.prefabs.p2p1t_red:clone()
newmodel488:PivotTo(CFrame.new(-40.69919919476739, 2.7056055411583437, 34.4508292238664) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel488.Parent = workspace.devices.p2p1t
newmodel489 = workspace.prefabs.p2p1t_cyan:clone()
newmodel489:PivotTo(CFrame.new(-40.50033445118119, 2.6816826364626993, 34.171171785414) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel489.Parent = workspace.devices.p2p1t
newmodel490 = workspace.prefabs.p2p1t:clone()
newmodel490:PivotTo(CFrame.new(-40.6039500602805, 2.6816828170274536, 34.17434269007415) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel490.Parent = workspace.devices.p2p1t
newmodel491 = workspace.prefabs.p2p1t_red:clone()
newmodel491:PivotTo(CFrame.new(-40.70755915958517, 2.6816826255567245, 34.17751425980068) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel491.Parent = workspace.devices.p2p1t
newmodel492 = workspace.prefabs.p2p1t_red:clone()
newmodel492:PivotTo(CFrame.new(-40.62501043648753, 2.6339649312703246, 33.62931701126952) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel492.Parent = workspace.devices.p2p1t
newmodel493 = workspace.prefabs.p2p1t:clone()
newmodel493:PivotTo(CFrame.new(-40.517021341699476, 2.6339649264202816, 33.62601080536627) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel493.Parent = workspace.devices.p2p1t
newmodel494 = workspace.prefabs.p2p1t_cyan:clone()
newmodel494:PivotTo(CFrame.new(-40.97792720106007, 2.705605548969359, 34.45936037237797) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel494.Parent = workspace.devices.p2p1t
newmodel495 = workspace.prefabs.p2p1t:clone()
newmodel495:PivotTo(CFrame.new(-41.0815423514136, 2.705605734913469, 34.46252835783286) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel495.Parent = workspace.devices.p2p1t
newmodel496 = workspace.prefabs.p2p1t_red:clone()
newmodel496:PivotTo(CFrame.new(-41.185148884853405, 2.705605534687201, 34.46569839622366) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel496.Parent = workspace.devices.p2p1t
newmodel497 = workspace.prefabs.p2p1t_cyan:clone()
newmodel497:PivotTo(CFrame.new(-40.98628881863979, 2.6816826403748286, 34.18604778324908) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel497.Parent = workspace.devices.p2p1t
newmodel498 = workspace.prefabs.p2p1t:clone()
newmodel498:PivotTo(CFrame.new(-41.0899065441298, 2.6816828123180043, 34.18921700935111) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel498.Parent = workspace.devices.p2p1t
newmodel499 = workspace.prefabs.p2p1t_red:clone()
newmodel499:PivotTo(CFrame.new(-41.19351427475631, 2.68168264736866, 34.19238650401846) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel499.Parent = workspace.devices.p2p1t
newmodel500 = workspace.prefabs.p2p1t_red:clone()
newmodel500:PivotTo(CFrame.new(-41.11096554981695, 2.6339649397855935, 33.64418925517072) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel500.Parent = workspace.devices.p2p1t
newmodel501 = workspace.prefabs.p2p1t:clone()
newmodel501:PivotTo(CFrame.new(-41.002975542555404, 2.633964937731538, 33.64088389297675) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel501.Parent = workspace.devices.p2p1t
newmodel502 = workspace.prefabs.p2p1t_cyan:clone()
newmodel502:PivotTo(CFrame.new(-41.46388427314602, 2.705605531317654, 34.474227736755786) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel502.Parent = workspace.devices.p2p1t
newmodel503 = workspace.prefabs.p2p1t:clone()
newmodel503:PivotTo(CFrame.new(-41.56749747361831, 2.7056057178109683, 34.477400310977345) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel503.Parent = workspace.devices.p2p1t
newmodel504 = workspace.prefabs.p2p1t_red:clone()
newmodel504:PivotTo(CFrame.new(-41.67110686478631, 2.705605526340239, 34.48057188963646) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel504.Parent = workspace.devices.p2p1t
newmodel505 = workspace.prefabs.p2p1t_cyan:clone()
newmodel505:PivotTo(CFrame.new(-41.472242280676, 2.681682652486686, 34.200917652465904) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel505.Parent = workspace.devices.p2p1t
newmodel506 = workspace.prefabs.p2p1t:clone()
newmodel506:PivotTo(CFrame.new(-41.575858045521116, 2.6816828369635406, 34.20409175776675) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel506.Parent = workspace.devices.p2p1t
newmodel507 = workspace.prefabs.p2p1t_red:clone()
newmodel507:PivotTo(CFrame.new(-41.67946487231628, 2.681682647509286, 34.207261805346576) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel507.Parent = workspace.devices.p2p1t
newmodel508 = workspace.prefabs.p2p1t_red:clone()
newmodel508:PivotTo(CFrame.new(-41.596918264676816, 2.633964937868824, 33.65906287809702) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel508.Parent = workspace.devices.p2p1t
newmodel509 = workspace.prefabs.p2p1t:clone()
newmodel509:PivotTo(CFrame.new(-41.48892825715882, 2.633964933963322, 33.655757515858966) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel509.Parent = workspace.devices.p2p1t
newmodel510 = workspace.prefabs.p2p1t:clone()
newmodel510:PivotTo(CFrame.new(-41.61665206613486, 2.6067340125502185, 33.348269737892586) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel510.Parent = workspace.devices.p2p1t
newmodel511 = workspace.prefabs.p2p1t_red:clone()
newmodel511:PivotTo(CFrame.new(-41.72464150180881, 2.6067340125502185, 33.35157479202567) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel511.Parent = workspace.devices.p2p1t
newmodel512 = workspace.prefabs.p2p1t_red:clone()
newmodel512:PivotTo(CFrame.new(-41.729001809722604, 2.594263768877884, 33.20910596337306) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel512.Parent = workspace.devices.p2p1t
newmodel513 = workspace.prefabs.p2p1t:clone()
newmodel513:PivotTo(CFrame.new(-41.621012374048654, 2.594263768877884, 33.20580090923997) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel513.Parent = workspace.devices.p2p1t
newmodel514 = workspace.prefabs.p2p1t:clone()
newmodel514:PivotTo(CFrame.new(-39.72983506108356, 2.568941551223885, 32.85834851705392) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel514.Parent = workspace.devices.p2p1t
newmodel515 = workspace.prefabs.p2p1t:clone()
newmodel515:PivotTo(CFrame.new(-39.62768309342762, 2.568941524702487, 32.85522415382448) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel515.Parent = workspace.devices.p2p1t
newmodel516 = workspace.prefabs.p2p1t:clone()
newmodel516:PivotTo(CFrame.new(-39.92100340374189, 2.568941533993987, 32.864201614363644) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel516.Parent = workspace.devices.p2p1t
newmodel517 = workspace.prefabs.p2p1t:clone()
newmodel517:PivotTo(CFrame.new(-39.818855951459085, 2.5689415129859636, 32.861074193639155) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel517.Parent = workspace.devices.p2p1t
newmodel518 = workspace.prefabs.p2p1t:clone()
newmodel518:PivotTo(CFrame.new(-40.11217791416229, 2.568941526591564, 32.87005402905103) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel518.Parent = workspace.devices.p2p1t
newmodel519 = workspace.prefabs.p2p1t:clone()
newmodel519:PivotTo(CFrame.new(-40.01002639215142, 2.568941533993987, 32.86692619380002) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel519.Parent = workspace.devices.p2p1t
newmodel520 = workspace.prefabs.p2p1t:clone()
newmodel520:PivotTo(CFrame.new(-40.303345955312665, 2.5689415294250626, 32.87590740805266) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel520.Parent = workspace.devices.p2p1t
newmodel521 = workspace.prefabs.p2p1t:clone()
newmodel521:PivotTo(CFrame.new(-40.20119592975841, 2.568941535883049, 32.872778747001604) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel521.Parent = workspace.devices.p2p1t
newmodel522 = workspace.prefabs.p2p1t:clone()
newmodel522:PivotTo(CFrame.new(-40.49451744317394, 2.5689415334580405, 32.88175537255169) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel522.Parent = workspace.devices.p2p1t
newmodel523 = workspace.prefabs.p2p1t:clone()
newmodel523:PivotTo(CFrame.new(-40.392365921163076, 2.5689415408604668, 32.878627537300666) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel523.Parent = workspace.devices.p2p1t
newmodel524 = workspace.prefabs.p2p1t:clone()
newmodel524:PivotTo(CFrame.new(-40.897290627595105, 2.5689415310330026, 32.89408180445433) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel524.Parent = workspace.devices.p2p1t
newmodel525 = workspace.prefabs.p2p1t:clone()
newmodel525:PivotTo(CFrame.new(-40.79513820324492, 2.568941524702487, 32.89095452237227) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel525.Parent = workspace.devices.p2p1t
newmodel526 = workspace.prefabs.p2p1t:clone()
newmodel526:PivotTo(CFrame.new(-41.08845970776184, 2.568941547726955, 32.89993143867506) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel526.Parent = workspace.devices.p2p1t
newmodel527 = workspace.prefabs.p2p1t:clone()
newmodel527:PivotTo(CFrame.new(-40.986312706258744, 2.568941553521511, 32.89680722806883) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel527.Parent = workspace.devices.p2p1t
newmodel528 = workspace.prefabs.p2p1t:clone()
newmodel528:PivotTo(CFrame.new(-41.27962895350551, 2.5689415496160026, 32.905783982944065) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel528.Parent = workspace.devices.p2p1t
newmodel529 = workspace.prefabs.p2p1t:clone()
newmodel529:PivotTo(CFrame.new(-41.17747802411991, 2.5689415315689637, 32.90265587480549) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel529.Parent = workspace.devices.p2p1t
newmodel530 = workspace.prefabs.p2p1t:clone()
newmodel530:PivotTo(CFrame.new(-41.46934180155728, 2.5689415541980685, 32.91159195370928) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel530.Parent = workspace.devices.p2p1t
newmodel531 = workspace.prefabs.p2p1t:clone()
newmodel531:PivotTo(CFrame.new(-41.36719012100305, 2.568941537490902, 32.908460917336704) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel531.Parent = workspace.devices.p2p1t
newmodel532 = workspace.prefabs.p2p1t:clone()
newmodel532:PivotTo(CFrame.new(-41.66197255243172, 2.5689415294185283, 32.9174857410033) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel532.Parent = workspace.devices.p2p1t
newmodel533 = workspace.prefabs.p2p1t:clone()
newmodel533:PivotTo(CFrame.new(-41.55982177119887, 2.568941550158585, 32.91436112448254) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel533.Parent = workspace.devices.p2p1t
newmodel534 = workspace.prefabs.p2p1t:clone()
newmodel534:PivotTo(CFrame.new(-58.39117890554528, 2.688554080726865, 28.76478804755142) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel534.Parent = workspace.devices.p2p1t
newmodel535 = workspace.prefabs.p2p1t:clone()
newmodel535:PivotTo(CFrame.new(-57.113841168160114, 2.6302747786663607, 28.854088112518262) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel535.Parent = workspace.devices.p2p1t
newmodel536 = workspace.prefabs.p2p1t:clone()
newmodel536:PivotTo(CFrame.new(-56.88881177119432, 2.6155140820746174, 28.806850517984522) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel536.Parent = workspace.devices.p2p1t
newmodel537 = workspace.prefabs.p2p1t:clone()
newmodel537:PivotTo(CFrame.new(-57.103168085433225, 2.6155140820746174, 28.654813645661037) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel537.Parent = workspace.devices.p2p1t
newmodel538 = workspace.prefabs.p2p1t:clone()
newmodel538:PivotTo(CFrame.new(-57.03171598068692, 2.6155140820746174, 28.705492603102197) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel538.Parent = workspace.devices.p2p1t
newmodel539 = workspace.prefabs.p2p1t:clone()
newmodel539:PivotTo(CFrame.new(-56.817359666448006, 2.6155140820746174, 28.857529475425686) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel539.Parent = workspace.devices.p2p1t
newmodel540 = workspace.prefabs.p2p1t:clone()
newmodel540:PivotTo(CFrame.new(-57.028098642464556, 2.6302747786663607, 28.914902861447658) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel540.Parent = workspace.devices.p2p1t
newmodel541 = workspace.prefabs.p2p1t:clone()
newmodel541:PivotTo(CFrame.new(-58.46501274711647, 2.688554080726865, 28.712419791528887) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel541.Parent = workspace.devices.p2p1t
newmodel542 = workspace.prefabs.p2p1t:clone()
newmodel542:PivotTo(CFrame.new(-44.207501670199406, 2.699475785509891, 34.20401172484987) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel542.Parent = workspace.devices.p2p1t
newmodel543 = workspace.prefabs.p2p1t:clone()
newmodel543:PivotTo(CFrame.new(-43.825712819304215, 2.6994758011776816, 34.227680493461065) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel543.Parent = workspace.devices.p2p1t
newmodel544 = workspace.prefabs.p2p1t:clone()
newmodel544:PivotTo(CFrame.new(-43.95394643428375, 2.699475803768036, 34.21973238037101) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel544.Parent = workspace.devices.p2p1t
newmodel545 = workspace.prefabs.p2p1t:clone()
newmodel545:PivotTo(CFrame.new(-44.19940342264982, 2.688023413634317, 34.07336740961375) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel545.Parent = workspace.devices.p2p1t
newmodel546 = workspace.prefabs.p2p1t:clone()
newmodel546:PivotTo(CFrame.new(-44.321808389142646, 2.688023440340433, 34.06577740198135) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel546.Parent = workspace.devices.p2p1t
newmodel547 = workspace.prefabs.p2p1t:clone()
newmodel547:PivotTo(CFrame.new(-44.33573528517894, 2.6994757881002456, 34.19606361175981) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel547.Parent = workspace.devices.p2p1t
newmodel548 = workspace.prefabs.p2p1t:clone()
newmodel548:PivotTo(CFrame.new(-44.46397074510773, 2.699475789685289, 34.18811770473803) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel548.Parent = workspace.devices.p2p1t
newmodel549 = workspace.prefabs.p2p1t:clone()
newmodel549:PivotTo(CFrame.new(-43.951676441933294, 2.6880234289737035, 34.08872041321346) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel549.Parent = workspace.devices.p2p1t
newmodel550 = workspace.prefabs.p2p1t:clone()
newmodel550:PivotTo(CFrame.new(-44.07408323604089, 2.688023432066714, 34.0811323214315) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel550.Parent = workspace.devices.p2p1t
newmodel551 = workspace.prefabs.p2p1t_cyan:clone()
newmodel551:PivotTo(CFrame.new(-44.129445532089534, 2.646795347717737, 33.60555624869013) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel551.Parent = workspace.devices.p2p1t
newmodel552 = workspace.prefabs.p2p1t_red:clone()
newmodel552:PivotTo(CFrame.new(-44.20813617774684, 2.64679517759379, 33.600677648119714) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel552.Parent = workspace.devices.p2p1t
newmodel553 = workspace.prefabs.p2p1t_cyan:clone()
newmodel553:PivotTo(CFrame.new(-44.32471022893364, 2.64679535858181, 33.59345372518227) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel553.Parent = workspace.devices.p2p1t
newmodel554 = workspace.prefabs.p2p1t_red:clone()
newmodel554:PivotTo(CFrame.new(-44.403402018925306, 2.6467952000759207, 33.588574474191084) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel554.Parent = workspace.devices.p2p1t
newmodel555 = workspace.prefabs.p2p1t:clone()
newmodel555:PivotTo(CFrame.new(-43.9694032500925, 2.632034568088887, 33.44643873245315) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel555.Parent = workspace.devices.p2p1t
newmodel556 = workspace.prefabs.p2p1t_red:clone()
newmodel556:PivotTo(CFrame.new(-44.045177416756594, 2.6320345692198623, 33.441739181819685) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel556.Parent = workspace.devices.p2p1t
newmodel557 = workspace.prefabs.p2p1t:clone()
newmodel557:PivotTo(CFrame.new(-43.79259414145581, 2.632034561777203, 33.45739987801628) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel557.Parent = workspace.devices.p2p1t
newmodel558 = workspace.prefabs.p2p1t_red:clone()
newmodel558:PivotTo(CFrame.new(-43.86836943445776, 2.6320345490767583, 33.45269938663043) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel558.Parent = workspace.devices.p2p1t
newmodel559 = workspace.prefabs.p2p1t:clone()
newmodel559:PivotTo(CFrame.new(-44.14620822444918, 2.632034549328086, 33.43547668154949) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel559.Parent = workspace.devices.p2p1t
newmodel560 = workspace.prefabs.p2p1t_red:clone()
newmodel560:PivotTo(CFrame.new(-44.22198280028754, 2.632034537835693, 33.43078000547031) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel560.Parent = workspace.devices.p2p1t
newmodel561 = workspace.prefabs.p2p1t:clone()
newmodel561:PivotTo(CFrame.new(-43.960952068996235, 2.6210361119535235, 33.304815825898956) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel561.Parent = workspace.devices.p2p1t
newmodel562 = workspace.prefabs.p2p1t_red:clone()
newmodel562:PivotTo(CFrame.new(-44.03672862274209, 2.6210360925644025, 33.30011757648429) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel562.Parent = workspace.devices.p2p1t
newmodel563 = workspace.prefabs.p2p1t:clone()
newmodel563:PivotTo(CFrame.new(-44.138242914986876, 2.6210361098658246, 33.29382452882916) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel563.Parent = workspace.devices.p2p1t
newmodel564 = workspace.prefabs.p2p1t_red:clone()
newmodel564:PivotTo(CFrame.new(-44.21402174006697, 2.6210360911050232, 33.289124688355145) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel564.Parent = workspace.devices.p2p1t
newmodel565 = workspace.prefabs.p2p1t:clone()
newmodel565:PivotTo(CFrame.new(-43.78268768956157, 2.6210361096144963, 33.31586456760057) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel565.Parent = workspace.devices.p2p1t
newmodel566 = workspace.prefabs.p2p1t_red:clone()
newmodel566:PivotTo(CFrame.new(-43.85846154480241, 2.621036076770948, 33.31116474435936) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel566.Parent = workspace.devices.p2p1t
newmodel567 = workspace.prefabs.p2p1t:clone()
newmodel567:PivotTo(CFrame.new(-44.31310746618506, 2.6210360940723696, 33.282982467164565) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel567.Parent = workspace.devices.p2p1t
newmodel568 = workspace.prefabs.p2p1t_red:clone()
newmodel568:PivotTo(CFrame.new(-44.38887806213209, 2.621036098624759, 33.27828835914141) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel568.Parent = workspace.devices.p2p1t
newmodel569 = workspace.prefabs.p2p1t:clone()
newmodel569:PivotTo(CFrame.new(-44.30432412057647, 2.6086167253637016, 33.14130360075583) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel569.Parent = workspace.devices.p2p1t
newmodel570 = workspace.prefabs.p2p1t_red:clone()
newmodel570:PivotTo(CFrame.new(-44.380102130741975, 2.6086167544088443, 33.136604973641944) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel570.Parent = workspace.devices.p2p1t
newmodel571 = workspace.prefabs.p2p1t:clone()
newmodel571:PivotTo(CFrame.new(-43.95168259696591, 2.6086167206856485, 33.163160129858085) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel571.Parent = workspace.devices.p2p1t
newmodel572 = workspace.prefabs.p2p1t_red:clone()
newmodel572:PivotTo(CFrame.new(-44.02745676098187, 2.608616710449894, 33.15846057876944) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel572.Parent = workspace.devices.p2p1t
newmodel573 = workspace.prefabs.p2p1t:clone()
newmodel573:PivotTo(CFrame.new(-43.77390265405221, 2.608616726243349, 33.17418029399338) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel573.Parent = workspace.devices.p2p1t
newmodel574 = workspace.prefabs.p2p1t_red:clone()
newmodel574:PivotTo(CFrame.new(-43.84967652728956, 2.608616718849277, 33.16948076108378) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel574.Parent = workspace.devices.p2p1t
newmodel575 = workspace.prefabs.p2p1t:clone()
newmodel575:PivotTo(CFrame.new(-44.12946057798251, 2.6086167399491047, 33.15214182904852) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel575.Parent = workspace.devices.p2p1t
newmodel576 = workspace.prefabs.p2p1t_red:clone()
newmodel576:PivotTo(CFrame.new(-44.20523825806622, 2.6086167067285646, 33.14744263888146) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel576.Parent = workspace.devices.p2p1t
newmodel577 = workspace.prefabs.p2p1t:clone()
newmodel577:PivotTo(CFrame.new(-43.94289942440231, 2.5961973617586662, 33.021478352650774) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel577.Parent = workspace.devices.p2p1t
newmodel578 = workspace.prefabs.p2p1t_red:clone()
newmodel578:PivotTo(CFrame.new(-44.01867329962578, 2.5961973628896415, 33.016778820082564) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel578.Parent = workspace.devices.p2p1t
newmodel579 = workspace.prefabs.p2p1t:clone()
newmodel579:PivotTo(CFrame.new(-44.295543647179926, 2.5961973827328304, 32.999623397488875) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel579.Parent = workspace.devices.p2p1t
newmodel580 = workspace.prefabs.p2p1t_red:clone()
newmodel580:PivotTo(CFrame.new(-44.371322472260005, 2.5961973639720295, 32.99492355701485) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel580.Parent = workspace.devices.p2p1t
newmodel581 = workspace.prefabs.p2p1t:clone()
newmodel581:PivotTo(CFrame.new(-43.765121458734065, 2.5961973565779575, 33.032496943336795) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel581.Parent = workspace.devices.p2p1t
newmodel582 = workspace.prefabs.p2p1t_red:clone()
newmodel582:PivotTo(CFrame.new(-43.84089617427477, 2.5961973749617666, 33.02780345089153) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel582.Parent = workspace.devices.p2p1t
newmodel583 = workspace.prefabs.p2p1t:clone()
newmodel583:PivotTo(CFrame.new(-44.120681653998616, 2.5961973709120327, 33.01045688733258) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel583.Parent = workspace.devices.p2p1t
newmodel584 = workspace.prefabs.p2p1t_red:clone()
newmodel584:PivotTo(CFrame.new(-44.196453670372286, 2.5961973729997316, 33.005761820946965) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel584.Parent = workspace.devices.p2p1t
newmodel585 = workspace.prefabs.p2p1t:clone()
newmodel585:PivotTo(CFrame.new(-43.756339841003154, 2.583778002329029, 32.8908173904906) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel585.Parent = workspace.devices.p2p1t
newmodel586 = workspace.prefabs.p2p1t_red:clone()
newmodel586:PivotTo(CFrame.new(-43.83211795090577, 2.5837779933013265, 32.88612136566462) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel586.Parent = workspace.devices.p2p1t
newmodel587 = workspace.prefabs.p2p1t:clone()
newmodel587:PivotTo(CFrame.new(-44.286759755342885, 2.5837780081380575, 32.857938473347126) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel587.Parent = workspace.devices.p2p1t
newmodel588 = workspace.prefabs.p2p1t_red:clone()
newmodel588:PivotTo(CFrame.new(-44.36253774552577, 2.5837780032086766, 32.853239555560236) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel588.Parent = workspace.devices.p2p1t
newmodel589 = workspace.prefabs.p2p1t:clone()
newmodel589:PivotTo(CFrame.new(-43.934117084087774, 2.583777977633536, 32.879795652301155) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel589.Parent = workspace.devices.p2p1t
newmodel590 = workspace.prefabs.p2p1t_red:clone()
newmodel590:PivotTo(CFrame.new(-44.00989294462488, 2.5837780104770838, 32.87510150954893) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel590.Parent = workspace.devices.p2p1t
newmodel591 = workspace.prefabs.p2p1t:clone()
newmodel591:PivotTo(CFrame.new(-44.11189392341818, 2.5837779966456647, 32.868778002367534) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel591.Parent = workspace.devices.p2p1t
newmodel592 = workspace.prefabs.p2p1t_red:clone()
newmodel592:PivotTo(CFrame.new(-44.187677001835965, 2.583777996017345, 32.86408196008117) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel592.Parent = workspace.devices.p2p1t
newmodel593 = workspace.prefabs.p2p1t:clone()
newmodel593:PivotTo(CFrame.new(-44.10311546765132, 2.5713588166190045, 32.72709623259276) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel593.Parent = workspace.devices.p2p1t
newmodel594 = workspace.prefabs.p2p1t_red:clone()
newmodel594:PivotTo(CFrame.new(-44.17889046855059, 2.571358801076877, 32.72239575915836) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel594.Parent = workspace.devices.p2p1t
newmodel595 = workspace.prefabs.p2p1t:clone()
newmodel595:PivotTo(CFrame.new(-43.74755612461844, 2.5713588110613035, 32.74913565612766) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel595.Parent = workspace.devices.p2p1t
newmodel596 = workspace.prefabs.p2p1t_red:clone()
newmodel596:PivotTo(CFrame.new(-43.823332973115114, 2.5713588058805943, 32.74443738921671) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel596.Parent = workspace.devices.p2p1t
newmodel597 = workspace.prefabs.p2p1t:clone()
newmodel597:PivotTo(CFrame.new(-43.92533635963483, 2.571358808345285, 32.73811547404091) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel597.Parent = workspace.devices.p2p1t
newmodel598 = workspace.prefabs.p2p1t_red:clone()
newmodel598:PivotTo(CFrame.new(-44.00111178836689, 2.571358808470949, 32.73341816560621) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel598.Parent = workspace.devices.p2p1t
newmodel599 = workspace.prefabs.p2p1t:clone()
newmodel599:PivotTo(CFrame.new(-44.27798015722777, 2.571358825018387, 32.71625735433449) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel599.Parent = workspace.devices.p2p1t
newmodel600 = workspace.prefabs.p2p1t_red:clone()
newmodel600:PivotTo(CFrame.new(-44.35375432124373, 2.571358814782633, 32.71155780324584) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel600.Parent = workspace.devices.p2p1t
newmodel601 = workspace.prefabs.p2p1t:clone()
newmodel601:PivotTo(CFrame.new(-59.417195137417586, 2.733671944094913, 28.56094119222865) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel601.Parent = workspace.devices.p2p1t
newmodel602 = workspace.prefabs.p2p1t:clone()
newmodel602:PivotTo(CFrame.new(-59.483660517780734, 2.733671944094913, 28.503878829736536) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel602.Parent = workspace.devices.p2p1t
newmodel603 = workspace.prefabs.p2p1t:clone()
newmodel603:PivotTo(CFrame.new(-59.55012589814388, 2.733671944094913, 28.44681646724441) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel603.Parent = workspace.devices.p2p1t
newmodel604 = workspace.prefabs.p2p1t:clone()
newmodel604:PivotTo(CFrame.new(-59.32070421191838, 2.7117853939761214, 28.314069779099867) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel604.Parent = workspace.devices.p2p1t
newmodel605 = workspace.prefabs.p2p1t:clone()
newmodel605:PivotTo(CFrame.new(-59.254238831555234, 2.7117853939761214, 28.371132141591982) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel605.Parent = workspace.devices.p2p1t
newmodel606 = workspace.prefabs.p2p1t:clone()
newmodel606:PivotTo(CFrame.new(-59.38716959228153, 2.7117853939761214, 28.257007416607742) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel606.Parent = workspace.devices.p2p1t
newmodel607 = workspace.prefabs.p2p1t:clone()
newmodel607:PivotTo(CFrame.new(-59.22421328641918, 2.6898988438573292, 28.067198365971073) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel607.Parent = workspace.devices.p2p1t
newmodel608 = workspace.prefabs.p2p1t:clone()
newmodel608:PivotTo(CFrame.new(-59.29067866678232, 2.6898988438573292, 28.01013600347896) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel608.Parent = workspace.devices.p2p1t
newmodel609 = workspace.prefabs.p2p1t:clone()
newmodel609:PivotTo(CFrame.new(-59.35714404714547, 2.6898988438573292, 27.953073640986837) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel609.Parent = workspace.devices.p2p1t
newmodel610 = workspace.prefabs.p2p1t:clone()
newmodel610:PivotTo(CFrame.new(-59.377841342011024, 2.7016056032231948, 28.111661774749738) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel610.Parent = workspace.devices.p2p1t
newmodel611 = workspace.prefabs.p2p1t:clone()
newmodel611:PivotTo(CFrame.new(-59.05003388952048, 2.6575780082167877, 27.729836591492255) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel611.Parent = workspace.devices.p2p1t
newmodel612 = workspace.prefabs.p2p1t:clone()
newmodel612:PivotTo(CFrame.new(-58.98356850915733, 2.6575780082167877, 27.78689895398437) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel612.Parent = workspace.devices.p2p1t
newmodel613 = workspace.prefabs.p2p1t:clone()
newmodel613:PivotTo(CFrame.new(-59.116499269883626, 2.6575780082167877, 27.67277422900013) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel613.Parent = workspace.devices.p2p1t
newmodel614 = workspace.prefabs.p2p1t:clone()
newmodel614:PivotTo(CFrame.new(-59.19987226358064, 2.6687757780450068, 27.769885836302613) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel614.Parent = workspace.devices.p2p1t
newmodel615 = workspace.prefabs.p2p1t:clone()
newmodel615:PivotTo(CFrame.new(-59.133406883217496, 2.6687757780450068, 27.826948198794735) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel615.Parent = workspace.devices.p2p1t
newmodel616 = workspace.prefabs.p2p1t:clone()
newmodel616:PivotTo(CFrame.new(-59.06694150285435, 2.6687757780450068, 27.884010561286857) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel616.Parent = workspace.devices.p2p1t
newmodel617 = workspace.prefabs.p2p1t:clone()
newmodel617:PivotTo(CFrame.new(-58.91710312879418, 2.6575780082167877, 27.843961316476495) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel617.Parent = workspace.devices.p2p1t
newmodel618 = workspace.prefabs.p2p1t:clone()
newmodel618:PivotTo(CFrame.new(-58.85063774843103, 2.6575780082167877, 27.90102367896861) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel618.Parent = workspace.devices.p2p1t
newmodel619 = workspace.prefabs.p2p1t:clone()
newmodel619:PivotTo(CFrame.new(-58.90602599131654, 2.6382364057862278, 27.562098360697057) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel619.Parent = workspace.devices.p2p1t
newmodel620 = workspace.prefabs.p2p1t:clone()
newmodel620:PivotTo(CFrame.new(-59.69862405496127, 2.7107674149008285, 27.97427974870898) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel620.Parent = workspace.devices.p2p1t
newmodel621 = workspace.prefabs.p2p1t:clone()
newmodel621:PivotTo(CFrame.new(-60.09237273275228, 2.7288365434872732, 27.90843935586418) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel621.Parent = workspace.devices.p2p1t
newmodel622 = workspace.prefabs.p2p1t:clone()
newmodel622:PivotTo(CFrame.new(-59.30038682222167, 2.6575780082167877, 27.514901692771932) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel622.Parent = workspace.devices.p2p1t
newmodel623 = workspace.prefabs.p2p1t:clone()
newmodel623:PivotTo(CFrame.new(-59.36685220258481, 2.6575780082167877, 27.457839330279814) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel623.Parent = workspace.devices.p2p1t
newmodel624 = workspace.prefabs.p2p1t:clone()
newmodel624:PivotTo(CFrame.new(-59.433317582947964, 2.6575780082167877, 27.400776967787692) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel624.Parent = workspace.devices.p2p1t
newmodel625 = workspace.prefabs.p2p1t:clone()
newmodel625:PivotTo(CFrame.new(-59.49756745063234, 2.6575780082167877, 27.345616684045314) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel625.Parent = workspace.devices.p2p1t
newmodel626 = workspace.prefabs.p2p1t:clone()
newmodel626:PivotTo(CFrame.new(-59.56181731831671, 2.6575780082167877, 27.29045640030293) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel626.Parent = workspace.devices.p2p1t
newmodel627 = workspace.prefabs.p2p1t:clone()
newmodel627:PivotTo(CFrame.new(-59.236136954537294, 2.6575780082167877, 27.57006197651431) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel627.Parent = workspace.devices.p2p1t
newmodel628 = workspace.prefabs.p2p1t:clone()
newmodel628:PivotTo(CFrame.new(-60.0281228650679, 2.7288365434872732, 27.963599639606556) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel628.Parent = workspace.devices.p2p1t
newmodel629 = workspace.prefabs.p2p1t:clone()
newmodel629:PivotTo(CFrame.new(-59.6343741872769, 2.7107674149008285, 28.02944003245136) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel629.Parent = workspace.devices.p2p1t
newmodel630 = workspace.prefabs.p2p1t:clone()
newmodel630:PivotTo(CFrame.new(-59.444306722374165, 2.7016056032231948, 28.054599412257616) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel630.Parent = workspace.devices.p2p1t
newmodel631 = workspace.prefabs.p2p1t:clone()
newmodel631:PivotTo(CFrame.new(-59.15774790605603, 2.6898988438573292, 28.1242607284632) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel631.Parent = workspace.devices.p2p1t
newmodel632 = workspace.prefabs.p2p1t:clone()
newmodel632:PivotTo(CFrame.new(-59.091282525692876, 2.6898988438573292, 28.181323090955317) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel632.Parent = workspace.devices.p2p1t
newmodel633 = workspace.prefabs.p2p1t:clone()
newmodel633:PivotTo(CFrame.new(-58.834959315563516, 2.619912903522125, 27.347076816494635) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel633.Parent = workspace.devices.p2p1t
newmodel634 = workspace.prefabs.p2p1t:clone()
newmodel634:PivotTo(CFrame.new(-58.5690941227646, 2.619912855056834, 27.575327246052005) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel634.Parent = workspace.devices.p2p1t
newmodel635 = workspace.prefabs.p2p1t:clone()
newmodel635:PivotTo(CFrame.new(-58.768490388010214, 2.6199128780366174, 27.404140784482884) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel635.Parent = workspace.devices.p2p1t
newmodel636 = workspace.prefabs.p2p1t:clone()
newmodel636:PivotTo(CFrame.new(-58.702026047705615, 2.619912850081416, 27.4612011633048) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel636.Parent = workspace.devices.p2p1t
newmodel637 = workspace.prefabs.p2p1t:clone()
newmodel637:PivotTo(CFrame.new(-58.6355591373114, 2.61991279170132, 27.518263006981563) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel637.Parent = workspace.devices.p2p1t
newmodel638 = workspace.prefabs.p2p1t:clone()
newmodel638:PivotTo(CFrame.new(-58.707742786140386, 2.639167121840168, 27.73347528288224) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel638.Parent = workspace.devices.p2p1t
newmodel639 = workspace.prefabs.p2p1t:clone()
newmodel639:PivotTo(CFrame.new(-58.84067015589987, 2.639167093884967, 27.6193523783853) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel639.Parent = workspace.devices.p2p1t
newmodel640 = workspace.prefabs.p2p1t:clone()
newmodel640:PivotTo(CFrame.new(-58.77421099629738, 2.639167254779479, 27.67641558415291) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel640.Parent = workspace.devices.p2p1t
newmodel641 = workspace.prefabs.p2p1t:clone()
newmodel641:PivotTo(CFrame.new(-59.288027754235316, 2.619912822126215, 26.958101442615707) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel641.Parent = workspace.devices.p2p1t
newmodel642 = workspace.prefabs.p2p1t:clone()
newmodel642:PivotTo(CFrame.new(-59.02216754600227, 2.619912931477326, 27.186354477267162) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel642.Parent = workspace.devices.p2p1t
newmodel643 = workspace.prefabs.p2p1t:clone()
newmodel643:PivotTo(CFrame.new(-59.221562541334926, 2.6199128525871402, 27.015165459453407) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel643.Parent = workspace.devices.p2p1t
newmodel644 = workspace.prefabs.p2p1t:clone()
newmodel644:PivotTo(CFrame.new(-59.155101636649725, 2.61991293706116, 27.0722269003082) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel644.Parent = workspace.devices.p2p1t
newmodel645 = workspace.prefabs.p2p1t:clone()
newmodel645:PivotTo(CFrame.new(-59.08863125856892, 2.61991279170132, 27.129288092868155) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel645.Parent = workspace.devices.p2p1t
newmodel646 = workspace.prefabs.p2p1t:clone()
newmodel646:PivotTo(CFrame.new(-59.160816209378055, 2.63916719826066, 27.344502514097393) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel646.Parent = workspace.devices.p2p1t
newmodel647 = workspace.prefabs.p2p1t:clone()
newmodel647:PivotTo(CFrame.new(-59.293744673284635, 2.6391671118893316, 27.2303757813768) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel647.Parent = workspace.devices.p2p1t
newmodel648 = workspace.prefabs.p2p1t:clone()
newmodel648:PivotTo(CFrame.new(-59.22728011142878, 2.6391670839341304, 27.28743635040659) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel648.Parent = workspace.devices.p2p1t
newmodel649 = workspace.prefabs.p2p1t:clone()
newmodel649:PivotTo(CFrame.new(-59.41652904283281, 2.6199128476117224, 26.847780981505686) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel649.Parent = workspace.devices.p2p1t
newmodel650 = workspace.prefabs.p2p1t:clone()
newmodel650:PivotTo(CFrame.new(-59.54946335724892, 2.619912855056834, 26.733653214719986) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel650.Parent = workspace.devices.p2p1t
newmodel651 = workspace.prefabs.p2p1t:clone()
newmodel651:PivotTo(CFrame.new(-59.48299446841495, 2.619912809705684, 26.790716772935568) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel651.Parent = workspace.devices.p2p1t
newmodel652 = workspace.prefabs.p2p1t:clone()
newmodel652:PivotTo(CFrame.new(-59.555173562062414, 2.63916711686475, 27.0059322270865) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel652.Parent = workspace.devices.p2p1t
newmodel653 = workspace.prefabs.p2p1t:clone()
newmodel653:PivotTo(CFrame.new(-59.68810787426114, 2.6391671224485838, 26.891804459919666) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel653.Parent = workspace.devices.p2p1t
newmodel654 = workspace.prefabs.p2p1t:clone()
newmodel654:PivotTo(CFrame.new(-59.62164092514758, 2.6391670839341304, 26.948866713369096) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel654.Parent = workspace.devices.p2p1t
newmodel655 = workspace.prefabs.p2p1t:clone()
newmodel655:PivotTo(CFrame.new(-58.27396585406535, 2.5807205619382696, 27.238287093966537) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel655.Parent = workspace.devices.p2p1t
newmodel656 = workspace.prefabs.p2p1t:clone()
newmodel656:PivotTo(CFrame.new(-58.34264781614428, 2.5807205818039125, 27.17932211145797) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel656.Parent = workspace.devices.p2p1t
newmodel657 = workspace.prefabs.p2p1t:clone()
newmodel657:PivotTo(CFrame.new(-58.18111933362586, 2.5682504045652017, 27.130141362107207) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel657.Parent = workspace.devices.p2p1t
newmodel658 = workspace.prefabs.p2p1t:clone()
newmodel658:PivotTo(CFrame.new(-58.249798897360165, 2.5682504045652017, 27.0711780621126) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel658.Parent = workspace.devices.p2p1t
newmodel659 = workspace.prefabs.p2p1t:clone()
newmodel659:PivotTo(CFrame.new(-58.314048910028504, 2.568250369164889, 27.01601655400697) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel659.Parent = workspace.devices.p2p1t
newmodel660 = workspace.prefabs.p2p1t:clone()
newmodel660:PivotTo(CFrame.new(-58.38272864772523, 2.568250381585419, 26.957053472052618) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel660.Parent = workspace.devices.p2p1t
newmodel661 = workspace.prefabs.p2p1t:clone()
newmodel661:PivotTo(CFrame.new(-58.44698235184881, 2.568250435026128, 26.901892425237058) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel661.Parent = workspace.devices.p2p1t
newmodel662 = workspace.prefabs.p2p1t:clone()
newmodel662:PivotTo(CFrame.new(-58.515661305584224, 2.568250282185144, 26.842923122714446) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel662.Parent = workspace.devices.p2p1t
newmodel663 = workspace.prefabs.p2p1t:clone()
newmodel663:PivotTo(CFrame.new(-58.57991211773553, 2.568250425075291, 26.78776783784502) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel663.Parent = workspace.devices.p2p1t
newmodel664 = workspace.prefabs.p2p1t:clone()
newmodel664:PivotTo(CFrame.new(-58.648593849393656, 2.5682504374958217, 26.728803044019788) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel664.Parent = workspace.devices.p2p1t
newmodel665 = workspace.prefabs.p2p1t:clone()
newmodel665:PivotTo(CFrame.new(-58.774877746637614, 2.568250478516, 26.620386997913084) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel665.Parent = workspace.devices.p2p1t
newmodel666 = workspace.prefabs.p2p1t:clone()
newmodel666:PivotTo(CFrame.new(-58.843557499856, 2.568250503965477, 26.561423918626673) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel666.Parent = workspace.devices.p2p1t
newmodel667 = workspace.prefabs.p2p1t:clone()
newmodel667:PivotTo(CFrame.new(-58.90559229796415, 2.568250503965477, 26.50816533321828) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel667.Parent = workspace.devices.p2p1t
newmodel668 = workspace.prefabs.p2p1t:clone()
newmodel668:PivotTo(CFrame.new(-58.97427143999011, 2.5682503232053224, 26.44919583477077) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel668.Parent = workspace.devices.p2p1t
newmodel669 = workspace.prefabs.p2p1t:clone()
newmodel669:PivotTo(CFrame.new(-59.03630771404081, 2.568250412046345, 26.395939612731183) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel669.Parent = workspace.devices.p2p1t
newmodel670 = workspace.prefabs.p2p1t:clone()
newmodel670:PivotTo(CFrame.new(-59.10498576976537, 2.568250348654799, 26.336974360283833) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel670.Parent = workspace.devices.p2p1t
newmodel671 = workspace.prefabs.p2p1t:clone()
newmodel671:PivotTo(CFrame.new(-59.115889361236974, 2.578939148919107, 26.48863878433456) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel671.Parent = workspace.devices.p2p1t
newmodel672 = workspace.prefabs.p2p1t:clone()
newmodel672:PivotTo(CFrame.new(-59.18456982076476, 2.57893905760839, 26.429671433883556) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel672.Parent = workspace.devices.p2p1t
newmodel673 = workspace.prefabs.p2p1t:clone()
newmodel673:PivotTo(CFrame.new(-60.30349451800719, 2.621154790844801, 26.05611682053386) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel673.Parent = workspace.devices.p2p1t
newmodel674 = workspace.prefabs.p2p1t:clone()
newmodel674:PivotTo(CFrame.new(-60.24258418114986, 2.621154790844801, 26.119074670433022) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel674.Parent = workspace.devices.p2p1t
newmodel675 = workspace.prefabs.p2p1t:clone()
newmodel675:PivotTo(CFrame.new(-60.181673844292526, 2.621154790844801, 26.1820325203322) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel675.Parent = workspace.devices.p2p1t
newmodel676 = workspace.prefabs.p2p1t:clone()
newmodel676:PivotTo(CFrame.new(-60.9478188672169, 2.7094226517703643, 26.90158058760276) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel676.Parent = workspace.devices.p2p1t
newmodel677 = workspace.prefabs.p2p1t:clone()
newmodel677:PivotTo(CFrame.new(-61.01278989319806, 2.7094226517703643, 26.83442554771031) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel677.Parent = workspace.devices.p2p1t
newmodel678 = workspace.prefabs.p2p1t:clone()
newmodel678:PivotTo(CFrame.new(-60.44957589713108, 2.555962306169998, 24.893919218176062) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel678.Parent = workspace.devices.p2p1t
newmodel679 = workspace.prefabs.p2p1t:clone()
newmodel679:PivotTo(CFrame.new(-60.38866556027376, 2.555962306169998, 24.95687706807523) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel679.Parent = workspace.devices.p2p1t
newmodel680 = workspace.prefabs.p2p1t:clone()
newmodel680:PivotTo(CFrame.new(-60.57499104539574, 2.6616194590876834, 26.44067101000519) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel680.Parent = workspace.devices.p2p1t
newmodel681 = workspace.prefabs.p2p1t:clone()
newmodel681:PivotTo(CFrame.new(-60.51306553625744, 2.6616194590876834, 26.50467815740268) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel681.Parent = workspace.devices.p2p1t
newmodel682 = workspace.prefabs.p2p1t:clone()
newmodel682:PivotTo(CFrame.new(-60.405651699459156, 2.6410053828130073, 26.276838912487293) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel682.Parent = workspace.devices.p2p1t
newmodel683 = workspace.prefabs.p2p1t:clone()
newmodel683:PivotTo(CFrame.new(-60.34474136260182, 2.6410053828130073, 26.339796762386467) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel683.Parent = workspace.devices.p2p1t
newmodel684 = workspace.prefabs.p2p1t:clone()
newmodel684:PivotTo(CFrame.new(-61.18232366411763, 2.7094226517703643, 26.659192865490965) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel684.Parent = workspace.devices.p2p1t
newmodel685 = workspace.prefabs.p2p1t:clone()
newmodel685:PivotTo(CFrame.new(-61.35185743503721, 2.7094226517703643, 26.48396018327161) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel685.Parent = workspace.devices.p2p1t
newmodel686 = workspace.prefabs.p2p1t:clone()
newmodel686:PivotTo(CFrame.new(-61.28688640905605, 2.7094226517703643, 26.55111522316406) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel686.Parent = workspace.devices.p2p1t
newmodel687 = workspace.prefabs.p2p1t:clone()
newmodel687:PivotTo(CFrame.new(-62.193672010217796, 2.736144602496796, 26.05311575802867) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel687.Parent = workspace.devices.p2p1t
newmodel688 = workspace.prefabs.p2p1t:clone()
newmodel688:PivotTo(CFrame.new(-62.10795703264496, 2.7257103169750465, 25.970188400025787) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel688.Parent = workspace.devices.p2p1t
newmodel689 = workspace.prefabs.p2p1t:clone()
newmodel689:PivotTo(CFrame.new(-62.594474940532535, 2.731054707120333, 25.555169679003875) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel689.Parent = workspace.devices.p2p1t
newmodel690 = workspace.prefabs.p2p1t:clone()
newmodel690:PivotTo(CFrame.new(-62.53153425911329, 2.731054707120333, 25.620226123899684) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel690.Parent = workspace.devices.p2p1t
newmodel691 = workspace.prefabs.p2p1t:clone()
newmodel691:PivotTo(CFrame.new(-62.16886736950228, 2.7257103169750465, 25.90723055012662) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel691.Parent = workspace.devices.p2p1t
newmodel692 = workspace.prefabs.p2p1t:clone()
newmodel692:PivotTo(CFrame.new(-62.25458234707512, 2.736144602496796, 25.9901579081295) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel692.Parent = workspace.devices.p2p1t
newmodel693 = workspace.prefabs.p2p1t:clone()
newmodel693:PivotTo(CFrame.new(-61.117352638136474, 2.7094226517703643, 26.726347905383406) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel693.Parent = workspace.devices.p2p1t
newmodel694 = workspace.prefabs.p2p1t:clone()
newmodel694:PivotTo(CFrame.new(-60.518297318734106, 2.619373554417138, 25.80481560724315) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel694.Parent = workspace.devices.p2p1t
newmodel695 = workspace.prefabs.p2p1t:clone()
newmodel695:PivotTo(CFrame.new(-60.45941288439345, 2.6193735076876363, 25.865678250045974) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel695.Parent = workspace.devices.p2p1t
newmodel696 = workspace.prefabs.p2p1t:clone()
newmodel696:PivotTo(CFrame.new(-60.648238775690906, 2.619373521618641, 25.670505337288997) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel696.Parent = workspace.devices.p2p1t
newmodel697 = workspace.prefabs.p2p1t:clone()
newmodel697:PivotTo(CFrame.new(-60.589352350148744, 2.6193734807040876, 25.731369674329454) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel697.Parent = workspace.devices.p2p1t
newmodel698 = workspace.prefabs.p2p1t:clone()
newmodel698:PivotTo(CFrame.new(-60.40121745471152, 2.6051215739022884, 25.691545460564022) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel698.Parent = workspace.devices.p2p1t
newmodel699 = workspace.prefabs.p2p1t:clone()
newmodel699:PivotTo(CFrame.new(-60.34233579050614, 2.6051217408514935, 25.75241271876457) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel699.Parent = workspace.devices.p2p1t
newmodel700 = workspace.prefabs.p2p1t:clone()
newmodel700:PivotTo(CFrame.new(-60.53116040126641, 2.605121660667883, 25.557237599439656) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel700.Parent = workspace.devices.p2p1t
newmodel701 = workspace.prefabs.p2p1t:clone()
newmodel701:PivotTo(CFrame.new(-60.47227709919482, 2.6051215460402792, 25.618096335473783) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel701.Parent = workspace.devices.p2p1t
newmodel702 = workspace.prefabs.p2p1t:clone()
newmodel702:PivotTo(CFrame.new(-60.778180847777534, 2.6193735142696206, 25.53619484987769) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel702.Parent = workspace.devices.p2p1t
newmodel703 = workspace.prefabs.p2p1t:clone()
newmodel703:PivotTo(CFrame.new(-60.719294939374606, 2.619373380007488, 25.59705549760661) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel703.Parent = workspace.devices.p2p1t
newmodel704 = workspace.prefabs.p2p1t:clone()
newmodel704:PivotTo(CFrame.new(-60.908118614873814, 2.619373342272503, 25.401883663069533) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel704.Parent = workspace.devices.p2p1t
newmodel705 = workspace.prefabs.p2p1t:clone()
newmodel705:PivotTo(CFrame.new(-60.8492366017432, 2.6193733488544875, 25.462745018201584) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel705.Parent = workspace.devices.p2p1t
newmodel706 = workspace.prefabs.p2p1t:clone()
newmodel706:PivotTo(CFrame.new(-59.89548555724271, 2.5786542841268485, 25.779199126058856) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel706.Parent = workspace.devices.p2p1t
newmodel707 = workspace.prefabs.p2p1t:clone()
newmodel707:PivotTo(CFrame.new(-59.832547394691694, 2.578654370892443, 25.84425611073919) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel707.Parent = workspace.devices.p2p1t
newmodel708 = workspace.prefabs.p2p1t:clone()
newmodel708:PivotTo(CFrame.new(-60.06603522860088, 2.578654332390422, 25.60291834789566) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel708.Parent = workspace.devices.p2p1t
newmodel709 = workspace.prefabs.p2p1t:clone()
newmodel709:PivotTo(CFrame.new(-60.00309060970319, 2.5786540900826704, 25.66797021203699) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel709.Parent = workspace.devices.p2p1t
newmodel710 = workspace.prefabs.p2p1t:clone()
newmodel710:PivotTo(CFrame.new(-60.23658013624494, 2.5786541711447413, 25.42663464816375) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel710.Parent = workspace.devices.p2p1t
newmodel711 = workspace.prefabs.p2p1t:clone()
newmodel711:PivotTo(CFrame.new(-60.173641964184554, 2.5786542513283517, 25.491691631209555) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel711.Parent = workspace.devices.p2p1t
newmodel712 = workspace.prefabs.p2p1t:clone()
newmodel712:PivotTo(CFrame.new(-59.79513949641874, 2.566438595005383, 25.68211212474174) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel712.Parent = workspace.devices.p2p1t
newmodel713 = workspace.prefabs.p2p1t:clone()
newmodel713:PivotTo(CFrame.new(-59.732191930934164, 2.566438408310225, 25.747169375534945) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel713.Parent = workspace.devices.p2p1t
newmodel714 = workspace.prefabs.p2p1t:clone()
newmodel714:PivotTo(CFrame.new(-59.96568460709725, 2.5664384337597017, 25.505828215150327) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel714.Parent = workspace.devices.p2p1t
newmodel715 = workspace.prefabs.p2p1t:clone()
newmodel715:PivotTo(CFrame.new(-59.90274569822177, 2.5664385957724187, 25.570889094506764) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel715.Parent = workspace.devices.p2p1t
newmodel716 = workspace.prefabs.p2p1t:clone()
newmodel716:PivotTo(CFrame.new(-60.136230987698, 2.5664383805596405, 25.329546921387784) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel716.Parent = workspace.devices.p2p1t
newmodel717 = workspace.prefabs.p2p1t:clone()
newmodel717:PivotTo(CFrame.new(-60.07329409855215, 2.5664385565033614, 25.394606111410162) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel717.Parent = workspace.devices.p2p1t
newmodel718 = workspace.prefabs.p2p1t:clone()
newmodel718:PivotTo(CFrame.new(-60.40712872059102, 2.578654118711716, 25.2503514519386) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel718.Parent = workspace.devices.p2p1t
newmodel719 = workspace.prefabs.p2p1t:clone()
newmodel719:PivotTo(CFrame.new(-60.34418815474314, 2.5786541858427814, 25.315410138454208) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel719.Parent = workspace.devices.p2p1t
newmodel720 = workspace.prefabs.p2p1t:clone()
newmodel720:PivotTo(CFrame.new(-61.367133328933335, 2.637188161585483, 25.220287669511748) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel720.Parent = workspace.devices.p2p1t
newmodel721 = workspace.prefabs.p2p1t:clone()
newmodel721:PivotTo(CFrame.new(-61.42195392634964, 2.637187818345351, 25.163619180731313) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel721.Parent = workspace.devices.p2p1t
newmodel722 = workspace.prefabs.p2p1t:clone()
newmodel722:PivotTo(CFrame.new(-61.54276017645563, 2.637188263816154, 25.038761383050723) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel722.Parent = workspace.devices.p2p1t
newmodel723 = workspace.prefabs.p2p1t:clone()
newmodel723:PivotTo(CFrame.new(-61.597578570126615, 2.637187919808986, 24.982094796732895) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel723.Parent = workspace.devices.p2p1t
newmodel724 = workspace.prefabs.p2p1t:clone()
newmodel724:PivotTo(CFrame.new(-61.71839057507972, 2.6371883498147124, 24.857229901741594) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel724.Parent = workspace.devices.p2p1t
newmodel725 = workspace.prefabs.p2p1t:clone()
newmodel725:PivotTo(CFrame.new(-61.77320235497116, 2.6371879591894674, 24.800568200203408) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel725.Parent = workspace.devices.p2p1t
newmodel726 = workspace.prefabs.p2p1t:clone()
newmodel726:PivotTo(CFrame.new(-61.20198087440556, 2.6170832664800994, 25.060501263455095) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel726.Parent = workspace.devices.p2p1t
newmodel727 = workspace.prefabs.p2p1t:clone()
newmodel727:PivotTo(CFrame.new(-61.25679706781413, 2.6170829028384026, 25.003836169113043) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel727.Parent = workspace.devices.p2p1t
newmodel728 = workspace.prefabs.p2p1t:clone()
newmodel728:PivotTo(CFrame.new(-61.55322704052167, 2.6170830937159457, 24.697441976583402) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel728.Parent = workspace.devices.p2p1t
newmodel729 = workspace.prefabs.p2p1t:clone()
newmodel729:PivotTo(CFrame.new(-61.608041020675536, 2.617082722725229, 24.640778783069432) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel729.Parent = workspace.devices.p2p1t
newmodel730 = workspace.prefabs.p2p1t:clone()
newmodel730:PivotTo(CFrame.new(-61.37760274804726, 2.617083154265028, 24.87897226405895) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel730.Parent = workspace.devices.p2p1t
newmodel731 = workspace.prefabs.p2p1t:clone()
newmodel731:PivotTo(CFrame.new(-61.432421144095585, 2.6170828119033556, 24.822305678149753) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel731.Parent = workspace.devices.p2p1t
newmodel732 = workspace.prefabs.p2p1t:clone()
newmodel732:PivotTo(CFrame.new(-60.86968840225356, 2.5771273004815964, 24.7471487056757) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel732.Parent = workspace.devices.p2p1t
newmodel733 = workspace.prefabs.p2p1t:clone()
newmodel733:PivotTo(CFrame.new(-60.92450877383837, 2.577127273498048, 24.690484367363823) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel733.Parent = workspace.devices.p2p1t
newmodel734 = workspace.prefabs.p2p1t:clone()
newmodel734:PivotTo(CFrame.new(-60.985417747283904, 2.577127207134018, 24.62752594099374) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel734.Parent = workspace.devices.p2p1t
newmodel735 = workspace.prefabs.p2p1t:clone()
newmodel735:PivotTo(CFrame.new(-61.040239399405884, 2.577127274265084, 24.57086380924979) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel735.Parent = workspace.devices.p2p1t
newmodel736 = workspace.prefabs.p2p1t:clone()
newmodel736:PivotTo(CFrame.new(-61.10114616307964, 2.577127181684541, 24.50790687322097) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel736.Parent = workspace.devices.p2p1t
newmodel737 = workspace.prefabs.p2p1t:clone()
newmodel737:PivotTo(CFrame.new(-61.15596245427085, 2.5771270475338333, 24.451242451529954) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel737.Parent = workspace.devices.p2p1t
newmodel738 = workspace.prefabs.p2p1t:clone()
newmodel738:PivotTo(CFrame.new(-61.21687859472737, 2.5771272103135856, 24.38828524489331) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel738.Parent = workspace.devices.p2p1t
newmodel739 = workspace.prefabs.p2p1t:clone()
newmodel739:PivotTo(CFrame.new(-61.27169826277989, 2.5771272881960887, 24.331624808612894) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel739.Parent = workspace.devices.p2p1t
newmodel740 = workspace.prefabs.p2p1t:clone()
newmodel740:PivotTo(CFrame.new(-60.76933976719674, 2.564911392744936, 24.65005687787548) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel740.Parent = workspace.devices.p2p1t
newmodel741 = workspace.prefabs.p2p1t:clone()
newmodel741:PivotTo(CFrame.new(-60.82416028467231, 2.564911526128608, 24.593398652491587) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel741.Parent = workspace.devices.p2p1t
newmodel742 = workspace.prefabs.p2p1t:clone()
newmodel742:PivotTo(CFrame.new(-61.00080013078378, 2.5649115123090276, 24.41081987680742) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel742.Parent = workspace.devices.p2p1t
newmodel743 = workspace.prefabs.p2p1t:clone()
newmodel743:PivotTo(CFrame.new(-61.055618070543595, 2.5649114459449978, 24.35415723542725) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel743.Parent = workspace.devices.p2p1t
newmodel744 = workspace.prefabs.p2p1t:clone()
newmodel744:PivotTo(CFrame.new(-60.885065995888546, 2.5649113780468955, 24.530439715425725) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel744.Parent = workspace.devices.p2p1t
newmodel745 = workspace.prefabs.p2p1t:clone()
newmodel745:PivotTo(CFrame.new(-60.939885235204294, 2.564911418961449, 24.473779283882536) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel745.Parent = workspace.devices.p2p1t
newmodel746 = workspace.prefabs.p2p1t:clone()
newmodel746:PivotTo(CFrame.new(-61.11652465020164, 2.564911366528423, 24.291200512526977) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel746.Parent = workspace.devices.p2p1t
newmodel747 = workspace.prefabs.p2p1t:clone()
newmodel747:PivotTo(CFrame.new(-61.17134850971807, 2.5649114582305064, 24.234536890033137) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel747.Parent = workspace.devices.p2p1t
newmodel748 = workspace.prefabs.p2p1t:clone()
newmodel748:PivotTo(CFrame.new(-62.15842973768369, 2.57415933028296, 23.288257585531053) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel748.Parent = workspace.devices.p2p1t
newmodel749 = workspace.prefabs.p2p1t:clone()
newmodel749:PivotTo(CFrame.new(-62.89503738154078, 2.5741591620051123, 22.37055669018318) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel749.Parent = workspace.devices.p2p1t
