newmodel0 = workspace.prefabs.np_lamp_real:clone()
newmodel0:PivotTo(CFrame.new(-21.93294009455215, 2.7352538708059155, 27.806529682825726) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.np_l
newmodel1 = workspace.prefabs.np_lamp_real:clone()
newmodel1:PivotTo(CFrame.new(-22.04663874769193, 2.7352538708059155, 27.898119072354213) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.devices.np_l
newmodel2 = workspace.prefabs.np_lamp_real:clone()
newmodel2:PivotTo(CFrame.new(-22.160337400831708, 2.7352538708059155, 27.989708461882696) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.np_l
newmodel3 = workspace.prefabs.np_lamp_real:clone()
newmodel3:PivotTo(CFrame.new(-22.274036053971486, 2.7352538708059155, 28.08129785141118) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.np_l
newmodel4 = workspace.prefabs.np_lamp_real:clone()
newmodel4:PivotTo(CFrame.new(-21.808012546967355, 2.7288915015853363, 27.61251260081399) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.np_l
newmodel5 = workspace.prefabs.np_lamp_real:clone()
newmodel5:PivotTo(CFrame.new(-21.921711200107133, 2.7288915015853363, 27.704101990342476) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.np_l
newmodel6 = workspace.prefabs.np_lamp_real:clone()
newmodel6:PivotTo(CFrame.new(-22.14910850638669, 2.7288915015853363, 27.887280769399446) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.devices.np_l
newmodel7 = workspace.prefabs.np_lamp_real:clone()
newmodel7:PivotTo(CFrame.new(-22.37650581266624, 2.7288915015853363, 28.070459548456416) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.devices.np_l
newmodel8 = workspace.prefabs.np_lamp_real:clone()
newmodel8:PivotTo(CFrame.new(-22.49020446580602, 2.7288915015853363, 28.1620489379849) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.devices.np_l
newmodel9 = workspace.prefabs.np_lamp_real:clone()
newmodel9:PivotTo(CFrame.new(-21.796783652522336, 2.722529132364757, 27.51008490833074) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.devices.np_l
newmodel10 = workspace.prefabs.np_lamp_real:clone()
newmodel10:PivotTo(CFrame.new(-21.91048230566211, 2.722529132364757, 27.601674297859223) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.devices.np_l
newmodel11 = workspace.prefabs.np_lamp_real:clone()
newmodel11:PivotTo(CFrame.new(-22.02418095880189, 2.722529132364757, 27.693263687387706) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.devices.np_l
newmodel12 = workspace.prefabs.np_lamp_real:clone()
newmodel12:PivotTo(CFrame.new(-22.137879611941667, 2.722529132364757, 27.784853076916193) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.np_l
newmodel13 = workspace.prefabs.np_lamp_real:clone()
newmodel13:PivotTo(CFrame.new(-22.251578265081445, 2.722529132364757, 27.87644246644468) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.np_l
newmodel14 = workspace.prefabs.np_lamp_real:clone()
newmodel14:PivotTo(CFrame.new(-22.365276918221223, 2.722529132364757, 27.968031855973162) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.np_l
newmodel15 = workspace.prefabs.np_lamp_real:clone()
newmodel15:PivotTo(CFrame.new(-22.478975571360998, 2.722529132364757, 28.059621245501646) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.np_l
newmodel16 = workspace.prefabs.np_lamp_real:clone()
newmodel16:PivotTo(CFrame.new(-22.592674224500776, 2.722529132364757, 28.151210635030132) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.np_l
newmodel17 = workspace.prefabs.np_lamp_real:clone()
newmodel17:PivotTo(CFrame.new(-21.785554758077314, 2.7161667631441784, 27.407657215847486) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel17.Parent = workspace.devices.np_l
newmodel18 = workspace.prefabs.np_lamp_real:clone()
newmodel18:PivotTo(CFrame.new(-21.899253411217092, 2.7161667631441784, 27.499246605375973) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel18.Parent = workspace.devices.np_l
newmodel19 = workspace.prefabs.np_lamp_real:clone()
newmodel19:PivotTo(CFrame.new(-22.126650717496645, 2.7161667631441784, 27.68242538443294) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel19.Parent = workspace.devices.np_l
newmodel20 = workspace.prefabs.np_lamp_real:clone()
newmodel20:PivotTo(CFrame.new(-22.240349370636423, 2.7161667631441784, 27.774014773961426) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel20.Parent = workspace.devices.np_l
newmodel21 = workspace.prefabs.np_lamp_real:clone()
newmodel21:PivotTo(CFrame.new(-22.3540480237762, 2.7161667631441784, 27.86560416348991) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel21.Parent = workspace.devices.np_l
newmodel22 = workspace.prefabs.np_lamp_real:clone()
newmodel22:PivotTo(CFrame.new(-22.581445330055757, 2.7161667631441784, 28.048782942546882) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.np_l
newmodel23 = workspace.prefabs.np_lamp_real:clone()
newmodel23:PivotTo(CFrame.new(-22.695143983195535, 2.7161667631441784, 28.140372332075366) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel23.Parent = workspace.devices.np_l
newmodel24 = workspace.prefabs.np_lamp_real:clone()
newmodel24:PivotTo(CFrame.new(-21.774325863632292, 2.709804393923599, 27.305229523364233) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.np_l
newmodel25 = workspace.prefabs.np_lamp_real:clone()
newmodel25:PivotTo(CFrame.new(-21.88802451677207, 2.709804393923599, 27.39681891289272) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.np_l
newmodel26 = workspace.prefabs.np_lamp_real:clone()
newmodel26:PivotTo(CFrame.new(-22.00172316991185, 2.709804393923599, 27.488408302421202) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.np_l
newmodel27 = workspace.prefabs.np_lamp_real:clone()
newmodel27:PivotTo(CFrame.new(-22.115421823051626, 2.709804393923599, 27.57999769194969) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel27.Parent = workspace.devices.np_l
newmodel28 = workspace.prefabs.np_lamp_real:clone()
newmodel28:PivotTo(CFrame.new(-22.229120476191405, 2.709804393923599, 27.671587081478176) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel28.Parent = workspace.devices.np_l
newmodel29 = workspace.prefabs.np_lamp_real:clone()
newmodel29:PivotTo(CFrame.new(-22.342819129331183, 2.709804393923599, 27.76317647100666) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel29.Parent = workspace.devices.np_l
newmodel30 = workspace.prefabs.np_lamp_real:clone()
newmodel30:PivotTo(CFrame.new(-22.45651778247096, 2.709804393923599, 27.854765860535142) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel30.Parent = workspace.devices.np_l
newmodel31 = workspace.prefabs.np_lamp_real:clone()
newmodel31:PivotTo(CFrame.new(-22.570216435610735, 2.709804393923599, 27.946355250063625) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel31.Parent = workspace.devices.np_l
newmodel32 = workspace.prefabs.np_lamp_real:clone()
newmodel32:PivotTo(CFrame.new(-22.68391508875051, 2.709804393923599, 28.037944639592112) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel32.Parent = workspace.devices.np_l
newmodel33 = workspace.prefabs.np_lamp_real:clone()
newmodel33:PivotTo(CFrame.new(-22.79761374189029, 2.709804393923599, 28.1295340291206) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel33.Parent = workspace.devices.np_l
newmodel34 = workspace.prefabs.np_lamp_real:clone()
newmodel34:PivotTo(CFrame.new(-21.763096969187274, 2.70344202470302, 27.20280183088098) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel34.Parent = workspace.devices.np_l
newmodel35 = workspace.prefabs.np_lamp_real:clone()
newmodel35:PivotTo(CFrame.new(-21.876795622327048, 2.70344202470302, 27.294391220409466) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel35.Parent = workspace.devices.np_l
newmodel36 = workspace.prefabs.np_lamp_real:clone()
newmodel36:PivotTo(CFrame.new(-22.104192928606604, 2.70344202470302, 27.477569999466436) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel36.Parent = workspace.devices.np_l
newmodel37 = workspace.prefabs.np_lamp_real:clone()
newmodel37:PivotTo(CFrame.new(-22.33159023488616, 2.70344202470302, 27.660748778523406) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel37.Parent = workspace.devices.np_l
newmodel38 = workspace.prefabs.np_lamp_real:clone()
newmodel38:PivotTo(CFrame.new(-22.558987541165713, 2.70344202470302, 27.84392755758038) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel38.Parent = workspace.devices.np_l
newmodel39 = workspace.prefabs.np_lamp_real:clone()
newmodel39:PivotTo(CFrame.new(-22.78638484744527, 2.70344202470302, 28.027106336637345) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel39.Parent = workspace.devices.np_l
newmodel40 = workspace.prefabs.np_lamp_real:clone()
newmodel40:PivotTo(CFrame.new(-22.900083500585048, 2.70344202470302, 28.118695726165832) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel40.Parent = workspace.devices.np_l
newmodel41 = workspace.prefabs.np_lamp_real:clone()
newmodel41:PivotTo(CFrame.new(-21.86556672788203, 2.6970796554824408, 27.191963527926216) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel41.Parent = workspace.devices.np_l
newmodel42 = workspace.prefabs.np_lamp_real:clone()
newmodel42:PivotTo(CFrame.new(-21.979265381021808, 2.6970796554824408, 27.2835529174547) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel42.Parent = workspace.devices.np_l
newmodel43 = workspace.prefabs.np_lamp_real:clone()
newmodel43:PivotTo(CFrame.new(-22.092964034161586, 2.6970796554824408, 27.375142306983186) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel43.Parent = workspace.devices.np_l
newmodel44 = workspace.prefabs.np_lamp_real:clone()
newmodel44:PivotTo(CFrame.new(-22.20666268730136, 2.6970796554824408, 27.466731696511673) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel44.Parent = workspace.devices.np_l
newmodel45 = workspace.prefabs.np_lamp_real:clone()
newmodel45:PivotTo(CFrame.new(-22.32036134044114, 2.6970796554824408, 27.558321086040156) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel45.Parent = workspace.devices.np_l
newmodel46 = workspace.prefabs.np_lamp_real:clone()
newmodel46:PivotTo(CFrame.new(-22.434059993580917, 2.6970796554824408, 27.649910475568642) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel46.Parent = workspace.devices.np_l
newmodel47 = workspace.prefabs.np_lamp_real:clone()
newmodel47:PivotTo(CFrame.new(-22.547758646720695, 2.6970796554824408, 27.741499865097126) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel47.Parent = workspace.devices.np_l
newmodel48 = workspace.prefabs.np_lamp_real:clone()
newmodel48:PivotTo(CFrame.new(-22.661457299860473, 2.6970796554824408, 27.833089254625612) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel48.Parent = workspace.devices.np_l
newmodel49 = workspace.prefabs.np_lamp_real:clone()
newmodel49:PivotTo(CFrame.new(-22.77515595300025, 2.6970796554824408, 27.924678644154096) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel49.Parent = workspace.devices.np_l
newmodel50 = workspace.prefabs.np_lamp_real:clone()
newmodel50:PivotTo(CFrame.new(-22.88885460614003, 2.6970796554824408, 28.01626803368258) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel50.Parent = workspace.devices.np_l
newmodel51 = workspace.prefabs.np_lamp_real:clone()
newmodel51:PivotTo(CFrame.new(-21.854337833437008, 2.6907172862618616, 27.089535835442963) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel51.Parent = workspace.devices.np_l
newmodel52 = workspace.prefabs.np_lamp_real:clone()
newmodel52:PivotTo(CFrame.new(-22.081735139716564, 2.6907172862618616, 27.272714614499932) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel52.Parent = workspace.devices.np_l
newmodel53 = workspace.prefabs.np_lamp_real:clone()
newmodel53:PivotTo(CFrame.new(-22.195433792856342, 2.6907172862618616, 27.36430400402842) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel53.Parent = workspace.devices.np_l
newmodel54 = workspace.prefabs.np_lamp_real:clone()
newmodel54:PivotTo(CFrame.new(-22.30913244599612, 2.6907172862618616, 27.455893393556902) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel54.Parent = workspace.devices.np_l
newmodel55 = workspace.prefabs.np_lamp_real:clone()
newmodel55:PivotTo(CFrame.new(-22.536529752275676, 2.6907172862618616, 27.639072172613876) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel55.Parent = workspace.devices.np_l
newmodel56 = workspace.prefabs.np_lamp_real:clone()
newmodel56:PivotTo(CFrame.new(-22.65022840541545, 2.6907172862618616, 27.73066156214236) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel56.Parent = workspace.devices.np_l
newmodel57 = workspace.prefabs.np_lamp_real:clone()
newmodel57:PivotTo(CFrame.new(-22.76392705855523, 2.6907172862618616, 27.822250951670846) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel57.Parent = workspace.devices.np_l
newmodel58 = workspace.prefabs.np_lamp_real:clone()
newmodel58:PivotTo(CFrame.new(-22.99132436483478, 2.6907172862618616, 28.005429730727812) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel58.Parent = workspace.devices.np_l
newmodel59 = workspace.prefabs.np_lamp_real:clone()
newmodel59:PivotTo(CFrame.new(-21.84310893899199, 2.684354917041283, 26.987108142959713) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel59.Parent = workspace.devices.np_l
newmodel60 = workspace.prefabs.np_lamp_real:clone()
newmodel60:PivotTo(CFrame.new(-21.956807592131767, 2.684354917041283, 27.078697532488196) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel60.Parent = workspace.devices.np_l
newmodel61 = workspace.prefabs.np_lamp_real:clone()
newmodel61:PivotTo(CFrame.new(-22.070506245271545, 2.684354917041283, 27.17028692201668) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel61.Parent = workspace.devices.np_l
newmodel62 = workspace.prefabs.np_lamp_real:clone()
newmodel62:PivotTo(CFrame.new(-22.18420489841132, 2.684354917041283, 27.261876311545166) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel62.Parent = workspace.devices.np_l
newmodel63 = workspace.prefabs.np_lamp_real:clone()
newmodel63:PivotTo(CFrame.new(-22.297903551551098, 2.684354917041283, 27.353465701073652) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel63.Parent = workspace.devices.np_l
newmodel64 = workspace.prefabs.np_lamp_real:clone()
newmodel64:PivotTo(CFrame.new(-22.411602204690876, 2.684354917041283, 27.44505509060214) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel64.Parent = workspace.devices.np_l
newmodel65 = workspace.prefabs.np_lamp_real:clone()
newmodel65:PivotTo(CFrame.new(-22.525300857830654, 2.684354917041283, 27.536644480130622) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel65.Parent = workspace.devices.np_l
newmodel66 = workspace.prefabs.np_lamp_real:clone()
newmodel66:PivotTo(CFrame.new(-22.63899951097043, 2.684354917041283, 27.628233869659105) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel66.Parent = workspace.devices.np_l
newmodel67 = workspace.prefabs.np_lamp_real:clone()
newmodel67:PivotTo(CFrame.new(-22.752698164110207, 2.684354917041283, 27.719823259187592) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel67.Parent = workspace.devices.np_l
newmodel68 = workspace.prefabs.np_lamp_real:clone()
newmodel68:PivotTo(CFrame.new(-22.866396817249985, 2.684354917041283, 27.81141264871608) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel68.Parent = workspace.devices.np_l
newmodel69 = workspace.prefabs.np_lamp_real:clone()
newmodel69:PivotTo(CFrame.new(-22.980095470389763, 2.684354917041283, 27.903002038244562) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel69.Parent = workspace.devices.np_l
newmodel70 = workspace.prefabs.np_lamp_real:clone()
newmodel70:PivotTo(CFrame.new(-23.09379412352954, 2.684354917041283, 27.994591427773045) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel70.Parent = workspace.devices.np_l
newmodel71 = workspace.prefabs.np_lamp_real:clone()
newmodel71:PivotTo(CFrame.new(-22.059277350826523, 2.6779925478207036, 27.06785922953343) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel71.Parent = workspace.devices.np_l
newmodel72 = workspace.prefabs.np_lamp_real:clone()
newmodel72:PivotTo(CFrame.new(-22.286674657106076, 2.6779925478207036, 27.2510380085904) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel72.Parent = workspace.devices.np_l
newmodel73 = workspace.prefabs.np_lamp_real:clone()
newmodel73:PivotTo(CFrame.new(-22.514071963385632, 2.6779925478207036, 27.434216787647372) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel73.Parent = workspace.devices.np_l
newmodel74 = workspace.prefabs.np_lamp_real:clone()
newmodel74:PivotTo(CFrame.new(-22.74146926966519, 2.6779925478207036, 27.61739556670434) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel74.Parent = workspace.devices.np_l
newmodel75 = workspace.prefabs.np_lamp_real:clone()
newmodel75:PivotTo(CFrame.new(-22.968866575944745, 2.6779925478207036, 27.80057434576131) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel75.Parent = workspace.devices.np_l
newmodel76 = workspace.prefabs.np_lamp_real:clone()
newmodel76:PivotTo(CFrame.new(-21.934349803241723, 2.671630178600125, 26.873842147521692) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel76.Parent = workspace.devices.np_l
newmodel77 = workspace.prefabs.np_lamp_real:clone()
newmodel77:PivotTo(CFrame.new(-22.0480484563815, 2.671630178600125, 26.96543153705018) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel77.Parent = workspace.devices.np_l
newmodel78 = workspace.prefabs.np_lamp_real:clone()
newmodel78:PivotTo(CFrame.new(-22.16174710952128, 2.671630178600125, 27.057020926578662) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel78.Parent = workspace.devices.np_l
newmodel79 = workspace.prefabs.np_lamp_real:clone()
newmodel79:PivotTo(CFrame.new(-22.275445762661057, 2.671630178600125, 27.14861031610715) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel79.Parent = workspace.devices.np_l
newmodel80 = workspace.prefabs.np_lamp_real:clone()
newmodel80:PivotTo(CFrame.new(-22.389144415800835, 2.671630178600125, 27.240199705635632) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel80.Parent = workspace.devices.np_l
newmodel81 = workspace.prefabs.np_lamp_real:clone()
newmodel81:PivotTo(CFrame.new(-22.502843068940614, 2.671630178600125, 27.33178909516412) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel81.Parent = workspace.devices.np_l
newmodel82 = workspace.prefabs.np_lamp_real:clone()
newmodel82:PivotTo(CFrame.new(-22.61654172208039, 2.671630178600125, 27.423378484692602) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel82.Parent = workspace.devices.np_l
newmodel83 = workspace.prefabs.np_lamp_real:clone()
newmodel83:PivotTo(CFrame.new(-22.730240375220166, 2.671630178600125, 27.514967874221085) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel83.Parent = workspace.devices.np_l
newmodel84 = workspace.prefabs.np_lamp_real:clone()
newmodel84:PivotTo(CFrame.new(-22.843939028359944, 2.671630178600125, 27.606557263749572) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel84.Parent = workspace.devices.np_l
newmodel85 = workspace.prefabs.np_lamp_real:clone()
newmodel85:PivotTo(CFrame.new(-22.957637681499723, 2.671630178600125, 27.69814665327806) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel85.Parent = workspace.devices.np_l
newmodel86 = workspace.prefabs.np_lamp_real:clone()
newmodel86:PivotTo(CFrame.new(-23.071336334639497, 2.671630178600125, 27.789736042806542) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel86.Parent = workspace.devices.np_l
newmodel87 = workspace.prefabs.np_lamp_real:clone()
newmodel87:PivotTo(CFrame.new(-23.185034987779275, 2.671630178600125, 27.881325432335025) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel87.Parent = workspace.devices.np_l
newmodel88 = workspace.prefabs.np_lamp_real:clone()
newmodel88:PivotTo(CFrame.new(-22.036819561936483, 2.6652678093795457, 26.863003844566926) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel88.Parent = workspace.devices.np_l
newmodel89 = workspace.prefabs.np_lamp_real:clone()
newmodel89:PivotTo(CFrame.new(-22.15051821507626, 2.6652678093795457, 26.954593234095412) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel89.Parent = workspace.devices.np_l
newmodel90 = workspace.prefabs.np_lamp_real:clone()
newmodel90:PivotTo(CFrame.new(-22.26421686821604, 2.6652678093795457, 27.046182623623896) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel90.Parent = workspace.devices.np_l
newmodel91 = workspace.prefabs.np_lamp_real:clone()
newmodel91:PivotTo(CFrame.new(-22.491614174495595, 2.6652678093795457, 27.229361402680865) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel91.Parent = workspace.devices.np_l
newmodel92 = workspace.prefabs.np_lamp_real:clone()
newmodel92:PivotTo(CFrame.new(-22.60531282763537, 2.6652678093795457, 27.320950792209352) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel92.Parent = workspace.devices.np_l
newmodel93 = workspace.prefabs.np_lamp_real:clone()
newmodel93:PivotTo(CFrame.new(-22.719011480775148, 2.6652678093795457, 27.412540181737835) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel93.Parent = workspace.devices.np_l
newmodel94 = workspace.prefabs.np_lamp_real:clone()
newmodel94:PivotTo(CFrame.new(-22.9464087870547, 2.6652678093795457, 27.595718960794805) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel94.Parent = workspace.devices.np_l
newmodel95 = workspace.prefabs.np_lamp_real:clone()
newmodel95:PivotTo(CFrame.new(-23.06010744019448, 2.6652678093795457, 27.687308350323292) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel95.Parent = workspace.devices.np_l
newmodel96 = workspace.prefabs.np_lamp_real:clone()
newmodel96:PivotTo(CFrame.new(-23.173806093334257, 2.6652678093795457, 27.778897739851775) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel96.Parent = workspace.devices.np_l
newmodel97 = workspace.prefabs.np_lamp_real:clone()
newmodel97:PivotTo(CFrame.new(-22.02559066749146, 2.6589054401589665, 26.760576152083672) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel97.Parent = workspace.devices.np_l
newmodel98 = workspace.prefabs.np_lamp_real:clone()
newmodel98:PivotTo(CFrame.new(-22.13928932063124, 2.6589054401589665, 26.85216554161216) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel98.Parent = workspace.devices.np_l
newmodel99 = workspace.prefabs.np_lamp_real:clone()
newmodel99:PivotTo(CFrame.new(-22.252987973771017, 2.6589054401589665, 26.943754931140646) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel99.Parent = workspace.devices.np_l
newmodel100 = workspace.prefabs.np_lamp_real:clone()
newmodel100:PivotTo(CFrame.new(-22.366686626910795, 2.6589054401589665, 27.03534432066913) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel100.Parent = workspace.devices.np_l
newmodel101 = workspace.prefabs.np_lamp_real:clone()
newmodel101:PivotTo(CFrame.new(-22.480385280050573, 2.6589054401589665, 27.126933710197612) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel101.Parent = workspace.devices.np_l
newmodel102 = workspace.prefabs.np_lamp_real:clone()
newmodel102:PivotTo(CFrame.new(-22.594083933190348, 2.6589054401589665, 27.2185230997261) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel102.Parent = workspace.devices.np_l
newmodel103 = workspace.prefabs.np_lamp_real:clone()
newmodel103:PivotTo(CFrame.new(-22.707782586330126, 2.6589054401589665, 27.310112489254582) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel103.Parent = workspace.devices.np_l
newmodel104 = workspace.prefabs.np_lamp_real:clone()
newmodel104:PivotTo(CFrame.new(-22.821481239469904, 2.6589054401589665, 27.40170187878307) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel104.Parent = workspace.devices.np_l
newmodel105 = workspace.prefabs.np_lamp_real:clone()
newmodel105:PivotTo(CFrame.new(-22.935179892609682, 2.6589054401589665, 27.493291268311555) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel105.Parent = workspace.devices.np_l
newmodel106 = workspace.prefabs.np_lamp_real:clone()
newmodel106:PivotTo(CFrame.new(-23.04887854574946, 2.6589054401589665, 27.58488065784004) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel106.Parent = workspace.devices.np_l
newmodel107 = workspace.prefabs.np_lamp_real:clone()
newmodel107:PivotTo(CFrame.new(-23.162577198889235, 2.6589054401589665, 27.676470047368525) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel107.Parent = workspace.devices.np_l
newmodel108 = workspace.prefabs.np_lamp_real:clone()
newmodel108:PivotTo(CFrame.new(-23.276275852029016, 2.6589054401589665, 27.76805943689701) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel108.Parent = workspace.devices.np_l
newmodel109 = workspace.prefabs.np_lamp_real:clone()
newmodel109:PivotTo(CFrame.new(-22.241759079326, 2.6525430709383877, 26.841327238657392) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel109.Parent = workspace.devices.np_l
newmodel110 = workspace.prefabs.np_lamp_real:clone()
newmodel110:PivotTo(CFrame.new(-22.46915638560555, 2.6525430709383877, 27.024506017714362) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel110.Parent = workspace.devices.np_l
newmodel111 = workspace.prefabs.np_lamp_real:clone()
newmodel111:PivotTo(CFrame.new(-22.696553691885107, 2.6525430709383877, 27.207684796771332) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel111.Parent = workspace.devices.np_l
newmodel112 = workspace.prefabs.np_lamp_real:clone()
newmodel112:PivotTo(CFrame.new(-22.923950998164663, 2.6525430709383877, 27.390863575828302) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel112.Parent = workspace.devices.np_l
newmodel113 = workspace.prefabs.np_lamp_real:clone()
newmodel113:PivotTo(CFrame.new(-23.151348304444216, 2.6525430709383877, 27.574042354885272) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel113.Parent = workspace.devices.np_l
newmodel114 = workspace.prefabs.np_lamp_real:clone()
newmodel114:PivotTo(CFrame.new(-22.116831531741198, 2.6461807017178085, 26.647310156645656) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel114.Parent = workspace.devices.np_l
newmodel115 = workspace.prefabs.np_lamp_real:clone()
newmodel115:PivotTo(CFrame.new(-22.230530184880976, 2.6461807017178085, 26.73889954617414) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel115.Parent = workspace.devices.np_l
newmodel116 = workspace.prefabs.np_lamp_real:clone()
newmodel116:PivotTo(CFrame.new(-22.344228838020754, 2.6461807017178085, 26.830488935702625) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel116.Parent = workspace.devices.np_l
newmodel117 = workspace.prefabs.np_lamp_real:clone()
newmodel117:PivotTo(CFrame.new(-22.457927491160532, 2.6461807017178085, 26.92207832523111) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel117.Parent = workspace.devices.np_l
newmodel118 = workspace.prefabs.np_lamp_real:clone()
newmodel118:PivotTo(CFrame.new(-22.571626144300307, 2.6461807017178085, 27.013667714759595) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel118.Parent = workspace.devices.np_l
newmodel119 = workspace.prefabs.np_lamp_real:clone()
newmodel119:PivotTo(CFrame.new(-22.685324797440085, 2.6461807017178085, 27.10525710428808) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel119.Parent = workspace.devices.np_l
newmodel120 = workspace.prefabs.np_lamp_real:clone()
newmodel120:PivotTo(CFrame.new(-22.799023450579863, 2.6461807017178085, 27.196846493816565) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel120.Parent = workspace.devices.np_l
newmodel121 = workspace.prefabs.np_lamp_real:clone()
newmodel121:PivotTo(CFrame.new(-22.912722103719638, 2.6461807017178085, 27.288435883345052) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel121.Parent = workspace.devices.np_l
newmodel122 = workspace.prefabs.np_lamp_real:clone()
newmodel122:PivotTo(CFrame.new(-23.026420756859416, 2.6461807017178085, 27.380025272873535) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel122.Parent = workspace.devices.np_l
newmodel123 = workspace.prefabs.np_lamp_real:clone()
newmodel123:PivotTo(CFrame.new(-23.140119409999194, 2.6461807017178085, 27.47161466240202) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel123.Parent = workspace.devices.np_l
newmodel124 = workspace.prefabs.np_lamp_real:clone()
newmodel124:PivotTo(CFrame.new(-23.253818063138972, 2.6461807017178085, 27.563204051930505) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel124.Parent = workspace.devices.np_l
newmodel125 = workspace.prefabs.np_lamp_real:clone()
newmodel125:PivotTo(CFrame.new(-23.36751671627875, 2.6461807017178085, 27.65479344145899) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel125.Parent = workspace.devices.np_l
newmodel126 = workspace.prefabs.np_lamp_real:clone()
newmodel126:PivotTo(CFrame.new(-22.219301290435954, 2.6398183324972297, 26.636471853690885) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel126.Parent = workspace.devices.np_l
newmodel127 = workspace.prefabs.np_lamp_real:clone()
newmodel127:PivotTo(CFrame.new(-22.44669859671551, 2.6398183324972297, 26.81965063274786) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel127.Parent = workspace.devices.np_l
newmodel128 = workspace.prefabs.np_lamp_real:clone()
newmodel128:PivotTo(CFrame.new(-22.560397249855285, 2.6398183324972297, 26.911240022276342) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel128.Parent = workspace.devices.np_l
newmodel129 = workspace.prefabs.np_lamp_real:clone()
newmodel129:PivotTo(CFrame.new(-22.674095902995063, 2.6398183324972297, 27.00282941180483) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel129.Parent = workspace.devices.np_l
newmodel130 = workspace.prefabs.np_lamp_real:clone()
newmodel130:PivotTo(CFrame.new(-22.90149320927462, 2.6398183324972297, 27.1860081908618) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel130.Parent = workspace.devices.np_l
newmodel131 = workspace.prefabs.np_lamp_real:clone()
newmodel131:PivotTo(CFrame.new(-23.015191862414397, 2.6398183324972297, 27.277597580390285) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel131.Parent = workspace.devices.np_l
newmodel132 = workspace.prefabs.np_lamp_real:clone()
newmodel132:PivotTo(CFrame.new(-23.128890515554176, 2.6398183324972297, 27.36918696991877) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel132.Parent = workspace.devices.np_l
newmodel133 = workspace.prefabs.np_lamp_real:clone()
newmodel133:PivotTo(CFrame.new(-23.356287821833728, 2.6398183324972297, 27.55236574897574) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel133.Parent = workspace.devices.np_l
newmodel134 = workspace.prefabs.np_lamp_real:clone()
newmodel134:PivotTo(CFrame.new(-22.32177104913071, 2.6334559632766505, 26.625633550736122) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel134.Parent = workspace.devices.np_l
newmodel135 = workspace.prefabs.np_lamp_real:clone()
newmodel135:PivotTo(CFrame.new(-22.43546970227049, 2.6334559632766505, 26.717222940264605) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel135.Parent = workspace.devices.np_l
newmodel136 = workspace.prefabs.np_lamp_real:clone()
newmodel136:PivotTo(CFrame.new(-22.549168355410266, 2.6334559632766505, 26.808812329793092) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel136.Parent = workspace.devices.np_l
newmodel137 = workspace.prefabs.np_lamp_real:clone()
newmodel137:PivotTo(CFrame.new(-22.662867008550045, 2.6334559632766505, 26.90040171932158) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel137.Parent = workspace.devices.np_l
newmodel138 = workspace.prefabs.np_lamp_real:clone()
newmodel138:PivotTo(CFrame.new(-22.776565661689823, 2.6334559632766505, 26.991991108850062) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel138.Parent = workspace.devices.np_l
newmodel139 = workspace.prefabs.np_lamp_real:clone()
newmodel139:PivotTo(CFrame.new(-22.8902643148296, 2.6334559632766505, 27.08358049837855) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel139.Parent = workspace.devices.np_l
newmodel140 = workspace.prefabs.np_lamp_real:clone()
newmodel140:PivotTo(CFrame.new(-23.00396296796938, 2.6334559632766505, 27.175169887907032) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel140.Parent = workspace.devices.np_l
newmodel141 = workspace.prefabs.np_lamp_real:clone()
newmodel141:PivotTo(CFrame.new(-23.117661621109153, 2.6334559632766505, 27.26675927743552) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel141.Parent = workspace.devices.np_l
newmodel142 = workspace.prefabs.np_lamp_real:clone()
newmodel142:PivotTo(CFrame.new(-23.23136027424893, 2.6334559632766505, 27.358348666964) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel142.Parent = workspace.devices.np_l
newmodel143 = workspace.prefabs.np_lamp_real:clone()
newmodel143:PivotTo(CFrame.new(-23.345058927388706, 2.6334559632766505, 27.449938056492485) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel143.Parent = workspace.devices.np_l
newmodel144 = workspace.prefabs.np_lamp_real:clone()
newmodel144:PivotTo(CFrame.new(-23.458757580528484, 2.6334559632766505, 27.54152744602097) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel144.Parent = workspace.devices.np_l
newmodel145 = workspace.prefabs.np_lamp_real:clone()
newmodel145:PivotTo(CFrame.new(-22.31054215468569, 2.6270935940560713, 26.52320585825287) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel145.Parent = workspace.devices.np_l
newmodel146 = workspace.prefabs.np_lamp_real:clone()
newmodel146:PivotTo(CFrame.new(-22.42424080782547, 2.6270935940560713, 26.614795247781355) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel146.Parent = workspace.devices.np_l
newmodel147 = workspace.prefabs.np_lamp_real:clone()
newmodel147:PivotTo(CFrame.new(-22.651638114105026, 2.6270935940560713, 26.797974026838325) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel147.Parent = workspace.devices.np_l
newmodel148 = workspace.prefabs.np_lamp_real:clone()
newmodel148:PivotTo(CFrame.new(-22.87903542038458, 2.6270935940560713, 26.981152805895295) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel148.Parent = workspace.devices.np_l
newmodel149 = workspace.prefabs.np_lamp_real:clone()
newmodel149:PivotTo(CFrame.new(-23.10643272666413, 2.6270935940560713, 27.164331584952265) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel149.Parent = workspace.devices.np_l
newmodel150 = workspace.prefabs.np_lamp_real:clone()
newmodel150:PivotTo(CFrame.new(-23.333830032943688, 2.6270935940560713, 27.347510364009235) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel150.Parent = workspace.devices.np_l
newmodel151 = workspace.prefabs.np_lamp_real:clone()
newmodel151:PivotTo(CFrame.new(-23.447528686083466, 2.6270935940560713, 27.439099753537718) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel151.Parent = workspace.devices.np_l
newmodel152 = workspace.prefabs.np_lamp_real:clone()
newmodel152:PivotTo(CFrame.new(-22.413011913380448, 2.6207312248354926, 26.512367555298102) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel152.Parent = workspace.devices.np_l
newmodel153 = workspace.prefabs.np_lamp_real:clone()
newmodel153:PivotTo(CFrame.new(-22.526710566520226, 2.6207312248354926, 26.60395694482659) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel153.Parent = workspace.devices.np_l
newmodel154 = workspace.prefabs.np_lamp_real:clone()
newmodel154:PivotTo(CFrame.new(-22.640409219660004, 2.6207312248354926, 26.695546334355072) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel154.Parent = workspace.devices.np_l
newmodel155 = workspace.prefabs.np_lamp_real:clone()
newmodel155:PivotTo(CFrame.new(-22.75410787279978, 2.6207312248354926, 26.78713572388356) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel155.Parent = workspace.devices.np_l
newmodel156 = workspace.prefabs.np_lamp_real:clone()
newmodel156:PivotTo(CFrame.new(-22.867806525939557, 2.6207312248354926, 26.878725113412045) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel156.Parent = workspace.devices.np_l
newmodel157 = workspace.prefabs.np_lamp_real:clone()
newmodel157:PivotTo(CFrame.new(-22.981505179079335, 2.6207312248354926, 26.97031450294053) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel157.Parent = workspace.devices.np_l
newmodel158 = workspace.prefabs.np_lamp_real:clone()
newmodel158:PivotTo(CFrame.new(-23.095203832219113, 2.6207312248354926, 27.06190389246901) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel158.Parent = workspace.devices.np_l
newmodel159 = workspace.prefabs.np_lamp_real:clone()
newmodel159:PivotTo(CFrame.new(-23.20890248535889, 2.6207312248354926, 27.1534932819975) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel159.Parent = workspace.devices.np_l
newmodel160 = workspace.prefabs.np_lamp_real:clone()
newmodel160:PivotTo(CFrame.new(-23.32260113849867, 2.6207312248354926, 27.245082671525985) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel160.Parent = workspace.devices.np_l
newmodel161 = workspace.prefabs.np_lamp_real:clone()
newmodel161:PivotTo(CFrame.new(-23.436299791638447, 2.6207312248354926, 27.33667206105447) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel161.Parent = workspace.devices.np_l
newmodel162 = workspace.prefabs.np_lamp_real:clone()
newmodel162:PivotTo(CFrame.new(-22.515481672075204, 2.6143688556149134, 26.501529252343335) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel162.Parent = workspace.devices.np_l
newmodel163 = workspace.prefabs.np_lamp_real:clone()
newmodel163:PivotTo(CFrame.new(-22.629180325214982, 2.6143688556149134, 26.593118641871822) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel163.Parent = workspace.devices.np_l
newmodel164 = workspace.prefabs.np_lamp_real:clone()
newmodel164:PivotTo(CFrame.new(-22.856577631494538, 2.6143688556149134, 26.776297420928792) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel164.Parent = workspace.devices.np_l
newmodel165 = workspace.prefabs.np_lamp_real:clone()
newmodel165:PivotTo(CFrame.new(-22.970276284634316, 2.6143688556149134, 26.867886810457275) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel165.Parent = workspace.devices.np_l
newmodel166 = workspace.prefabs.np_lamp_real:clone()
newmodel166:PivotTo(CFrame.new(-23.08397493777409, 2.6143688556149134, 26.959476199985758) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel166.Parent = workspace.devices.np_l
newmodel167 = workspace.prefabs.np_lamp_real:clone()
newmodel167:PivotTo(CFrame.new(-23.311372244053647, 2.6143688556149134, 27.14265497904273) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel167.Parent = workspace.devices.np_l
newmodel168 = workspace.prefabs.np_lamp_real:clone()
newmodel168:PivotTo(CFrame.new(-23.425070897193425, 2.6143688556149134, 27.234244368571215) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel168.Parent = workspace.devices.np_l
newmodel169 = workspace.prefabs.np_lamp_real:clone()
newmodel169:PivotTo(CFrame.new(-22.617951430769963, 2.6080064863943346, 26.49069094938857) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel169.Parent = workspace.devices.np_l
newmodel170 = workspace.prefabs.np_lamp_real:clone()
newmodel170:PivotTo(CFrame.new(-22.73165008390974, 2.6080064863943346, 26.582280338917055) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel170.Parent = workspace.devices.np_l
newmodel171 = workspace.prefabs.np_lamp_real:clone()
newmodel171:PivotTo(CFrame.new(-22.84534873704952, 2.6080064863943346, 26.67386972844554) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel171.Parent = workspace.devices.np_l
newmodel172 = workspace.prefabs.np_lamp_real:clone()
newmodel172:PivotTo(CFrame.new(-22.959047390189294, 2.6080064863943346, 26.765459117974025) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel172.Parent = workspace.devices.np_l
newmodel173 = workspace.prefabs.np_lamp_real:clone()
newmodel173:PivotTo(CFrame.new(-23.072746043329072, 2.6080064863943346, 26.857048507502512) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel173.Parent = workspace.devices.np_l
newmodel174 = workspace.prefabs.np_lamp_real:clone()
newmodel174:PivotTo(CFrame.new(-23.18644469646885, 2.6080064863943346, 26.948637897030995) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel174.Parent = workspace.devices.np_l
newmodel175 = workspace.prefabs.np_lamp_real:clone()
newmodel175:PivotTo(CFrame.new(-23.30014334960863, 2.6080064863943346, 27.040227286559478) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel175.Parent = workspace.devices.np_l
newmodel176 = workspace.prefabs.np_lamp_real:clone()
newmodel176:PivotTo(CFrame.new(-23.413842002748403, 2.6080064863943346, 27.131816676087965) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel176.Parent = workspace.devices.np_l
newmodel177 = workspace.prefabs.np_lamp_real:clone()
newmodel177:PivotTo(CFrame.new(-22.720421189464716, 2.6016441171737554, 26.4798526464338) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel177.Parent = workspace.devices.np_l
newmodel178 = workspace.prefabs.np_lamp_real:clone()
newmodel178:PivotTo(CFrame.new(-22.834119842604494, 2.6016441171737554, 26.571442035962285) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel178.Parent = workspace.devices.np_l
newmodel179 = workspace.prefabs.np_lamp_real:clone()
newmodel179:PivotTo(CFrame.new(-23.06151714888405, 2.6016441171737554, 26.75462081501926) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel179.Parent = workspace.devices.np_l
newmodel180 = workspace.prefabs.np_lamp_real:clone()
newmodel180:PivotTo(CFrame.new(-23.288914455163606, 2.6016441171737554, 26.93779959407623) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel180.Parent = workspace.devices.np_l
newmodel181 = workspace.prefabs.np_lamp_real:clone()
newmodel181:PivotTo(CFrame.new(-23.402613108303385, 2.6016441171737554, 27.02938898360471) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel181.Parent = workspace.devices.np_l
newmodel182 = workspace.prefabs.np_lamp_real:clone()
newmodel182:PivotTo(CFrame.new(-22.936589601299254, 2.5952817479531762, 26.560603733007518) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel182.Parent = workspace.devices.np_l
newmodel183 = workspace.prefabs.np_lamp_real:clone()
newmodel183:PivotTo(CFrame.new(-23.05028825443903, 2.5952817479531762, 26.652193122536005) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel183.Parent = workspace.devices.np_l
newmodel184 = workspace.prefabs.np_lamp_real:clone()
newmodel184:PivotTo(CFrame.new(-23.163986907578806, 2.5952817479531762, 26.74378251206449) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel184.Parent = workspace.devices.np_l
newmodel185 = workspace.prefabs.np_lamp_real:clone()
newmodel185:PivotTo(CFrame.new(-23.277685560718588, 2.5952817479531762, 26.835371901592975) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel185.Parent = workspace.devices.np_l
newmodel186 = workspace.prefabs.np_lamp_real:clone()
newmodel186:PivotTo(CFrame.new(-23.391384213858366, 2.5952817479531762, 26.92696129112146) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel186.Parent = workspace.devices.np_l
