newmodel0 = workspace.prefabs.pamir_tumbler:clone()
newmodel0:PivotTo(CFrame.new(-23.385914875505584, 3.3557134794516807, 29.522647774892555) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel0.Parent = workspace.devices.pamir
newmodel1 = workspace.prefabs.pamir_tumbler:clone()
newmodel1:PivotTo(CFrame.new(-23.402534309545157, 3.1851882949023245, 29.49758875239285) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel1.Parent = workspace.devices.pamir
newmodel2 = workspace.prefabs.pamir_tumbler:clone()
newmodel2:PivotTo(CFrame.new(-23.424766540366427, 2.954562139417709, 29.46353680230282) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel2.Parent = workspace.devices.pamir
newmodel3 = workspace.prefabs.pamir_tumbler:clone()
newmodel3:PivotTo(CFrame.new(-24.028835342496883, 3.35571080013861, 29.949043389468194) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel3.Parent = workspace.devices.pamir
newmodel4 = workspace.prefabs.pamir_tumbler:clone()
newmodel4:PivotTo(CFrame.new(-24.045453178934956, 3.1851854367549652, 29.92398252494316) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel4.Parent = workspace.devices.pamir
newmodel5 = workspace.prefabs.pamir_tumbler:clone()
newmodel5:PivotTo(CFrame.new(-23.981329703641016, 3.071597724704656, 29.857421576606313) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel5.Parent = workspace.devices.pamir
