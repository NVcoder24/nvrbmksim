newmodel0 = workspace.prefabs.ksp4:clone()
newmodel0:PivotTo(CFrame.new(-11.259770055950952, 4.86196, 24.474336721081144) * CFrame.fromEulerAngles(0, math.rad(51.260000999999995), 0))
newmodel0.Parent = workspace.devices.ksp4
newmodel1 = workspace.prefabs.ksp4:clone()
newmodel1:PivotTo(CFrame.new(-12.254626558362393, 4.86196, 25.714345569099443) * CFrame.fromEulerAngles(0, math.rad(51.260000999999995), 0))
newmodel1.Parent = workspace.devices.ksp4
