newmodel0 = workspace.prefabs.lar_rot:clone()
newmodel0:PivotTo(CFrame.new(-24.123174504274765, 2.699139975119803, 28.876043469838027) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel1 = workspace.prefabs.lar_rot:clone()
newmodel1:PivotTo(CFrame.new(-24.161800509283175, 2.6710692219507375, 28.516658577022266) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel2 = workspace.prefabs.lar_rot:clone()
newmodel2:PivotTo(CFrame.new(-24.073857607941807, 2.6849900735773073, 28.64926226382606) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel3 = workspace.prefabs.lar_rot:clone()
newmodel3:PivotTo(CFrame.new(-23.84868040439592, 2.6991399599460806, 28.693992004662462) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel4 = workspace.prefabs.lar_rot:clone()
newmodel4:PivotTo(CFrame.new(-23.938070629438723, 2.6849900697752713, 28.559207109220093) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel5 = workspace.prefabs.lar_rot:clone()
newmodel5:PivotTo(CFrame.new(-23.896520753645625, 2.7130608225333623, 28.916650780485362) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel6 = workspace.prefabs.lar_rot:clone()
newmodel6:PivotTo(CFrame.new(-23.984466298393095, 2.6991399613504172, 28.784047813949726) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel7 = workspace.prefabs.lar_rot:clone()
newmodel7:PivotTo(CFrame.new(-24.24849546469074, 2.6991399585417435, 28.959155664594938) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel8 = workspace.prefabs.lar_rot:clone()
newmodel8:PivotTo(CFrame.new(-24.337889207694193, 2.6849900707686336, 28.824371728378964) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel9 = workspace.prefabs.lar_rot:clone()
newmodel9:PivotTo(CFrame.new(-24.035227920518512, 2.713060814518315, 29.008643680949596) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel10 = workspace.prefabs.lar_rot:clone()
newmodel10:PivotTo(CFrame.new(-24.212563838310874, 2.684990067103589, 28.74125557435636) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel11 = workspace.prefabs.lar_rot:clone()
newmodel11:PivotTo(CFrame.new(-24.300508681770744, 2.671069226163748, 28.608653177880264) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.RBMKSYS.viur.larcorrector
