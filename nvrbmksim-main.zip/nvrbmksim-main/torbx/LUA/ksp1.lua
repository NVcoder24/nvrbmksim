newmodel0 = workspace.prefabs.ksp1:clone()
newmodel0:PivotTo(CFrame.new(-27.443232475254305, 3.7436000000000003, 37.22823118179939) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel0.Parent = workspace.devices.ksp1
newmodel1 = workspace.prefabs.ksp1:clone()
newmodel1:PivotTo(CFrame.new(-28.292218927550557, 3.7436000000000003, 37.57833168082422) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel1.Parent = workspace.devices.ksp1
newmodel2 = workspace.prefabs.ksp1:clone()
newmodel2:PivotTo(CFrame.new(-56.35170816449635, 3.5829999999999997, 36.433689572753146) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel2.Parent = workspace.devices.ksp1
newmodel3 = workspace.prefabs.ksp1:clone()
newmodel3:PivotTo(CFrame.new(-64.32637367526414, 3.5829999999999997, 31.08761267005957) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel3.Parent = workspace.devices.ksp1
