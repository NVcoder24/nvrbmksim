newmodel0 = workspace.prefabs.defind:clone()
newmodel0:PivotTo(CFrame.new(-11.041588260549771, 9.284297956, 24.03366083908061) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel0.Parent = workspace.devices.definds
newmodel0.RandBr.Value = 0.5639242640250677
newmodel1 = workspace.prefabs.defind:clone()
newmodel1:PivotTo(CFrame.new(-11.170487523910197, 9.284297956, 24.228479248761477) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel1.Parent = workspace.devices.definds
newmodel1.RandBr.Value = 0.024824327137209945
newmodel2 = workspace.prefabs.defind:clone()
newmodel2:PivotTo(CFrame.new(-11.299386002767763, 9.284297956, 24.423297477241785) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel2.Parent = workspace.devices.definds
newmodel2.RandBr.Value = 0.5804226148382148
newmodel3 = workspace.prefabs.defind:clone()
newmodel3:PivotTo(CFrame.new(-11.428283671945476, 9.284297956, 24.618115191052098) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel3.Parent = workspace.devices.definds
newmodel3.RandBr.Value = 0.30836823671553903
newmodel4 = workspace.prefabs.defind:clone()
newmodel4:PivotTo(CFrame.new(-11.041588260549771, 9.167498832, 24.03366083908061) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel4.Parent = workspace.devices.definds
newmodel4.RandBr.Value = 0.06971976889243922
newmodel5 = workspace.prefabs.defind:clone()
newmodel5:PivotTo(CFrame.new(-11.170487523910197, 9.167498832, 24.228479248761477) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel5.Parent = workspace.devices.definds
newmodel5.RandBr.Value = 0.05376205852163369
newmodel6 = workspace.prefabs.defind:clone()
newmodel6:PivotTo(CFrame.new(-11.299386002767763, 9.167498832, 24.423297477241785) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel6.Parent = workspace.devices.definds
newmodel6.RandBr.Value = 0.20604547100570755
newmodel7 = workspace.prefabs.defind:clone()
newmodel7:PivotTo(CFrame.new(-11.428283671945476, 9.167498832, 24.618115191052098) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel7.Parent = workspace.devices.definds
newmodel7.RandBr.Value = 0.2503073329528344
newmodel8 = workspace.prefabs.defind:clone()
newmodel8:PivotTo(CFrame.new(-11.041588260549771, 9.050699124, 24.03366083908061) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel8.Parent = workspace.devices.definds
newmodel8.RandBr.Value = 0.0688047670889147
newmodel9 = workspace.prefabs.defind:clone()
newmodel9:PivotTo(CFrame.new(-11.170487523910197, 9.050699124, 24.228479248761477) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel9.Parent = workspace.devices.definds
newmodel9.RandBr.Value = 0.2679990609497073
newmodel10 = workspace.prefabs.defind:clone()
newmodel10:PivotTo(CFrame.new(-11.299386002767763, 9.050699124, 24.423297477241785) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel10.Parent = workspace.devices.definds
newmodel10.RandBr.Value = 0.39628118103887816
newmodel11 = workspace.prefabs.defind:clone()
newmodel11:PivotTo(CFrame.new(-11.428283671945476, 9.050699124, 24.618115191052098) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel11.Parent = workspace.devices.definds
newmodel11.RandBr.Value = 0.18631805898216272
newmodel12 = workspace.prefabs.defind:clone()
newmodel12:PivotTo(CFrame.new(-11.041588260549771, 8.933896204, 24.03366083908061) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel12.Parent = workspace.devices.definds
newmodel12.RandBr.Value = 0.3087382783464418
newmodel13 = workspace.prefabs.defind:clone()
newmodel13:PivotTo(CFrame.new(-11.170487523910197, 8.933896204, 24.228479248761477) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel13.Parent = workspace.devices.definds
newmodel13.RandBr.Value = 0.18549588030385686
newmodel14 = workspace.prefabs.defind:clone()
newmodel14:PivotTo(CFrame.new(-11.299386002767763, 8.933896204, 24.423297477241785) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel14.Parent = workspace.devices.definds
newmodel14.RandBr.Value = 0.06590128114086892
newmodel15 = workspace.prefabs.defind:clone()
newmodel15:PivotTo(CFrame.new(-11.428283671945476, 8.933896204, 24.618115191052098) * CFrame.fromEulerAngles(0, math.rad(-33.490001), 0))
newmodel15.Parent = workspace.devices.definds
newmodel15.RandBr.Value = 0.06338951609384953
newmodel16 = workspace.prefabs.defind:clone()
newmodel16:PivotTo(CFrame.new(-11.936731553079701, 9.5018393576, 25.318113621778945) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel16.Parent = workspace.devices.definds
newmodel16.RandBr.Value = 0.06719473397253257
newmodel17 = workspace.prefabs.defind:clone()
newmodel17:PivotTo(CFrame.new(-11.936731553079701, 9.3929578428, 25.318113621778945) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel17.Parent = workspace.devices.definds
newmodel17.RandBr.Value = 0.151941120443461
newmodel18 = workspace.prefabs.defind:clone()
newmodel18:PivotTo(CFrame.new(-11.936731553079701, 9.284074868, 25.318113621778945) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel18.Parent = workspace.devices.definds
newmodel18.RandBr.Value = 0.3574555192994028
newmodel19 = workspace.prefabs.defind:clone()
newmodel19:PivotTo(CFrame.new(-11.936731553079701, 9.1751942, 25.318113621778945) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel19.Parent = workspace.devices.definds
newmodel19.RandBr.Value = 0.3080661998080781
newmodel20 = workspace.prefabs.defind:clone()
newmodel20:PivotTo(CFrame.new(-11.936731553079701, 9.066312656000001, 25.318113621778945) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel20.Parent = workspace.devices.definds
newmodel20.RandBr.Value = 0.5136750170494057
newmodel21 = workspace.prefabs.defind:clone()
newmodel21:PivotTo(CFrame.new(-12.069550896180107, 9.5018393576, 25.48366334079931) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel21.Parent = workspace.devices.definds
newmodel21.RandBr.Value = 0.5589182030793785
newmodel22 = workspace.prefabs.defind:clone()
newmodel22:PivotTo(CFrame.new(-12.069550896180107, 9.3929578428, 25.48366334079931) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel22.Parent = workspace.devices.definds
newmodel22.RandBr.Value = 0.3945458049122991
newmodel23 = workspace.prefabs.defind:clone()
newmodel23:PivotTo(CFrame.new(-12.069550896180107, 9.284074868, 25.48366334079931) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel23.Parent = workspace.devices.definds
newmodel23.RandBr.Value = 0.35499531529887646
newmodel24 = workspace.prefabs.defind:clone()
newmodel24:PivotTo(CFrame.new(-12.069550896180107, 9.1751942, 25.48366334079931) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel24.Parent = workspace.devices.definds
newmodel24.RandBr.Value = 0.25070080077279694
newmodel25 = workspace.prefabs.defind:clone()
newmodel25:PivotTo(CFrame.new(-12.069550896180107, 9.066312656000001, 25.48366334079931) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel25.Parent = workspace.devices.definds
newmodel25.RandBr.Value = 0.4686249465947874
newmodel26 = workspace.prefabs.defind:clone()
newmodel26:PivotTo(CFrame.new(-12.20237062690179, 9.5018393576, 25.649213347811116) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel26.Parent = workspace.devices.definds
newmodel26.RandBr.Value = 0.2503475753683215
newmodel27 = workspace.prefabs.defind:clone()
newmodel27:PivotTo(CFrame.new(-12.20237062690179, 9.3929578428, 25.649213347811116) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel27.Parent = workspace.devices.definds
newmodel27.RandBr.Value = 0.07041744831749953
newmodel28 = workspace.prefabs.defind:clone()
newmodel28:PivotTo(CFrame.new(-12.20237062690179, 9.284074868, 25.649213347811116) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel28.Parent = workspace.devices.definds
newmodel28.RandBr.Value = 0.2939979092886006
newmodel29 = workspace.prefabs.defind:clone()
newmodel29:PivotTo(CFrame.new(-12.20237062690179, 9.1751942, 25.649213347811116) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel29.Parent = workspace.devices.definds
newmodel29.RandBr.Value = 0.043018927939586546
newmodel30 = workspace.prefabs.defind:clone()
newmodel30:PivotTo(CFrame.new(-12.20237062690179, 9.066312656000001, 25.649213347811116) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel30.Parent = workspace.devices.definds
newmodel30.RandBr.Value = 0.019118186398529625
newmodel31 = workspace.prefabs.defind:clone()
newmodel31:PivotTo(CFrame.new(-12.335189911625783, 9.5018393576, 25.814762963921964) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel31.Parent = workspace.devices.definds
newmodel31.RandBr.Value = 0.2825037385223236
newmodel32 = workspace.prefabs.defind:clone()
newmodel32:PivotTo(CFrame.new(-12.335189911625783, 9.3929578428, 25.814762963921964) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel32.Parent = workspace.devices.definds
newmodel32.RandBr.Value = 0.2684711343325113
newmodel33 = workspace.prefabs.defind:clone()
newmodel33:PivotTo(CFrame.new(-12.335189911625783, 9.284074868, 25.814762963921964) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel33.Parent = workspace.devices.definds
newmodel33.RandBr.Value = 0.037346357025699724
newmodel34 = workspace.prefabs.defind:clone()
newmodel34:PivotTo(CFrame.new(-12.335189911625783, 9.1751942, 25.814762963921964) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel34.Parent = workspace.devices.definds
newmodel34.RandBr.Value = 0.005342590627396748
newmodel35 = workspace.prefabs.defind:clone()
newmodel35:PivotTo(CFrame.new(-12.335189911625783, 9.066312656000001, 25.814762963921964) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel35.Parent = workspace.devices.definds
newmodel35.RandBr.Value = 0.4864343345457363
newmodel36 = workspace.prefabs.defind:clone()
newmodel36:PivotTo(CFrame.new(-12.511417807820392, 9.5018393576, 26.034413759758145) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel36.Parent = workspace.devices.definds
newmodel36.RandBr.Value = 0.386148933219025
newmodel37 = workspace.prefabs.defind:clone()
newmodel37:PivotTo(CFrame.new(-12.511417807820392, 9.3929578428, 26.034413759758145) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel37.Parent = workspace.devices.definds
newmodel37.RandBr.Value = 0.03580554069218531
newmodel38 = workspace.prefabs.defind:clone()
newmodel38:PivotTo(CFrame.new(-12.511417807820392, 9.284074868, 26.034413759758145) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel38.Parent = workspace.devices.definds
newmodel38.RandBr.Value = 0.5114464956864929
newmodel39 = workspace.prefabs.defind:clone()
newmodel39:PivotTo(CFrame.new(-12.511417807820392, 9.1751942, 26.034413759758145) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel39.Parent = workspace.devices.definds
newmodel39.RandBr.Value = 0.1729236361127996
newmodel40 = workspace.prefabs.defind:clone()
newmodel40:PivotTo(CFrame.new(-12.511417807820392, 9.066312656000001, 26.034413759758145) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel40.Parent = workspace.devices.definds
newmodel40.RandBr.Value = 0.3663101725326546
newmodel41 = workspace.prefabs.defind:clone()
newmodel41:PivotTo(CFrame.new(-12.644237517529469, 9.5018393576, 26.19996378362832) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel41.Parent = workspace.devices.definds
newmodel41.RandBr.Value = 0.20130033057429642
newmodel42 = workspace.prefabs.defind:clone()
newmodel42:PivotTo(CFrame.new(-12.644237517529469, 9.3929578428, 26.19996378362832) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel42.Parent = workspace.devices.definds
newmodel42.RandBr.Value = 0.0194034393363228
newmodel43 = workspace.prefabs.defind:clone()
newmodel43:PivotTo(CFrame.new(-12.644237517529469, 9.284074868, 26.19996378362832) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel43.Parent = workspace.devices.definds
newmodel43.RandBr.Value = 0.04919810302209022
newmodel44 = workspace.prefabs.defind:clone()
newmodel44:PivotTo(CFrame.new(-12.644237517529469, 9.1751942, 26.19996378362832) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel44.Parent = workspace.devices.definds
newmodel44.RandBr.Value = 0.29904641458312137
newmodel45 = workspace.prefabs.defind:clone()
newmodel45:PivotTo(CFrame.new(-12.644237517529469, 9.066312656000001, 26.19996378362832) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel45.Parent = workspace.devices.definds
newmodel45.RandBr.Value = 0.37740816360061324
newmodel46 = workspace.prefabs.defind:clone()
newmodel46:PivotTo(CFrame.new(-12.77705572275218, 9.5018393576, 26.365510147838943) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel46.Parent = workspace.devices.definds
newmodel46.RandBr.Value = 0.3105615871820937
newmodel47 = workspace.prefabs.defind:clone()
newmodel47:PivotTo(CFrame.new(-12.77705572275218, 9.3929578428, 26.365510147838943) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel47.Parent = workspace.devices.definds
newmodel47.RandBr.Value = 0.4902409590800596
newmodel48 = workspace.prefabs.defind:clone()
newmodel48:PivotTo(CFrame.new(-12.77705572275218, 9.284074868, 26.365510147838943) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel48.Parent = workspace.devices.definds
newmodel48.RandBr.Value = 0.34384299370973764
newmodel49 = workspace.prefabs.defind:clone()
newmodel49:PivotTo(CFrame.new(-12.77705572275218, 9.1751942, 26.365510147838943) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel49.Parent = workspace.devices.definds
newmodel49.RandBr.Value = 0.05865056288748749
newmodel50 = workspace.prefabs.defind:clone()
newmodel50:PivotTo(CFrame.new(-12.77705572275218, 9.066312656000001, 26.365510147838943) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel50.Parent = workspace.devices.definds
newmodel50.RandBr.Value = 0.454651517965867
newmodel51 = workspace.prefabs.defind:clone()
newmodel51:PivotTo(CFrame.new(-12.9098767379061, 9.5018393576, 26.53106024743941) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel51.Parent = workspace.devices.definds
newmodel51.RandBr.Value = 0.18395125515380828
newmodel52 = workspace.prefabs.defind:clone()
newmodel52:PivotTo(CFrame.new(-12.9098767379061, 9.3929578428, 26.53106024743941) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel52.Parent = workspace.devices.definds
newmodel52.RandBr.Value = 0.514088786210413
newmodel53 = workspace.prefabs.defind:clone()
newmodel53:PivotTo(CFrame.new(-12.9098767379061, 9.284074868, 26.53106024743941) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel53.Parent = workspace.devices.definds
newmodel53.RandBr.Value = 0.22243670870687918
newmodel54 = workspace.prefabs.defind:clone()
newmodel54:PivotTo(CFrame.new(-12.9098767379061, 9.1751942, 26.53106024743941) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel54.Parent = workspace.devices.definds
newmodel54.RandBr.Value = 0.07538895368686276
newmodel55 = workspace.prefabs.defind:clone()
newmodel55:PivotTo(CFrame.new(-12.9098767379061, 9.066312656000001, 26.53106024743941) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel55.Parent = workspace.devices.definds
newmodel55.RandBr.Value = 0.12639215918920635
newmodel56 = workspace.prefabs.defind_y:clone()
newmodel56:PivotTo(CFrame.new(-13.086100831052505, 9.5018393576, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel56.Parent = workspace.devices.definds
newmodel56.RandBr.Value = 0.32441553342994417
newmodel57 = workspace.prefabs.defind:clone()
newmodel57:PivotTo(CFrame.new(-13.086100831052505, 9.3929578428, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel57.Parent = workspace.devices.definds
newmodel57.RandBr.Value = 0.5294918433697651
newmodel58 = workspace.prefabs.defind:clone()
newmodel58:PivotTo(CFrame.new(-13.086100831052505, 9.284074868, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel58.Parent = workspace.devices.definds
newmodel58.RandBr.Value = 0.43499704063771544
newmodel59 = workspace.prefabs.defind:clone()
newmodel59:PivotTo(CFrame.new(-13.086100831052505, 9.1751942, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel59.Parent = workspace.devices.definds
newmodel59.RandBr.Value = 0.08876249240911557
newmodel60 = workspace.prefabs.defind:clone()
newmodel60:PivotTo(CFrame.new(-13.086100831052505, 9.066312656000001, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel60.Parent = workspace.devices.definds
newmodel60.RandBr.Value = 0.5090248876942652
newmodel61 = workspace.prefabs.defind:clone()
newmodel61:PivotTo(CFrame.new(-13.218923032513139, 9.5018393576, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel61.Parent = workspace.devices.definds
newmodel61.RandBr.Value = 0.2107981408460762
newmodel62 = workspace.prefabs.defind:clone()
newmodel62:PivotTo(CFrame.new(-13.218923032513139, 9.3929578428, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel62.Parent = workspace.devices.definds
newmodel62.RandBr.Value = 0.5543139323662977
newmodel63 = workspace.prefabs.defind:clone()
newmodel63:PivotTo(CFrame.new(-13.218923032513139, 9.284074868, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel63.Parent = workspace.devices.definds
newmodel63.RandBr.Value = 0.011976066849558343
newmodel64 = workspace.prefabs.defind:clone()
newmodel64:PivotTo(CFrame.new(-13.218923032513139, 9.1751942, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel64.Parent = workspace.devices.definds
newmodel64.RandBr.Value = 0.4146927314162318
newmodel65 = workspace.prefabs.defind:clone()
newmodel65:PivotTo(CFrame.new(-13.218923032513139, 9.066312656000001, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel65.Parent = workspace.devices.definds
newmodel65.RandBr.Value = 0.07864138707333253
newmodel66 = workspace.prefabs.defind:clone()
newmodel66:PivotTo(CFrame.new(-13.351741117934964, 9.5018393576, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel66.Parent = workspace.devices.definds
newmodel66.RandBr.Value = 0.4372435068294644
newmodel67 = workspace.prefabs.defind:clone()
newmodel67:PivotTo(CFrame.new(-13.351741117934964, 9.3929578428, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel67.Parent = workspace.devices.definds
newmodel67.RandBr.Value = 0.457603176547427
newmodel68 = workspace.prefabs.defind:clone()
newmodel68:PivotTo(CFrame.new(-13.351741117934964, 9.284074868, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel68.Parent = workspace.devices.definds
newmodel68.RandBr.Value = 0.1184757786614401
newmodel69 = workspace.prefabs.defind:clone()
newmodel69:PivotTo(CFrame.new(-13.351741117934964, 9.1751942, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel69.Parent = workspace.devices.definds
newmodel69.RandBr.Value = 0.5026227235384311
newmodel70 = workspace.prefabs.defind:clone()
newmodel70:PivotTo(CFrame.new(-13.351741117934964, 9.066312656000001, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel70.Parent = workspace.devices.definds
newmodel70.RandBr.Value = 0.14547443492577752
newmodel71 = workspace.prefabs.defind:clone()
newmodel71:PivotTo(CFrame.new(-13.48456074359278, 9.5018393576, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel71.Parent = workspace.devices.definds
newmodel71.RandBr.Value = 0.3363133713101081
newmodel72 = workspace.prefabs.defind:clone()
newmodel72:PivotTo(CFrame.new(-13.48456074359278, 9.3929578428, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel72.Parent = workspace.devices.definds
newmodel72.RandBr.Value = 0.41886589347628334
newmodel73 = workspace.prefabs.defind:clone()
newmodel73:PivotTo(CFrame.new(-13.48456074359278, 9.284074868, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel73.Parent = workspace.devices.definds
newmodel73.RandBr.Value = 0.2877163816130956
newmodel74 = workspace.prefabs.defind:clone()
newmodel74:PivotTo(CFrame.new(-13.48456074359278, 9.1751942, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel74.Parent = workspace.devices.definds
newmodel74.RandBr.Value = 0.20491587865000133
newmodel75 = workspace.prefabs.defind:clone()
newmodel75:PivotTo(CFrame.new(-13.48456074359278, 9.066312656000001, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel75.Parent = workspace.devices.definds
newmodel75.RandBr.Value = 0.008225659324021306
newmodel76 = workspace.prefabs.defind:clone()
newmodel76:PivotTo(CFrame.new(-11.936731553079701, 8.866844536, 25.318113621778945) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel76.Parent = workspace.devices.definds
newmodel76.RandBr.Value = 0.1370078605184696
newmodel77 = workspace.prefabs.defind:clone()
newmodel77:PivotTo(CFrame.new(-11.936731553079701, 8.757962992, 25.318113621778945) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel77.Parent = workspace.devices.definds
newmodel77.RandBr.Value = 0.11481903457763469
newmodel78 = workspace.prefabs.defind:clone()
newmodel78:PivotTo(CFrame.new(-11.936731553079701, 8.64907882, 25.318113621778945) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel78.Parent = workspace.devices.definds
newmodel78.RandBr.Value = 0.13539470116915323
newmodel79 = workspace.prefabs.defind:clone()
newmodel79:PivotTo(CFrame.new(-11.936731553079701, 8.54019932, 25.318113621778945) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel79.Parent = workspace.devices.definds
newmodel79.RandBr.Value = 0.42270656871968154
newmodel80 = workspace.prefabs.defind:clone()
newmodel80:PivotTo(CFrame.new(-11.936731553079701, 8.431317776, 25.318113621778945) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel80.Parent = workspace.devices.definds
newmodel80.RandBr.Value = 0.4755451243532105
newmodel81 = workspace.prefabs.defind:clone()
newmodel81:PivotTo(CFrame.new(-12.06955231362738, 8.866844536, 25.483663701032274) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel81.Parent = workspace.devices.definds
newmodel81.RandBr.Value = 0.23240273152672478
newmodel82 = workspace.prefabs.defind:clone()
newmodel82:PivotTo(CFrame.new(-12.06955231362738, 8.757962992, 25.483663701032274) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel82.Parent = workspace.devices.definds
newmodel82.RandBr.Value = 0.23357748155779168
newmodel83 = workspace.prefabs.defind:clone()
newmodel83:PivotTo(CFrame.new(-12.06955231362738, 8.64907882, 25.483663701032274) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel83.Parent = workspace.devices.definds
newmodel83.RandBr.Value = 0.23928584567090927
newmodel84 = workspace.prefabs.defind:clone()
newmodel84:PivotTo(CFrame.new(-12.06955231362738, 8.54019932, 25.483663701032274) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel84.Parent = workspace.devices.definds
newmodel84.RandBr.Value = 0.5240522209262565
newmodel85 = workspace.prefabs.defind:clone()
newmodel85:PivotTo(CFrame.new(-12.06955231362738, 8.431317776, 25.483663701032274) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel85.Parent = workspace.devices.definds
newmodel85.RandBr.Value = 0.1780952910117214
newmodel86 = workspace.prefabs.defind:clone()
newmodel86:PivotTo(CFrame.new(-12.20237062690179, 8.866844536, 25.649213347811116) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel86.Parent = workspace.devices.definds
newmodel86.RandBr.Value = 0.2427572787685346
newmodel87 = workspace.prefabs.defind:clone()
newmodel87:PivotTo(CFrame.new(-12.20237062690179, 8.757962992, 25.649213347811116) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel87.Parent = workspace.devices.definds
newmodel87.RandBr.Value = 0.07492049463040297
newmodel88 = workspace.prefabs.defind:clone()
newmodel88:PivotTo(CFrame.new(-12.20237062690179, 8.64907882, 25.649213347811116) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel88.Parent = workspace.devices.definds
newmodel88.RandBr.Value = 0.09585637916912877
newmodel89 = workspace.prefabs.defind:clone()
newmodel89:PivotTo(CFrame.new(-12.20237062690179, 8.54019932, 25.649213347811116) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel89.Parent = workspace.devices.definds
newmodel89.RandBr.Value = 0.15750559338588516
newmodel90 = workspace.prefabs.defind:clone()
newmodel90:PivotTo(CFrame.new(-12.20237062690179, 8.431317776, 25.649213347811116) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel90.Parent = workspace.devices.definds
newmodel90.RandBr.Value = 0.09468879272944743
newmodel91 = workspace.prefabs.defind:clone()
newmodel91:PivotTo(CFrame.new(-12.335190554202535, 8.866844536, 25.814760202212067) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel91.Parent = workspace.devices.definds
newmodel91.RandBr.Value = 0.012745202576898018
newmodel92 = workspace.prefabs.defind:clone()
newmodel92:PivotTo(CFrame.new(-12.335190554202535, 8.757962992, 25.814760202212067) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel92.Parent = workspace.devices.definds
newmodel92.RandBr.Value = 0.3195392079618614
newmodel93 = workspace.prefabs.defind:clone()
newmodel93:PivotTo(CFrame.new(-12.335190554202535, 8.64907882, 25.814760202212067) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel93.Parent = workspace.devices.definds
newmodel93.RandBr.Value = 0.4274281057499101
newmodel94 = workspace.prefabs.defind:clone()
newmodel94:PivotTo(CFrame.new(-12.335190554202535, 8.54019932, 25.814760202212067) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel94.Parent = workspace.devices.definds
newmodel94.RandBr.Value = 0.039857105903104935
newmodel95 = workspace.prefabs.defind:clone()
newmodel95:PivotTo(CFrame.new(-12.335190554202535, 8.431317776, 25.814760202212067) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel95.Parent = workspace.devices.definds
newmodel95.RandBr.Value = 0.3962274110867039
newmodel96 = workspace.prefabs.defind:clone()
newmodel96:PivotTo(CFrame.new(-12.511417807820392, 8.866844536, 26.034413759758145) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel96.Parent = workspace.devices.definds
newmodel96.RandBr.Value = 0.39913285218920347
newmodel97 = workspace.prefabs.defind:clone()
newmodel97:PivotTo(CFrame.new(-12.511417807820392, 8.757962992, 26.034413759758145) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel97.Parent = workspace.devices.definds
newmodel97.RandBr.Value = 0.40249363810286315
newmodel98 = workspace.prefabs.defind:clone()
newmodel98:PivotTo(CFrame.new(-12.511417807820392, 8.64907882, 26.034413759758145) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel98.Parent = workspace.devices.definds
newmodel98.RandBr.Value = 0.36986165980973995
newmodel99 = workspace.prefabs.defind:clone()
newmodel99:PivotTo(CFrame.new(-12.511417807820392, 8.54019932, 26.034413759758145) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel99.Parent = workspace.devices.definds
newmodel99.RandBr.Value = 0.0705372012333629
newmodel100 = workspace.prefabs.defind:clone()
newmodel100:PivotTo(CFrame.new(-12.511417807820392, 8.431317776, 26.034413759758145) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel100.Parent = workspace.devices.definds
newmodel100.RandBr.Value = 0.005102735953603443
newmodel101 = workspace.prefabs.defind:clone()
newmodel101:PivotTo(CFrame.new(-12.644237517529469, 8.866844536, 26.19996378362832) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel101.Parent = workspace.devices.definds
newmodel101.RandBr.Value = 0.33192991870709265
newmodel102 = workspace.prefabs.defind:clone()
newmodel102:PivotTo(CFrame.new(-12.644237517529469, 8.757962992, 26.19996378362832) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel102.Parent = workspace.devices.definds
newmodel102.RandBr.Value = 0.19403129317001555
newmodel103 = workspace.prefabs.defind:clone()
newmodel103:PivotTo(CFrame.new(-12.644237517529469, 8.64907882, 26.19996378362832) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel103.Parent = workspace.devices.definds
newmodel103.RandBr.Value = 0.32095410214414405
newmodel104 = workspace.prefabs.defind:clone()
newmodel104:PivotTo(CFrame.new(-12.644237517529469, 8.54019932, 26.19996378362832) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel104.Parent = workspace.devices.definds
newmodel104.RandBr.Value = 0.5801601954539743
newmodel105 = workspace.prefabs.defind:clone()
newmodel105:PivotTo(CFrame.new(-12.644237517529469, 8.431317776, 26.19996378362832) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel105.Parent = workspace.devices.definds
newmodel105.RandBr.Value = 0.4466101009526635
newmodel106 = workspace.prefabs.defind:clone()
newmodel106:PivotTo(CFrame.new(-12.77705572275218, 8.866844536, 26.365510147838943) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel106.Parent = workspace.devices.definds
newmodel106.RandBr.Value = 0.28267010515961766
newmodel107 = workspace.prefabs.defind:clone()
newmodel107:PivotTo(CFrame.new(-12.77705572275218, 8.757962992, 26.365510147838943) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel107.Parent = workspace.devices.definds
newmodel107.RandBr.Value = 0.13258812987318006
newmodel108 = workspace.prefabs.defind:clone()
newmodel108:PivotTo(CFrame.new(-12.77705572275218, 8.64907882, 26.365510147838943) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel108.Parent = workspace.devices.definds
newmodel108.RandBr.Value = 0.28092239915795475
newmodel109 = workspace.prefabs.defind:clone()
newmodel109:PivotTo(CFrame.new(-12.77705572275218, 8.54019932, 26.365510147838943) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel109.Parent = workspace.devices.definds
newmodel109.RandBr.Value = 0.12797857563132847
newmodel110 = workspace.prefabs.defind:clone()
newmodel110:PivotTo(CFrame.new(-12.77705572275218, 8.431317776, 26.365510147838943) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel110.Parent = workspace.devices.definds
newmodel110.RandBr.Value = 0.23864920765495584
newmodel111 = workspace.prefabs.defind:clone()
newmodel111:PivotTo(CFrame.new(-12.9098767379061, 8.866844536, 26.53106024743941) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel111.Parent = workspace.devices.definds
newmodel111.RandBr.Value = 0.21389604741970156
newmodel112 = workspace.prefabs.defind:clone()
newmodel112:PivotTo(CFrame.new(-12.9098767379061, 8.757962992, 26.53106024743941) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel112.Parent = workspace.devices.definds
newmodel112.RandBr.Value = 0.1598398541663255
newmodel113 = workspace.prefabs.defind:clone()
newmodel113:PivotTo(CFrame.new(-12.9098767379061, 8.64907882, 26.53106024743941) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel113.Parent = workspace.devices.definds
newmodel113.RandBr.Value = 0.5262225590291852
newmodel114 = workspace.prefabs.defind:clone()
newmodel114:PivotTo(CFrame.new(-12.9098767379061, 8.54019932, 26.53106024743941) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel114.Parent = workspace.devices.definds
newmodel114.RandBr.Value = 0.0849752823904459
newmodel115 = workspace.prefabs.defind:clone()
newmodel115:PivotTo(CFrame.new(-12.9098767379061, 8.431317776, 26.53106024743941) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel115.Parent = workspace.devices.definds
newmodel115.RandBr.Value = 0.4738392277312579
newmodel116 = workspace.prefabs.defind:clone()
newmodel116:PivotTo(CFrame.new(-13.086100831052505, 8.866844536, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel116.Parent = workspace.devices.definds
newmodel116.RandBr.Value = 0.39166018438361233
newmodel117 = workspace.prefabs.defind:clone()
newmodel117:PivotTo(CFrame.new(-13.086100831052505, 8.757962992, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel117.Parent = workspace.devices.definds
newmodel117.RandBr.Value = 0.39025037121020417
newmodel118 = workspace.prefabs.defind:clone()
newmodel118:PivotTo(CFrame.new(-13.086100831052505, 8.64907882, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel118.Parent = workspace.devices.definds
newmodel118.RandBr.Value = 0.36287182469689766
newmodel119 = workspace.prefabs.defind:clone()
newmodel119:PivotTo(CFrame.new(-13.086100831052505, 8.54019932, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel119.Parent = workspace.devices.definds
newmodel119.RandBr.Value = 0.194650095803755
newmodel120 = workspace.prefabs.defind:clone()
newmodel120:PivotTo(CFrame.new(-13.086100831052505, 8.431317776, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel120.Parent = workspace.devices.definds
newmodel120.RandBr.Value = 0.5259121258375364
newmodel121 = workspace.prefabs.defind:clone()
newmodel121:PivotTo(CFrame.new(-13.218923032513139, 8.866844536, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel121.Parent = workspace.devices.definds
newmodel121.RandBr.Value = 0.5590090705553135
newmodel122 = workspace.prefabs.defind:clone()
newmodel122:PivotTo(CFrame.new(-13.218923032513139, 8.757962992, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel122.Parent = workspace.devices.definds
newmodel122.RandBr.Value = 0.05635979528546466
newmodel123 = workspace.prefabs.defind:clone()
newmodel123:PivotTo(CFrame.new(-13.218923032513139, 8.64907882, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel123.Parent = workspace.devices.definds
newmodel123.RandBr.Value = 0.030228318485561245
newmodel124 = workspace.prefabs.defind:clone()
newmodel124:PivotTo(CFrame.new(-13.218923032513139, 8.54019932, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel124.Parent = workspace.devices.definds
newmodel124.RandBr.Value = 0.3350681736446513
newmodel125 = workspace.prefabs.defind:clone()
newmodel125:PivotTo(CFrame.new(-13.218923032513139, 8.431317776, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel125.Parent = workspace.devices.definds
newmodel125.RandBr.Value = 0.19478182122024848
newmodel126 = workspace.prefabs.defind:clone()
newmodel126:PivotTo(CFrame.new(-13.351741117934964, 8.866844536, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel126.Parent = workspace.devices.definds
newmodel126.RandBr.Value = 0.1574747492659451
newmodel127 = workspace.prefabs.defind:clone()
newmodel127:PivotTo(CFrame.new(-13.351741117934964, 8.757962992, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel127.Parent = workspace.devices.definds
newmodel127.RandBr.Value = 0.5349580849622766
newmodel128 = workspace.prefabs.defind:clone()
newmodel128:PivotTo(CFrame.new(-13.351741117934964, 8.64907882, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel128.Parent = workspace.devices.definds
newmodel128.RandBr.Value = 0.14742099841710501
newmodel129 = workspace.prefabs.defind:clone()
newmodel129:PivotTo(CFrame.new(-13.351741117934964, 8.54019932, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel129.Parent = workspace.devices.definds
newmodel129.RandBr.Value = 0.22836697149472632
newmodel130 = workspace.prefabs.defind:clone()
newmodel130:PivotTo(CFrame.new(-13.351741117934964, 8.431317776, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel130.Parent = workspace.devices.definds
newmodel130.RandBr.Value = 0.5274178403337698
newmodel131 = workspace.prefabs.defind:clone()
newmodel131:PivotTo(CFrame.new(-13.48456074359278, 8.866844536, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel131.Parent = workspace.devices.definds
newmodel131.RandBr.Value = 0.4412037521436641
newmodel132 = workspace.prefabs.defind:clone()
newmodel132:PivotTo(CFrame.new(-13.48456074359278, 8.757962992, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel132.Parent = workspace.devices.definds
newmodel132.RandBr.Value = 0.12975147726422664
newmodel133 = workspace.prefabs.defind:clone()
newmodel133:PivotTo(CFrame.new(-13.48456074359278, 8.64907882, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel133.Parent = workspace.devices.definds
newmodel133.RandBr.Value = 0.3334501523046009
newmodel134 = workspace.prefabs.defind:clone()
newmodel134:PivotTo(CFrame.new(-13.48456074359278, 8.54019932, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel134.Parent = workspace.devices.definds
newmodel134.RandBr.Value = 0.20840189093042608
newmodel135 = workspace.prefabs.defind:clone()
newmodel135:PivotTo(CFrame.new(-13.48456074359278, 8.431317776, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel135.Parent = workspace.devices.definds
newmodel135.RandBr.Value = 0.40029056636166305
newmodel136 = workspace.prefabs.defind:clone()
newmodel136:PivotTo(CFrame.new(-13.086100831052505, 8.23185316, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel136.Parent = workspace.devices.definds
newmodel136.RandBr.Value = 0.5151687763346486
newmodel137 = workspace.prefabs.defind:clone()
newmodel137:PivotTo(CFrame.new(-13.086100831052505, 8.122971616, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel137.Parent = workspace.devices.definds
newmodel137.RandBr.Value = 0.33643590533213974
newmodel138 = workspace.prefabs.defind:clone()
newmodel138:PivotTo(CFrame.new(-13.086100831052505, 8.014087444000001, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel138.Parent = workspace.devices.definds
newmodel138.RandBr.Value = 0.07589303321966187
newmodel139 = workspace.prefabs.defind:clone()
newmodel139:PivotTo(CFrame.new(-13.086100831052505, 7.9052058999999995, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel139.Parent = workspace.devices.definds
newmodel139.RandBr.Value = 0.2807388250842363
newmodel140 = workspace.prefabs.defind:clone()
newmodel140:PivotTo(CFrame.new(-13.086100831052505, 7.796325231999999, 26.75071297136725) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel140.Parent = workspace.devices.definds
newmodel140.RandBr.Value = 0.49459598481469536
newmodel141 = workspace.prefabs.defind:clone()
newmodel141:PivotTo(CFrame.new(-13.218923032513139, 8.23185316, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel141.Parent = workspace.devices.definds
newmodel141.RandBr.Value = 0.4739031186162105
newmodel142 = workspace.prefabs.defind:clone()
newmodel142:PivotTo(CFrame.new(-13.218923032513139, 8.122971616, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel142.Parent = workspace.devices.definds
newmodel142.RandBr.Value = 0.07957368256181119
newmodel143 = workspace.prefabs.defind:clone()
newmodel143:PivotTo(CFrame.new(-13.218923032513139, 8.014087444000001, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel143.Parent = workspace.devices.definds
newmodel143.RandBr.Value = 0.14851812249524335
newmodel144 = workspace.prefabs.defind:clone()
newmodel144:PivotTo(CFrame.new(-13.218923032513139, 7.9052058999999995, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel144.Parent = workspace.devices.definds
newmodel144.RandBr.Value = 0.5235552165402594
newmodel145 = workspace.prefabs.defind:clone()
newmodel145:PivotTo(CFrame.new(-13.218923032513139, 7.796325231999999, 26.916263616644265) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel145.Parent = workspace.devices.definds
newmodel145.RandBr.Value = 0.20272568022675327
newmodel146 = workspace.prefabs.defind:clone()
newmodel146:PivotTo(CFrame.new(-13.351741117934964, 8.23185316, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel146.Parent = workspace.devices.definds
newmodel146.RandBr.Value = 0.42072578336866584
newmodel147 = workspace.prefabs.defind:clone()
newmodel147:PivotTo(CFrame.new(-13.351741117934964, 8.122971616, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel147.Parent = workspace.devices.definds
newmodel147.RandBr.Value = 0.32262752491614016
newmodel148 = workspace.prefabs.defind:clone()
newmodel148:PivotTo(CFrame.new(-13.351741117934964, 8.014087444000001, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel148.Parent = workspace.devices.definds
newmodel148.RandBr.Value = 0.18908569806243464
newmodel149 = workspace.prefabs.defind:clone()
newmodel149:PivotTo(CFrame.new(-13.351741117934964, 7.9052058999999995, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel149.Parent = workspace.devices.definds
newmodel149.RandBr.Value = 0.02029727017563594
newmodel150 = workspace.prefabs.defind:clone()
newmodel150:PivotTo(CFrame.new(-13.351741117934964, 7.796325231999999, 27.081810451332878) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel150.Parent = workspace.devices.definds
newmodel150.RandBr.Value = 0.40749225543450557
newmodel151 = workspace.prefabs.defind:clone()
newmodel151:PivotTo(CFrame.new(-13.48456074359278, 8.23185316, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel151.Parent = workspace.devices.definds
newmodel151.RandBr.Value = 0.5804011804918352
newmodel152 = workspace.prefabs.defind:clone()
newmodel152:PivotTo(CFrame.new(-13.48456074359278, 8.122971616, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel152.Parent = workspace.devices.definds
newmodel152.RandBr.Value = 0.2701045485380074
newmodel153 = workspace.prefabs.defind:clone()
newmodel153:PivotTo(CFrame.new(-13.48456074359278, 8.014087444000001, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel153.Parent = workspace.devices.definds
newmodel153.RandBr.Value = 0.32930638823000746
newmodel154 = workspace.prefabs.defind:clone()
newmodel154:PivotTo(CFrame.new(-13.48456074359278, 7.9052058999999995, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel154.Parent = workspace.devices.definds
newmodel154.RandBr.Value = 0.02321693277299932
newmodel155 = workspace.prefabs.defind:clone()
newmodel155:PivotTo(CFrame.new(-13.48456074359278, 7.796325231999999, 27.2473605426372) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel155.Parent = workspace.devices.definds
newmodel155.RandBr.Value = 0.13278615677327735
newmodel156 = workspace.prefabs.defind_r:clone()
newmodel156:PivotTo(CFrame.new(-13.964331687927917, 9.4959997664, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel156.Parent = workspace.devices.definds
newmodel156.RandBr.Value = 0.39935107411166754
newmodel157 = workspace.prefabs.defind_y:clone()
newmodel157:PivotTo(CFrame.new(-13.964331687927917, 9.387228248, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel157.Parent = workspace.devices.definds
newmodel157.RandBr.Value = 0.12836043234416497
newmodel158 = workspace.prefabs.defind_y:clone()
newmodel158:PivotTo(CFrame.new(-13.964331687927917, 9.278458248, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel158.Parent = workspace.devices.definds
newmodel158.RandBr.Value = 0.19035903863016373
newmodel159 = workspace.prefabs.defind_y:clone()
newmodel159:PivotTo(CFrame.new(-13.964331687927917, 9.169687956, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel159.Parent = workspace.devices.definds
newmodel159.RandBr.Value = 0.06264218180086953
newmodel160 = workspace.prefabs.defind_y:clone()
newmodel160:PivotTo(CFrame.new(-13.964331687927917, 9.060917955999999, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel160.Parent = workspace.devices.definds
newmodel160.RandBr.Value = 0.2790005614538327
newmodel161 = workspace.prefabs.defind_y:clone()
newmodel161:PivotTo(CFrame.new(-14.109806062987616, 9.4959997664, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel161.Parent = workspace.devices.definds
newmodel161.RandBr.Value = 0.04403724080470297
newmodel162 = workspace.prefabs.defind:clone()
newmodel162:PivotTo(CFrame.new(-14.109806062987616, 9.387228248, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel162.Parent = workspace.devices.definds
newmodel162.RandBr.Value = 0.07149472173014033
newmodel163 = workspace.prefabs.defind:clone()
newmodel163:PivotTo(CFrame.new(-14.109806062987616, 9.278458248, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel163.Parent = workspace.devices.definds
newmodel163.RandBr.Value = 0.0030310171669378104
newmodel164 = workspace.prefabs.defind:clone()
newmodel164:PivotTo(CFrame.new(-14.109806062987616, 9.169687956, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel164.Parent = workspace.devices.definds
newmodel164.RandBr.Value = 0.1475568613711577
newmodel165 = workspace.prefabs.defind:clone()
newmodel165:PivotTo(CFrame.new(-14.109806062987616, 9.060917955999999, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel165.Parent = workspace.devices.definds
newmodel165.RandBr.Value = 0.4787614833450474
newmodel166 = workspace.prefabs.defind:clone()
newmodel166:PivotTo(CFrame.new(-14.255279531345039, 9.4959997664, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel166.Parent = workspace.devices.definds
newmodel166.RandBr.Value = 0.28070736461741214
newmodel167 = workspace.prefabs.defind_y:clone()
newmodel167:PivotTo(CFrame.new(-14.255279531345039, 9.387228248, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel167.Parent = workspace.devices.definds
newmodel167.RandBr.Value = 0.5391657418709541
newmodel168 = workspace.prefabs.defind_y:clone()
newmodel168:PivotTo(CFrame.new(-14.255279531345039, 9.278458248, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel168.Parent = workspace.devices.definds
newmodel168.RandBr.Value = 0.30188650937027534
newmodel169 = workspace.prefabs.defind_y:clone()
newmodel169:PivotTo(CFrame.new(-14.255279531345039, 9.169687956, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel169.Parent = workspace.devices.definds
newmodel169.RandBr.Value = 0.09994514465957834
newmodel170 = workspace.prefabs.defind_y:clone()
newmodel170:PivotTo(CFrame.new(-14.255279531345039, 9.060917955999999, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel170.Parent = workspace.devices.definds
newmodel170.RandBr.Value = 0.08134751792170673
newmodel171 = workspace.prefabs.defind:clone()
newmodel171:PivotTo(CFrame.new(-14.400753573597104, 9.4959997664, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel171.Parent = workspace.devices.definds
newmodel171.RandBr.Value = 0.07601237821095512
newmodel172 = workspace.prefabs.defind:clone()
newmodel172:PivotTo(CFrame.new(-14.400753573597104, 9.387228248, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel172.Parent = workspace.devices.definds
newmodel172.RandBr.Value = 0.04601476030879714
newmodel173 = workspace.prefabs.defind:clone()
newmodel173:PivotTo(CFrame.new(-14.400753573597104, 9.278458248, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel173.Parent = workspace.devices.definds
newmodel173.RandBr.Value = 0.253287338445816
newmodel174 = workspace.prefabs.defind:clone()
newmodel174:PivotTo(CFrame.new(-14.400753573597104, 9.169687956, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel174.Parent = workspace.devices.definds
newmodel174.RandBr.Value = 0.043011051097885056
newmodel175 = workspace.prefabs.defind:clone()
newmodel175:PivotTo(CFrame.new(-14.400753573597104, 9.060917955999999, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel175.Parent = workspace.devices.definds
newmodel175.RandBr.Value = 0.16973472232914813
newmodel176 = workspace.prefabs.defind_g:clone()
newmodel176:PivotTo(CFrame.new(-13.964331687927917, 8.856518831999999, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel176.Parent = workspace.devices.definds
newmodel176.RandBr.Value = 0.005774770695074216
newmodel177 = workspace.prefabs.defind_g:clone()
newmodel177:PivotTo(CFrame.new(-13.964331687927917, 8.747749416, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel177.Parent = workspace.devices.definds
newmodel177.RandBr.Value = 0.09653160553325917
newmodel178 = workspace.prefabs.defind:clone()
newmodel178:PivotTo(CFrame.new(-13.964331687927917, 8.638979124, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel178.Parent = workspace.devices.definds
newmodel178.RandBr.Value = 0.028770038502359527
newmodel179 = workspace.prefabs.defind:clone()
newmodel179:PivotTo(CFrame.new(-13.964331687927917, 8.530209124, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel179.Parent = workspace.devices.definds
newmodel179.RandBr.Value = 0.5193386868538389
newmodel180 = workspace.prefabs.defind:clone()
newmodel180:PivotTo(CFrame.new(-13.964331687927917, 8.421439123999999, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel180.Parent = workspace.devices.definds
newmodel180.RandBr.Value = 0.2822173061477021
newmodel181 = workspace.prefabs.defind:clone()
newmodel181:PivotTo(CFrame.new(-14.109806062987616, 8.856518831999999, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel181.Parent = workspace.devices.definds
newmodel181.RandBr.Value = 0.14573954726222266
newmodel182 = workspace.prefabs.defind:clone()
newmodel182:PivotTo(CFrame.new(-14.109806062987616, 8.747749416, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel182.Parent = workspace.devices.definds
newmodel182.RandBr.Value = 0.020169802140439373
newmodel183 = workspace.prefabs.defind_g:clone()
newmodel183:PivotTo(CFrame.new(-14.109806062987616, 8.638979124, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel183.Parent = workspace.devices.definds
newmodel183.RandBr.Value = 0.3174835359604913
newmodel184 = workspace.prefabs.defind:clone()
newmodel184:PivotTo(CFrame.new(-14.109806062987616, 8.530209124, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel184.Parent = workspace.devices.definds
newmodel184.RandBr.Value = 0.38705631855191547
newmodel185 = workspace.prefabs.defind:clone()
newmodel185:PivotTo(CFrame.new(-14.109806062987616, 8.421439123999999, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel185.Parent = workspace.devices.definds
newmodel185.RandBr.Value = 0.5420537423098485
newmodel186 = workspace.prefabs.defind_g:clone()
newmodel186:PivotTo(CFrame.new(-14.255279531345039, 8.856518831999999, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel186.Parent = workspace.devices.definds
newmodel186.RandBr.Value = 0.296094750160852
newmodel187 = workspace.prefabs.defind_g:clone()
newmodel187:PivotTo(CFrame.new(-14.255279531345039, 8.747749416, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel187.Parent = workspace.devices.definds
newmodel187.RandBr.Value = 0.4555418984513699
newmodel188 = workspace.prefabs.defind:clone()
newmodel188:PivotTo(CFrame.new(-14.255279531345039, 8.638979124, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel188.Parent = workspace.devices.definds
newmodel188.RandBr.Value = 0.3042417289147979
newmodel189 = workspace.prefabs.defind:clone()
newmodel189:PivotTo(CFrame.new(-14.255279531345039, 8.530209124, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel189.Parent = workspace.devices.definds
newmodel189.RandBr.Value = 0.5584538555204303
newmodel190 = workspace.prefabs.defind:clone()
newmodel190:PivotTo(CFrame.new(-14.255279531345039, 8.421439123999999, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel190.Parent = workspace.devices.definds
newmodel190.RandBr.Value = 0.024965447701959787
newmodel191 = workspace.prefabs.defind:clone()
newmodel191:PivotTo(CFrame.new(-14.400753573597104, 8.856518831999999, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel191.Parent = workspace.devices.definds
newmodel191.RandBr.Value = 0.2778987562523322
newmodel192 = workspace.prefabs.defind:clone()
newmodel192:PivotTo(CFrame.new(-14.400753573597104, 8.747749416, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel192.Parent = workspace.devices.definds
newmodel192.RandBr.Value = 0.5027837592031317
newmodel193 = workspace.prefabs.defind_g:clone()
newmodel193:PivotTo(CFrame.new(-14.400753573597104, 8.638979124, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel193.Parent = workspace.devices.definds
newmodel193.RandBr.Value = 0.28365361040499354
newmodel194 = workspace.prefabs.defind:clone()
newmodel194:PivotTo(CFrame.new(-14.400753573597104, 8.530209124, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel194.Parent = workspace.devices.definds
newmodel194.RandBr.Value = 0.2949220985374004
newmodel195 = workspace.prefabs.defind:clone()
newmodel195:PivotTo(CFrame.new(-14.400753573597104, 8.421439123999999, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel195.Parent = workspace.devices.definds
newmodel195.RandBr.Value = 0.3352212438388225
newmodel196 = workspace.prefabs.defind:clone()
newmodel196:PivotTo(CFrame.new(-13.964331687927917, 8.217039999999999, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel196.Parent = workspace.devices.definds
newmodel196.RandBr.Value = 0.5766732403192458
newmodel197 = workspace.prefabs.defind:clone()
newmodel197:PivotTo(CFrame.new(-13.964331687927917, 8.108269124, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel197.Parent = workspace.devices.definds
newmodel197.RandBr.Value = 0.5290897295573533
newmodel198 = workspace.prefabs.defind:clone()
newmodel198:PivotTo(CFrame.new(-13.964331687927917, 7.9994988320000004, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel198.Parent = workspace.devices.definds
newmodel198.RandBr.Value = 0.1416128461798751
newmodel199 = workspace.prefabs.defind:clone()
newmodel199:PivotTo(CFrame.new(-13.964331687927917, 7.890728832, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel199.Parent = workspace.devices.definds
newmodel199.RandBr.Value = 0.5380033174738695
newmodel200 = workspace.prefabs.defind:clone()
newmodel200:PivotTo(CFrame.new(-13.964331687927917, 7.781958832, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel200.Parent = workspace.devices.definds
newmodel200.RandBr.Value = 0.32643490023014426
newmodel201 = workspace.prefabs.defind:clone()
newmodel201:PivotTo(CFrame.new(-14.109806062987616, 8.217039999999999, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel201.Parent = workspace.devices.definds
newmodel201.RandBr.Value = 0.5292519065522908
newmodel202 = workspace.prefabs.defind:clone()
newmodel202:PivotTo(CFrame.new(-14.109806062987616, 8.108269124, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel202.Parent = workspace.devices.definds
newmodel202.RandBr.Value = 0.17128371384702276
newmodel203 = workspace.prefabs.defind:clone()
newmodel203:PivotTo(CFrame.new(-14.109806062987616, 7.9994988320000004, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel203.Parent = workspace.devices.definds
newmodel203.RandBr.Value = 0.03851888945012416
newmodel204 = workspace.prefabs.defind:clone()
newmodel204:PivotTo(CFrame.new(-14.109806062987616, 7.890728832, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel204.Parent = workspace.devices.definds
newmodel204.RandBr.Value = 0.2222476386976074
newmodel205 = workspace.prefabs.defind:clone()
newmodel205:PivotTo(CFrame.new(-14.109806062987616, 7.781958832, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel205.Parent = workspace.devices.definds
newmodel205.RandBr.Value = 0.11349545442826833
newmodel206 = workspace.prefabs.defind:clone()
newmodel206:PivotTo(CFrame.new(-14.255279531345039, 8.217039999999999, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel206.Parent = workspace.devices.definds
newmodel206.RandBr.Value = 0.4940142684182489
newmodel207 = workspace.prefabs.defind:clone()
newmodel207:PivotTo(CFrame.new(-14.255279531345039, 8.108269124, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel207.Parent = workspace.devices.definds
newmodel207.RandBr.Value = 0.515318131573992
newmodel208 = workspace.prefabs.defind:clone()
newmodel208:PivotTo(CFrame.new(-14.255279531345039, 7.9994988320000004, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel208.Parent = workspace.devices.definds
newmodel208.RandBr.Value = 0.26940317301503397
newmodel209 = workspace.prefabs.defind:clone()
newmodel209:PivotTo(CFrame.new(-14.255279531345039, 7.890728832, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel209.Parent = workspace.devices.definds
newmodel209.RandBr.Value = 0.5743336694588993
newmodel210 = workspace.prefabs.defind:clone()
newmodel210:PivotTo(CFrame.new(-14.255279531345039, 7.781958832, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel210.Parent = workspace.devices.definds
newmodel210.RandBr.Value = 0.24175590248136775
newmodel211 = workspace.prefabs.defind:clone()
newmodel211:PivotTo(CFrame.new(-14.400753573597104, 8.217039999999999, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel211.Parent = workspace.devices.definds
newmodel211.RandBr.Value = 0.05109021379426732
newmodel212 = workspace.prefabs.defind:clone()
newmodel212:PivotTo(CFrame.new(-14.400753573597104, 8.108269124, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel212.Parent = workspace.devices.definds
newmodel212.RandBr.Value = 0.4027394985991764
newmodel213 = workspace.prefabs.defind:clone()
newmodel213:PivotTo(CFrame.new(-14.400753573597104, 7.9994988320000004, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel213.Parent = workspace.devices.definds
newmodel213.RandBr.Value = 0.11512161722877846
newmodel214 = workspace.prefabs.defind:clone()
newmodel214:PivotTo(CFrame.new(-14.400753573597104, 7.890728832, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel214.Parent = workspace.devices.definds
newmodel214.RandBr.Value = 0.2561085094259784
newmodel215 = workspace.prefabs.defind:clone()
newmodel215:PivotTo(CFrame.new(-14.400753573597104, 7.781958832, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel215.Parent = workspace.devices.definds
newmodel215.RandBr.Value = 0.5233106013563006
newmodel216 = workspace.prefabs.defind:clone()
newmodel216:PivotTo(CFrame.new(-13.964331687927917, 7.577559707999999, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel216.Parent = workspace.devices.definds
newmodel216.RandBr.Value = 0.4420873493886274
newmodel217 = workspace.prefabs.defind:clone()
newmodel217:PivotTo(CFrame.new(-13.964331687927917, 7.4687888319999995, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel217.Parent = workspace.devices.definds
newmodel217.RandBr.Value = 0.5571145624707944
newmodel218 = workspace.prefabs.defind:clone()
newmodel218:PivotTo(CFrame.new(-13.964331687927917, 7.360019415999999, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel218.Parent = workspace.devices.definds
newmodel218.RandBr.Value = 0.5921338630696797
newmodel219 = workspace.prefabs.defind:clone()
newmodel219:PivotTo(CFrame.new(-13.964331687927917, 7.251249123999999, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel219.Parent = workspace.devices.definds
newmodel219.RandBr.Value = 0.5652119944158169
newmodel220 = workspace.prefabs.defind:clone()
newmodel220:PivotTo(CFrame.new(-13.964331687927917, 7.142479124, 27.806135350884162) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel220.Parent = workspace.devices.definds
newmodel220.RandBr.Value = 0.13777080821922721
newmodel221 = workspace.prefabs.defind:clone()
newmodel221:PivotTo(CFrame.new(-14.109806062987616, 7.577559707999999, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel221.Parent = workspace.devices.definds
newmodel221.RandBr.Value = 0.3902622670128027
newmodel222 = workspace.prefabs.defind:clone()
newmodel222:PivotTo(CFrame.new(-14.109806062987616, 7.4687888319999995, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel222.Parent = workspace.devices.definds
newmodel222.RandBr.Value = 0.1394224760025812
newmodel223 = workspace.prefabs.defind:clone()
newmodel223:PivotTo(CFrame.new(-14.109806062987616, 7.360019415999999, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel223.Parent = workspace.devices.definds
newmodel223.RandBr.Value = 0.3922659621910931
newmodel224 = workspace.prefabs.defind:clone()
newmodel224:PivotTo(CFrame.new(-14.109806062987616, 7.251249123999999, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel224.Parent = workspace.devices.definds
newmodel224.RandBr.Value = 0.2978084771742585
newmodel225 = workspace.prefabs.defind:clone()
newmodel225:PivotTo(CFrame.new(-14.109806062987616, 7.142479124, 27.956565029193772) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel225.Parent = workspace.devices.definds
newmodel225.RandBr.Value = 0.2557077284685438
newmodel226 = workspace.prefabs.defind:clone()
newmodel226:PivotTo(CFrame.new(-14.255279531345039, 7.577559707999999, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel226.Parent = workspace.devices.definds
newmodel226.RandBr.Value = 0.23411009523920417
newmodel227 = workspace.prefabs.defind:clone()
newmodel227:PivotTo(CFrame.new(-14.255279531345039, 7.4687888319999995, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel227.Parent = workspace.devices.definds
newmodel227.RandBr.Value = 0.5691819622019274
newmodel228 = workspace.prefabs.defind:clone()
newmodel228:PivotTo(CFrame.new(-14.255279531345039, 7.360019415999999, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel228.Parent = workspace.devices.definds
newmodel228.RandBr.Value = 0.1825896380338127
newmodel229 = workspace.prefabs.defind:clone()
newmodel229:PivotTo(CFrame.new(-14.255279531345039, 7.251249123999999, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel229.Parent = workspace.devices.definds
newmodel229.RandBr.Value = 0.24732501633500012
newmodel230 = workspace.prefabs.defind:clone()
newmodel230:PivotTo(CFrame.new(-14.255279531345039, 7.142479124, 28.106997087266073) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel230.Parent = workspace.devices.definds
newmodel230.RandBr.Value = 0.12553903857415807
newmodel231 = workspace.prefabs.defind:clone()
newmodel231:PivotTo(CFrame.new(-14.400753573597104, 7.577559707999999, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel231.Parent = workspace.devices.definds
newmodel231.RandBr.Value = 0.03516940209821664
newmodel232 = workspace.prefabs.defind:clone()
newmodel232:PivotTo(CFrame.new(-14.400753573597104, 7.4687888319999995, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel232.Parent = workspace.devices.definds
newmodel232.RandBr.Value = 0.1324150149332217
newmodel233 = workspace.prefabs.defind:clone()
newmodel233:PivotTo(CFrame.new(-14.400753573597104, 7.360019415999999, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel233.Parent = workspace.devices.definds
newmodel233.RandBr.Value = 0.4285157009418108
newmodel234 = workspace.prefabs.defind:clone()
newmodel234:PivotTo(CFrame.new(-14.400753573597104, 7.251249123999999, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel234.Parent = workspace.devices.definds
newmodel234.RandBr.Value = 0.5432512312338744
newmodel235 = workspace.prefabs.defind:clone()
newmodel235:PivotTo(CFrame.new(-14.400753573597104, 7.142479124, 28.25742980896512) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel235.Parent = workspace.devices.definds
newmodel235.RandBr.Value = 0.024406851729051104
newmodel236 = workspace.prefabs.defind_r:clone()
newmodel236:PivotTo(CFrame.new(-14.60576967830567, 9.4959997664, 28.469436629960256) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel236.Parent = workspace.devices.definds
newmodel236.RandBr.Value = 0.4627430375408724
newmodel237 = workspace.prefabs.defind_r:clone()
newmodel237:PivotTo(CFrame.new(-14.60576967830567, 9.387228248, 28.469436629960256) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel237.Parent = workspace.devices.definds
newmodel237.RandBr.Value = 0.02878382668960495
newmodel238 = workspace.prefabs.defind_y:clone()
newmodel238:PivotTo(CFrame.new(-14.60576967830567, 9.278458248, 28.469436629960256) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel238.Parent = workspace.devices.definds
newmodel238.RandBr.Value = 0.43721607608910085
newmodel239 = workspace.prefabs.defind_y:clone()
newmodel239:PivotTo(CFrame.new(-14.60576967830567, 9.169687956, 28.469436629960256) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel239.Parent = workspace.devices.definds
newmodel239.RandBr.Value = 0.4644975672575632
newmodel240 = workspace.prefabs.defind_y:clone()
newmodel240:PivotTo(CFrame.new(-14.60576967830567, 9.060917955999999, 28.469436629960256) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel240.Parent = workspace.devices.definds
newmodel240.RandBr.Value = 0.1809968566195769
newmodel241 = workspace.prefabs.defind_r:clone()
newmodel241:PivotTo(CFrame.new(-14.751244173097053, 9.4959997664, 28.619866476825877) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel241.Parent = workspace.devices.definds
newmodel241.RandBr.Value = 0.3263474322884327
newmodel242 = workspace.prefabs.defind_r:clone()
newmodel242:PivotTo(CFrame.new(-14.751244173097053, 9.387228248, 28.619866476825877) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel242.Parent = workspace.devices.definds
newmodel242.RandBr.Value = 0.330796398716695
newmodel243 = workspace.prefabs.defind:clone()
newmodel243:PivotTo(CFrame.new(-14.751244173097053, 9.278458248, 28.619866476825877) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel243.Parent = workspace.devices.definds
newmodel243.RandBr.Value = 0.4450012802143483
newmodel244 = workspace.prefabs.defind:clone()
newmodel244:PivotTo(CFrame.new(-14.751244173097053, 9.169687956, 28.619866476825877) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel244.Parent = workspace.devices.definds
newmodel244.RandBr.Value = 0.5613688385452815
newmodel245 = workspace.prefabs.defind:clone()
newmodel245:PivotTo(CFrame.new(-14.751244173097053, 9.060917955999999, 28.619866476825877) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel245.Parent = workspace.devices.definds
newmodel245.RandBr.Value = 0.49868201851014715
newmodel246 = workspace.prefabs.defind_r:clone()
newmodel246:PivotTo(CFrame.new(-14.896720685568027, 9.4959997664, 28.770302090349595) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel246.Parent = workspace.devices.definds
newmodel246.RandBr.Value = 0.31682935665431755
newmodel247 = workspace.prefabs.defind_r:clone()
newmodel247:PivotTo(CFrame.new(-14.896720685568027, 9.387228248, 28.770302090349595) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel247.Parent = workspace.devices.definds
newmodel247.RandBr.Value = 0.44975027481877494
newmodel248 = workspace.prefabs.defind:clone()
newmodel248:PivotTo(CFrame.new(-14.896720685568027, 9.278458248, 28.770302090349595) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel248.Parent = workspace.devices.definds
newmodel248.RandBr.Value = 0.5206252603430804
newmodel249 = workspace.prefabs.defind:clone()
newmodel249:PivotTo(CFrame.new(-14.896720685568027, 9.169687956, 28.770302090349595) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel249.Parent = workspace.devices.definds
newmodel249.RandBr.Value = 0.018303758602126585
newmodel250 = workspace.prefabs.defind:clone()
newmodel250:PivotTo(CFrame.new(-14.896720685568027, 9.060917955999999, 28.770302090349595) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel250.Parent = workspace.devices.definds
newmodel250.RandBr.Value = 0.179171754580658
newmodel251 = workspace.prefabs.defind_r:clone()
newmodel251:PivotTo(CFrame.new(-15.042191645219592, 9.4959997664, 28.92073129381561) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel251.Parent = workspace.devices.definds
newmodel251.RandBr.Value = 0.2726444725552897
newmodel252 = workspace.prefabs.defind_r:clone()
newmodel252:PivotTo(CFrame.new(-15.042191645219592, 9.387228248, 28.92073129381561) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel252.Parent = workspace.devices.definds
newmodel252.RandBr.Value = 0.31500833910155684
newmodel253 = workspace.prefabs.defind:clone()
newmodel253:PivotTo(CFrame.new(-15.042191645219592, 9.278458248, 28.92073129381561) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel253.Parent = workspace.devices.definds
newmodel253.RandBr.Value = 0.548705931563217
newmodel254 = workspace.prefabs.defind:clone()
newmodel254:PivotTo(CFrame.new(-15.042191645219592, 9.169687956, 28.92073129381561) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel254.Parent = workspace.devices.definds
newmodel254.RandBr.Value = 0.11435346005689079
newmodel255 = workspace.prefabs.defind:clone()
newmodel255:PivotTo(CFrame.new(-15.042191645219592, 9.060917955999999, 28.92073129381561) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel255.Parent = workspace.devices.definds
newmodel255.RandBr.Value = 0.08324946925848235
newmodel256 = workspace.prefabs.defind_r:clone()
newmodel256:PivotTo(CFrame.new(-19.417619065317588, 9.4959997664, 32.71019690498895) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel256.Parent = workspace.devices.definds
newmodel256.RandBr.Value = 0.09990568488833214
newmodel257 = workspace.prefabs.defind:clone()
newmodel257:PivotTo(CFrame.new(-19.417619065317588, 9.387228248, 32.71019690498895) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel257.Parent = workspace.devices.definds
newmodel257.RandBr.Value = 0.5015812619447823
newmodel258 = workspace.prefabs.defind:clone()
newmodel258:PivotTo(CFrame.new(-19.417619065317588, 9.278458248, 32.71019690498895) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel258.Parent = workspace.devices.definds
newmodel258.RandBr.Value = 0.23859148330318425
newmodel259 = workspace.prefabs.defind_g:clone()
newmodel259:PivotTo(CFrame.new(-19.417619065317588, 9.169687956, 32.71019690498895) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel259.Parent = workspace.devices.definds
newmodel259.RandBr.Value = 0.24975162429526454
newmodel260 = workspace.prefabs.defind:clone()
newmodel260:PivotTo(CFrame.new(-19.417619065317588, 9.060917955999999, 32.71019690498895) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel260.Parent = workspace.devices.definds
newmodel260.RandBr.Value = 0.3649237858931263
newmodel261 = workspace.prefabs.defind_r:clone()
newmodel261:PivotTo(CFrame.new(-19.588071256232343, 9.4959997664, 32.831599660836616) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel261.Parent = workspace.devices.definds
newmodel261.RandBr.Value = 0.5687261015064824
newmodel262 = workspace.prefabs.defind:clone()
newmodel262:PivotTo(CFrame.new(-19.588071256232343, 9.387228248, 32.831599660836616) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel262.Parent = workspace.devices.definds
newmodel262.RandBr.Value = 0.3161582783433549
newmodel263 = workspace.prefabs.defind:clone()
newmodel263:PivotTo(CFrame.new(-19.588071256232343, 9.278458248, 32.831599660836616) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel263.Parent = workspace.devices.definds
newmodel263.RandBr.Value = 0.4848466745819264
newmodel264 = workspace.prefabs.defind:clone()
newmodel264:PivotTo(CFrame.new(-19.588071256232343, 9.169687956, 32.831599660836616) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel264.Parent = workspace.devices.definds
newmodel264.RandBr.Value = 0.5637724167312541
newmodel265 = workspace.prefabs.defind:clone()
newmodel265:PivotTo(CFrame.new(-19.588071256232343, 9.060917955999999, 32.831599660836616) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel265.Parent = workspace.devices.definds
newmodel265.RandBr.Value = 0.548894139781407
newmodel266 = workspace.prefabs.defind_r:clone()
newmodel266:PivotTo(CFrame.new(-19.75852193452774, 9.4959997664, 32.953002023775056) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel266.Parent = workspace.devices.definds
newmodel266.RandBr.Value = 0.2555642737328905
newmodel267 = workspace.prefabs.defind:clone()
newmodel267:PivotTo(CFrame.new(-19.75852193452774, 9.387228248, 32.953002023775056) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel267.Parent = workspace.devices.definds
newmodel267.RandBr.Value = 0.28134400492234035
newmodel268 = workspace.prefabs.defind_r:clone()
newmodel268:PivotTo(CFrame.new(-19.75852193452774, 9.278458248, 32.953002023775056) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel268.Parent = workspace.devices.definds
newmodel268.RandBr.Value = 0.13221031387988805
newmodel269 = workspace.prefabs.defind_y:clone()
newmodel269:PivotTo(CFrame.new(-19.75852193452774, 9.169687956, 32.953002023775056) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel269.Parent = workspace.devices.definds
newmodel269.RandBr.Value = 0.49900560912353614
newmodel270 = workspace.prefabs.defind_g:clone()
newmodel270:PivotTo(CFrame.new(-19.75852193452774, 9.060917955999999, 32.953002023775056) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel270.Parent = workspace.devices.definds
newmodel270.RandBr.Value = 0.28612513870053663
newmodel271 = workspace.prefabs.defind:clone()
newmodel271:PivotTo(CFrame.new(-19.92897553786308, 9.4959997664, 33.0744043065499) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel271.Parent = workspace.devices.definds
newmodel271.RandBr.Value = 0.5256372178457284
newmodel272 = workspace.prefabs.defind:clone()
newmodel272:PivotTo(CFrame.new(-19.92897553786308, 9.387228248, 33.0744043065499) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel272.Parent = workspace.devices.definds
newmodel272.RandBr.Value = 0.36970690369040166
newmodel273 = workspace.prefabs.defind_r:clone()
newmodel273:PivotTo(CFrame.new(-19.92897553786308, 9.278458248, 33.0744043065499) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel273.Parent = workspace.devices.definds
newmodel273.RandBr.Value = 0.5488237048151255
newmodel274 = workspace.prefabs.defind_y:clone()
newmodel274:PivotTo(CFrame.new(-19.92897553786308, 9.169687956, 33.0744043065499) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel274.Parent = workspace.devices.definds
newmodel274.RandBr.Value = 0.010551129267966974
newmodel275 = workspace.prefabs.defind_g:clone()
newmodel275:PivotTo(CFrame.new(-19.92897553786308, 9.060917955999999, 33.0744043065499) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel275.Parent = workspace.devices.definds
newmodel275.RandBr.Value = 0.5914977158241657
newmodel276 = workspace.prefabs.defind:clone()
newmodel276:PivotTo(CFrame.new(-20.169191422200463, 9.4959997664, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel276.Parent = workspace.devices.definds
newmodel276.RandBr.Value = 0.08067040265763747
newmodel277 = workspace.prefabs.defind_y:clone()
newmodel277:PivotTo(CFrame.new(-20.169191422200463, 9.387228248, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel277.Parent = workspace.devices.definds
newmodel277.RandBr.Value = 0.5556130380879443
newmodel278 = workspace.prefabs.defind_y:clone()
newmodel278:PivotTo(CFrame.new(-20.169191422200463, 9.278458248, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel278.Parent = workspace.devices.definds
newmodel278.RandBr.Value = 0.30544616310122413
newmodel279 = workspace.prefabs.defind_y:clone()
newmodel279:PivotTo(CFrame.new(-20.169191422200463, 9.169687956, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel279.Parent = workspace.devices.definds
newmodel279.RandBr.Value = 0.13309946490394806
newmodel280 = workspace.prefabs.defind_y:clone()
newmodel280:PivotTo(CFrame.new(-20.169191422200463, 9.060917955999999, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel280.Parent = workspace.devices.definds
newmodel280.RandBr.Value = 0.49049094672658056
newmodel281 = workspace.prefabs.defind:clone()
newmodel281:PivotTo(CFrame.new(-20.33964619895959, 9.4959997664, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel281.Parent = workspace.devices.definds
newmodel281.RandBr.Value = 0.3865253891882318
newmodel282 = workspace.prefabs.defind:clone()
newmodel282:PivotTo(CFrame.new(-20.33964619895959, 9.387228248, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel282.Parent = workspace.devices.definds
newmodel282.RandBr.Value = 0.38111982850084075
newmodel283 = workspace.prefabs.defind:clone()
newmodel283:PivotTo(CFrame.new(-20.33964619895959, 9.278458248, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel283.Parent = workspace.devices.definds
newmodel283.RandBr.Value = 0.5027828590172587
newmodel284 = workspace.prefabs.defind:clone()
newmodel284:PivotTo(CFrame.new(-20.33964619895959, 9.169687956, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel284.Parent = workspace.devices.definds
newmodel284.RandBr.Value = 0.5089794095725131
newmodel285 = workspace.prefabs.defind:clone()
newmodel285:PivotTo(CFrame.new(-20.33964619895959, 9.060917955999999, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel285.Parent = workspace.devices.definds
newmodel285.RandBr.Value = 0.42775148979218086
newmodel286 = workspace.prefabs.defind:clone()
newmodel286:PivotTo(CFrame.new(-20.510095303528104, 9.4959997664, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel286.Parent = workspace.devices.definds
newmodel286.RandBr.Value = 0.5577218554635645
newmodel287 = workspace.prefabs.defind:clone()
newmodel287:PivotTo(CFrame.new(-20.510095303528104, 9.387228248, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel287.Parent = workspace.devices.definds
newmodel287.RandBr.Value = 0.3565473165710113
newmodel288 = workspace.prefabs.defind_y:clone()
newmodel288:PivotTo(CFrame.new(-20.510095303528104, 9.278458248, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel288.Parent = workspace.devices.definds
newmodel288.RandBr.Value = 0.3623722654085857
newmodel289 = workspace.prefabs.defind_y:clone()
newmodel289:PivotTo(CFrame.new(-20.510095303528104, 9.169687956, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel289.Parent = workspace.devices.definds
newmodel289.RandBr.Value = 0.22342077610917824
newmodel290 = workspace.prefabs.defind_y:clone()
newmodel290:PivotTo(CFrame.new(-20.510095303528104, 9.060917955999999, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel290.Parent = workspace.devices.definds
newmodel290.RandBr.Value = 0.16329185401469723
newmodel291 = workspace.prefabs.defind:clone()
newmodel291:PivotTo(CFrame.new(-20.68054768372607, 9.4959997664, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel291.Parent = workspace.devices.definds
newmodel291.RandBr.Value = 0.42941869817238737
newmodel292 = workspace.prefabs.defind:clone()
newmodel292:PivotTo(CFrame.new(-20.68054768372607, 9.387228248, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel292.Parent = workspace.devices.definds
newmodel292.RandBr.Value = 0.17910826498430435
newmodel293 = workspace.prefabs.defind:clone()
newmodel293:PivotTo(CFrame.new(-20.68054768372607, 9.278458248, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel293.Parent = workspace.devices.definds
newmodel293.RandBr.Value = 0.022930692929156393
newmodel294 = workspace.prefabs.defind:clone()
newmodel294:PivotTo(CFrame.new(-20.68054768372607, 9.169687956, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel294.Parent = workspace.devices.definds
newmodel294.RandBr.Value = 0.469118036566561
newmodel295 = workspace.prefabs.defind:clone()
newmodel295:PivotTo(CFrame.new(-20.68054768372607, 9.060917955999999, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel295.Parent = workspace.devices.definds
newmodel295.RandBr.Value = 0.10369257432836972
newmodel296 = workspace.prefabs.defind:clone()
newmodel296:PivotTo(CFrame.new(-20.169191422200463, 8.856518831999999, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel296.Parent = workspace.devices.definds
newmodel296.RandBr.Value = 0.4617731173118431
newmodel297 = workspace.prefabs.defind:clone()
newmodel297:PivotTo(CFrame.new(-20.169191422200463, 8.747749416, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel297.Parent = workspace.devices.definds
newmodel297.RandBr.Value = 0.2595593907991525
newmodel298 = workspace.prefabs.defind:clone()
newmodel298:PivotTo(CFrame.new(-20.169191422200463, 8.638979124, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel298.Parent = workspace.devices.definds
newmodel298.RandBr.Value = 0.4492746275563508
newmodel299 = workspace.prefabs.defind:clone()
newmodel299:PivotTo(CFrame.new(-20.169191422200463, 8.530209124, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel299.Parent = workspace.devices.definds
newmodel299.RandBr.Value = 0.3176510067826457
newmodel300 = workspace.prefabs.defind:clone()
newmodel300:PivotTo(CFrame.new(-20.169191422200463, 8.421439123999999, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel300.Parent = workspace.devices.definds
newmodel300.RandBr.Value = 0.10485936707673864
newmodel301 = workspace.prefabs.defind:clone()
newmodel301:PivotTo(CFrame.new(-20.33964619895959, 8.856518831999999, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel301.Parent = workspace.devices.definds
newmodel301.RandBr.Value = 0.11744557422011274
newmodel302 = workspace.prefabs.defind:clone()
newmodel302:PivotTo(CFrame.new(-20.33964619895959, 8.747749416, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel302.Parent = workspace.devices.definds
newmodel302.RandBr.Value = 0.562305905795677
newmodel303 = workspace.prefabs.defind_g:clone()
newmodel303:PivotTo(CFrame.new(-20.33964619895959, 8.638979124, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel303.Parent = workspace.devices.definds
newmodel303.RandBr.Value = 0.2784409415216235
newmodel304 = workspace.prefabs.defind:clone()
newmodel304:PivotTo(CFrame.new(-20.33964619895959, 8.530209124, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel304.Parent = workspace.devices.definds
newmodel304.RandBr.Value = 0.5291155848133114
newmodel305 = workspace.prefabs.defind:clone()
newmodel305:PivotTo(CFrame.new(-20.33964619895959, 8.421439123999999, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel305.Parent = workspace.devices.definds
newmodel305.RandBr.Value = 0.34212303116648185
newmodel306 = workspace.prefabs.defind:clone()
newmodel306:PivotTo(CFrame.new(-20.510095303528104, 8.856518831999999, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel306.Parent = workspace.devices.definds
newmodel306.RandBr.Value = 0.5289534460432752
newmodel307 = workspace.prefabs.defind:clone()
newmodel307:PivotTo(CFrame.new(-20.510095303528104, 8.747749416, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel307.Parent = workspace.devices.definds
newmodel307.RandBr.Value = 0.11406315408414289
newmodel308 = workspace.prefabs.defind:clone()
newmodel308:PivotTo(CFrame.new(-20.510095303528104, 8.638979124, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel308.Parent = workspace.devices.definds
newmodel308.RandBr.Value = 0.5684854833538654
newmodel309 = workspace.prefabs.defind:clone()
newmodel309:PivotTo(CFrame.new(-20.510095303528104, 8.530209124, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel309.Parent = workspace.devices.definds
newmodel309.RandBr.Value = 0.5713289557647943
newmodel310 = workspace.prefabs.defind:clone()
newmodel310:PivotTo(CFrame.new(-20.510095303528104, 8.421439123999999, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel310.Parent = workspace.devices.definds
newmodel310.RandBr.Value = 0.5763662374815695
newmodel311 = workspace.prefabs.defind:clone()
newmodel311:PivotTo(CFrame.new(-20.68054768372607, 8.856518831999999, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel311.Parent = workspace.devices.definds
newmodel311.RandBr.Value = 0.3850578083872337
newmodel312 = workspace.prefabs.defind:clone()
newmodel312:PivotTo(CFrame.new(-20.68054768372607, 8.747749416, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel312.Parent = workspace.devices.definds
newmodel312.RandBr.Value = 0.29061531677401226
newmodel313 = workspace.prefabs.defind:clone()
newmodel313:PivotTo(CFrame.new(-20.68054768372607, 8.638979124, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel313.Parent = workspace.devices.definds
newmodel313.RandBr.Value = 0.39205330556423224
newmodel314 = workspace.prefabs.defind:clone()
newmodel314:PivotTo(CFrame.new(-20.68054768372607, 8.530209124, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel314.Parent = workspace.devices.definds
newmodel314.RandBr.Value = 0.09359314246142382
newmodel315 = workspace.prefabs.defind:clone()
newmodel315:PivotTo(CFrame.new(-20.68054768372607, 8.421439123999999, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel315.Parent = workspace.devices.definds
newmodel315.RandBr.Value = 0.3078536957604437
newmodel316 = workspace.prefabs.defind:clone()
newmodel316:PivotTo(CFrame.new(-20.169191422200463, 8.217039999999999, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel316.Parent = workspace.devices.definds
newmodel316.RandBr.Value = 0.11237940972053724
newmodel317 = workspace.prefabs.defind:clone()
newmodel317:PivotTo(CFrame.new(-20.169191422200463, 8.108269124, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel317.Parent = workspace.devices.definds
newmodel317.RandBr.Value = 0.5886352466842749
newmodel318 = workspace.prefabs.defind:clone()
newmodel318:PivotTo(CFrame.new(-20.169191422200463, 7.9994988320000004, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel318.Parent = workspace.devices.definds
newmodel318.RandBr.Value = 0.23498485949466183
newmodel319 = workspace.prefabs.defind:clone()
newmodel319:PivotTo(CFrame.new(-20.169191422200463, 7.890728832, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel319.Parent = workspace.devices.definds
newmodel319.RandBr.Value = 0.45258280807398454
newmodel320 = workspace.prefabs.defind:clone()
newmodel320:PivotTo(CFrame.new(-20.169191422200463, 7.781958832, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel320.Parent = workspace.devices.definds
newmodel320.RandBr.Value = 0.38676424268122905
newmodel321 = workspace.prefabs.defind:clone()
newmodel321:PivotTo(CFrame.new(-20.33964619895959, 8.217039999999999, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel321.Parent = workspace.devices.definds
newmodel321.RandBr.Value = 0.04829356273649843
newmodel322 = workspace.prefabs.defind:clone()
newmodel322:PivotTo(CFrame.new(-20.33964619895959, 8.108269124, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel322.Parent = workspace.devices.definds
newmodel322.RandBr.Value = 0.42911658979271905
newmodel323 = workspace.prefabs.defind:clone()
newmodel323:PivotTo(CFrame.new(-20.33964619895959, 7.9994988320000004, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel323.Parent = workspace.devices.definds
newmodel323.RandBr.Value = 0.18436454086199483
newmodel324 = workspace.prefabs.defind:clone()
newmodel324:PivotTo(CFrame.new(-20.33964619895959, 7.890728832, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel324.Parent = workspace.devices.definds
newmodel324.RandBr.Value = 0.007172264105812176
newmodel325 = workspace.prefabs.defind:clone()
newmodel325:PivotTo(CFrame.new(-20.33964619895959, 7.781958832, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel325.Parent = workspace.devices.definds
newmodel325.RandBr.Value = 0.41147031627427694
newmodel326 = workspace.prefabs.defind:clone()
newmodel326:PivotTo(CFrame.new(-20.510095303528104, 8.217039999999999, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel326.Parent = workspace.devices.definds
newmodel326.RandBr.Value = 0.40542984284801575
newmodel327 = workspace.prefabs.defind:clone()
newmodel327:PivotTo(CFrame.new(-20.510095303528104, 8.108269124, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel327.Parent = workspace.devices.definds
newmodel327.RandBr.Value = 0.26531375137057234
newmodel328 = workspace.prefabs.defind:clone()
newmodel328:PivotTo(CFrame.new(-20.510095303528104, 7.9994988320000004, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel328.Parent = workspace.devices.definds
newmodel328.RandBr.Value = 0.214560125592765
newmodel329 = workspace.prefabs.defind:clone()
newmodel329:PivotTo(CFrame.new(-20.510095303528104, 7.890728832, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel329.Parent = workspace.devices.definds
newmodel329.RandBr.Value = 0.02792339880650656
newmodel330 = workspace.prefabs.defind:clone()
newmodel330:PivotTo(CFrame.new(-20.510095303528104, 7.781958832, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel330.Parent = workspace.devices.definds
newmodel330.RandBr.Value = 0.06721470283937678
newmodel331 = workspace.prefabs.defind:clone()
newmodel331:PivotTo(CFrame.new(-20.68054768372607, 8.217039999999999, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel331.Parent = workspace.devices.definds
newmodel331.RandBr.Value = 0.32620334060585465
newmodel332 = workspace.prefabs.defind:clone()
newmodel332:PivotTo(CFrame.new(-20.68054768372607, 8.108269124, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel332.Parent = workspace.devices.definds
newmodel332.RandBr.Value = 0.1408354447725744
newmodel333 = workspace.prefabs.defind:clone()
newmodel333:PivotTo(CFrame.new(-20.68054768372607, 7.9994988320000004, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel333.Parent = workspace.devices.definds
newmodel333.RandBr.Value = 0.4031454458019397
newmodel334 = workspace.prefabs.defind:clone()
newmodel334:PivotTo(CFrame.new(-20.68054768372607, 7.890728832, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel334.Parent = workspace.devices.definds
newmodel334.RandBr.Value = 0.5688460512691786
newmodel335 = workspace.prefabs.defind:clone()
newmodel335:PivotTo(CFrame.new(-20.68054768372607, 7.781958832, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel335.Parent = workspace.devices.definds
newmodel335.RandBr.Value = 0.08783699737641415
newmodel336 = workspace.prefabs.defind:clone()
newmodel336:PivotTo(CFrame.new(-20.169191422200463, 7.577559707999999, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel336.Parent = workspace.devices.definds
newmodel336.RandBr.Value = 0.5430137655733795
newmodel337 = workspace.prefabs.defind:clone()
newmodel337:PivotTo(CFrame.new(-20.169191422200463, 7.4687888319999995, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel337.Parent = workspace.devices.definds
newmodel337.RandBr.Value = 0.5160945048339065
newmodel338 = workspace.prefabs.defind:clone()
newmodel338:PivotTo(CFrame.new(-20.169191422200463, 7.360019415999999, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel338.Parent = workspace.devices.definds
newmodel338.RandBr.Value = 0.41322548672843323
newmodel339 = workspace.prefabs.defind:clone()
newmodel339:PivotTo(CFrame.new(-20.169191422200463, 7.251249123999999, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel339.Parent = workspace.devices.definds
newmodel339.RandBr.Value = 0.12386255679133333
newmodel340 = workspace.prefabs.defind:clone()
newmodel340:PivotTo(CFrame.new(-20.169191422200463, 7.142479124, 33.24549713939962) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel340.Parent = workspace.devices.definds
newmodel340.RandBr.Value = 0.35019716240536086
newmodel341 = workspace.prefabs.defind:clone()
newmodel341:PivotTo(CFrame.new(-20.33964619895959, 7.577559707999999, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel341.Parent = workspace.devices.definds
newmodel341.RandBr.Value = 0.3527823669217397
newmodel342 = workspace.prefabs.defind:clone()
newmodel342:PivotTo(CFrame.new(-20.33964619895959, 7.4687888319999995, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel342.Parent = workspace.devices.definds
newmodel342.RandBr.Value = 0.38508162826425746
newmodel343 = workspace.prefabs.defind:clone()
newmodel343:PivotTo(CFrame.new(-20.33964619895959, 7.360019415999999, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel343.Parent = workspace.devices.definds
newmodel343.RandBr.Value = 0.028953453739119905
newmodel344 = workspace.prefabs.defind:clone()
newmodel344:PivotTo(CFrame.new(-20.33964619895959, 7.251249123999999, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel344.Parent = workspace.devices.definds
newmodel344.RandBr.Value = 0.5888956778312462
newmodel345 = workspace.prefabs.defind:clone()
newmodel345:PivotTo(CFrame.new(-20.33964619895959, 7.142479124, 33.36690029132127) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel345.Parent = workspace.devices.definds
newmodel345.RandBr.Value = 0.4404060476716876
newmodel346 = workspace.prefabs.defind:clone()
newmodel346:PivotTo(CFrame.new(-20.510095303528104, 7.577559707999999, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel346.Parent = workspace.devices.definds
newmodel346.RandBr.Value = 0.07553093712221937
newmodel347 = workspace.prefabs.defind:clone()
newmodel347:PivotTo(CFrame.new(-20.510095303528104, 7.4687888319999995, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel347.Parent = workspace.devices.definds
newmodel347.RandBr.Value = 0.555761989087999
newmodel348 = workspace.prefabs.defind:clone()
newmodel348:PivotTo(CFrame.new(-20.510095303528104, 7.360019415999999, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel348.Parent = workspace.devices.definds
newmodel348.RandBr.Value = 0.5302390131916428
newmodel349 = workspace.prefabs.defind:clone()
newmodel349:PivotTo(CFrame.new(-20.510095303528104, 7.251249123999999, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel349.Parent = workspace.devices.definds
newmodel349.RandBr.Value = 0.45950226478474016
newmodel350 = workspace.prefabs.defind:clone()
newmodel350:PivotTo(CFrame.new(-20.510095303528104, 7.142479124, 33.48830385714148) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel350.Parent = workspace.devices.definds
newmodel350.RandBr.Value = 0.31600517243400955
newmodel351 = workspace.prefabs.defind:clone()
newmodel351:PivotTo(CFrame.new(-20.68054768372607, 7.577559707999999, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel351.Parent = workspace.devices.definds
newmodel351.RandBr.Value = 0.4283207996395486
newmodel352 = workspace.prefabs.defind:clone()
newmodel352:PivotTo(CFrame.new(-20.68054768372607, 7.4687888319999995, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel352.Parent = workspace.devices.definds
newmodel352.RandBr.Value = 0.49398435809081775
newmodel353 = workspace.prefabs.defind:clone()
newmodel353:PivotTo(CFrame.new(-20.68054768372607, 7.360019415999999, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel353.Parent = workspace.devices.definds
newmodel353.RandBr.Value = 0.3922569892447605
newmodel354 = workspace.prefabs.defind:clone()
newmodel354:PivotTo(CFrame.new(-20.68054768372607, 7.251249123999999, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel354.Parent = workspace.devices.definds
newmodel354.RandBr.Value = 0.41613122069556213
newmodel355 = workspace.prefabs.defind:clone()
newmodel355:PivotTo(CFrame.new(-20.68054768372607, 7.142479124, 33.60970433390524) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel355.Parent = workspace.devices.definds
newmodel355.RandBr.Value = 0.2799954140474868
newmodel356 = workspace.prefabs.defind:clone()
newmodel356:PivotTo(CFrame.new(-25.152886218011922, 9.284297956, 36.16959460260145) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel356.Parent = workspace.devices.definds
newmodel356.RandBr.Value = 0.40980754135155867
newmodel357 = workspace.prefabs.defind:clone()
newmodel357:PivotTo(CFrame.new(-25.359789520512784, 9.284297956, 36.278036801813) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel357.Parent = workspace.devices.definds
newmodel357.RandBr.Value = 0.4695326850044617
newmodel358 = workspace.prefabs.defind:clone()
newmodel358:PivotTo(CFrame.new(-25.566690093551202, 9.284297956, 36.38647980566622) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel358.Parent = workspace.devices.definds
newmodel358.RandBr.Value = 0.4387281306815155
newmodel359 = workspace.prefabs.defind:clone()
newmodel359:PivotTo(CFrame.new(-25.773596113640785, 9.284297956, 36.494923109911426) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel359.Parent = workspace.devices.definds
newmodel359.RandBr.Value = 0.24190386299502625
newmodel360 = workspace.prefabs.defind:clone()
newmodel360:PivotTo(CFrame.new(-25.152886218011922, 9.167498832, 36.16959460260145) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel360.Parent = workspace.devices.definds
newmodel360.RandBr.Value = 0.08344977692477837
newmodel361 = workspace.prefabs.defind:clone()
newmodel361:PivotTo(CFrame.new(-25.359789520512784, 9.167498832, 36.278036801813) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel361.Parent = workspace.devices.definds
newmodel361.RandBr.Value = 0.4006633314940737
newmodel362 = workspace.prefabs.defind:clone()
newmodel362:PivotTo(CFrame.new(-25.566690093551202, 9.167498832, 36.38647980566622) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel362.Parent = workspace.devices.definds
newmodel362.RandBr.Value = 0.5061786807081471
newmodel363 = workspace.prefabs.defind:clone()
newmodel363:PivotTo(CFrame.new(-25.773596113640785, 9.167498832, 36.494923109911426) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel363.Parent = workspace.devices.definds
newmodel363.RandBr.Value = 0.5483004060834472
newmodel364 = workspace.prefabs.defind:clone()
newmodel364:PivotTo(CFrame.new(-25.152886218011922, 9.050699124, 36.16959460260145) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel364.Parent = workspace.devices.definds
newmodel364.RandBr.Value = 0.07867531429257753
newmodel365 = workspace.prefabs.defind:clone()
newmodel365:PivotTo(CFrame.new(-25.359789520512784, 9.050699124, 36.278036801813) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel365.Parent = workspace.devices.definds
newmodel365.RandBr.Value = 0.24401122118356477
newmodel366 = workspace.prefabs.defind:clone()
newmodel366:PivotTo(CFrame.new(-25.566690093551202, 9.050699124, 36.38647980566622) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel366.Parent = workspace.devices.definds
newmodel366.RandBr.Value = 0.2368416183995386
newmodel367 = workspace.prefabs.defind:clone()
newmodel367:PivotTo(CFrame.new(-25.773596113640785, 9.050699124, 36.494923109911426) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel367.Parent = workspace.devices.definds
newmodel367.RandBr.Value = 0.063341851493583
newmodel368 = workspace.prefabs.defind:clone()
newmodel368:PivotTo(CFrame.new(-25.152886218011922, 8.933896204, 36.16959460260145) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel368.Parent = workspace.devices.definds
newmodel368.RandBr.Value = 0.41899281289985707
newmodel369 = workspace.prefabs.defind:clone()
newmodel369:PivotTo(CFrame.new(-25.359789520512784, 8.933896204, 36.278036801813) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel369.Parent = workspace.devices.definds
newmodel369.RandBr.Value = 0.036839283490741344
newmodel370 = workspace.prefabs.defind:clone()
newmodel370:PivotTo(CFrame.new(-25.566690093551202, 8.933896204, 36.38647980566622) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel370.Parent = workspace.devices.definds
newmodel370.RandBr.Value = 0.24961194916026952
newmodel371 = workspace.prefabs.defind:clone()
newmodel371:PivotTo(CFrame.new(-25.773596113640785, 8.933896204, 36.494923109911426) * CFrame.fromEulerAngles(0, math.rad(-62.339999999999996), 0))
newmodel371.Parent = workspace.devices.definds
newmodel371.RandBr.Value = 0.4538168388637801
newmodel372 = workspace.prefabs.defind:clone()
newmodel372:PivotTo(CFrame.new(-26.397832790677406, 6.868000292000001, 36.797135725513144) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel372.Parent = workspace.devices.definds
newmodel372.RandBr.Value = 0.06139306274335183
newmodel373 = workspace.prefabs.defind:clone()
newmodel373:PivotTo(CFrame.new(-26.397832790677406, 6.759604052000001, 36.797135725513144) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel373.Parent = workspace.devices.definds
newmodel373.RandBr.Value = 0.498180140828839
newmodel374 = workspace.prefabs.defind:clone()
newmodel374:PivotTo(CFrame.new(-26.397832790677406, 6.6512072280000005, 36.797135725513144) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel374.Parent = workspace.devices.definds
newmodel374.RandBr.Value = 0.45583369722191097
newmodel375 = workspace.prefabs.defind:clone()
newmodel375:PivotTo(CFrame.new(-26.397832790677406, 6.542810696, 36.797135725513144) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel375.Parent = workspace.devices.definds
newmodel375.RandBr.Value = 0.5589950036851093
newmodel376 = workspace.prefabs.defind_y:clone()
newmodel376:PivotTo(CFrame.new(-26.397832790677406, 6.434414456, 36.797135725513144) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel376.Parent = workspace.devices.definds
newmodel376.RandBr.Value = 0.2184083531456489
newmodel377 = workspace.prefabs.defind_y:clone()
newmodel377:PivotTo(CFrame.new(-26.397832790677406, 6.326019092000001, 36.797135725513144) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel377.Parent = workspace.devices.definds
newmodel377.RandBr.Value = 0.006964773976517202
newmodel378 = workspace.prefabs.defind:clone()
newmodel378:PivotTo(CFrame.new(-26.592311303191963, 6.868000292000001, 36.877332094433754) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel378.Parent = workspace.devices.definds
newmodel378.RandBr.Value = 0.017949025385708816
newmodel379 = workspace.prefabs.defind:clone()
newmodel379:PivotTo(CFrame.new(-26.592311303191963, 6.759604052000001, 36.877332094433754) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel379.Parent = workspace.devices.definds
newmodel379.RandBr.Value = 0.09091597998424424
newmodel380 = workspace.prefabs.defind:clone()
newmodel380:PivotTo(CFrame.new(-26.592311303191963, 6.6512072280000005, 36.877332094433754) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel380.Parent = workspace.devices.definds
newmodel380.RandBr.Value = 0.4601310059146987
newmodel381 = workspace.prefabs.defind:clone()
newmodel381:PivotTo(CFrame.new(-26.592311303191963, 6.542810696, 36.877332094433754) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel381.Parent = workspace.devices.definds
newmodel381.RandBr.Value = 0.05307358230470929
newmodel382 = workspace.prefabs.defind_y:clone()
newmodel382:PivotTo(CFrame.new(-26.592311303191963, 6.434414456, 36.877332094433754) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel382.Parent = workspace.devices.definds
newmodel382.RandBr.Value = 0.04802522952477193
newmodel383 = workspace.prefabs.defind_y:clone()
newmodel383:PivotTo(CFrame.new(-26.592311303191963, 6.326019092000001, 36.877332094433754) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel383.Parent = workspace.devices.definds
newmodel383.RandBr.Value = 0.47723648573834165
newmodel384 = workspace.prefabs.defind:clone()
newmodel384:PivotTo(CFrame.new(-26.786790862062254, 6.868000292000001, 36.9575325130303) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel384.Parent = workspace.devices.definds
newmodel384.RandBr.Value = 0.5941763427824861
newmodel385 = workspace.prefabs.defind:clone()
newmodel385:PivotTo(CFrame.new(-26.786790862062254, 6.759604052000001, 36.9575325130303) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel385.Parent = workspace.devices.definds
newmodel385.RandBr.Value = 0.521506849168049
newmodel386 = workspace.prefabs.defind:clone()
newmodel386:PivotTo(CFrame.new(-26.786790862062254, 6.6512072280000005, 36.9575325130303) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel386.Parent = workspace.devices.definds
newmodel386.RandBr.Value = 0.3348797552710873
newmodel387 = workspace.prefabs.defind:clone()
newmodel387:PivotTo(CFrame.new(-26.786790862062254, 6.542810696, 36.9575325130303) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel387.Parent = workspace.devices.definds
newmodel387.RandBr.Value = 0.5872970729345486
newmodel388 = workspace.prefabs.defind_y:clone()
newmodel388:PivotTo(CFrame.new(-26.786790862062254, 6.434414456, 36.9575325130303) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel388.Parent = workspace.devices.definds
newmodel388.RandBr.Value = 0.31712717291733206
newmodel389 = workspace.prefabs.defind_y:clone()
newmodel389:PivotTo(CFrame.new(-26.786790862062254, 6.326019092000001, 36.9575325130303) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel389.Parent = workspace.devices.definds
newmodel389.RandBr.Value = 0.3684816673959773
newmodel390 = workspace.prefabs.defind:clone()
newmodel390:PivotTo(CFrame.new(-27.175748829614783, 6.868000292000001, 37.11792924596347) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel390.Parent = workspace.devices.definds
newmodel390.RandBr.Value = 0.20491187871426297
newmodel391 = workspace.prefabs.defind:clone()
newmodel391:PivotTo(CFrame.new(-27.175748829614783, 6.759604052000001, 37.11792924596347) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel391.Parent = workspace.devices.definds
newmodel391.RandBr.Value = 0.4684005895939288
newmodel392 = workspace.prefabs.defind:clone()
newmodel392:PivotTo(CFrame.new(-27.175748829614783, 6.6512072280000005, 37.11792924596347) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel392.Parent = workspace.devices.definds
newmodel392.RandBr.Value = 0.3601834102461071
newmodel393 = workspace.prefabs.defind:clone()
newmodel393:PivotTo(CFrame.new(-27.175748829614783, 6.542810696, 37.11792924596347) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel393.Parent = workspace.devices.definds
newmodel393.RandBr.Value = 0.3104991333554055
newmodel394 = workspace.prefabs.defind:clone()
newmodel394:PivotTo(CFrame.new(-27.175748829614783, 6.434414456, 37.11792924596347) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel394.Parent = workspace.devices.definds
newmodel394.RandBr.Value = 0.038176608990824666
newmodel395 = workspace.prefabs.defind:clone()
newmodel395:PivotTo(CFrame.new(-27.175748829614783, 6.326019092000001, 37.11792924596347) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel395.Parent = workspace.devices.definds
newmodel395.RandBr.Value = 0.21076549047242987
newmodel396 = workspace.prefabs.defind:clone()
newmodel396:PivotTo(CFrame.new(-27.37022751031858, 6.868000292000001, 37.198125666591494) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel396.Parent = workspace.devices.definds
newmodel396.RandBr.Value = 0.5359325722069681
newmodel397 = workspace.prefabs.defind:clone()
newmodel397:PivotTo(CFrame.new(-27.37022751031858, 6.759604052000001, 37.198125666591494) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel397.Parent = workspace.devices.definds
newmodel397.RandBr.Value = 0.3189422009882475
newmodel398 = workspace.prefabs.defind:clone()
newmodel398:PivotTo(CFrame.new(-27.37022751031858, 6.6512072280000005, 37.198125666591494) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel398.Parent = workspace.devices.definds
newmodel398.RandBr.Value = 0.05623294835789376
newmodel399 = workspace.prefabs.defind:clone()
newmodel399:PivotTo(CFrame.new(-27.37022751031858, 6.542810696, 37.198125666591494) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel399.Parent = workspace.devices.definds
newmodel399.RandBr.Value = 0.4075872783821703
newmodel400 = workspace.prefabs.defind_y:clone()
newmodel400:PivotTo(CFrame.new(-27.37022751031858, 6.434414456, 37.198125666591494) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel400.Parent = workspace.devices.definds
newmodel400.RandBr.Value = 0.502010948603117
newmodel401 = workspace.prefabs.defind:clone()
newmodel401:PivotTo(CFrame.new(-27.37022751031858, 6.326019092000001, 37.198125666591494) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel401.Parent = workspace.devices.definds
newmodel401.RandBr.Value = 0.3944040609411026
newmodel402 = workspace.prefabs.defind:clone()
newmodel402:PivotTo(CFrame.new(-27.564703879970708, 6.868000292000001, 37.278325393657866) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel402.Parent = workspace.devices.definds
newmodel402.RandBr.Value = 0.21188020400208527
newmodel403 = workspace.prefabs.defind:clone()
newmodel403:PivotTo(CFrame.new(-27.564703879970708, 6.759604052000001, 37.278325393657866) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel403.Parent = workspace.devices.definds
newmodel403.RandBr.Value = 0.4468965776182148
newmodel404 = workspace.prefabs.defind:clone()
newmodel404:PivotTo(CFrame.new(-27.564703879970708, 6.6512072280000005, 37.278325393657866) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel404.Parent = workspace.devices.definds
newmodel404.RandBr.Value = 0.45449796851904267
newmodel405 = workspace.prefabs.defind:clone()
newmodel405:PivotTo(CFrame.new(-27.564703879970708, 6.542810696, 37.278325393657866) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel405.Parent = workspace.devices.definds
newmodel405.RandBr.Value = 0.15057690752656333
newmodel406 = workspace.prefabs.defind_y:clone()
newmodel406:PivotTo(CFrame.new(-27.564703879970708, 6.434414456, 37.278325393657866) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel406.Parent = workspace.devices.definds
newmodel406.RandBr.Value = 0.4958133225866806
newmodel407 = workspace.prefabs.defind_y:clone()
newmodel407:PivotTo(CFrame.new(-27.564703879970708, 6.326019092000001, 37.278325393657866) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel407.Parent = workspace.devices.definds
newmodel407.RandBr.Value = 0.010512391359139017
newmodel408 = workspace.prefabs.defind:clone()
newmodel408:PivotTo(CFrame.new(-27.75919144250004, 6.868000292000001, 37.35852248824537) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel408.Parent = workspace.devices.definds
newmodel408.RandBr.Value = 0.589656242819725
newmodel409 = workspace.prefabs.defind:clone()
newmodel409:PivotTo(CFrame.new(-27.75919144250004, 6.759604052000001, 37.35852248824537) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel409.Parent = workspace.devices.definds
newmodel409.RandBr.Value = 0.45168418635472785
newmodel410 = workspace.prefabs.defind:clone()
newmodel410:PivotTo(CFrame.new(-27.75919144250004, 6.6512072280000005, 37.35852248824537) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel410.Parent = workspace.devices.definds
newmodel410.RandBr.Value = 0.40662189440506186
newmodel411 = workspace.prefabs.defind:clone()
newmodel411:PivotTo(CFrame.new(-27.75919144250004, 6.542810696, 37.35852248824537) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel411.Parent = workspace.devices.definds
newmodel411.RandBr.Value = 0.2981592462482627
newmodel412 = workspace.prefabs.defind:clone()
newmodel412:PivotTo(CFrame.new(-27.75919144250004, 6.434414456, 37.35852248824537) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel412.Parent = workspace.devices.definds
newmodel412.RandBr.Value = 0.5770412945301653
newmodel413 = workspace.prefabs.defind_y:clone()
newmodel413:PivotTo(CFrame.new(-27.75919144250004, 6.326019092000001, 37.35852248824537) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel413.Parent = workspace.devices.definds
newmodel413.RandBr.Value = 0.5535873497687473
newmodel414 = workspace.prefabs.defind:clone()
newmodel414:PivotTo(CFrame.new(-28.148146950600626, 6.868000292000001, 37.518920589670486) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel414.Parent = workspace.devices.definds
newmodel414.RandBr.Value = 0.17969354589599976
newmodel415 = workspace.prefabs.defind:clone()
newmodel415:PivotTo(CFrame.new(-28.148146950600626, 6.759604052000001, 37.518920589670486) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel415.Parent = workspace.devices.definds
newmodel415.RandBr.Value = 0.2521725994161337
newmodel416 = workspace.prefabs.defind:clone()
newmodel416:PivotTo(CFrame.new(-28.148146950600626, 6.6512072280000005, 37.518920589670486) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel416.Parent = workspace.devices.definds
newmodel416.RandBr.Value = 0.23190604595691233
newmodel417 = workspace.prefabs.defind:clone()
newmodel417:PivotTo(CFrame.new(-28.148146950600626, 6.542810696, 37.518920589670486) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel417.Parent = workspace.devices.definds
newmodel417.RandBr.Value = 0.06640836152554597
newmodel418 = workspace.prefabs.defind:clone()
newmodel418:PivotTo(CFrame.new(-28.148146950600626, 6.434414456, 37.518920589670486) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel418.Parent = workspace.devices.definds
newmodel418.RandBr.Value = 0.08161254438287913
newmodel419 = workspace.prefabs.defind_y:clone()
newmodel419:PivotTo(CFrame.new(-28.148146950600626, 6.326019092000001, 37.518920589670486) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel419.Parent = workspace.devices.definds
newmodel419.RandBr.Value = 0.3777365425459574
newmodel420 = workspace.prefabs.defind:clone()
newmodel420:PivotTo(CFrame.new(-28.342628201439723, 6.868000292000001, 37.59911690527773) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel420.Parent = workspace.devices.definds
newmodel420.RandBr.Value = 0.3074971927056108
newmodel421 = workspace.prefabs.defind:clone()
newmodel421:PivotTo(CFrame.new(-28.342628201439723, 6.759604052000001, 37.59911690527773) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel421.Parent = workspace.devices.definds
newmodel421.RandBr.Value = 0.3561439841377807
newmodel422 = workspace.prefabs.defind:clone()
newmodel422:PivotTo(CFrame.new(-28.342628201439723, 6.6512072280000005, 37.59911690527773) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel422.Parent = workspace.devices.definds
newmodel422.RandBr.Value = 0.1519774686456567
newmodel423 = workspace.prefabs.defind:clone()
newmodel423:PivotTo(CFrame.new(-28.342628201439723, 6.542810696, 37.59911690527773) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel423.Parent = workspace.devices.definds
newmodel423.RandBr.Value = 0.08773050905399842
newmodel424 = workspace.prefabs.defind:clone()
newmodel424:PivotTo(CFrame.new(-28.342628201439723, 6.434414456, 37.59911690527773) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel424.Parent = workspace.devices.definds
newmodel424.RandBr.Value = 0.531736561220522
newmodel425 = workspace.prefabs.defind:clone()
newmodel425:PivotTo(CFrame.new(-28.342628201439723, 6.326019092000001, 37.59911690527773) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel425.Parent = workspace.devices.definds
newmodel425.RandBr.Value = 0.5082008856227526
newmodel426 = workspace.prefabs.defind:clone()
newmodel426:PivotTo(CFrame.new(-28.53710497038462, 6.868000292000001, 37.679317961881445) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel426.Parent = workspace.devices.definds
newmodel426.RandBr.Value = 0.23237731573267356
newmodel427 = workspace.prefabs.defind:clone()
newmodel427:PivotTo(CFrame.new(-28.53710497038462, 6.759604052000001, 37.679317961881445) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel427.Parent = workspace.devices.definds
newmodel427.RandBr.Value = 0.31606262378206457
newmodel428 = workspace.prefabs.defind:clone()
newmodel428:PivotTo(CFrame.new(-28.53710497038462, 6.6512072280000005, 37.679317961881445) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel428.Parent = workspace.devices.definds
newmodel428.RandBr.Value = 0.1531292771490469
newmodel429 = workspace.prefabs.defind:clone()
newmodel429:PivotTo(CFrame.new(-28.53710497038462, 6.542810696, 37.679317961881445) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel429.Parent = workspace.devices.definds
newmodel429.RandBr.Value = 0.2492878644440072
newmodel430 = workspace.prefabs.defind_y:clone()
newmodel430:PivotTo(CFrame.new(-28.53710497038462, 6.434414456, 37.679317961881445) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel430.Parent = workspace.devices.definds
newmodel430.RandBr.Value = 0.20587318893069653
newmodel431 = workspace.prefabs.defind:clone()
newmodel431:PivotTo(CFrame.new(-28.53710497038462, 6.326019092000001, 37.679317961881445) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel431.Parent = workspace.devices.definds
newmodel431.RandBr.Value = 0.44477740992261167
newmodel432 = workspace.prefabs.defind:clone()
newmodel432:PivotTo(CFrame.new(-28.731586994927305, 6.868000292000001, 37.75951699690164) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel432.Parent = workspace.devices.definds
newmodel432.RandBr.Value = 0.26200728346741314
newmodel433 = workspace.prefabs.defind:clone()
newmodel433:PivotTo(CFrame.new(-28.731586994927305, 6.759604052000001, 37.75951699690164) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel433.Parent = workspace.devices.definds
newmodel433.RandBr.Value = 0.23324264935684472
newmodel434 = workspace.prefabs.defind:clone()
newmodel434:PivotTo(CFrame.new(-28.731586994927305, 6.6512072280000005, 37.75951699690164) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel434.Parent = workspace.devices.definds
newmodel434.RandBr.Value = 0.5316787464219855
newmodel435 = workspace.prefabs.defind:clone()
newmodel435:PivotTo(CFrame.new(-28.731586994927305, 6.542810696, 37.75951699690164) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel435.Parent = workspace.devices.definds
newmodel435.RandBr.Value = 0.07734486130550601
newmodel436 = workspace.prefabs.defind:clone()
newmodel436:PivotTo(CFrame.new(-28.731586994927305, 6.434414456, 37.75951699690164) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel436.Parent = workspace.devices.definds
newmodel436.RandBr.Value = 0.4492540836980637
newmodel437 = workspace.prefabs.defind_y:clone()
newmodel437:PivotTo(CFrame.new(-28.731586994927305, 6.326019092000001, 37.75951699690164) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel437.Parent = workspace.devices.definds
newmodel437.RandBr.Value = 0.004470756345251736
newmodel438 = workspace.prefabs.defind:clone()
newmodel438:PivotTo(CFrame.new(-30.178999322657198, 6.868, 38.24916891655395) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel438.Parent = workspace.devices.definds
newmodel438.RandBr.Value = 0.25406435422022916
newmodel439 = workspace.prefabs.defind:clone()
newmodel439:PivotTo(CFrame.new(-30.178999361170156, 6.76069, 38.249168791830584) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel439.Parent = workspace.devices.definds
newmodel439.RandBr.Value = 0.037834395416172395
newmodel440 = workspace.prefabs.defind:clone()
newmodel440:PivotTo(CFrame.new(-30.178999361170156, 6.653380584000001, 38.249168791830584) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel440.Parent = workspace.devices.definds
newmodel440.RandBr.Value = 0.20964152531712596
newmodel441 = workspace.prefabs.defind:clone()
newmodel441:PivotTo(CFrame.new(-30.178999361170156, 6.5460702920000005, 38.249168791830584) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel441.Parent = workspace.devices.definds
newmodel441.RandBr.Value = 0.49891237748581985
newmodel442 = workspace.prefabs.defind_y:clone()
newmodel442:PivotTo(CFrame.new(-30.178999361170156, 6.438760000000001, 38.249168791830584) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel442.Parent = workspace.devices.definds
newmodel442.RandBr.Value = 0.4581602144607131
newmodel443 = workspace.prefabs.defind:clone()
newmodel443:PivotTo(CFrame.new(-30.37988218730647, 6.868000292000001, 38.31119948769326) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel443.Parent = workspace.devices.definds
newmodel443.RandBr.Value = 0.3532354320351781
newmodel444 = workspace.prefabs.defind:clone()
newmodel444:PivotTo(CFrame.new(-30.37988218730647, 6.76069, 38.31119948769326) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel444.Parent = workspace.devices.definds
newmodel444.RandBr.Value = 0.4449047073592392
newmodel445 = workspace.prefabs.defind:clone()
newmodel445:PivotTo(CFrame.new(-30.37988218730647, 6.653380584000001, 38.31119948769326) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel445.Parent = workspace.devices.definds
newmodel445.RandBr.Value = 0.09510843430418292
newmodel446 = workspace.prefabs.defind:clone()
newmodel446:PivotTo(CFrame.new(-30.37988218730647, 6.5460702920000005, 38.31119948769326) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel446.Parent = workspace.devices.definds
newmodel446.RandBr.Value = 0.2855631140107188
newmodel447 = workspace.prefabs.defind_y:clone()
newmodel447:PivotTo(CFrame.new(-30.37988218730647, 6.438760000000001, 38.31119948769326) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel447.Parent = workspace.devices.definds
newmodel447.RandBr.Value = 0.29549334586887893
newmodel448 = workspace.prefabs.defind:clone()
newmodel448:PivotTo(CFrame.new(-30.58076063629072, 6.868000292000001, 38.37322753409934) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel448.Parent = workspace.devices.definds
newmodel448.RandBr.Value = 0.4438954477059092
newmodel449 = workspace.prefabs.defind_y:clone()
newmodel449:PivotTo(CFrame.new(-30.58076063629072, 6.76069, 38.37322753409934) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel449.Parent = workspace.devices.definds
newmodel449.RandBr.Value = 0.1834450598348417
newmodel450 = workspace.prefabs.defind:clone()
newmodel450:PivotTo(CFrame.new(-30.58076063629072, 6.653380584000001, 38.37322753409934) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel450.Parent = workspace.devices.definds
newmodel450.RandBr.Value = 0.16142423636053657
newmodel451 = workspace.prefabs.defind:clone()
newmodel451:PivotTo(CFrame.new(-30.58076063629072, 6.5460702920000005, 38.37322753409934) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel451.Parent = workspace.devices.definds
newmodel451.RandBr.Value = 0.330955466789643
newmodel452 = workspace.prefabs.defind_y:clone()
newmodel452:PivotTo(CFrame.new(-30.58076063629072, 6.438760000000001, 38.37322753409934) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel452.Parent = workspace.devices.definds
newmodel452.RandBr.Value = 0.48570038233671686
newmodel453 = workspace.prefabs.defind:clone()
newmodel453:PivotTo(CFrame.new(-30.781642132042855, 6.868000292000001, 38.43525561053664) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel453.Parent = workspace.devices.definds
newmodel453.RandBr.Value = 0.4184011294328852
newmodel454 = workspace.prefabs.defind_y:clone()
newmodel454:PivotTo(CFrame.new(-30.781642132042855, 6.76069, 38.43525561053664) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel454.Parent = workspace.devices.definds
newmodel454.RandBr.Value = 0.5535026968501381
newmodel455 = workspace.prefabs.defind:clone()
newmodel455:PivotTo(CFrame.new(-30.781642132042855, 6.653380584000001, 38.43525561053664) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel455.Parent = workspace.devices.definds
newmodel455.RandBr.Value = 0.34230740263017156
newmodel456 = workspace.prefabs.defind:clone()
newmodel456:PivotTo(CFrame.new(-30.781642132042855, 6.5460702920000005, 38.43525561053664) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel456.Parent = workspace.devices.definds
newmodel456.RandBr.Value = 0.3475609376233794
newmodel457 = workspace.prefabs.defind_y:clone()
newmodel457:PivotTo(CFrame.new(-30.781642132042855, 6.438760000000001, 38.43525561053664) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel457.Parent = workspace.devices.definds
newmodel457.RandBr.Value = 0.46233432298237803
newmodel458 = workspace.prefabs.defind:clone()
newmodel458:PivotTo(CFrame.new(-30.982524442116137, 6.868000292000001, 38.49728500858156) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel458.Parent = workspace.devices.definds
newmodel458.RandBr.Value = 0.5169525708224366
newmodel459 = workspace.prefabs.defind_y:clone()
newmodel459:PivotTo(CFrame.new(-30.982524442116137, 6.76069, 38.49728500858156) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel459.Parent = workspace.devices.definds
newmodel459.RandBr.Value = 0.138007028379372
newmodel460 = workspace.prefabs.defind:clone()
newmodel460:PivotTo(CFrame.new(-30.982524442116137, 6.653380584000001, 38.49728500858156) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel460.Parent = workspace.devices.definds
newmodel460.RandBr.Value = 0.48724476786308957
newmodel461 = workspace.prefabs.defind:clone()
newmodel461:PivotTo(CFrame.new(-30.982524442116137, 6.5460702920000005, 38.49728500858156) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel461.Parent = workspace.devices.definds
newmodel461.RandBr.Value = 0.00641377460040653
newmodel462 = workspace.prefabs.defind_y:clone()
newmodel462:PivotTo(CFrame.new(-30.982524442116137, 6.438760000000001, 38.49728500858156) * CFrame.fromEulerAngles(0, math.rad(-72.83999), 0))
newmodel462.Parent = workspace.devices.definds
newmodel462.RandBr.Value = 0.2276725226674269
newmodel463 = workspace.prefabs.defind_y:clone()
newmodel463:PivotTo(CFrame.new(-32.35291848555233, 6.868000292000001, 38.906745385859026) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel463.Parent = workspace.devices.definds
newmodel463.RandBr.Value = 0.18073220981783406
newmodel464 = workspace.prefabs.defind:clone()
newmodel464:PivotTo(CFrame.new(-33.375776721712626, 6.868000292000001, 39.122478877095126) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel464.Parent = workspace.devices.definds
newmodel464.RandBr.Value = 0.08920894465917643
newmodel465 = workspace.prefabs.defind:clone()
newmodel465:PivotTo(CFrame.new(-32.35291848555233, 6.759960584000001, 38.906745385859026) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel465.Parent = workspace.devices.definds
newmodel465.RandBr.Value = 0.22443986359607923
newmodel466 = workspace.prefabs.defind:clone()
newmodel466:PivotTo(CFrame.new(-32.35291848555233, 6.6519200000000005, 38.906745385859026) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel466.Parent = workspace.devices.definds
newmodel466.RandBr.Value = 0.41133537111593893
newmodel467 = workspace.prefabs.defind:clone()
newmodel467:PivotTo(CFrame.new(-32.35291848555233, 6.543880292000001, 38.906745385859026) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel467.Parent = workspace.devices.definds
newmodel467.RandBr.Value = 0.48965978362240997
newmodel468 = workspace.prefabs.defind_y:clone()
newmodel468:PivotTo(CFrame.new(-32.35291848555233, 6.435840292000001, 38.906745385859026) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel468.Parent = workspace.devices.definds
newmodel468.RandBr.Value = 0.578545594933144
newmodel469 = workspace.prefabs.defind_y:clone()
newmodel469:PivotTo(CFrame.new(-32.35291848555233, 6.327800584, 38.906745385859026) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel469.Parent = workspace.devices.definds
newmodel469.RandBr.Value = 0.5154753537553011
newmodel470 = workspace.prefabs.defind_y:clone()
newmodel470:PivotTo(CFrame.new(-32.35291848555233, 6.219760000000001, 38.906745385859026) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel470.Parent = workspace.devices.definds
newmodel470.RandBr.Value = 0.2758870676262878
newmodel471 = workspace.prefabs.defind_y:clone()
newmodel471:PivotTo(CFrame.new(-32.35291848555233, 6.111720292, 38.906745385859026) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel471.Parent = workspace.devices.definds
newmodel471.RandBr.Value = 0.3735565493513113
newmodel472 = workspace.prefabs.defind_y:clone()
newmodel472:PivotTo(CFrame.new(-32.35291848555233, 6.003680292, 38.906745385859026) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel472.Parent = workspace.devices.definds
newmodel472.RandBr.Value = 0.5037868235974794
newmodel473 = workspace.prefabs.defind_y:clone()
newmodel473:PivotTo(CFrame.new(-32.35291848555233, 5.895639708, 38.906745385859026) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel473.Parent = workspace.devices.definds
newmodel473.RandBr.Value = 0.19000821519428915
newmodel474 = workspace.prefabs.defind_y:clone()
newmodel474:PivotTo(CFrame.new(-32.35291848555233, 5.7876002920000005, 38.906745385859026) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel474.Parent = workspace.devices.definds
newmodel474.RandBr.Value = 0.16580828340812495
newmodel475 = workspace.prefabs.defind:clone()
newmodel475:PivotTo(CFrame.new(-32.35291848555233, 5.679559708000001, 38.906745385859026) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel475.Parent = workspace.devices.definds
newmodel475.RandBr.Value = 0.5238278232078883
newmodel476 = workspace.prefabs.defind_y:clone()
newmodel476:PivotTo(CFrame.new(-32.55862999620597, 6.868000292000001, 38.95013334147177) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel476.Parent = workspace.devices.definds
newmodel476.RandBr.Value = 0.36101151173578594
newmodel477 = workspace.prefabs.defind:clone()
newmodel477:PivotTo(CFrame.new(-32.55862999620597, 6.759960584000001, 38.95013334147177) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel477.Parent = workspace.devices.definds
newmodel477.RandBr.Value = 0.27185069873765944
newmodel478 = workspace.prefabs.defind:clone()
newmodel478:PivotTo(CFrame.new(-32.55862999620597, 6.6519200000000005, 38.95013334147177) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel478.Parent = workspace.devices.definds
newmodel478.RandBr.Value = 0.1420493337563589
newmodel479 = workspace.prefabs.defind:clone()
newmodel479:PivotTo(CFrame.new(-32.55862999620597, 6.543880292000001, 38.95013334147177) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel479.Parent = workspace.devices.definds
newmodel479.RandBr.Value = 0.3804324417937066
newmodel480 = workspace.prefabs.defind_y:clone()
newmodel480:PivotTo(CFrame.new(-32.55862999620597, 6.435840292000001, 38.95013334147177) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel480.Parent = workspace.devices.definds
newmodel480.RandBr.Value = 0.4228949102128908
newmodel481 = workspace.prefabs.defind_y:clone()
newmodel481:PivotTo(CFrame.new(-32.55862999620597, 6.327800584, 38.95013334147177) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel481.Parent = workspace.devices.definds
newmodel481.RandBr.Value = 0.2495348120464462
newmodel482 = workspace.prefabs.defind_y:clone()
newmodel482:PivotTo(CFrame.new(-32.55862999620597, 6.219760000000001, 38.95013334147177) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel482.Parent = workspace.devices.definds
newmodel482.RandBr.Value = 0.018789297551480708
newmodel483 = workspace.prefabs.defind_y:clone()
newmodel483:PivotTo(CFrame.new(-32.55862999620597, 6.111720292, 38.95013334147177) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel483.Parent = workspace.devices.definds
newmodel483.RandBr.Value = 0.12178457382439627
newmodel484 = workspace.prefabs.defind_y:clone()
newmodel484:PivotTo(CFrame.new(-32.55862999620597, 6.003680292, 38.95013334147177) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel484.Parent = workspace.devices.definds
newmodel484.RandBr.Value = 0.2778627122282219
newmodel485 = workspace.prefabs.defind_y:clone()
newmodel485:PivotTo(CFrame.new(-32.55862999620597, 5.895639708, 38.95013334147177) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel485.Parent = workspace.devices.definds
newmodel485.RandBr.Value = 0.43922917147585666
newmodel486 = workspace.prefabs.defind_y:clone()
newmodel486:PivotTo(CFrame.new(-32.55862999620597, 5.7876002920000005, 38.95013334147177) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel486.Parent = workspace.devices.definds
newmodel486.RandBr.Value = 0.47500303386696263
newmodel487 = workspace.prefabs.defind:clone()
newmodel487:PivotTo(CFrame.new(-32.55862999620597, 5.679559708000001, 38.95013334147177) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel487.Parent = workspace.devices.definds
newmodel487.RandBr.Value = 0.06542982183257591
newmodel488 = workspace.prefabs.defind_y:clone()
newmodel488:PivotTo(CFrame.new(-32.76434087303504, 6.868000292000001, 38.993520198987355) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel488.Parent = workspace.devices.definds
newmodel488.RandBr.Value = 0.14427426969180082
newmodel489 = workspace.prefabs.defind:clone()
newmodel489:PivotTo(CFrame.new(-32.76434087303504, 6.759960584000001, 38.993520198987355) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel489.Parent = workspace.devices.definds
newmodel489.RandBr.Value = 0.26546146321127667
newmodel490 = workspace.prefabs.defind:clone()
newmodel490:PivotTo(CFrame.new(-32.76434087303504, 6.6519200000000005, 38.993520198987355) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel490.Parent = workspace.devices.definds
newmodel490.RandBr.Value = 0.1258312751018427
newmodel491 = workspace.prefabs.defind:clone()
newmodel491:PivotTo(CFrame.new(-32.76434087303504, 6.543880292000001, 38.993520198987355) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel491.Parent = workspace.devices.definds
newmodel491.RandBr.Value = 0.2890969940447957
newmodel492 = workspace.prefabs.defind_y:clone()
newmodel492:PivotTo(CFrame.new(-32.76434087303504, 6.435840292000001, 38.993520198987355) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel492.Parent = workspace.devices.definds
newmodel492.RandBr.Value = 0.5746712627991033
newmodel493 = workspace.prefabs.defind_y:clone()
newmodel493:PivotTo(CFrame.new(-32.76434087303504, 6.327800584, 38.993520198987355) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel493.Parent = workspace.devices.definds
newmodel493.RandBr.Value = 0.3117247343900528
newmodel494 = workspace.prefabs.defind_y:clone()
newmodel494:PivotTo(CFrame.new(-32.76434087303504, 6.219760000000001, 38.993520198987355) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel494.Parent = workspace.devices.definds
newmodel494.RandBr.Value = 0.5734296816617318
newmodel495 = workspace.prefabs.defind_y:clone()
newmodel495:PivotTo(CFrame.new(-32.76434087303504, 6.111720292, 38.993520198987355) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel495.Parent = workspace.devices.definds
newmodel495.RandBr.Value = 0.18498696309535825
newmodel496 = workspace.prefabs.defind_y:clone()
newmodel496:PivotTo(CFrame.new(-32.76434087303504, 6.003680292, 38.993520198987355) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel496.Parent = workspace.devices.definds
newmodel496.RandBr.Value = 0.37221745643360604
newmodel497 = workspace.prefabs.defind_y:clone()
newmodel497:PivotTo(CFrame.new(-32.76434087303504, 5.895639708, 38.993520198987355) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel497.Parent = workspace.devices.definds
newmodel497.RandBr.Value = 0.2133358102021036
newmodel498 = workspace.prefabs.defind_y:clone()
newmodel498:PivotTo(CFrame.new(-32.76434087303504, 5.7876002920000005, 38.993520198987355) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel498.Parent = workspace.devices.definds
newmodel498.RandBr.Value = 0.14213356278199502
newmodel499 = workspace.prefabs.defind:clone()
newmodel499:PivotTo(CFrame.new(-32.76434087303504, 5.679559708000001, 38.993520198987355) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel499.Parent = workspace.devices.definds
newmodel499.RandBr.Value = 0.07456591195339868
newmodel500 = workspace.prefabs.defind_y:clone()
newmodel500:PivotTo(CFrame.new(-32.970061852514256, 6.868000292000001, 39.0369072640367) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel500.Parent = workspace.devices.definds
newmodel500.RandBr.Value = 0.13939300471953855
newmodel501 = workspace.prefabs.defind:clone()
newmodel501:PivotTo(CFrame.new(-32.970061852514256, 6.759960584000001, 39.0369072640367) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel501.Parent = workspace.devices.definds
newmodel501.RandBr.Value = 0.41639573034165855
newmodel502 = workspace.prefabs.defind:clone()
newmodel502:PivotTo(CFrame.new(-32.970061852514256, 6.6519200000000005, 39.0369072640367) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel502.Parent = workspace.devices.definds
newmodel502.RandBr.Value = 0.4414423249476583
newmodel503 = workspace.prefabs.defind:clone()
newmodel503:PivotTo(CFrame.new(-32.970061852514256, 6.543880292000001, 39.0369072640367) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel503.Parent = workspace.devices.definds
newmodel503.RandBr.Value = 0.44426211353123385
newmodel504 = workspace.prefabs.defind_y:clone()
newmodel504:PivotTo(CFrame.new(-32.970061852514256, 6.435840292000001, 39.0369072640367) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel504.Parent = workspace.devices.definds
newmodel504.RandBr.Value = 0.5663694175689609
newmodel505 = workspace.prefabs.defind_y:clone()
newmodel505:PivotTo(CFrame.new(-32.970061852514256, 6.327800584, 39.0369072640367) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel505.Parent = workspace.devices.definds
newmodel505.RandBr.Value = 0.2942556860635381
newmodel506 = workspace.prefabs.defind_y:clone()
newmodel506:PivotTo(CFrame.new(-32.970061852514256, 6.219760000000001, 39.0369072640367) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel506.Parent = workspace.devices.definds
newmodel506.RandBr.Value = 0.17167584351188844
newmodel507 = workspace.prefabs.defind_y:clone()
newmodel507:PivotTo(CFrame.new(-32.970061852514256, 6.111720292, 39.0369072640367) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel507.Parent = workspace.devices.definds
newmodel507.RandBr.Value = 0.45747710011549847
newmodel508 = workspace.prefabs.defind_y:clone()
newmodel508:PivotTo(CFrame.new(-32.970061852514256, 6.003680292, 39.0369072640367) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel508.Parent = workspace.devices.definds
newmodel508.RandBr.Value = 0.3584157206912913
newmodel509 = workspace.prefabs.defind_y:clone()
newmodel509:PivotTo(CFrame.new(-32.970061852514256, 5.895639708, 39.0369072640367) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel509.Parent = workspace.devices.definds
newmodel509.RandBr.Value = 0.4553052078752271
newmodel510 = workspace.prefabs.defind_y:clone()
newmodel510:PivotTo(CFrame.new(-32.970061852514256, 5.7876002920000005, 39.0369072640367) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel510.Parent = workspace.devices.definds
newmodel510.RandBr.Value = 0.5785280649516751
newmodel511 = workspace.prefabs.defind:clone()
newmodel511:PivotTo(CFrame.new(-32.970061852514256, 5.679559708000001, 39.0369072640367) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel511.Parent = workspace.devices.definds
newmodel511.RandBr.Value = 0.20439973020068591
newmodel512 = workspace.prefabs.defind:clone()
newmodel512:PivotTo(CFrame.new(-33.375776721712626, 6.760794536000001, 39.122478877095126) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel512.Parent = workspace.devices.definds
newmodel512.RandBr.Value = 0.37437537641805807
newmodel513 = workspace.prefabs.defind:clone()
newmodel513:PivotTo(CFrame.new(-33.375776721712626, 6.653588780000001, 39.122478877095126) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel513.Parent = workspace.devices.definds
newmodel513.RandBr.Value = 0.13461701253667263
newmodel514 = workspace.prefabs.defind:clone()
newmodel514:PivotTo(CFrame.new(-33.375776721712626, 6.546383024000001, 39.122478877095126) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel514.Parent = workspace.devices.definds
newmodel514.RandBr.Value = 0.25550967316483497
newmodel515 = workspace.prefabs.defind_y:clone()
newmodel515:PivotTo(CFrame.new(-33.375776721712626, 6.439177852, 39.122478877095126) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel515.Parent = workspace.devices.definds
newmodel515.RandBr.Value = 0.12171095740093364
newmodel516 = workspace.prefabs.defind_y:clone()
newmodel516:PivotTo(CFrame.new(-33.375776721712626, 6.331972096000001, 39.122478877095126) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel516.Parent = workspace.devices.definds
newmodel516.RandBr.Value = 0.06957262088603013
newmodel517 = workspace.prefabs.defind_y:clone()
newmodel517:PivotTo(CFrame.new(-33.375776721712626, 6.224766340000001, 39.122478877095126) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel517.Parent = workspace.devices.definds
newmodel517.RandBr.Value = 0.09448330653792392
newmodel518 = workspace.prefabs.defind_y:clone()
newmodel518:PivotTo(CFrame.new(-33.375776721712626, 6.117560292000001, 39.122478877095126) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel518.Parent = workspace.devices.definds
newmodel518.RandBr.Value = 0.5810050567513485
newmodel519 = workspace.prefabs.defind:clone()
newmodel519:PivotTo(CFrame.new(-33.58149086935711, 6.868000292000001, 39.16586579079717) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel519.Parent = workspace.devices.definds
newmodel519.RandBr.Value = 0.3597217587060533
newmodel520 = workspace.prefabs.defind:clone()
newmodel520:PivotTo(CFrame.new(-33.58149086935711, 6.760794536000001, 39.16586579079717) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel520.Parent = workspace.devices.definds
newmodel520.RandBr.Value = 0.3253524405621186
newmodel521 = workspace.prefabs.defind:clone()
newmodel521:PivotTo(CFrame.new(-33.58149086935711, 6.653588780000001, 39.16586579079717) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel521.Parent = workspace.devices.definds
newmodel521.RandBr.Value = 0.18475174648360396
newmodel522 = workspace.prefabs.defind:clone()
newmodel522:PivotTo(CFrame.new(-33.58149086935711, 6.546383024000001, 39.16586579079717) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel522.Parent = workspace.devices.definds
newmodel522.RandBr.Value = 0.4465754110536941
newmodel523 = workspace.prefabs.defind_y:clone()
newmodel523:PivotTo(CFrame.new(-33.58149086935711, 6.439177852, 39.16586579079717) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel523.Parent = workspace.devices.definds
newmodel523.RandBr.Value = 0.0779446746080761
newmodel524 = workspace.prefabs.defind_y:clone()
newmodel524:PivotTo(CFrame.new(-33.58149086935711, 6.331972096000001, 39.16586579079717) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel524.Parent = workspace.devices.definds
newmodel524.RandBr.Value = 0.5624471338743399
newmodel525 = workspace.prefabs.defind_y:clone()
newmodel525:PivotTo(CFrame.new(-33.58149086935711, 6.224766340000001, 39.16586579079717) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel525.Parent = workspace.devices.definds
newmodel525.RandBr.Value = 0.5693558927241924
newmodel526 = workspace.prefabs.defind_y:clone()
newmodel526:PivotTo(CFrame.new(-33.58149086935711, 6.117560292000001, 39.16586579079717) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel526.Parent = workspace.devices.definds
newmodel526.RandBr.Value = 0.37206505034626564
newmodel527 = workspace.prefabs.defind:clone()
newmodel527:PivotTo(CFrame.new(-33.78720382148695, 6.868000292000001, 39.209255542918996) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel527.Parent = workspace.devices.definds
newmodel527.RandBr.Value = 0.14603512952486222
newmodel528 = workspace.prefabs.defind:clone()
newmodel528:PivotTo(CFrame.new(-33.78720382148695, 6.760794536000001, 39.209255542918996) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel528.Parent = workspace.devices.definds
newmodel528.RandBr.Value = 0.19930020376213878
newmodel529 = workspace.prefabs.defind:clone()
newmodel529:PivotTo(CFrame.new(-33.78720382148695, 6.653588780000001, 39.209255542918996) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel529.Parent = workspace.devices.definds
newmodel529.RandBr.Value = 0.537318509912798
newmodel530 = workspace.prefabs.defind:clone()
newmodel530:PivotTo(CFrame.new(-33.78720382148695, 6.546383024000001, 39.209255542918996) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel530.Parent = workspace.devices.definds
newmodel530.RandBr.Value = 0.1949733012820112
newmodel531 = workspace.prefabs.defind_y:clone()
newmodel531:PivotTo(CFrame.new(-33.78720382148695, 6.439177852, 39.209255542918996) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel531.Parent = workspace.devices.definds
newmodel531.RandBr.Value = 0.5141487296554906
newmodel532 = workspace.prefabs.defind:clone()
newmodel532:PivotTo(CFrame.new(-33.78720382148695, 6.331972096000001, 39.209255542918996) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel532.Parent = workspace.devices.definds
newmodel532.RandBr.Value = 0.334090047136374
newmodel533 = workspace.prefabs.defind_y:clone()
newmodel533:PivotTo(CFrame.new(-33.78720382148695, 6.224766340000001, 39.209255542918996) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel533.Parent = workspace.devices.definds
newmodel533.RandBr.Value = 0.25209086420590604
newmodel534 = workspace.prefabs.defind_y:clone()
newmodel534:PivotTo(CFrame.new(-33.78720382148695, 6.117560292000001, 39.209255542918996) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel534.Parent = workspace.devices.definds
newmodel534.RandBr.Value = 0.090904113245306
newmodel535 = workspace.prefabs.defind:clone()
newmodel535:PivotTo(CFrame.new(-33.99291816953872, 6.868000292000001, 39.25264292134257) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel535.Parent = workspace.devices.definds
newmodel535.RandBr.Value = 0.0021756966685027466
newmodel536 = workspace.prefabs.defind:clone()
newmodel536:PivotTo(CFrame.new(-33.99291816953872, 6.760794536000001, 39.25264292134257) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel536.Parent = workspace.devices.definds
newmodel536.RandBr.Value = 0.18465220015213826
newmodel537 = workspace.prefabs.defind:clone()
newmodel537:PivotTo(CFrame.new(-33.99291816953872, 6.653588780000001, 39.25264292134257) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel537.Parent = workspace.devices.definds
newmodel537.RandBr.Value = 0.4964302493407569
newmodel538 = workspace.prefabs.defind:clone()
newmodel538:PivotTo(CFrame.new(-33.99291816953872, 6.546383024000001, 39.25264292134257) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel538.Parent = workspace.devices.definds
newmodel538.RandBr.Value = 0.38936651231686153
newmodel539 = workspace.prefabs.defind:clone()
newmodel539:PivotTo(CFrame.new(-33.99291816953872, 6.439177852, 39.25264292134257) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel539.Parent = workspace.devices.definds
newmodel539.RandBr.Value = 0.49039006122701523
newmodel540 = workspace.prefabs.defind_y:clone()
newmodel540:PivotTo(CFrame.new(-33.99291816953872, 6.331972096000001, 39.25264292134257) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel540.Parent = workspace.devices.definds
newmodel540.RandBr.Value = 0.06810731052376537
newmodel541 = workspace.prefabs.defind_y:clone()
newmodel541:PivotTo(CFrame.new(-33.99291816953872, 6.224766340000001, 39.25264292134257) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel541.Parent = workspace.devices.definds
newmodel541.RandBr.Value = 0.060627264449320206
newmodel542 = workspace.prefabs.defind_y:clone()
newmodel542:PivotTo(CFrame.new(-33.99291816953872, 6.117560292000001, 39.25264292134257) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel542.Parent = workspace.devices.definds
newmodel542.RandBr.Value = 0.5919226626368795
newmodel543 = workspace.prefabs.defind:clone()
newmodel543:PivotTo(CFrame.new(-35.49208647250063, 6.868000292000001, 39.55600103446693) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel543.Parent = workspace.devices.definds
newmodel543.RandBr.Value = 0.3646807955540296
newmodel544 = workspace.prefabs.defind:clone()
newmodel544:PivotTo(CFrame.new(-35.49208647250063, 6.761628488000001, 39.55600103446693) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel544.Parent = workspace.devices.definds
newmodel544.RandBr.Value = 0.035395649641403605
newmodel545 = workspace.prefabs.defind:clone()
newmodel545:PivotTo(CFrame.new(-35.49208647250063, 6.655257560000001, 39.55600103446693) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel545.Parent = workspace.devices.definds
newmodel545.RandBr.Value = 0.5826417308871303
newmodel546 = workspace.prefabs.defind:clone()
newmodel546:PivotTo(CFrame.new(-35.49208647250063, 6.54888634, 39.55600103446693) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel546.Parent = workspace.devices.definds
newmodel546.RandBr.Value = 0.4906922908498329
newmodel547 = workspace.prefabs.defind_y:clone()
newmodel547:PivotTo(CFrame.new(-35.49208647250063, 6.442513952000001, 39.55600103446693) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel547.Parent = workspace.devices.definds
newmodel547.RandBr.Value = 0.40213015949211833
newmodel548 = workspace.prefabs.defind_y:clone()
newmodel548:PivotTo(CFrame.new(-35.49208647250063, 6.336142732, 39.55600103446693) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel548.Parent = workspace.devices.definds
newmodel548.RandBr.Value = 0.05487601848680927
newmodel549 = workspace.prefabs.defind_y:clone()
newmodel549:PivotTo(CFrame.new(-35.49208647250063, 6.229770344, 39.55600103446693) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel549.Parent = workspace.devices.definds
newmodel549.RandBr.Value = 0.5483401817099595
newmodel550 = workspace.prefabs.defind:clone()
newmodel550:PivotTo(CFrame.new(-35.49208647250063, 6.123400584000001, 39.55600103446693) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel550.Parent = workspace.devices.definds
newmodel550.RandBr.Value = 0.09432937857327651
newmodel551 = workspace.prefabs.defind:clone()
newmodel551:PivotTo(CFrame.new(-35.70090927195408, 6.868000292000001, 39.58038788896614) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel551.Parent = workspace.devices.definds
newmodel551.RandBr.Value = 0.21831002442924868
newmodel552 = workspace.prefabs.defind:clone()
newmodel552:PivotTo(CFrame.new(-35.70090927195408, 6.761628488000001, 39.58038788896614) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel552.Parent = workspace.devices.definds
newmodel552.RandBr.Value = 0.17858755315779978
newmodel553 = workspace.prefabs.defind:clone()
newmodel553:PivotTo(CFrame.new(-35.70090927195408, 6.655257560000001, 39.58038788896614) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel553.Parent = workspace.devices.definds
newmodel553.RandBr.Value = 0.3178855526010655
newmodel554 = workspace.prefabs.defind:clone()
newmodel554:PivotTo(CFrame.new(-35.70090927195408, 6.54888634, 39.58038788896614) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel554.Parent = workspace.devices.definds
newmodel554.RandBr.Value = 0.5068077320741118
newmodel555 = workspace.prefabs.defind_y:clone()
newmodel555:PivotTo(CFrame.new(-35.70090927195408, 6.442513952000001, 39.58038788896614) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel555.Parent = workspace.devices.definds
newmodel555.RandBr.Value = 0.23360364434363398
newmodel556 = workspace.prefabs.defind_y:clone()
newmodel556:PivotTo(CFrame.new(-35.70090927195408, 6.336142732, 39.58038788896614) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel556.Parent = workspace.devices.definds
newmodel556.RandBr.Value = 0.27779474669892007
newmodel557 = workspace.prefabs.defind_y:clone()
newmodel557:PivotTo(CFrame.new(-35.70090927195408, 6.229770344, 39.58038788896614) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel557.Parent = workspace.devices.definds
newmodel557.RandBr.Value = 0.3652673502467295
newmodel558 = workspace.prefabs.defind:clone()
newmodel558:PivotTo(CFrame.new(-35.70090927195408, 6.123400584000001, 39.58038788896614) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel558.Parent = workspace.devices.definds
newmodel558.RandBr.Value = 0.38744956477071635
newmodel559 = workspace.prefabs.defind:clone()
newmodel559:PivotTo(CFrame.new(-35.90973585968216, 6.868000292000001, 39.60477075034427) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel559.Parent = workspace.devices.definds
newmodel559.RandBr.Value = 0.13376939914550376
newmodel560 = workspace.prefabs.defind:clone()
newmodel560:PivotTo(CFrame.new(-35.90973585968216, 6.761628488000001, 39.60477075034427) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel560.Parent = workspace.devices.definds
newmodel560.RandBr.Value = 0.24104090085019672
newmodel561 = workspace.prefabs.defind:clone()
newmodel561:PivotTo(CFrame.new(-35.90973585968216, 6.655257560000001, 39.60477075034427) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel561.Parent = workspace.devices.definds
newmodel561.RandBr.Value = 0.05022992858131729
newmodel562 = workspace.prefabs.defind:clone()
newmodel562:PivotTo(CFrame.new(-35.90973585968216, 6.54888634, 39.60477075034427) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel562.Parent = workspace.devices.definds
newmodel562.RandBr.Value = 0.40595366869339544
newmodel563 = workspace.prefabs.defind_y:clone()
newmodel563:PivotTo(CFrame.new(-35.90973585968216, 6.442513952000001, 39.60477075034427) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel563.Parent = workspace.devices.definds
newmodel563.RandBr.Value = 0.12486409981734425
newmodel564 = workspace.prefabs.defind:clone()
newmodel564:PivotTo(CFrame.new(-35.90973585968216, 6.336142732, 39.60477075034427) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel564.Parent = workspace.devices.definds
newmodel564.RandBr.Value = 0.44601318213877045
newmodel565 = workspace.prefabs.defind_y:clone()
newmodel565:PivotTo(CFrame.new(-35.90973585968216, 6.229770344, 39.60477075034427) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel565.Parent = workspace.devices.definds
newmodel565.RandBr.Value = 0.47301935181314486
newmodel566 = workspace.prefabs.defind:clone()
newmodel566:PivotTo(CFrame.new(-35.90973585968216, 6.123400584000001, 39.60477075034427) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel566.Parent = workspace.devices.definds
newmodel566.RandBr.Value = 0.42886979888967575
newmodel567 = workspace.prefabs.defind:clone()
newmodel567:PivotTo(CFrame.new(-36.11855295717636, 6.868000292000001, 39.62915180268204) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel567.Parent = workspace.devices.definds
newmodel567.RandBr.Value = 0.5585803474655094
newmodel568 = workspace.prefabs.defind:clone()
newmodel568:PivotTo(CFrame.new(-36.11855295717636, 6.761628488000001, 39.62915180268204) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel568.Parent = workspace.devices.definds
newmodel568.RandBr.Value = 0.2637266040136152
newmodel569 = workspace.prefabs.defind:clone()
newmodel569:PivotTo(CFrame.new(-36.11855295717636, 6.655257560000001, 39.62915180268204) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel569.Parent = workspace.devices.definds
newmodel569.RandBr.Value = 0.29185203375687124
newmodel570 = workspace.prefabs.defind:clone()
newmodel570:PivotTo(CFrame.new(-36.11855295717636, 6.54888634, 39.62915180268204) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel570.Parent = workspace.devices.definds
newmodel570.RandBr.Value = 0.2500333760722742
newmodel571 = workspace.prefabs.defind_y:clone()
newmodel571:PivotTo(CFrame.new(-36.11855295717636, 6.442513952000001, 39.62915180268204) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel571.Parent = workspace.devices.definds
newmodel571.RandBr.Value = 0.32023748733554624
newmodel572 = workspace.prefabs.defind:clone()
newmodel572:PivotTo(CFrame.new(-36.11855295717636, 6.336142732, 39.62915180268204) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel572.Parent = workspace.devices.definds
newmodel572.RandBr.Value = 0.5816155262728611
newmodel573 = workspace.prefabs.defind_y:clone()
newmodel573:PivotTo(CFrame.new(-36.11855295717636, 6.229770344, 39.62915180268204) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel573.Parent = workspace.devices.definds
newmodel573.RandBr.Value = 0.023108191876529103
newmodel574 = workspace.prefabs.defind:clone()
newmodel574:PivotTo(CFrame.new(-36.11855295717636, 6.123400584000001, 39.62915180268204) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel574.Parent = workspace.devices.definds
newmodel574.RandBr.Value = 0.33178340105218423
newmodel575 = workspace.prefabs.defind:clone()
newmodel575:PivotTo(CFrame.new(-36.536192359812226, 6.868000292000001, 39.6779196627523) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel575.Parent = workspace.devices.definds
newmodel575.RandBr.Value = 0.43714208279469247
newmodel576 = workspace.prefabs.defind:clone()
newmodel576:PivotTo(CFrame.new(-36.536192359812226, 6.761628488000001, 39.6779196627523) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel576.Parent = workspace.devices.definds
newmodel576.RandBr.Value = 0.4347642903073625
newmodel577 = workspace.prefabs.defind:clone()
newmodel577:PivotTo(CFrame.new(-36.536192359812226, 6.655257560000001, 39.6779196627523) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel577.Parent = workspace.devices.definds
newmodel577.RandBr.Value = 0.26577233197204797
newmodel578 = workspace.prefabs.defind:clone()
newmodel578:PivotTo(CFrame.new(-36.536192359812226, 6.54888634, 39.6779196627523) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel578.Parent = workspace.devices.definds
newmodel578.RandBr.Value = 0.5801885989715934
newmodel579 = workspace.prefabs.defind:clone()
newmodel579:PivotTo(CFrame.new(-36.536192359812226, 6.442513952000001, 39.6779196627523) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel579.Parent = workspace.devices.definds
newmodel579.RandBr.Value = 0.03737557101021569
newmodel580 = workspace.prefabs.defind:clone()
newmodel580:PivotTo(CFrame.new(-36.536192359812226, 6.336142732, 39.6779196627523) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel580.Parent = workspace.devices.definds
newmodel580.RandBr.Value = 0.4525344402740778
newmodel581 = workspace.prefabs.defind_y:clone()
newmodel581:PivotTo(CFrame.new(-36.536192359812226, 6.229770344, 39.6779196627523) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel581.Parent = workspace.devices.definds
newmodel581.RandBr.Value = 0.21854759036853713
newmodel582 = workspace.prefabs.defind:clone()
newmodel582:PivotTo(CFrame.new(-36.536192359812226, 6.123400584000001, 39.6779196627523) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel582.Parent = workspace.devices.definds
newmodel582.RandBr.Value = 0.12434808303770659
newmodel583 = workspace.prefabs.defind:clone()
newmodel583:PivotTo(CFrame.new(-36.745018046180704, 6.868000292000001, 39.70229765487143) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel583.Parent = workspace.devices.definds
newmodel583.RandBr.Value = 0.4354603283114492
newmodel584 = workspace.prefabs.defind:clone()
newmodel584:PivotTo(CFrame.new(-36.745018046180704, 6.761628488000001, 39.70229765487143) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel584.Parent = workspace.devices.definds
newmodel584.RandBr.Value = 0.11665107329057542
newmodel585 = workspace.prefabs.defind:clone()
newmodel585:PivotTo(CFrame.new(-36.745018046180704, 6.655257560000001, 39.70229765487143) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel585.Parent = workspace.devices.definds
newmodel585.RandBr.Value = 0.493474713074614
newmodel586 = workspace.prefabs.defind:clone()
newmodel586:PivotTo(CFrame.new(-36.745018046180704, 6.54888634, 39.70229765487143) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel586.Parent = workspace.devices.definds
newmodel586.RandBr.Value = 0.14319807497742693
newmodel587 = workspace.prefabs.defind:clone()
newmodel587:PivotTo(CFrame.new(-36.745018046180704, 6.442513952000001, 39.70229765487143) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel587.Parent = workspace.devices.definds
newmodel587.RandBr.Value = 0.36706485788167914
newmodel588 = workspace.prefabs.defind:clone()
newmodel588:PivotTo(CFrame.new(-36.745018046180704, 6.336142732, 39.70229765487143) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel588.Parent = workspace.devices.definds
newmodel588.RandBr.Value = 0.41848364270331606
newmodel589 = workspace.prefabs.defind_y:clone()
newmodel589:PivotTo(CFrame.new(-36.745018046180704, 6.229770344, 39.70229765487143) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel589.Parent = workspace.devices.definds
newmodel589.RandBr.Value = 0.5889340023720542
newmodel590 = workspace.prefabs.defind:clone()
newmodel590:PivotTo(CFrame.new(-36.745018046180704, 6.123400584000001, 39.70229765487143) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel590.Parent = workspace.devices.definds
newmodel590.RandBr.Value = 0.5101202884119809
newmodel591 = workspace.prefabs.defind:clone()
newmodel591:PivotTo(CFrame.new(-36.95384398937472, 6.868000292000001, 39.726683518432395) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel591.Parent = workspace.devices.definds
newmodel591.RandBr.Value = 0.3837902758924961
newmodel592 = workspace.prefabs.defind:clone()
newmodel592:PivotTo(CFrame.new(-36.95384398937472, 6.761628488000001, 39.726683518432395) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel592.Parent = workspace.devices.definds
newmodel592.RandBr.Value = 0.1864958913913524
newmodel593 = workspace.prefabs.defind:clone()
newmodel593:PivotTo(CFrame.new(-36.95384398937472, 6.655257560000001, 39.726683518432395) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel593.Parent = workspace.devices.definds
newmodel593.RandBr.Value = 0.432307475496719
newmodel594 = workspace.prefabs.defind_y:clone()
newmodel594:PivotTo(CFrame.new(-36.95384398937472, 6.54888634, 39.726683518432395) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel594.Parent = workspace.devices.definds
newmodel594.RandBr.Value = 0.08501989298615743
newmodel595 = workspace.prefabs.defind:clone()
newmodel595:PivotTo(CFrame.new(-36.95384398937472, 6.442513952000001, 39.726683518432395) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel595.Parent = workspace.devices.definds
newmodel595.RandBr.Value = 0.26328608217975913
newmodel596 = workspace.prefabs.defind:clone()
newmodel596:PivotTo(CFrame.new(-36.95384398937472, 6.336142732, 39.726683518432395) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel596.Parent = workspace.devices.definds
newmodel596.RandBr.Value = 0.24368637091310813
newmodel597 = workspace.prefabs.defind:clone()
newmodel597:PivotTo(CFrame.new(-36.95384398937472, 6.229770344, 39.726683518432395) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel597.Parent = workspace.devices.definds
newmodel597.RandBr.Value = 0.42264151659172305
newmodel598 = workspace.prefabs.defind:clone()
newmodel598:PivotTo(CFrame.new(-36.95384398937472, 6.123400584000001, 39.726683518432395) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel598.Parent = workspace.devices.definds
newmodel598.RandBr.Value = 0.3211170877567931
newmodel599 = workspace.prefabs.defind:clone()
newmodel599:PivotTo(CFrame.new(-37.16265681059039, 6.868000292000001, 39.75106846310253) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel599.Parent = workspace.devices.definds
newmodel599.RandBr.Value = 0.4185225648272088
newmodel600 = workspace.prefabs.defind:clone()
newmodel600:PivotTo(CFrame.new(-37.16265681059039, 6.761628488000001, 39.75106846310253) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel600.Parent = workspace.devices.definds
newmodel600.RandBr.Value = 0.20291711877575858
newmodel601 = workspace.prefabs.defind:clone()
newmodel601:PivotTo(CFrame.new(-37.16265681059039, 6.655257560000001, 39.75106846310253) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel601.Parent = workspace.devices.definds
newmodel601.RandBr.Value = 0.10868276735249705
newmodel602 = workspace.prefabs.defind:clone()
newmodel602:PivotTo(CFrame.new(-37.16265681059039, 6.54888634, 39.75106846310253) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel602.Parent = workspace.devices.definds
newmodel602.RandBr.Value = 0.5120419459340714
newmodel603 = workspace.prefabs.defind:clone()
newmodel603:PivotTo(CFrame.new(-37.16265681059039, 6.442513952000001, 39.75106846310253) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel603.Parent = workspace.devices.definds
newmodel603.RandBr.Value = 0.30702050326977653
newmodel604 = workspace.prefabs.defind_y:clone()
newmodel604:PivotTo(CFrame.new(-37.16265681059039, 6.336142732, 39.75106846310253) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel604.Parent = workspace.devices.definds
newmodel604.RandBr.Value = 0.40926244066752687
newmodel605 = workspace.prefabs.defind:clone()
newmodel605:PivotTo(CFrame.new(-37.16265681059039, 6.229770344, 39.75106846310253) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel605.Parent = workspace.devices.definds
newmodel605.RandBr.Value = 0.02352387808159966
newmodel606 = workspace.prefabs.defind:clone()
newmodel606:PivotTo(CFrame.new(-37.16265681059039, 6.123400584000001, 39.75106846310253) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel606.Parent = workspace.devices.definds
newmodel606.RandBr.Value = 0.11325774079407924
newmodel607 = workspace.prefabs.defind:clone()
newmodel607:PivotTo(CFrame.new(-37.58030049328951, 6.868000292000001, 39.799832398427306) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel607.Parent = workspace.devices.definds
newmodel607.RandBr.Value = 0.5598824034896224
newmodel608 = workspace.prefabs.defind:clone()
newmodel608:PivotTo(CFrame.new(-37.58030049328951, 6.761628488000001, 39.799832398427306) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel608.Parent = workspace.devices.definds
newmodel608.RandBr.Value = 0.2743765933345785
newmodel609 = workspace.prefabs.defind:clone()
newmodel609:PivotTo(CFrame.new(-37.58030049328951, 6.655257560000001, 39.799832398427306) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel609.Parent = workspace.devices.definds
newmodel609.RandBr.Value = 0.13074952769906162
newmodel610 = workspace.prefabs.defind:clone()
newmodel610:PivotTo(CFrame.new(-37.58030049328951, 6.54888634, 39.799832398427306) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel610.Parent = workspace.devices.definds
newmodel610.RandBr.Value = 0.29444021754821936
newmodel611 = workspace.prefabs.defind:clone()
newmodel611:PivotTo(CFrame.new(-37.58030049328951, 6.442513952000001, 39.799832398427306) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel611.Parent = workspace.devices.definds
newmodel611.RandBr.Value = 0.5032140417761077
newmodel612 = workspace.prefabs.defind_y:clone()
newmodel612:PivotTo(CFrame.new(-37.58030049328951, 6.336142732, 39.799832398427306) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel612.Parent = workspace.devices.definds
newmodel612.RandBr.Value = 0.2299814630736123
newmodel613 = workspace.prefabs.defind_y:clone()
newmodel613:PivotTo(CFrame.new(-37.58030049328951, 6.229770344, 39.799832398427306) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel613.Parent = workspace.devices.definds
newmodel613.RandBr.Value = 0.5131805591736337
newmodel614 = workspace.prefabs.defind:clone()
newmodel614:PivotTo(CFrame.new(-37.58030049328951, 6.123400584000001, 39.799832398427306) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel614.Parent = workspace.devices.definds
newmodel614.RandBr.Value = 0.06386430421201336
newmodel615 = workspace.prefabs.defind:clone()
newmodel615:PivotTo(CFrame.new(-37.78912524635609, 6.868000292000001, 39.8242133480583) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel615.Parent = workspace.devices.definds
newmodel615.RandBr.Value = 0.5110609694723731
newmodel616 = workspace.prefabs.defind:clone()
newmodel616:PivotTo(CFrame.new(-37.78912524635609, 6.761628488000001, 39.8242133480583) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel616.Parent = workspace.devices.definds
newmodel616.RandBr.Value = 0.13552361419564116
newmodel617 = workspace.prefabs.defind:clone()
newmodel617:PivotTo(CFrame.new(-37.78912524635609, 6.655257560000001, 39.8242133480583) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel617.Parent = workspace.devices.definds
newmodel617.RandBr.Value = 0.08697055855653184
newmodel618 = workspace.prefabs.defind:clone()
newmodel618:PivotTo(CFrame.new(-37.78912524635609, 6.54888634, 39.8242133480583) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel618.Parent = workspace.devices.definds
newmodel618.RandBr.Value = 0.002195821944374354
newmodel619 = workspace.prefabs.defind:clone()
newmodel619:PivotTo(CFrame.new(-37.78912524635609, 6.442513952000001, 39.8242133480583) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel619.Parent = workspace.devices.definds
newmodel619.RandBr.Value = 0.13551249400963594
newmodel620 = workspace.prefabs.defind_y:clone()
newmodel620:PivotTo(CFrame.new(-37.78912524635609, 6.336142732, 39.8242133480583) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel620.Parent = workspace.devices.definds
newmodel620.RandBr.Value = 0.576542307518855
newmodel621 = workspace.prefabs.defind_y:clone()
newmodel621:PivotTo(CFrame.new(-37.78912524635609, 6.229770344, 39.8242133480583) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel621.Parent = workspace.devices.definds
newmodel621.RandBr.Value = 0.34866653639256256
newmodel622 = workspace.prefabs.defind:clone()
newmodel622:PivotTo(CFrame.new(-37.78912524635609, 6.123400584000001, 39.8242133480583) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel622.Parent = workspace.devices.definds
newmodel622.RandBr.Value = 0.007516807057055197
newmodel623 = workspace.prefabs.defind:clone()
newmodel623:PivotTo(CFrame.new(-37.99794600938868, 6.868000292000001, 39.84859825630251) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel623.Parent = workspace.devices.definds
newmodel623.RandBr.Value = 0.4163066132625258
newmodel624 = workspace.prefabs.defind:clone()
newmodel624:PivotTo(CFrame.new(-37.99794600938868, 6.761628488000001, 39.84859825630251) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel624.Parent = workspace.devices.definds
newmodel624.RandBr.Value = 0.25867126146569785
newmodel625 = workspace.prefabs.defind:clone()
newmodel625:PivotTo(CFrame.new(-37.99794600938868, 6.655257560000001, 39.84859825630251) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel625.Parent = workspace.devices.definds
newmodel625.RandBr.Value = 0.43874089777324965
newmodel626 = workspace.prefabs.defind:clone()
newmodel626:PivotTo(CFrame.new(-37.99794600938868, 6.54888634, 39.84859825630251) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel626.Parent = workspace.devices.definds
newmodel626.RandBr.Value = 0.386621500951131
newmodel627 = workspace.prefabs.defind_y:clone()
newmodel627:PivotTo(CFrame.new(-37.99794600938868, 6.442513952000001, 39.84859825630251) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel627.Parent = workspace.devices.definds
newmodel627.RandBr.Value = 0.3190585198680463
newmodel628 = workspace.prefabs.defind_y:clone()
newmodel628:PivotTo(CFrame.new(-37.99794600938868, 6.336142732, 39.84859825630251) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel628.Parent = workspace.devices.definds
newmodel628.RandBr.Value = 0.12501138465515635
newmodel629 = workspace.prefabs.defind_y:clone()
newmodel629:PivotTo(CFrame.new(-37.99794600938868, 6.229770344, 39.84859825630251) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel629.Parent = workspace.devices.definds
newmodel629.RandBr.Value = 0.09465446440767837
newmodel630 = workspace.prefabs.defind:clone()
newmodel630:PivotTo(CFrame.new(-37.99794600938868, 6.123400584000001, 39.84859825630251) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel630.Parent = workspace.devices.definds
newmodel630.RandBr.Value = 0.32711411858724126
newmodel631 = workspace.prefabs.defind:clone()
newmodel631:PivotTo(CFrame.new(-38.20676571322978, 6.868000292000001, 39.872982164728754) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel631.Parent = workspace.devices.definds
newmodel631.RandBr.Value = 0.09901392619418671
newmodel632 = workspace.prefabs.defind_y:clone()
newmodel632:PivotTo(CFrame.new(-38.20676571322978, 6.761628488000001, 39.872982164728754) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel632.Parent = workspace.devices.definds
newmodel632.RandBr.Value = 0.2938240625621014
newmodel633 = workspace.prefabs.defind_y:clone()
newmodel633:PivotTo(CFrame.new(-38.20676571322978, 6.655257560000001, 39.872982164728754) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel633.Parent = workspace.devices.definds
newmodel633.RandBr.Value = 0.4040844666576809
newmodel634 = workspace.prefabs.defind:clone()
newmodel634:PivotTo(CFrame.new(-38.20676571322978, 6.54888634, 39.872982164728754) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel634.Parent = workspace.devices.definds
newmodel634.RandBr.Value = 0.2853662201577091
newmodel635 = workspace.prefabs.defind_y:clone()
newmodel635:PivotTo(CFrame.new(-38.20676571322978, 6.442513952000001, 39.872982164728754) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel635.Parent = workspace.devices.definds
newmodel635.RandBr.Value = 0.5073523672551914
newmodel636 = workspace.prefabs.defind:clone()
newmodel636:PivotTo(CFrame.new(-38.20676571322978, 6.336142732, 39.872982164728754) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel636.Parent = workspace.devices.definds
newmodel636.RandBr.Value = 0.2195139036059794
newmodel637 = workspace.prefabs.defind:clone()
newmodel637:PivotTo(CFrame.new(-38.20676571322978, 6.229770344, 39.872982164728754) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel637.Parent = workspace.devices.definds
newmodel637.RandBr.Value = 0.4954945288971813
newmodel638 = workspace.prefabs.defind:clone()
newmodel638:PivotTo(CFrame.new(-38.20676571322978, 6.123400584000001, 39.872982164728754) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel638.Parent = workspace.devices.definds
newmodel638.RandBr.Value = 0.11400219756974567
newmodel639 = workspace.prefabs.defind_y:clone()
newmodel639:PivotTo(CFrame.new(-36.646405270616434, 7.043200000000001, 39.69078667100608) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel639.Parent = workspace.devices.definds
newmodel639.RandBr.Value = 0.44485256081428975
newmodel640 = workspace.prefabs.defind_r:clone()
newmodel640:PivotTo(CFrame.new(-37.05244663886781, 7.043200000000001, 39.7381981386964) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel640.Parent = workspace.devices.definds
newmodel640.RandBr.Value = 0.2879536686880761
newmodel641 = workspace.prefabs.defind_y:clone()
newmodel641:PivotTo(CFrame.new(-38.6891304788831, 6.868000292000001, 39.916130933909386) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel641.Parent = workspace.devices.definds
newmodel641.RandBr.Value = 0.0142591735036538
newmodel642 = workspace.prefabs.defind:clone()
newmodel642:PivotTo(CFrame.new(-39.73417575442139, 6.868000292000001, 39.94184945920574) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel642.Parent = workspace.devices.definds
newmodel642.RandBr.Value = 0.2087607828342415
newmodel643 = workspace.prefabs.defind:clone()
newmodel643:PivotTo(CFrame.new(-38.6891304788831, 6.759960584000001, 39.916130933909386) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel643.Parent = workspace.devices.definds
newmodel643.RandBr.Value = 0.038365269427122484
newmodel644 = workspace.prefabs.defind:clone()
newmodel644:PivotTo(CFrame.new(-38.6891304788831, 6.6519200000000005, 39.916130933909386) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel644.Parent = workspace.devices.definds
newmodel644.RandBr.Value = 0.21771826904704708
newmodel645 = workspace.prefabs.defind:clone()
newmodel645:PivotTo(CFrame.new(-38.6891304788831, 6.543880292000001, 39.916130933909386) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel645.Parent = workspace.devices.definds
newmodel645.RandBr.Value = 0.4800439700466205
newmodel646 = workspace.prefabs.defind_y:clone()
newmodel646:PivotTo(CFrame.new(-38.6891304788831, 6.435840292000001, 39.916130933909386) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel646.Parent = workspace.devices.definds
newmodel646.RandBr.Value = 0.059060229637514894
newmodel647 = workspace.prefabs.defind_y:clone()
newmodel647:PivotTo(CFrame.new(-38.6891304788831, 6.327800584, 39.916130933909386) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel647.Parent = workspace.devices.definds
newmodel647.RandBr.Value = 0.3242199620727389
newmodel648 = workspace.prefabs.defind_y:clone()
newmodel648:PivotTo(CFrame.new(-38.6891304788831, 6.219760000000001, 39.916130933909386) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel648.Parent = workspace.devices.definds
newmodel648.RandBr.Value = 0.17789653773857117
newmodel649 = workspace.prefabs.defind_y:clone()
newmodel649:PivotTo(CFrame.new(-38.6891304788831, 6.111720292, 39.916130933909386) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel649.Parent = workspace.devices.definds
newmodel649.RandBr.Value = 0.2884875455317853
newmodel650 = workspace.prefabs.defind_y:clone()
newmodel650:PivotTo(CFrame.new(-38.6891304788831, 6.003680292, 39.916130933909386) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel650.Parent = workspace.devices.definds
newmodel650.RandBr.Value = 0.26784509053871425
newmodel651 = workspace.prefabs.defind_y:clone()
newmodel651:PivotTo(CFrame.new(-38.6891304788831, 5.895639708, 39.916130933909386) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel651.Parent = workspace.devices.definds
newmodel651.RandBr.Value = 0.3542984950175617
newmodel652 = workspace.prefabs.defind_y:clone()
newmodel652:PivotTo(CFrame.new(-38.6891304788831, 5.7876002920000005, 39.916130933909386) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel652.Parent = workspace.devices.definds
newmodel652.RandBr.Value = 0.4115180012199297
newmodel653 = workspace.prefabs.defind:clone()
newmodel653:PivotTo(CFrame.new(-38.6891304788831, 5.679559708000001, 39.916130933909386) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel653.Parent = workspace.devices.definds
newmodel653.RandBr.Value = 0.3378080946251657
newmodel654 = workspace.prefabs.defind_y:clone()
newmodel654:PivotTo(CFrame.new(-38.8993055625703, 6.868000292000001, 39.92130549895331) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel654.Parent = workspace.devices.definds
newmodel654.RandBr.Value = 0.20185964488808786
newmodel655 = workspace.prefabs.defind:clone()
newmodel655:PivotTo(CFrame.new(-38.8993055625703, 6.759960584000001, 39.92130549895331) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel655.Parent = workspace.devices.definds
newmodel655.RandBr.Value = 0.03358161860607287
newmodel656 = workspace.prefabs.defind:clone()
newmodel656:PivotTo(CFrame.new(-38.8993055625703, 6.6519200000000005, 39.92130549895331) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel656.Parent = workspace.devices.definds
newmodel656.RandBr.Value = 0.19717460517240862
newmodel657 = workspace.prefabs.defind:clone()
newmodel657:PivotTo(CFrame.new(-38.8993055625703, 6.543880292000001, 39.92130549895331) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel657.Parent = workspace.devices.definds
newmodel657.RandBr.Value = 0.1605148215803809
newmodel658 = workspace.prefabs.defind_y:clone()
newmodel658:PivotTo(CFrame.new(-38.8993055625703, 6.435840292000001, 39.92130549895331) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel658.Parent = workspace.devices.definds
newmodel658.RandBr.Value = 0.33705285385036055
newmodel659 = workspace.prefabs.defind_y:clone()
newmodel659:PivotTo(CFrame.new(-38.8993055625703, 6.327800584, 39.92130549895331) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel659.Parent = workspace.devices.definds
newmodel659.RandBr.Value = 0.1208459152236238
newmodel660 = workspace.prefabs.defind_y:clone()
newmodel660:PivotTo(CFrame.new(-38.8993055625703, 6.219760000000001, 39.92130549895331) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel660.Parent = workspace.devices.definds
newmodel660.RandBr.Value = 0.41072700655107397
newmodel661 = workspace.prefabs.defind_y:clone()
newmodel661:PivotTo(CFrame.new(-38.8993055625703, 6.111720292, 39.92130549895331) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel661.Parent = workspace.devices.definds
newmodel661.RandBr.Value = 0.4450271282531606
newmodel662 = workspace.prefabs.defind_y:clone()
newmodel662:PivotTo(CFrame.new(-38.8993055625703, 6.003680292, 39.92130549895331) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel662.Parent = workspace.devices.definds
newmodel662.RandBr.Value = 0.175952305291225
newmodel663 = workspace.prefabs.defind_y:clone()
newmodel663:PivotTo(CFrame.new(-38.8993055625703, 5.895639708, 39.92130549895331) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel663.Parent = workspace.devices.definds
newmodel663.RandBr.Value = 0.015713636141679553
newmodel664 = workspace.prefabs.defind_y:clone()
newmodel664:PivotTo(CFrame.new(-38.8993055625703, 5.7876002920000005, 39.92130549895331) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel664.Parent = workspace.devices.definds
newmodel664.RandBr.Value = 0.1788646738934855
newmodel665 = workspace.prefabs.defind:clone()
newmodel665:PivotTo(CFrame.new(-38.8993055625703, 5.679559708000001, 39.92130549895331) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel665.Parent = workspace.devices.definds
newmodel665.RandBr.Value = 0.35202441030079623
newmodel666 = workspace.prefabs.defind_y:clone()
newmodel666:PivotTo(CFrame.new(-39.10948554867618, 6.868000292000001, 39.9264731336853) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel666.Parent = workspace.devices.definds
newmodel666.RandBr.Value = 0.5341648809412056
newmodel667 = workspace.prefabs.defind:clone()
newmodel667:PivotTo(CFrame.new(-39.10948554867618, 6.759960584000001, 39.9264731336853) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel667.Parent = workspace.devices.definds
newmodel667.RandBr.Value = 0.38868624836102933
newmodel668 = workspace.prefabs.defind:clone()
newmodel668:PivotTo(CFrame.new(-39.10948554867618, 6.6519200000000005, 39.9264731336853) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel668.Parent = workspace.devices.definds
newmodel668.RandBr.Value = 0.01985029832023086
newmodel669 = workspace.prefabs.defind:clone()
newmodel669:PivotTo(CFrame.new(-39.10948554867618, 6.543880292000001, 39.9264731336853) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel669.Parent = workspace.devices.definds
newmodel669.RandBr.Value = 0.16634555666787462
newmodel670 = workspace.prefabs.defind_y:clone()
newmodel670:PivotTo(CFrame.new(-39.10948554867618, 6.435840292000001, 39.9264731336853) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel670.Parent = workspace.devices.definds
newmodel670.RandBr.Value = 0.4236022753837492
newmodel671 = workspace.prefabs.defind_y:clone()
newmodel671:PivotTo(CFrame.new(-39.10948554867618, 6.327800584, 39.9264731336853) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel671.Parent = workspace.devices.definds
newmodel671.RandBr.Value = 0.5979172359555228
newmodel672 = workspace.prefabs.defind_y:clone()
newmodel672:PivotTo(CFrame.new(-39.10948554867618, 6.219760000000001, 39.9264731336853) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel672.Parent = workspace.devices.definds
newmodel672.RandBr.Value = 0.14460893206162292
newmodel673 = workspace.prefabs.defind_y:clone()
newmodel673:PivotTo(CFrame.new(-39.10948554867618, 6.111720292, 39.9264731336853) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel673.Parent = workspace.devices.definds
newmodel673.RandBr.Value = 0.5527127103223335
newmodel674 = workspace.prefabs.defind_y:clone()
newmodel674:PivotTo(CFrame.new(-39.10948554867618, 6.003680292, 39.9264731336853) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel674.Parent = workspace.devices.definds
newmodel674.RandBr.Value = 0.08041335781432586
newmodel675 = workspace.prefabs.defind_y:clone()
newmodel675:PivotTo(CFrame.new(-39.10948554867618, 5.895639708, 39.9264731336853) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel675.Parent = workspace.devices.definds
newmodel675.RandBr.Value = 0.09493125405218084
newmodel676 = workspace.prefabs.defind_y:clone()
newmodel676:PivotTo(CFrame.new(-39.10948554867618, 5.7876002920000005, 39.9264731336853) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel676.Parent = workspace.devices.definds
newmodel676.RandBr.Value = 0.24675300545476672
newmodel677 = workspace.prefabs.defind:clone()
newmodel677:PivotTo(CFrame.new(-39.10948554867618, 5.679559708000001, 39.9264731336853) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel677.Parent = workspace.devices.definds
newmodel677.RandBr.Value = 0.4140125179843023
newmodel678 = workspace.prefabs.defind_y:clone()
newmodel678:PivotTo(CFrame.new(-39.31965990976662, 6.868000292000001, 39.931643829017176) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel678.Parent = workspace.devices.definds
newmodel678.RandBr.Value = 0.4611234239282917
newmodel679 = workspace.prefabs.defind:clone()
newmodel679:PivotTo(CFrame.new(-39.31965990976662, 6.759960584000001, 39.931643829017176) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel679.Parent = workspace.devices.definds
newmodel679.RandBr.Value = 0.22110101547418337
newmodel680 = workspace.prefabs.defind:clone()
newmodel680:PivotTo(CFrame.new(-39.31965990976662, 6.6519200000000005, 39.931643829017176) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel680.Parent = workspace.devices.definds
newmodel680.RandBr.Value = 0.12794526304859358
newmodel681 = workspace.prefabs.defind:clone()
newmodel681:PivotTo(CFrame.new(-39.31965990976662, 6.543880292000001, 39.931643829017176) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel681.Parent = workspace.devices.definds
newmodel681.RandBr.Value = 0.4672922919177629
newmodel682 = workspace.prefabs.defind_y:clone()
newmodel682:PivotTo(CFrame.new(-39.31965990976662, 6.435840292000001, 39.931643829017176) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel682.Parent = workspace.devices.definds
newmodel682.RandBr.Value = 0.15429732762481604
newmodel683 = workspace.prefabs.defind_y:clone()
newmodel683:PivotTo(CFrame.new(-39.31965990976662, 6.327800584, 39.931643829017176) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel683.Parent = workspace.devices.definds
newmodel683.RandBr.Value = 0.47246833769907126
newmodel684 = workspace.prefabs.defind_y:clone()
newmodel684:PivotTo(CFrame.new(-39.31965990976662, 6.219760000000001, 39.931643829017176) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel684.Parent = workspace.devices.definds
newmodel684.RandBr.Value = 0.32307911776629583
newmodel685 = workspace.prefabs.defind_y:clone()
newmodel685:PivotTo(CFrame.new(-39.31965990976662, 6.111720292, 39.931643829017176) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel685.Parent = workspace.devices.definds
newmodel685.RandBr.Value = 0.30982336654643094
newmodel686 = workspace.prefabs.defind_y:clone()
newmodel686:PivotTo(CFrame.new(-39.31965990976662, 6.003680292, 39.931643829017176) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel686.Parent = workspace.devices.definds
newmodel686.RandBr.Value = 0.05775375623741381
newmodel687 = workspace.prefabs.defind_y:clone()
newmodel687:PivotTo(CFrame.new(-39.31965990976662, 5.895639708, 39.931643829017176) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel687.Parent = workspace.devices.definds
newmodel687.RandBr.Value = 0.5289225494182593
newmodel688 = workspace.prefabs.defind_y:clone()
newmodel688:PivotTo(CFrame.new(-39.31965990976662, 5.7876002920000005, 39.931643829017176) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel688.Parent = workspace.devices.definds
newmodel688.RandBr.Value = 0.5934704155568038
newmodel689 = workspace.prefabs.defind:clone()
newmodel689:PivotTo(CFrame.new(-39.31965990976662, 5.679559708000001, 39.931643829017176) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel689.Parent = workspace.devices.definds
newmodel689.RandBr.Value = 0.4779347559554261
newmodel690 = workspace.prefabs.defind:clone()
newmodel690:PivotTo(CFrame.new(-39.73417575442139, 6.760794536000001, 39.94184945920574) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel690.Parent = workspace.devices.definds
newmodel690.RandBr.Value = 0.2563411362424431
newmodel691 = workspace.prefabs.defind:clone()
newmodel691:PivotTo(CFrame.new(-39.73417575442139, 6.653588780000001, 39.94184945920574) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel691.Parent = workspace.devices.definds
newmodel691.RandBr.Value = 0.19794250453396334
newmodel692 = workspace.prefabs.defind:clone()
newmodel692:PivotTo(CFrame.new(-39.73417575442139, 6.546383024000001, 39.94184945920574) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel692.Parent = workspace.devices.definds
newmodel692.RandBr.Value = 0.261936304385621
newmodel693 = workspace.prefabs.defind_y:clone()
newmodel693:PivotTo(CFrame.new(-39.73417575442139, 6.439177852, 39.94184945920574) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel693.Parent = workspace.devices.definds
newmodel693.RandBr.Value = 0.41061167189379855
newmodel694 = workspace.prefabs.defind_y:clone()
newmodel694:PivotTo(CFrame.new(-39.73417575442139, 6.331972096000001, 39.94184945920574) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel694.Parent = workspace.devices.definds
newmodel694.RandBr.Value = 0.25975194661522366
newmodel695 = workspace.prefabs.defind_y:clone()
newmodel695:PivotTo(CFrame.new(-39.73417575442139, 6.224766340000001, 39.94184945920574) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel695.Parent = workspace.devices.definds
newmodel695.RandBr.Value = 0.035382462484463174
newmodel696 = workspace.prefabs.defind_y:clone()
newmodel696:PivotTo(CFrame.new(-39.73417575442139, 6.117560292000001, 39.94184945920574) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel696.Parent = workspace.devices.definds
newmodel696.RandBr.Value = 0.5288496851611743
newmodel697 = workspace.prefabs.defind:clone()
newmodel697:PivotTo(CFrame.new(-39.94435434375432, 6.868000292000001, 39.94702637381546) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel697.Parent = workspace.devices.definds
newmodel697.RandBr.Value = 0.31159116569961853
newmodel698 = workspace.prefabs.defind:clone()
newmodel698:PivotTo(CFrame.new(-39.94435434375432, 6.760794536000001, 39.94702637381546) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel698.Parent = workspace.devices.definds
newmodel698.RandBr.Value = 0.31604518120860675
newmodel699 = workspace.prefabs.defind:clone()
newmodel699:PivotTo(CFrame.new(-39.94435434375432, 6.653588780000001, 39.94702637381546) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel699.Parent = workspace.devices.definds
newmodel699.RandBr.Value = 0.23877121945253268
newmodel700 = workspace.prefabs.defind:clone()
newmodel700:PivotTo(CFrame.new(-39.94435434375432, 6.546383024000001, 39.94702637381546) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel700.Parent = workspace.devices.definds
newmodel700.RandBr.Value = 0.039957141281057894
newmodel701 = workspace.prefabs.defind_y:clone()
newmodel701:PivotTo(CFrame.new(-39.94435434375432, 6.439177852, 39.94702637381546) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel701.Parent = workspace.devices.definds
newmodel701.RandBr.Value = 0.07169051147625911
newmodel702 = workspace.prefabs.defind_y:clone()
newmodel702:PivotTo(CFrame.new(-39.94435434375432, 6.331972096000001, 39.94702637381546) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel702.Parent = workspace.devices.definds
newmodel702.RandBr.Value = 0.23227559993977095
newmodel703 = workspace.prefabs.defind_y:clone()
newmodel703:PivotTo(CFrame.new(-39.94435434375432, 6.224766340000001, 39.94702637381546) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel703.Parent = workspace.devices.definds
newmodel703.RandBr.Value = 0.493307124981042
newmodel704 = workspace.prefabs.defind_y:clone()
newmodel704:PivotTo(CFrame.new(-39.94435434375432, 6.117560292000001, 39.94702637381546) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel704.Parent = workspace.devices.definds
newmodel704.RandBr.Value = 0.08919231700506244
newmodel705 = workspace.prefabs.defind:clone()
newmodel705:PivotTo(CFrame.new(-40.15452985482479, 6.868000292000001, 39.95219781560871) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel705.Parent = workspace.devices.definds
newmodel705.RandBr.Value = 0.25963598800000115
newmodel706 = workspace.prefabs.defind:clone()
newmodel706:PivotTo(CFrame.new(-40.15452985482479, 6.760794536000001, 39.95219781560871) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel706.Parent = workspace.devices.definds
newmodel706.RandBr.Value = 0.10868873940937493
newmodel707 = workspace.prefabs.defind:clone()
newmodel707:PivotTo(CFrame.new(-40.15452985482479, 6.653588780000001, 39.95219781560871) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel707.Parent = workspace.devices.definds
newmodel707.RandBr.Value = 0.17195270815653974
newmodel708 = workspace.prefabs.defind:clone()
newmodel708:PivotTo(CFrame.new(-40.15452985482479, 6.546383024000001, 39.95219781560871) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel708.Parent = workspace.devices.definds
newmodel708.RandBr.Value = 0.048471595323541124
newmodel709 = workspace.prefabs.defind_y:clone()
newmodel709:PivotTo(CFrame.new(-40.15452985482479, 6.439177852, 39.95219781560871) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel709.Parent = workspace.devices.definds
newmodel709.RandBr.Value = 0.17020964103225458
newmodel710 = workspace.prefabs.defind:clone()
newmodel710:PivotTo(CFrame.new(-40.15452985482479, 6.331972096000001, 39.95219781560871) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel710.Parent = workspace.devices.definds
newmodel710.RandBr.Value = 0.3106997587396815
newmodel711 = workspace.prefabs.defind_y:clone()
newmodel711:PivotTo(CFrame.new(-40.15452985482479, 6.224766340000001, 39.95219781560871) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel711.Parent = workspace.devices.definds
newmodel711.RandBr.Value = 0.17933427825088272
newmodel712 = workspace.prefabs.defind_y:clone()
newmodel712:PivotTo(CFrame.new(-40.15452985482479, 6.117560292000001, 39.95219781560871) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel712.Parent = workspace.devices.definds
newmodel712.RandBr.Value = 0.5447311128599915
newmodel713 = workspace.prefabs.defind:clone()
newmodel713:PivotTo(CFrame.new(-40.36470413829056, 6.868000292000001, 39.95737166456097) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel713.Parent = workspace.devices.definds
newmodel713.RandBr.Value = 0.5510202050675385
newmodel714 = workspace.prefabs.defind:clone()
newmodel714:PivotTo(CFrame.new(-40.36470413829056, 6.760794536000001, 39.95737166456097) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel714.Parent = workspace.devices.definds
newmodel714.RandBr.Value = 0.4427788040112175
newmodel715 = workspace.prefabs.defind:clone()
newmodel715:PivotTo(CFrame.new(-40.36470413829056, 6.653588780000001, 39.95737166456097) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel715.Parent = workspace.devices.definds
newmodel715.RandBr.Value = 0.24757495649242311
newmodel716 = workspace.prefabs.defind:clone()
newmodel716:PivotTo(CFrame.new(-40.36470413829056, 6.546383024000001, 39.95737166456097) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel716.Parent = workspace.devices.definds
newmodel716.RandBr.Value = 0.4610427558400406
newmodel717 = workspace.prefabs.defind:clone()
newmodel717:PivotTo(CFrame.new(-40.36470413829056, 6.439177852, 39.95737166456097) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel717.Parent = workspace.devices.definds
newmodel717.RandBr.Value = 0.15199798533418
newmodel718 = workspace.prefabs.defind_y:clone()
newmodel718:PivotTo(CFrame.new(-40.36470413829056, 6.331972096000001, 39.95737166456097) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel718.Parent = workspace.devices.definds
newmodel718.RandBr.Value = 0.4239039009877754
newmodel719 = workspace.prefabs.defind_y:clone()
newmodel719:PivotTo(CFrame.new(-40.36470413829056, 6.224766340000001, 39.95737166456097) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel719.Parent = workspace.devices.definds
newmodel719.RandBr.Value = 0.5981629712698607
newmodel720 = workspace.prefabs.defind_y:clone()
newmodel720:PivotTo(CFrame.new(-40.36470413829056, 6.117560292000001, 39.95737166456097) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel720.Parent = workspace.devices.definds
newmodel720.RandBr.Value = 0.17874323373739048
newmodel721 = workspace.prefabs.defind:clone()
newmodel721:PivotTo(CFrame.new(-41.88969097572347, 6.868000292000001, 39.982747808517345) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel721.Parent = workspace.devices.definds
newmodel721.RandBr.Value = 0.25390408561681865
newmodel722 = workspace.prefabs.defind:clone()
newmodel722:PivotTo(CFrame.new(-41.88969097572347, 6.760932944, 39.982747808517345) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel722.Parent = workspace.devices.definds
newmodel722.RandBr.Value = 0.12733972166688087
newmodel723 = workspace.prefabs.defind:clone()
newmodel723:PivotTo(CFrame.new(-41.88969097572347, 6.653865888000001, 39.982747808517345) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel723.Parent = workspace.devices.definds
newmodel723.RandBr.Value = 0.21167379248155074
newmodel724 = workspace.prefabs.defind:clone()
newmodel724:PivotTo(CFrame.new(-41.88969097572347, 6.546800584000001, 39.982747808517345) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel724.Parent = workspace.devices.definds
newmodel724.RandBr.Value = 0.06161082365256416
newmodel725 = workspace.prefabs.defind:clone()
newmodel725:PivotTo(CFrame.new(-42.10013040881896, 6.868000292000001, 39.968624152569014) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel725.Parent = workspace.devices.definds
newmodel725.RandBr.Value = 0.39048329399008813
newmodel726 = workspace.prefabs.defind:clone()
newmodel726:PivotTo(CFrame.new(-42.10013040881896, 6.760932944, 39.968624152569014) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel726.Parent = workspace.devices.definds
newmodel726.RandBr.Value = 0.3909449460750607
newmodel727 = workspace.prefabs.defind:clone()
newmodel727:PivotTo(CFrame.new(-42.10013040881896, 6.653865888000001, 39.968624152569014) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel727.Parent = workspace.devices.definds
newmodel727.RandBr.Value = 0.5035468590327961
newmodel728 = workspace.prefabs.defind:clone()
newmodel728:PivotTo(CFrame.new(-42.10013040881896, 6.546800584000001, 39.968624152569014) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel728.Parent = workspace.devices.definds
newmodel728.RandBr.Value = 0.1526213489341152
newmodel729 = workspace.prefabs.defind:clone()
newmodel729:PivotTo(CFrame.new(-42.31057475211636, 6.868000292000001, 39.95449647660549) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel729.Parent = workspace.devices.definds
newmodel729.RandBr.Value = 0.3704156352723107
newmodel730 = workspace.prefabs.defind:clone()
newmodel730:PivotTo(CFrame.new(-42.31057475211636, 6.760932944, 39.95449647660549) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel730.Parent = workspace.devices.definds
newmodel730.RandBr.Value = 0.19579448538137972
newmodel731 = workspace.prefabs.defind:clone()
newmodel731:PivotTo(CFrame.new(-42.31057475211636, 6.653865888000001, 39.95449647660549) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel731.Parent = workspace.devices.definds
newmodel731.RandBr.Value = 0.27177958873962454
newmodel732 = workspace.prefabs.defind:clone()
newmodel732:PivotTo(CFrame.new(-42.31057475211636, 6.546800584000001, 39.95449647660549) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel732.Parent = workspace.devices.definds
newmodel732.RandBr.Value = 0.5719304748006687
newmodel733 = workspace.prefabs.defind:clone()
newmodel733:PivotTo(CFrame.new(-42.52100406351818, 6.868000292000001, 39.94037157577475) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel733.Parent = workspace.devices.definds
newmodel733.RandBr.Value = 0.12760513436740703
newmodel734 = workspace.prefabs.defind:clone()
newmodel734:PivotTo(CFrame.new(-42.52100406351818, 6.760932944, 39.94037157577475) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel734.Parent = workspace.devices.definds
newmodel734.RandBr.Value = 0.23319491474621315
newmodel735 = workspace.prefabs.defind:clone()
newmodel735:PivotTo(CFrame.new(-42.52100406351818, 6.653865888000001, 39.94037157577475) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel735.Parent = workspace.devices.definds
newmodel735.RandBr.Value = 0.33409880331792946
newmodel736 = workspace.prefabs.defind_y:clone()
newmodel736:PivotTo(CFrame.new(-42.52100406351818, 6.546800584000001, 39.94037157577475) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel736.Parent = workspace.devices.definds
newmodel736.RandBr.Value = 0.25239248730819397
newmodel737 = workspace.prefabs.defind:clone()
newmodel737:PivotTo(CFrame.new(-43.99408785252957, 6.868000292000001, 39.841499908719896) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel737.Parent = workspace.devices.definds
newmodel737.RandBr.Value = 0.367326593385741
newmodel738 = workspace.prefabs.defind:clone()
newmodel738:PivotTo(CFrame.new(-43.99408785252957, 6.760932944, 39.841499908719896) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel738.Parent = workspace.devices.definds
newmodel738.RandBr.Value = 0.5443556595000383
newmodel739 = workspace.prefabs.defind:clone()
newmodel739:PivotTo(CFrame.new(-43.99408785252957, 6.653865888000001, 39.841499908719896) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel739.Parent = workspace.devices.definds
newmodel739.RandBr.Value = 0.4242087673412044
newmodel740 = workspace.prefabs.defind_y:clone()
newmodel740:PivotTo(CFrame.new(-43.99408785252957, 6.546800584000001, 39.841499908719896) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel740.Parent = workspace.devices.definds
newmodel740.RandBr.Value = 0.3927203820181811
newmodel741 = workspace.prefabs.defind:clone()
newmodel741:PivotTo(CFrame.new(-44.204535406391194, 6.868000292000001, 39.827367743549196) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel741.Parent = workspace.devices.definds
newmodel741.RandBr.Value = 0.44867484375915084
newmodel742 = workspace.prefabs.defind:clone()
newmodel742:PivotTo(CFrame.new(-44.204535406391194, 6.760932944, 39.827367743549196) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel742.Parent = workspace.devices.definds
newmodel742.RandBr.Value = 0.1868331368587096
newmodel743 = workspace.prefabs.defind:clone()
newmodel743:PivotTo(CFrame.new(-44.204535406391194, 6.653865888000001, 39.827367743549196) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel743.Parent = workspace.devices.definds
newmodel743.RandBr.Value = 0.2664394745597277
newmodel744 = workspace.prefabs.defind_y:clone()
newmodel744:PivotTo(CFrame.new(-44.204535406391194, 6.546800584000001, 39.827367743549196) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel744.Parent = workspace.devices.definds
newmodel744.RandBr.Value = 0.3831116003505469
newmodel745 = workspace.prefabs.defind:clone()
newmodel745:PivotTo(CFrame.new(-44.41497766375922, 6.868000292000001, 39.81324823170543) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel745.Parent = workspace.devices.definds
newmodel745.RandBr.Value = 0.4512708326278032
newmodel746 = workspace.prefabs.defind:clone()
newmodel746:PivotTo(CFrame.new(-44.41497766375922, 6.760932944, 39.81324823170543) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel746.Parent = workspace.devices.definds
newmodel746.RandBr.Value = 0.022724876563203076
newmodel747 = workspace.prefabs.defind:clone()
newmodel747:PivotTo(CFrame.new(-44.41497766375922, 6.653865888000001, 39.81324823170543) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel747.Parent = workspace.devices.definds
newmodel747.RandBr.Value = 0.44780894265733723
newmodel748 = workspace.prefabs.defind_y:clone()
newmodel748:PivotTo(CFrame.new(-44.41497766375922, 6.546800584000001, 39.81324823170543) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel748.Parent = workspace.devices.definds
newmodel748.RandBr.Value = 0.2749153655202438
newmodel749 = workspace.prefabs.defind:clone()
newmodel749:PivotTo(CFrame.new(-44.62540967739528, 6.868000292000001, 39.7991243487535) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel749.Parent = workspace.devices.definds
newmodel749.RandBr.Value = 0.1762185198869599
newmodel750 = workspace.prefabs.defind:clone()
newmodel750:PivotTo(CFrame.new(-44.62540967739528, 6.760932944, 39.7991243487535) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel750.Parent = workspace.devices.definds
newmodel750.RandBr.Value = 0.3042891748059907
newmodel751 = workspace.prefabs.defind:clone()
newmodel751:PivotTo(CFrame.new(-44.62540967739528, 6.653865888000001, 39.7991243487535) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel751.Parent = workspace.devices.definds
newmodel751.RandBr.Value = 0.46658209732895833
newmodel752 = workspace.prefabs.defind:clone()
newmodel752:PivotTo(CFrame.new(-44.62540967739528, 6.546800584000001, 39.7991243487535) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel752.Parent = workspace.devices.definds
newmodel752.RandBr.Value = 0.09285968449988787
newmodel753 = workspace.prefabs.defind:clone()
newmodel753:PivotTo(CFrame.new(-42.94189166346511, 6.868000292000001, 39.91212183516596) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel753.Parent = workspace.devices.definds
newmodel753.RandBr.Value = 0.06428248648648682
newmodel754 = workspace.prefabs.defind:clone()
newmodel754:PivotTo(CFrame.new(-42.94189166346511, 6.760932944, 39.91212183516596) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel754.Parent = workspace.devices.definds
newmodel754.RandBr.Value = 0.043111074682201746
newmodel755 = workspace.prefabs.defind:clone()
newmodel755:PivotTo(CFrame.new(-42.94189166346511, 6.653865888000001, 39.91212183516596) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel755.Parent = workspace.devices.definds
newmodel755.RandBr.Value = 0.2733303900618773
newmodel756 = workspace.prefabs.defind:clone()
newmodel756:PivotTo(CFrame.new(-42.94189166346511, 6.546800584000001, 39.91212183516596) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel756.Parent = workspace.devices.definds
newmodel756.RandBr.Value = 0.531266633976966
newmodel757 = workspace.prefabs.defind:clone()
newmodel757:PivotTo(CFrame.new(-42.94189166346511, 6.439734696, 39.91212183516596) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel757.Parent = workspace.devices.definds
newmodel757.RandBr.Value = 0.5055806052052926
newmodel758 = workspace.prefabs.defind:clone()
newmodel758:PivotTo(CFrame.new(-42.94189166346511, 6.332667640000001, 39.91212183516596) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel758.Parent = workspace.devices.definds
newmodel758.RandBr.Value = 0.024661481628631465
newmodel759 = workspace.prefabs.defind:clone()
newmodel759:PivotTo(CFrame.new(-43.15233230087587, 6.868000292000001, 39.89799562900605) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel759.Parent = workspace.devices.definds
newmodel759.RandBr.Value = 0.058380345463212135
newmodel760 = workspace.prefabs.defind:clone()
newmodel760:PivotTo(CFrame.new(-43.15233230087587, 6.760932944, 39.89799562900605) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel760.Parent = workspace.devices.definds
newmodel760.RandBr.Value = 0.35440987159556303
newmodel761 = workspace.prefabs.defind:clone()
newmodel761:PivotTo(CFrame.new(-43.15233230087587, 6.653865888000001, 39.89799562900605) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel761.Parent = workspace.devices.definds
newmodel761.RandBr.Value = 0.13507059357947987
newmodel762 = workspace.prefabs.defind:clone()
newmodel762:PivotTo(CFrame.new(-43.15233230087587, 6.546800584000001, 39.89799562900605) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel762.Parent = workspace.devices.definds
newmodel762.RandBr.Value = 0.18831849913073131
newmodel763 = workspace.prefabs.defind_y:clone()
newmodel763:PivotTo(CFrame.new(-43.15233230087587, 6.439734696, 39.89799562900605) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel763.Parent = workspace.devices.definds
newmodel763.RandBr.Value = 0.097377183241202
newmodel764 = workspace.prefabs.defind_y:clone()
newmodel764:PivotTo(CFrame.new(-43.15233230087587, 6.332667640000001, 39.89799562900605) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel764.Parent = workspace.devices.definds
newmodel764.RandBr.Value = 0.3693906298434448
newmodel765 = workspace.prefabs.defind:clone()
newmodel765:PivotTo(CFrame.new(-43.36277314809256, 6.868000292000001, 39.883872548632965) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel765.Parent = workspace.devices.definds
newmodel765.RandBr.Value = 0.25814599031970037
newmodel766 = workspace.prefabs.defind:clone()
newmodel766:PivotTo(CFrame.new(-43.36277314809256, 6.760932944, 39.883872548632965) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel766.Parent = workspace.devices.definds
newmodel766.RandBr.Value = 0.2745121102452503
newmodel767 = workspace.prefabs.defind:clone()
newmodel767:PivotTo(CFrame.new(-43.36277314809256, 6.653865888000001, 39.883872548632965) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel767.Parent = workspace.devices.definds
newmodel767.RandBr.Value = 0.4202849429532302
newmodel768 = workspace.prefabs.defind:clone()
newmodel768:PivotTo(CFrame.new(-43.36277314809256, 6.546800584000001, 39.883872548632965) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel768.Parent = workspace.devices.definds
newmodel768.RandBr.Value = 0.032753595342987385
newmodel769 = workspace.prefabs.defind_y:clone()
newmodel769:PivotTo(CFrame.new(-43.36277314809256, 6.439734696, 39.883872548632965) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel769.Parent = workspace.devices.definds
newmodel769.RandBr.Value = 0.18655541922509944
newmodel770 = workspace.prefabs.defind_y:clone()
newmodel770:PivotTo(CFrame.new(-43.36277314809256, 6.332667640000001, 39.883872548632965) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel770.Parent = workspace.devices.definds
newmodel770.RandBr.Value = 0.5769743213813746
newmodel771 = workspace.prefabs.defind:clone()
newmodel771:PivotTo(CFrame.new(-43.57320907742127, 6.868000292000001, 39.869750321665435) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel771.Parent = workspace.devices.definds
newmodel771.RandBr.Value = 0.15381693464472415
newmodel772 = workspace.prefabs.defind:clone()
newmodel772:PivotTo(CFrame.new(-43.57320907742127, 6.760932944, 39.869750321665435) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel772.Parent = workspace.devices.definds
newmodel772.RandBr.Value = 0.23003073292448867
newmodel773 = workspace.prefabs.defind:clone()
newmodel773:PivotTo(CFrame.new(-43.57320907742127, 6.653865888000001, 39.869750321665435) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel773.Parent = workspace.devices.definds
newmodel773.RandBr.Value = 0.14001221434026564
newmodel774 = workspace.prefabs.defind_y:clone()
newmodel774:PivotTo(CFrame.new(-43.57320907742127, 6.546800584000001, 39.869750321665435) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel774.Parent = workspace.devices.definds
newmodel774.RandBr.Value = 0.5638575809626658
newmodel775 = workspace.prefabs.defind_y:clone()
newmodel775:PivotTo(CFrame.new(-43.57320907742127, 6.439734696, 39.869750321665435) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel775.Parent = workspace.devices.definds
newmodel775.RandBr.Value = 0.3901241946590007
newmodel776 = workspace.prefabs.defind:clone()
newmodel776:PivotTo(CFrame.new(-43.57320907742127, 6.332667640000001, 39.869750321665435) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel776.Parent = workspace.devices.definds
newmodel776.RandBr.Value = 0.12432134678427773
newmodel777 = workspace.prefabs.defind_y:clone()
newmodel777:PivotTo(CFrame.new(-43.05360909161448, 7.043200000000001, 39.90462237797583) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel777.Parent = workspace.devices.definds
newmodel777.RandBr.Value = 0.44173977160703515
newmodel778 = workspace.prefabs.defind_r:clone()
newmodel778:PivotTo(CFrame.new(-43.461491322907094, 7.043200000000001, 39.877244916520056) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel778.Parent = workspace.devices.definds
newmodel778.RandBr.Value = 0.4216877852125657
newmodel779 = workspace.prefabs.defind:clone()
newmodel779:PivotTo(CFrame.new(-51.460076463672976, 6.897200292000001, 38.397194138934594) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel779.Parent = workspace.devices.definds
newmodel779.RandBr.Value = 0.22995923731187926
newmodel780 = workspace.prefabs.defind:clone()
newmodel780:PivotTo(CFrame.new(-51.460076463672976, 6.787700584000001, 38.397194138934594) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel780.Parent = workspace.devices.definds
newmodel780.RandBr.Value = 0.2776535117867158
newmodel781 = workspace.prefabs.defind:clone()
newmodel781:PivotTo(CFrame.new(-51.460076463672976, 6.678200292000001, 38.397194138934594) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel781.Parent = workspace.devices.definds
newmodel781.RandBr.Value = 0.3659145674795014
newmodel782 = workspace.prefabs.defind:clone()
newmodel782:PivotTo(CFrame.new(-51.460076463672976, 6.5686997080000005, 38.397194138934594) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel782.Parent = workspace.devices.definds
newmodel782.RandBr.Value = 0.5961464569566702
newmodel783 = workspace.prefabs.defind_y:clone()
newmodel783:PivotTo(CFrame.new(-51.460076463672976, 6.4592, 38.397194138934594) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel783.Parent = workspace.devices.definds
newmodel783.RandBr.Value = 0.5192134212078036
newmodel784 = workspace.prefabs.defind:clone()
newmodel784:PivotTo(CFrame.new(-51.66090165221849, 6.897200292000001, 38.325729106321525) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel784.Parent = workspace.devices.definds
newmodel784.RandBr.Value = 0.3797559246974761
newmodel785 = workspace.prefabs.defind:clone()
newmodel785:PivotTo(CFrame.new(-51.66090165221849, 6.787700584000001, 38.325729106321525) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel785.Parent = workspace.devices.definds
newmodel785.RandBr.Value = 0.3885228000962565
newmodel786 = workspace.prefabs.defind:clone()
newmodel786:PivotTo(CFrame.new(-51.66090165221849, 6.678200292000001, 38.325729106321525) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel786.Parent = workspace.devices.definds
newmodel786.RandBr.Value = 0.52536186220115
newmodel787 = workspace.prefabs.defind:clone()
newmodel787:PivotTo(CFrame.new(-51.66090165221849, 6.5686997080000005, 38.325729106321525) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel787.Parent = workspace.devices.definds
newmodel787.RandBr.Value = 0.4685049367083174
newmodel788 = workspace.prefabs.defind_y:clone()
newmodel788:PivotTo(CFrame.new(-51.66090165221849, 6.4592, 38.325729106321525) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel788.Parent = workspace.devices.definds
newmodel788.RandBr.Value = 0.23652476699664907
newmodel789 = workspace.prefabs.defind:clone()
newmodel789:PivotTo(CFrame.new(-51.861717236326754, 6.897200292000001, 38.25425415595906) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel789.Parent = workspace.devices.definds
newmodel789.RandBr.Value = 0.28062509223354665
newmodel790 = workspace.prefabs.defind:clone()
newmodel790:PivotTo(CFrame.new(-51.861717236326754, 6.787700584000001, 38.25425415595906) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel790.Parent = workspace.devices.definds
newmodel790.RandBr.Value = 0.36069324910930384
newmodel791 = workspace.prefabs.defind:clone()
newmodel791:PivotTo(CFrame.new(-51.861717236326754, 6.678200292000001, 38.25425415595906) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel791.Parent = workspace.devices.definds
newmodel791.RandBr.Value = 0.027957258686228937
newmodel792 = workspace.prefabs.defind:clone()
newmodel792:PivotTo(CFrame.new(-51.861717236326754, 6.5686997080000005, 38.25425415595906) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel792.Parent = workspace.devices.definds
newmodel792.RandBr.Value = 0.3831035820704915
newmodel793 = workspace.prefabs.defind:clone()
newmodel793:PivotTo(CFrame.new(-51.861717236326754, 6.4592, 38.25425415595906) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel793.Parent = workspace.devices.definds
newmodel793.RandBr.Value = 0.5580351178861396
newmodel794 = workspace.prefabs.defind:clone()
newmodel794:PivotTo(CFrame.new(-52.06254445900081, 6.897200292000001, 38.182783169002015) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel794.Parent = workspace.devices.definds
newmodel794.RandBr.Value = 0.07961443598914604
newmodel795 = workspace.prefabs.defind:clone()
newmodel795:PivotTo(CFrame.new(-52.06254445900081, 6.787700584000001, 38.182783169002015) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel795.Parent = workspace.devices.definds
newmodel795.RandBr.Value = 0.41667059962692377
newmodel796 = workspace.prefabs.defind:clone()
newmodel796:PivotTo(CFrame.new(-52.06254445900081, 6.678200292000001, 38.182783169002015) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel796.Parent = workspace.devices.definds
newmodel796.RandBr.Value = 0.18751143108806878
newmodel797 = workspace.prefabs.defind:clone()
newmodel797:PivotTo(CFrame.new(-52.06254445900081, 6.5686997080000005, 38.182783169002015) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel797.Parent = workspace.devices.definds
newmodel797.RandBr.Value = 0.2926911804257683
newmodel798 = workspace.prefabs.defind:clone()
newmodel798:PivotTo(CFrame.new(-52.06254445900081, 6.4592, 38.182783169002015) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel798.Parent = workspace.devices.definds
newmodel798.RandBr.Value = 0.3369654883618562
newmodel799 = workspace.prefabs.defind:clone()
newmodel799:PivotTo(CFrame.new(-52.263366813304586, 6.897200292000001, 38.11131853311022) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel799.Parent = workspace.devices.definds
newmodel799.RandBr.Value = 0.4078817805928719
newmodel800 = workspace.prefabs.defind:clone()
newmodel800:PivotTo(CFrame.new(-52.263366813304586, 6.787700584000001, 38.11131853311022) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel800.Parent = workspace.devices.definds
newmodel800.RandBr.Value = 0.24163667840859976
newmodel801 = workspace.prefabs.defind_y:clone()
newmodel801:PivotTo(CFrame.new(-52.263366813304586, 6.678200292000001, 38.11131853311022) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel801.Parent = workspace.devices.definds
newmodel801.RandBr.Value = 0.38754047239122785
newmodel802 = workspace.prefabs.defind:clone()
newmodel802:PivotTo(CFrame.new(-52.263366813304586, 6.5686997080000005, 38.11131853311022) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel802.Parent = workspace.devices.definds
newmodel802.RandBr.Value = 0.37355345452735733
newmodel803 = workspace.prefabs.defind:clone()
newmodel803:PivotTo(CFrame.new(-52.263366813304586, 6.4592, 38.11131853311022) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel803.Parent = workspace.devices.definds
newmodel803.RandBr.Value = 0.5324925342735757
newmodel804 = workspace.prefabs.defind:clone()
newmodel804:PivotTo(CFrame.new(-52.46418275901825, 6.897200292000001, 38.03984634060545) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel804.Parent = workspace.devices.definds
newmodel804.RandBr.Value = 0.08026036537801233
newmodel805 = workspace.prefabs.defind:clone()
newmodel805:PivotTo(CFrame.new(-52.46418275901825, 6.787700584000001, 38.03984634060545) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel805.Parent = workspace.devices.definds
newmodel805.RandBr.Value = 0.35014345863943325
newmodel806 = workspace.prefabs.defind_y:clone()
newmodel806:PivotTo(CFrame.new(-52.46418275901825, 6.678200292000001, 38.03984634060545) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel806.Parent = workspace.devices.definds
newmodel806.RandBr.Value = 0.46852307325374065
newmodel807 = workspace.prefabs.defind:clone()
newmodel807:PivotTo(CFrame.new(-52.46418275901825, 6.5686997080000005, 38.03984634060545) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel807.Parent = workspace.devices.definds
newmodel807.RandBr.Value = 0.23010681185350915
newmodel808 = workspace.prefabs.defind:clone()
newmodel808:PivotTo(CFrame.new(-52.46418275901825, 6.4592, 38.03984634060545) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel808.Parent = workspace.devices.definds
newmodel808.RandBr.Value = 0.17357543299879633
newmodel809 = workspace.prefabs.defind:clone()
newmodel809:PivotTo(CFrame.new(-51.460076463672976, 6.237280000000001, 38.397194138934594) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel809.Parent = workspace.devices.definds
newmodel809.RandBr.Value = 0.569819817719903
newmodel810 = workspace.prefabs.defind:clone()
newmodel810:PivotTo(CFrame.new(-51.460076463672976, 6.128072, 38.397194138934594) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel810.Parent = workspace.devices.definds
newmodel810.RandBr.Value = 0.3810186618721977
newmodel811 = workspace.prefabs.defind:clone()
newmodel811:PivotTo(CFrame.new(-51.460076463672976, 6.018864000000001, 38.397194138934594) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel811.Parent = workspace.devices.definds
newmodel811.RandBr.Value = 0.1410846146820548
newmodel812 = workspace.prefabs.defind:clone()
newmodel812:PivotTo(CFrame.new(-51.460076463672976, 5.909656000000001, 38.397194138934594) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel812.Parent = workspace.devices.definds
newmodel812.RandBr.Value = 0.3744193077362227
newmodel813 = workspace.prefabs.defind_y:clone()
newmodel813:PivotTo(CFrame.new(-51.460076463672976, 5.800448, 38.397194138934594) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel813.Parent = workspace.devices.definds
newmodel813.RandBr.Value = 0.528051511669577
newmodel814 = workspace.prefabs.defind_y:clone()
newmodel814:PivotTo(CFrame.new(-51.460076463672976, 5.691239708, 38.397194138934594) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel814.Parent = workspace.devices.definds
newmodel814.RandBr.Value = 0.45380533855654137
newmodel815 = workspace.prefabs.defind:clone()
newmodel815:PivotTo(CFrame.new(-51.66090165221849, 6.237280000000001, 38.325729106321525) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel815.Parent = workspace.devices.definds
newmodel815.RandBr.Value = 0.28410759619310705
newmodel816 = workspace.prefabs.defind:clone()
newmodel816:PivotTo(CFrame.new(-51.66090165221849, 6.128072, 38.325729106321525) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel816.Parent = workspace.devices.definds
newmodel816.RandBr.Value = 0.47858642188891426
newmodel817 = workspace.prefabs.defind:clone()
newmodel817:PivotTo(CFrame.new(-51.66090165221849, 6.018864000000001, 38.325729106321525) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel817.Parent = workspace.devices.definds
newmodel817.RandBr.Value = 0.4222065305795044
newmodel818 = workspace.prefabs.defind:clone()
newmodel818:PivotTo(CFrame.new(-51.66090165221849, 5.909656000000001, 38.325729106321525) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel818.Parent = workspace.devices.definds
newmodel818.RandBr.Value = 0.49370406923348575
newmodel819 = workspace.prefabs.defind_y:clone()
newmodel819:PivotTo(CFrame.new(-51.66090165221849, 5.800448, 38.325729106321525) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel819.Parent = workspace.devices.definds
newmodel819.RandBr.Value = 0.14483672317173538
newmodel820 = workspace.prefabs.defind_y:clone()
newmodel820:PivotTo(CFrame.new(-51.66090165221849, 5.691239708, 38.325729106321525) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel820.Parent = workspace.devices.definds
newmodel820.RandBr.Value = 0.12124112791078627
newmodel821 = workspace.prefabs.defind:clone()
newmodel821:PivotTo(CFrame.new(-51.861717236326754, 6.237280000000001, 38.25425415595906) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel821.Parent = workspace.devices.definds
newmodel821.RandBr.Value = 0.4415395010715354
newmodel822 = workspace.prefabs.defind:clone()
newmodel822:PivotTo(CFrame.new(-51.861717236326754, 6.128072, 38.25425415595906) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel822.Parent = workspace.devices.definds
newmodel822.RandBr.Value = 0.006182456745191333
newmodel823 = workspace.prefabs.defind:clone()
newmodel823:PivotTo(CFrame.new(-51.861717236326754, 6.018864000000001, 38.25425415595906) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel823.Parent = workspace.devices.definds
newmodel823.RandBr.Value = 0.34919711074782384
newmodel824 = workspace.prefabs.defind:clone()
newmodel824:PivotTo(CFrame.new(-51.861717236326754, 5.909656000000001, 38.25425415595906) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel824.Parent = workspace.devices.definds
newmodel824.RandBr.Value = 0.040736799660443745
newmodel825 = workspace.prefabs.defind_y:clone()
newmodel825:PivotTo(CFrame.new(-51.861717236326754, 5.800448, 38.25425415595906) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel825.Parent = workspace.devices.definds
newmodel825.RandBr.Value = 0.18294845831977688
newmodel826 = workspace.prefabs.defind_y:clone()
newmodel826:PivotTo(CFrame.new(-51.861717236326754, 5.691239708, 38.25425415595906) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel826.Parent = workspace.devices.definds
newmodel826.RandBr.Value = 0.21452526121770357
newmodel827 = workspace.prefabs.defind:clone()
newmodel827:PivotTo(CFrame.new(-52.06254445900081, 6.237280000000001, 38.182783169002015) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel827.Parent = workspace.devices.definds
newmodel827.RandBr.Value = 0.30571348188806824
newmodel828 = workspace.prefabs.defind:clone()
newmodel828:PivotTo(CFrame.new(-52.06254445900081, 6.128072, 38.182783169002015) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel828.Parent = workspace.devices.definds
newmodel828.RandBr.Value = 0.39527946611475806
newmodel829 = workspace.prefabs.defind:clone()
newmodel829:PivotTo(CFrame.new(-52.06254445900081, 6.018864000000001, 38.182783169002015) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel829.Parent = workspace.devices.definds
newmodel829.RandBr.Value = 0.49195265264310384
newmodel830 = workspace.prefabs.defind:clone()
newmodel830:PivotTo(CFrame.new(-52.06254445900081, 5.909656000000001, 38.182783169002015) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel830.Parent = workspace.devices.definds
newmodel830.RandBr.Value = 0.40700099537026396
newmodel831 = workspace.prefabs.defind_y:clone()
newmodel831:PivotTo(CFrame.new(-52.06254445900081, 5.800448, 38.182783169002015) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel831.Parent = workspace.devices.definds
newmodel831.RandBr.Value = 0.17171612863580557
newmodel832 = workspace.prefabs.defind_y:clone()
newmodel832:PivotTo(CFrame.new(-52.06254445900081, 5.691239708, 38.182783169002015) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel832.Parent = workspace.devices.definds
newmodel832.RandBr.Value = 0.3140683068488525
newmodel833 = workspace.prefabs.defind_y:clone()
newmodel833:PivotTo(CFrame.new(-52.263366813304586, 6.237280000000001, 38.11131853311022) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel833.Parent = workspace.devices.definds
newmodel833.RandBr.Value = 0.1408796433607939
newmodel834 = workspace.prefabs.defind:clone()
newmodel834:PivotTo(CFrame.new(-52.263366813304586, 6.128072, 38.11131853311022) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel834.Parent = workspace.devices.definds
newmodel834.RandBr.Value = 0.45993838999421405
newmodel835 = workspace.prefabs.defind:clone()
newmodel835:PivotTo(CFrame.new(-52.263366813304586, 6.018864000000001, 38.11131853311022) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel835.Parent = workspace.devices.definds
newmodel835.RandBr.Value = 0.4018131144533466
newmodel836 = workspace.prefabs.defind:clone()
newmodel836:PivotTo(CFrame.new(-52.263366813304586, 5.909656000000001, 38.11131853311022) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel836.Parent = workspace.devices.definds
newmodel836.RandBr.Value = 0.1546770970856693
newmodel837 = workspace.prefabs.defind_y:clone()
newmodel837:PivotTo(CFrame.new(-52.263366813304586, 5.800448, 38.11131853311022) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel837.Parent = workspace.devices.definds
newmodel837.RandBr.Value = 0.4644415881311614
newmodel838 = workspace.prefabs.defind_y:clone()
newmodel838:PivotTo(CFrame.new(-52.263366813304586, 5.691239708, 38.11131853311022) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel838.Parent = workspace.devices.definds
newmodel838.RandBr.Value = 0.2331372711239192
newmodel839 = workspace.prefabs.defind_y:clone()
newmodel839:PivotTo(CFrame.new(-52.46418275901825, 6.237280000000001, 38.03984634060545) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel839.Parent = workspace.devices.definds
newmodel839.RandBr.Value = 0.013734704841649759
newmodel840 = workspace.prefabs.defind:clone()
newmodel840:PivotTo(CFrame.new(-52.46418275901825, 6.128072, 38.03984634060545) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel840.Parent = workspace.devices.definds
newmodel840.RandBr.Value = 0.5041762566827351
newmodel841 = workspace.prefabs.defind:clone()
newmodel841:PivotTo(CFrame.new(-52.46418275901825, 6.018864000000001, 38.03984634060545) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel841.Parent = workspace.devices.definds
newmodel841.RandBr.Value = 0.4324940820666801
newmodel842 = workspace.prefabs.defind:clone()
newmodel842:PivotTo(CFrame.new(-52.46418275901825, 5.909656000000001, 38.03984634060545) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel842.Parent = workspace.devices.definds
newmodel842.RandBr.Value = 0.34816115580889945
newmodel843 = workspace.prefabs.defind_y:clone()
newmodel843:PivotTo(CFrame.new(-52.46418275901825, 5.800448, 38.03984634060545) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel843.Parent = workspace.devices.definds
newmodel843.RandBr.Value = 0.09588590653572568
newmodel844 = workspace.prefabs.defind_y:clone()
newmodel844:PivotTo(CFrame.new(-52.46418275901825, 5.691239708, 38.03984634060545) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel844.Parent = workspace.devices.definds
newmodel844.RandBr.Value = 0.08208730049077426
newmodel845 = workspace.prefabs.defind:clone()
newmodel845:PivotTo(CFrame.new(-52.86032889890114, 6.897200292000001, 37.8988620241119) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel845.Parent = workspace.devices.definds
newmodel845.RandBr.Value = 0.4250362545708792
newmodel846 = workspace.prefabs.defind:clone()
newmodel846:PivotTo(CFrame.new(-52.86032889890114, 6.787700584000001, 37.8988620241119) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel846.Parent = workspace.devices.definds
newmodel846.RandBr.Value = 0.3586947372361068
newmodel847 = workspace.prefabs.defind:clone()
newmodel847:PivotTo(CFrame.new(-52.86032889890114, 6.678200292000001, 37.8988620241119) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel847.Parent = workspace.devices.definds
newmodel847.RandBr.Value = 0.5039655616084517
newmodel848 = workspace.prefabs.defind:clone()
newmodel848:PivotTo(CFrame.new(-52.86032889890114, 6.5686997080000005, 37.8988620241119) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel848.Parent = workspace.devices.definds
newmodel848.RandBr.Value = 0.5950305796324291
newmodel849 = workspace.prefabs.defind_y:clone()
newmodel849:PivotTo(CFrame.new(-52.86032889890114, 6.4592, 37.8988620241119) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel849.Parent = workspace.devices.definds
newmodel849.RandBr.Value = 0.4571561306987665
newmodel850 = workspace.prefabs.defind:clone()
newmodel850:PivotTo(CFrame.new(-53.06115151371429, 6.897200292000001, 37.827397249324406) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel850.Parent = workspace.devices.definds
newmodel850.RandBr.Value = 0.5152972575969641
newmodel851 = workspace.prefabs.defind:clone()
newmodel851:PivotTo(CFrame.new(-53.06115151371429, 6.787700584000001, 37.827397249324406) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel851.Parent = workspace.devices.definds
newmodel851.RandBr.Value = 0.002940003715532824
newmodel852 = workspace.prefabs.defind:clone()
newmodel852:PivotTo(CFrame.new(-53.06115151371429, 6.678200292000001, 37.827397249324406) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel852.Parent = workspace.devices.definds
newmodel852.RandBr.Value = 0.36974621850115497
newmodel853 = workspace.prefabs.defind_y:clone()
newmodel853:PivotTo(CFrame.new(-53.06115151371429, 6.5686997080000005, 37.827397249324406) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel853.Parent = workspace.devices.definds
newmodel853.RandBr.Value = 0.42802912557981543
newmodel854 = workspace.prefabs.defind_y:clone()
newmodel854:PivotTo(CFrame.new(-53.06115151371429, 6.4592, 37.827397249324406) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel854.Parent = workspace.devices.definds
newmodel854.RandBr.Value = 0.4084706562123643
newmodel855 = workspace.prefabs.defind:clone()
newmodel855:PivotTo(CFrame.new(-53.26197240701017, 6.897200292000001, 37.75592154101615) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel855.Parent = workspace.devices.definds
newmodel855.RandBr.Value = 0.47626575985488306
newmodel856 = workspace.prefabs.defind:clone()
newmodel856:PivotTo(CFrame.new(-53.26197240701017, 6.787700584000001, 37.75592154101615) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel856.Parent = workspace.devices.definds
newmodel856.RandBr.Value = 0.24402046407468925
newmodel857 = workspace.prefabs.defind:clone()
newmodel857:PivotTo(CFrame.new(-53.26197240701017, 6.678200292000001, 37.75592154101615) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel857.Parent = workspace.devices.definds
newmodel857.RandBr.Value = 0.5781874584768562
newmodel858 = workspace.prefabs.defind_y:clone()
newmodel858:PivotTo(CFrame.new(-53.26197240701017, 6.5686997080000005, 37.75592154101615) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel858.Parent = workspace.devices.definds
newmodel858.RandBr.Value = 0.256522613681958
newmodel859 = workspace.prefabs.defind_y:clone()
newmodel859:PivotTo(CFrame.new(-53.26197240701017, 6.4592, 37.75592154101615) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel859.Parent = workspace.devices.definds
newmodel859.RandBr.Value = 0.3375936610442964
newmodel860 = workspace.prefabs.defind:clone()
newmodel860:PivotTo(CFrame.new(-53.46279406728212, 6.897200292000001, 37.68445147139833) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel860.Parent = workspace.devices.definds
newmodel860.RandBr.Value = 0.006984094216907
newmodel861 = workspace.prefabs.defind:clone()
newmodel861:PivotTo(CFrame.new(-53.46279406728212, 6.787700584000001, 37.68445147139833) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel861.Parent = workspace.devices.definds
newmodel861.RandBr.Value = 0.057279593326983624
newmodel862 = workspace.prefabs.defind:clone()
newmodel862:PivotTo(CFrame.new(-53.46279406728212, 6.678200292000001, 37.68445147139833) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel862.Parent = workspace.devices.definds
newmodel862.RandBr.Value = 0.5663986743997367
newmodel863 = workspace.prefabs.defind:clone()
newmodel863:PivotTo(CFrame.new(-53.46279406728212, 6.5686997080000005, 37.68445147139833) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel863.Parent = workspace.devices.definds
newmodel863.RandBr.Value = 0.5866338608243672
newmodel864 = workspace.prefabs.defind_y:clone()
newmodel864:PivotTo(CFrame.new(-53.46279406728212, 6.4592, 37.68445147139833) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel864.Parent = workspace.devices.definds
newmodel864.RandBr.Value = 0.02036743683465032
newmodel865 = workspace.prefabs.defind:clone()
newmodel865:PivotTo(CFrame.new(-53.663615344065875, 6.897200292000001, 37.61297858243488) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel865.Parent = workspace.devices.definds
newmodel865.RandBr.Value = 0.25064519134447455
newmodel866 = workspace.prefabs.defind:clone()
newmodel866:PivotTo(CFrame.new(-53.663615344065875, 6.787700584000001, 37.61297858243488) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel866.Parent = workspace.devices.definds
newmodel866.RandBr.Value = 0.22256370178350698
newmodel867 = workspace.prefabs.defind:clone()
newmodel867:PivotTo(CFrame.new(-53.663615344065875, 6.678200292000001, 37.61297858243488) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel867.Parent = workspace.devices.definds
newmodel867.RandBr.Value = 0.5062069991800721
newmodel868 = workspace.prefabs.defind:clone()
newmodel868:PivotTo(CFrame.new(-53.663615344065875, 6.5686997080000005, 37.61297858243488) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel868.Parent = workspace.devices.definds
newmodel868.RandBr.Value = 0.3154381795640252
newmodel869 = workspace.prefabs.defind:clone()
newmodel869:PivotTo(CFrame.new(-53.663615344065875, 6.4592, 37.61297858243488) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel869.Parent = workspace.devices.definds
newmodel869.RandBr.Value = 0.5054540162622547
newmodel870 = workspace.prefabs.defind:clone()
newmodel870:PivotTo(CFrame.new(-53.86443798805686, 6.897200292000001, 37.54151388963351) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel870.Parent = workspace.devices.definds
newmodel870.RandBr.Value = 0.5264744794957802
newmodel871 = workspace.prefabs.defind:clone()
newmodel871:PivotTo(CFrame.new(-53.86443798805686, 6.787700584000001, 37.54151388963351) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel871.Parent = workspace.devices.definds
newmodel871.RandBr.Value = 0.09132150050431247
newmodel872 = workspace.prefabs.defind:clone()
newmodel872:PivotTo(CFrame.new(-53.86443798805686, 6.678200292000001, 37.54151388963351) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel872.Parent = workspace.devices.definds
newmodel872.RandBr.Value = 0.48211483782835235
newmodel873 = workspace.prefabs.defind:clone()
newmodel873:PivotTo(CFrame.new(-53.86443798805686, 6.5686997080000005, 37.54151388963351) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel873.Parent = workspace.devices.definds
newmodel873.RandBr.Value = 0.44761843685606567
newmodel874 = workspace.prefabs.defind:clone()
newmodel874:PivotTo(CFrame.new(-53.86443798805686, 6.4592, 37.54151388963351) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel874.Parent = workspace.devices.definds
newmodel874.RandBr.Value = 0.47059225475317773
newmodel875 = workspace.prefabs.defind:clone()
newmodel875:PivotTo(CFrame.new(-52.86032889890114, 6.237280000000001, 37.8988620241119) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel875.Parent = workspace.devices.definds
newmodel875.RandBr.Value = 0.16489860897513234
newmodel876 = workspace.prefabs.defind_y:clone()
newmodel876:PivotTo(CFrame.new(-52.86032889890114, 6.128072, 37.8988620241119) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel876.Parent = workspace.devices.definds
newmodel876.RandBr.Value = 0.05495972551437891
newmodel877 = workspace.prefabs.defind:clone()
newmodel877:PivotTo(CFrame.new(-52.86032889890114, 6.018864000000001, 37.8988620241119) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel877.Parent = workspace.devices.definds
newmodel877.RandBr.Value = 0.13402206393606148
newmodel878 = workspace.prefabs.defind:clone()
newmodel878:PivotTo(CFrame.new(-52.86032889890114, 5.909656000000001, 37.8988620241119) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel878.Parent = workspace.devices.definds
newmodel878.RandBr.Value = 0.06451910863684233
newmodel879 = workspace.prefabs.defind_y:clone()
newmodel879:PivotTo(CFrame.new(-52.86032889890114, 5.800448, 37.8988620241119) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel879.Parent = workspace.devices.definds
newmodel879.RandBr.Value = 0.4067862897053689
newmodel880 = workspace.prefabs.defind:clone()
newmodel880:PivotTo(CFrame.new(-52.86032889890114, 5.691239708, 37.8988620241119) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel880.Parent = workspace.devices.definds
newmodel880.RandBr.Value = 0.18842705464782233
newmodel881 = workspace.prefabs.defind:clone()
newmodel881:PivotTo(CFrame.new(-53.06115151371429, 6.237280000000001, 37.827397249324406) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel881.Parent = workspace.devices.definds
newmodel881.RandBr.Value = 0.5850788567648257
newmodel882 = workspace.prefabs.defind_y:clone()
newmodel882:PivotTo(CFrame.new(-53.06115151371429, 6.128072, 37.827397249324406) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel882.Parent = workspace.devices.definds
newmodel882.RandBr.Value = 0.14716098562802338
newmodel883 = workspace.prefabs.defind:clone()
newmodel883:PivotTo(CFrame.new(-53.06115151371429, 6.018864000000001, 37.827397249324406) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel883.Parent = workspace.devices.definds
newmodel883.RandBr.Value = 0.5208514451312756
newmodel884 = workspace.prefabs.defind:clone()
newmodel884:PivotTo(CFrame.new(-53.06115151371429, 5.909656000000001, 37.827397249324406) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel884.Parent = workspace.devices.definds
newmodel884.RandBr.Value = 0.596152817647634
newmodel885 = workspace.prefabs.defind_y:clone()
newmodel885:PivotTo(CFrame.new(-53.06115151371429, 5.800448, 37.827397249324406) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel885.Parent = workspace.devices.definds
newmodel885.RandBr.Value = 0.08669115883299801
newmodel886 = workspace.prefabs.defind:clone()
newmodel886:PivotTo(CFrame.new(-53.06115151371429, 5.691239708, 37.827397249324406) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel886.Parent = workspace.devices.definds
newmodel886.RandBr.Value = 0.5992761519573029
newmodel887 = workspace.prefabs.defind:clone()
newmodel887:PivotTo(CFrame.new(-53.26197240701017, 6.237280000000001, 37.75592154101615) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel887.Parent = workspace.devices.definds
newmodel887.RandBr.Value = 0.29423097645706126
newmodel888 = workspace.prefabs.defind:clone()
newmodel888:PivotTo(CFrame.new(-53.26197240701017, 6.128072, 37.75592154101615) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel888.Parent = workspace.devices.definds
newmodel888.RandBr.Value = 0.3272184133580756
newmodel889 = workspace.prefabs.defind:clone()
newmodel889:PivotTo(CFrame.new(-53.26197240701017, 6.018864000000001, 37.75592154101615) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel889.Parent = workspace.devices.definds
newmodel889.RandBr.Value = 0.2639212808899582
newmodel890 = workspace.prefabs.defind:clone()
newmodel890:PivotTo(CFrame.new(-53.26197240701017, 5.909656000000001, 37.75592154101615) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel890.Parent = workspace.devices.definds
newmodel890.RandBr.Value = 0.1892739734705258
newmodel891 = workspace.prefabs.defind_y:clone()
newmodel891:PivotTo(CFrame.new(-53.26197240701017, 5.800448, 37.75592154101615) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel891.Parent = workspace.devices.definds
newmodel891.RandBr.Value = 0.0020183858418365117
newmodel892 = workspace.prefabs.defind_y:clone()
newmodel892:PivotTo(CFrame.new(-53.26197240701017, 5.691239708, 37.75592154101615) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel892.Parent = workspace.devices.definds
newmodel892.RandBr.Value = 0.387552523106286
newmodel893 = workspace.prefabs.defind:clone()
newmodel893:PivotTo(CFrame.new(-53.46279406728212, 6.237280000000001, 37.68445147139833) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel893.Parent = workspace.devices.definds
newmodel893.RandBr.Value = 0.4494264877749162
newmodel894 = workspace.prefabs.defind:clone()
newmodel894:PivotTo(CFrame.new(-53.46279406728212, 6.128072, 37.68445147139833) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel894.Parent = workspace.devices.definds
newmodel894.RandBr.Value = 0.3902490303481371
newmodel895 = workspace.prefabs.defind:clone()
newmodel895:PivotTo(CFrame.new(-53.46279406728212, 6.018864000000001, 37.68445147139833) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel895.Parent = workspace.devices.definds
newmodel895.RandBr.Value = 0.30714710202423146
newmodel896 = workspace.prefabs.defind:clone()
newmodel896:PivotTo(CFrame.new(-53.46279406728212, 5.909656000000001, 37.68445147139833) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel896.Parent = workspace.devices.definds
newmodel896.RandBr.Value = 0.07318047229563453
newmodel897 = workspace.prefabs.defind_y:clone()
newmodel897:PivotTo(CFrame.new(-53.46279406728212, 5.800448, 37.68445147139833) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel897.Parent = workspace.devices.definds
newmodel897.RandBr.Value = 0.3677146839856803
newmodel898 = workspace.prefabs.defind:clone()
newmodel898:PivotTo(CFrame.new(-53.46279406728212, 5.691239708, 37.68445147139833) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel898.Parent = workspace.devices.definds
newmodel898.RandBr.Value = 0.5470533718360424
newmodel899 = workspace.prefabs.defind:clone()
newmodel899:PivotTo(CFrame.new(-53.663615344065875, 6.237280000000001, 37.61297858243488) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel899.Parent = workspace.devices.definds
newmodel899.RandBr.Value = 0.24726790941517668
newmodel900 = workspace.prefabs.defind:clone()
newmodel900:PivotTo(CFrame.new(-53.663615344065875, 6.128072, 37.61297858243488) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel900.Parent = workspace.devices.definds
newmodel900.RandBr.Value = 0.23309001677689917
newmodel901 = workspace.prefabs.defind:clone()
newmodel901:PivotTo(CFrame.new(-53.663615344065875, 6.018864000000001, 37.61297858243488) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel901.Parent = workspace.devices.definds
newmodel901.RandBr.Value = 0.3460698046611363
newmodel902 = workspace.prefabs.defind:clone()
newmodel902:PivotTo(CFrame.new(-53.663615344065875, 5.909656000000001, 37.61297858243488) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel902.Parent = workspace.devices.definds
newmodel902.RandBr.Value = 0.10686763123790467
newmodel903 = workspace.prefabs.defind_y:clone()
newmodel903:PivotTo(CFrame.new(-53.663615344065875, 5.800448, 37.61297858243488) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel903.Parent = workspace.devices.definds
newmodel903.RandBr.Value = 0.43110437825929177
newmodel904 = workspace.prefabs.defind:clone()
newmodel904:PivotTo(CFrame.new(-53.663615344065875, 5.691239708, 37.61297858243488) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel904.Parent = workspace.devices.definds
newmodel904.RandBr.Value = 0.037732750223459545
newmodel905 = workspace.prefabs.defind:clone()
newmodel905:PivotTo(CFrame.new(-53.86443798805686, 6.237280000000001, 37.54151388963351) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel905.Parent = workspace.devices.definds
newmodel905.RandBr.Value = 0.22201372214019938
newmodel906 = workspace.prefabs.defind:clone()
newmodel906:PivotTo(CFrame.new(-53.86443798805686, 6.128072, 37.54151388963351) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel906.Parent = workspace.devices.definds
newmodel906.RandBr.Value = 0.5385751745704483
newmodel907 = workspace.prefabs.defind:clone()
newmodel907:PivotTo(CFrame.new(-53.86443798805686, 6.018864000000001, 37.54151388963351) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel907.Parent = workspace.devices.definds
newmodel907.RandBr.Value = 0.4327572276399745
newmodel908 = workspace.prefabs.defind:clone()
newmodel908:PivotTo(CFrame.new(-53.86443798805686, 5.909656000000001, 37.54151388963351) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel908.Parent = workspace.devices.definds
newmodel908.RandBr.Value = 0.15399704438230657
newmodel909 = workspace.prefabs.defind:clone()
newmodel909:PivotTo(CFrame.new(-53.86443798805686, 5.800448, 37.54151388963351) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel909.Parent = workspace.devices.definds
newmodel909.RandBr.Value = 0.37369343109216846
newmodel910 = workspace.prefabs.defind:clone()
newmodel910:PivotTo(CFrame.new(-53.86443798805686, 5.691239708, 37.54151388963351) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel910.Parent = workspace.devices.definds
newmodel910.RandBr.Value = 0.3548643035262741
newmodel911 = workspace.prefabs.defind:clone()
newmodel911:PivotTo(CFrame.new(-54.51005936612134, 6.897200292000001, 37.286218075813224) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel911.Parent = workspace.devices.definds
newmodel911.RandBr.Value = 0.04463731440118788
newmodel912 = workspace.prefabs.defind_y:clone()
newmodel912:PivotTo(CFrame.new(-54.51005936612134, 6.791107056, 37.286218075813224) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel912.Parent = workspace.devices.definds
newmodel912.RandBr.Value = 0.02082726095868548
newmodel913 = workspace.prefabs.defind:clone()
newmodel913:PivotTo(CFrame.new(-54.51005936612134, 6.685013820000001, 37.286218075813224) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel913.Parent = workspace.devices.definds
newmodel913.RandBr.Value = 0.1938556311540534
newmodel914 = workspace.prefabs.defind_y:clone()
newmodel914:PivotTo(CFrame.new(-54.51005936612134, 6.578920292, 37.286218075813224) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel914.Parent = workspace.devices.definds
newmodel914.RandBr.Value = 0.09704571209130938
newmodel915 = workspace.prefabs.defind_y:clone()
newmodel915:PivotTo(CFrame.new(-54.697138802099076, 6.897200292000001, 37.1996193355137) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel915.Parent = workspace.devices.definds
newmodel915.RandBr.Value = 0.47037101173882606
newmodel916 = workspace.prefabs.defind:clone()
newmodel916:PivotTo(CFrame.new(-54.697138802099076, 6.791107056, 37.1996193355137) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel916.Parent = workspace.devices.definds
newmodel916.RandBr.Value = 0.19653981555571043
newmodel917 = workspace.prefabs.defind:clone()
newmodel917:PivotTo(CFrame.new(-54.697138802099076, 6.685013820000001, 37.1996193355137) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel917.Parent = workspace.devices.definds
newmodel917.RandBr.Value = 0.1257778151474497
newmodel918 = workspace.prefabs.defind_y:clone()
newmodel918:PivotTo(CFrame.new(-54.697138802099076, 6.578920292, 37.1996193355137) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel918.Parent = workspace.devices.definds
newmodel918.RandBr.Value = 0.41638286029505395
newmodel919 = workspace.prefabs.defind:clone()
newmodel919:PivotTo(CFrame.new(-54.88421481219899, 6.897200292000001, 37.11301882478804) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel919.Parent = workspace.devices.definds
newmodel919.RandBr.Value = 0.23727327360774725
newmodel920 = workspace.prefabs.defind:clone()
newmodel920:PivotTo(CFrame.new(-54.88421481219899, 6.791107056, 37.11301882478804) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel920.Parent = workspace.devices.definds
newmodel920.RandBr.Value = 0.5422600888257164
newmodel921 = workspace.prefabs.defind_y:clone()
newmodel921:PivotTo(CFrame.new(-54.88421481219899, 6.685013820000001, 37.11301882478804) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel921.Parent = workspace.devices.definds
newmodel921.RandBr.Value = 0.18291319146205554
newmodel922 = workspace.prefabs.defind_y:clone()
newmodel922:PivotTo(CFrame.new(-54.88421481219899, 6.578920292, 37.11301882478804) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel922.Parent = workspace.devices.definds
newmodel922.RandBr.Value = 0.49839460421159676
newmodel923 = workspace.prefabs.defind:clone()
newmodel923:PivotTo(CFrame.new(-55.071295171524454, 6.897200292000001, 37.0264138074928) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel923.Parent = workspace.devices.definds
newmodel923.RandBr.Value = 0.3561052322616824
newmodel924 = workspace.prefabs.defind:clone()
newmodel924:PivotTo(CFrame.new(-55.071295171524454, 6.791107056, 37.0264138074928) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel924.Parent = workspace.devices.definds
newmodel924.RandBr.Value = 0.510530326430329
newmodel925 = workspace.prefabs.defind:clone()
newmodel925:PivotTo(CFrame.new(-55.071295171524454, 6.685013820000001, 37.0264138074928) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel925.Parent = workspace.devices.definds
newmodel925.RandBr.Value = 0.5882619254136461
newmodel926 = workspace.prefabs.defind_y:clone()
newmodel926:PivotTo(CFrame.new(-55.071295171524454, 6.578920292, 37.0264138074928) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel926.Parent = workspace.devices.definds
newmodel926.RandBr.Value = 0.34326362680296946
newmodel927 = workspace.prefabs.defind:clone()
newmodel927:PivotTo(CFrame.new(-55.258378035217866, 6.897200292000001, 36.93981698060888) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel927.Parent = workspace.devices.definds
newmodel927.RandBr.Value = 0.588077363911536
newmodel928 = workspace.prefabs.defind:clone()
newmodel928:PivotTo(CFrame.new(-55.258378035217866, 6.791107056, 36.93981698060888) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel928.Parent = workspace.devices.definds
newmodel928.RandBr.Value = 0.449052769448024
newmodel929 = workspace.prefabs.defind:clone()
newmodel929:PivotTo(CFrame.new(-55.258378035217866, 6.685013820000001, 36.93981698060888) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel929.Parent = workspace.devices.definds
newmodel929.RandBr.Value = 0.22223304212135533
newmodel930 = workspace.prefabs.defind_y:clone()
newmodel930:PivotTo(CFrame.new(-55.258378035217866, 6.578920292, 36.93981698060888) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel930.Parent = workspace.devices.definds
newmodel930.RandBr.Value = 0.40419348391931104
newmodel931 = workspace.prefabs.defind:clone()
newmodel931:PivotTo(CFrame.new(-55.44545213579627, 6.897200292000001, 36.85321999092395) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel931.Parent = workspace.devices.definds
newmodel931.RandBr.Value = 0.40463320222538113
newmodel932 = workspace.prefabs.defind:clone()
newmodel932:PivotTo(CFrame.new(-55.44545213579627, 6.791107056, 36.85321999092395) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel932.Parent = workspace.devices.definds
newmodel932.RandBr.Value = 0.5468468477632026
newmodel933 = workspace.prefabs.defind:clone()
newmodel933:PivotTo(CFrame.new(-55.44545213579627, 6.685013820000001, 36.85321999092395) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel933.Parent = workspace.devices.definds
newmodel933.RandBr.Value = 0.3244301664153397
newmodel934 = workspace.prefabs.defind_y:clone()
newmodel934:PivotTo(CFrame.new(-55.44545213579627, 6.578920292, 36.85321999092395) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel934.Parent = workspace.devices.definds
newmodel934.RandBr.Value = 0.07575985014693316
newmodel935 = workspace.prefabs.defind:clone()
newmodel935:PivotTo(CFrame.new(-55.827037983902144, 6.897200292000001, 36.676566443327445) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel935.Parent = workspace.devices.definds
newmodel935.RandBr.Value = 0.23073657045573326
newmodel936 = workspace.prefabs.defind:clone()
newmodel936:PivotTo(CFrame.new(-55.827037983902144, 6.791107056, 36.676566443327445) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel936.Parent = workspace.devices.definds
newmodel936.RandBr.Value = 0.25462438953653804
newmodel937 = workspace.prefabs.defind:clone()
newmodel937:PivotTo(CFrame.new(-55.827037983902144, 6.685013820000001, 36.676566443327445) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel937.Parent = workspace.devices.definds
newmodel937.RandBr.Value = 0.36117152739268005
newmodel938 = workspace.prefabs.defind:clone()
newmodel938:PivotTo(CFrame.new(-55.827037983902144, 6.578920292, 36.676566443327445) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel938.Parent = workspace.devices.definds
newmodel938.RandBr.Value = 0.272043901322322
newmodel939 = workspace.prefabs.defind:clone()
newmodel939:PivotTo(CFrame.new(-56.01411552041656, 6.897200292000001, 36.58997131530637) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel939.Parent = workspace.devices.definds
newmodel939.RandBr.Value = 0.18477602424846465
newmodel940 = workspace.prefabs.defind:clone()
newmodel940:PivotTo(CFrame.new(-56.01411552041656, 6.791107056, 36.58997131530637) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel940.Parent = workspace.devices.definds
newmodel940.RandBr.Value = 0.5560774393641861
newmodel941 = workspace.prefabs.defind:clone()
newmodel941:PivotTo(CFrame.new(-56.01411552041656, 6.685013820000001, 36.58997131530637) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel941.Parent = workspace.devices.definds
newmodel941.RandBr.Value = 0.2954592066316841
newmodel942 = workspace.prefabs.defind:clone()
newmodel942:PivotTo(CFrame.new(-56.01411552041656, 6.578920292, 36.58997131530637) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel942.Parent = workspace.devices.definds
newmodel942.RandBr.Value = 0.3978904443325237
newmodel943 = workspace.prefabs.defind:clone()
newmodel943:PivotTo(CFrame.new(-56.20119340348063, 6.897200292000001, 36.50336720456744) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel943.Parent = workspace.devices.definds
newmodel943.RandBr.Value = 0.5463211979548278
newmodel944 = workspace.prefabs.defind:clone()
newmodel944:PivotTo(CFrame.new(-56.20119340348063, 6.791107056, 36.50336720456744) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel944.Parent = workspace.devices.definds
newmodel944.RandBr.Value = 0.41193368444283435
newmodel945 = workspace.prefabs.defind:clone()
newmodel945:PivotTo(CFrame.new(-56.20119340348063, 6.685013820000001, 36.50336720456744) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel945.Parent = workspace.devices.definds
newmodel945.RandBr.Value = 0.35106769327083226
newmodel946 = workspace.prefabs.defind_y:clone()
newmodel946:PivotTo(CFrame.new(-56.20119340348063, 6.578920292, 36.50336720456744) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel946.Parent = workspace.devices.definds
newmodel946.RandBr.Value = 0.34756073185347824
newmodel947 = workspace.prefabs.defind:clone()
newmodel947:PivotTo(CFrame.new(-56.38827445749589, 6.897200292000001, 36.41676507815872) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel947.Parent = workspace.devices.definds
newmodel947.RandBr.Value = 0.39942325714024157
newmodel948 = workspace.prefabs.defind:clone()
newmodel948:PivotTo(CFrame.new(-56.38827445749589, 6.791107056, 36.41676507815872) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel948.Parent = workspace.devices.definds
newmodel948.RandBr.Value = 0.15513048329812348
newmodel949 = workspace.prefabs.defind:clone()
newmodel949:PivotTo(CFrame.new(-56.38827445749589, 6.685013820000001, 36.41676507815872) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel949.Parent = workspace.devices.definds
newmodel949.RandBr.Value = 0.08183528292765305
newmodel950 = workspace.prefabs.defind:clone()
newmodel950:PivotTo(CFrame.new(-56.38827445749589, 6.578920292, 36.41676507815872) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel950.Parent = workspace.devices.definds
newmodel950.RandBr.Value = 0.4596245118775562
newmodel951 = workspace.prefabs.defind:clone()
newmodel951:PivotTo(CFrame.new(-56.57535290729984, 6.897200292000001, 36.33016358190423) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel951.Parent = workspace.devices.definds
newmodel951.RandBr.Value = 0.0601927726730725
newmodel952 = workspace.prefabs.defind:clone()
newmodel952:PivotTo(CFrame.new(-56.57535290729984, 6.791107056, 36.33016358190423) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel952.Parent = workspace.devices.definds
newmodel952.RandBr.Value = 0.24408775056839943
newmodel953 = workspace.prefabs.defind:clone()
newmodel953:PivotTo(CFrame.new(-56.57535290729984, 6.685013820000001, 36.33016358190423) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel953.Parent = workspace.devices.definds
newmodel953.RandBr.Value = 0.06346257258790411
newmodel954 = workspace.prefabs.defind_y:clone()
newmodel954:PivotTo(CFrame.new(-56.57535290729984, 6.578920292, 36.33016358190423) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel954.Parent = workspace.devices.definds
newmodel954.RandBr.Value = 0.4147471124142466
newmodel955 = workspace.prefabs.defind:clone()
newmodel955:PivotTo(CFrame.new(-56.76243955348039, 6.897200292000001, 36.243559633969454) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel955.Parent = workspace.devices.definds
newmodel955.RandBr.Value = 0.5710197340966814
newmodel956 = workspace.prefabs.defind:clone()
newmodel956:PivotTo(CFrame.new(-56.76243955348039, 6.791107056, 36.243559633969454) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel956.Parent = workspace.devices.definds
newmodel956.RandBr.Value = 0.2164852135783874
newmodel957 = workspace.prefabs.defind:clone()
newmodel957:PivotTo(CFrame.new(-56.76243955348039, 6.685013820000001, 36.243559633969454) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel957.Parent = workspace.devices.definds
newmodel957.RandBr.Value = 0.050264451404600514
newmodel958 = workspace.prefabs.defind_y:clone()
newmodel958:PivotTo(CFrame.new(-56.76243955348039, 6.578920292, 36.243559633969454) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel958.Parent = workspace.devices.definds
newmodel958.RandBr.Value = 0.07766937902488937
newmodel959 = workspace.prefabs.defind_y:clone()
newmodel959:PivotTo(CFrame.new(-55.45075753631332, 7.0723994452, 36.85074909606935) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel959.Parent = workspace.devices.definds
newmodel959.RandBr.Value = 0.43598445085900517
newmodel960 = workspace.prefabs.defind_r:clone()
newmodel960:PivotTo(CFrame.new(-55.821740266690824, 7.0723994452, 36.67901709583831) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel960.Parent = workspace.devices.definds
newmodel960.RandBr.Value = 0.052704327671849203
newmodel961 = workspace.prefabs.defind:clone()
newmodel961:PivotTo(CFrame.new(-57.767515767649485, 6.868000292000001, 35.710590790082) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel961.Parent = workspace.devices.definds
newmodel961.RandBr.Value = 0.0692992759120555
newmodel962 = workspace.prefabs.defind:clone()
newmodel962:PivotTo(CFrame.new(-57.767515767649485, 6.758987348, 35.710590790082) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel962.Parent = workspace.devices.definds
newmodel962.RandBr.Value = 0.17196879133118953
newmodel963 = workspace.prefabs.defind:clone()
newmodel963:PivotTo(CFrame.new(-57.767515767649485, 6.649973528, 35.710590790082) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel963.Parent = workspace.devices.definds
newmodel963.RandBr.Value = 0.39253843995955257
newmodel964 = workspace.prefabs.defind:clone()
newmodel964:PivotTo(CFrame.new(-57.767515767649485, 6.540959708000001, 35.710590790082) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel964.Parent = workspace.devices.definds
newmodel964.RandBr.Value = 0.33036213295693057
newmodel965 = workspace.prefabs.defind:clone()
newmodel965:PivotTo(CFrame.new(-57.94942571435907, 6.868000292000001, 35.6051897305266) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel965.Parent = workspace.devices.definds
newmodel965.RandBr.Value = 0.553112803856084
newmodel966 = workspace.prefabs.defind:clone()
newmodel966:PivotTo(CFrame.new(-57.94942571435907, 6.758987348, 35.6051897305266) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel966.Parent = workspace.devices.definds
newmodel966.RandBr.Value = 0.36682800836055574
newmodel967 = workspace.prefabs.defind:clone()
newmodel967:PivotTo(CFrame.new(-57.94942571435907, 6.649973528, 35.6051897305266) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel967.Parent = workspace.devices.definds
newmodel967.RandBr.Value = 0.10088824597655273
newmodel968 = workspace.prefabs.defind:clone()
newmodel968:PivotTo(CFrame.new(-57.94942571435907, 6.540959708000001, 35.6051897305266) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel968.Parent = workspace.devices.definds
newmodel968.RandBr.Value = 0.5948961610861618
newmodel969 = workspace.prefabs.defind:clone()
newmodel969:PivotTo(CFrame.new(-58.13133931791293, 6.868000292000001, 35.49978333357418) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel969.Parent = workspace.devices.definds
newmodel969.RandBr.Value = 0.04823915188126997
newmodel970 = workspace.prefabs.defind:clone()
newmodel970:PivotTo(CFrame.new(-58.13133931791293, 6.758987348, 35.49978333357418) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel970.Parent = workspace.devices.definds
newmodel970.RandBr.Value = 0.0070069441108908
newmodel971 = workspace.prefabs.defind:clone()
newmodel971:PivotTo(CFrame.new(-58.13133931791293, 6.649973528, 35.49978333357418) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel971.Parent = workspace.devices.definds
newmodel971.RandBr.Value = 0.1404937558708535
newmodel972 = workspace.prefabs.defind:clone()
newmodel972:PivotTo(CFrame.new(-58.13133931791293, 6.540959708000001, 35.49978333357418) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel972.Parent = workspace.devices.definds
newmodel972.RandBr.Value = 0.14343214356139763
newmodel973 = workspace.prefabs.defind:clone()
newmodel973:PivotTo(CFrame.new(-58.313242536517606, 6.868000292000001, 35.39437008034237) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel973.Parent = workspace.devices.definds
newmodel973.RandBr.Value = 0.5155198570597738
newmodel974 = workspace.prefabs.defind:clone()
newmodel974:PivotTo(CFrame.new(-58.313242536517606, 6.758987348, 35.39437008034237) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel974.Parent = workspace.devices.definds
newmodel974.RandBr.Value = 0.49147711736623845
newmodel975 = workspace.prefabs.defind:clone()
newmodel975:PivotTo(CFrame.new(-58.313242536517606, 6.649973528, 35.39437008034237) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel975.Parent = workspace.devices.definds
newmodel975.RandBr.Value = 0.4277474504472543
newmodel976 = workspace.prefabs.defind:clone()
newmodel976:PivotTo(CFrame.new(-58.313242536517606, 6.540959708000001, 35.39437008034237) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel976.Parent = workspace.devices.definds
newmodel976.RandBr.Value = 0.5117157902736031
newmodel977 = workspace.prefabs.defind:clone()
newmodel977:PivotTo(CFrame.new(-58.661901285624445, 6.868000292000001, 35.19234398236303) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel977.Parent = workspace.devices.definds
newmodel977.RandBr.Value = 0.5466547269620672
newmodel978 = workspace.prefabs.defind:clone()
newmodel978:PivotTo(CFrame.new(-58.661901285624445, 6.758987348, 35.19234398236303) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel978.Parent = workspace.devices.definds
newmodel978.RandBr.Value = 0.12137964531521467
newmodel979 = workspace.prefabs.defind:clone()
newmodel979:PivotTo(CFrame.new(-58.661901285624445, 6.649973528, 35.19234398236303) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel979.Parent = workspace.devices.definds
newmodel979.RandBr.Value = 0.101865316578535
newmodel980 = workspace.prefabs.defind:clone()
newmodel980:PivotTo(CFrame.new(-58.661901285624445, 6.540959708000001, 35.19234398236303) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel980.Parent = workspace.devices.definds
newmodel980.RandBr.Value = 0.34652901783578377
newmodel981 = workspace.prefabs.defind:clone()
newmodel981:PivotTo(CFrame.new(-58.843804948577926, 6.868000292000001, 35.08694314430436) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel981.Parent = workspace.devices.definds
newmodel981.RandBr.Value = 0.5272399084034042
newmodel982 = workspace.prefabs.defind:clone()
newmodel982:PivotTo(CFrame.new(-58.843804948577926, 6.758987348, 35.08694314430436) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel982.Parent = workspace.devices.definds
newmodel982.RandBr.Value = 0.26727437190129866
newmodel983 = workspace.prefabs.defind:clone()
newmodel983:PivotTo(CFrame.new(-58.843804948577926, 6.649973528, 35.08694314430436) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel983.Parent = workspace.devices.definds
newmodel983.RandBr.Value = 0.10470595438727677
newmodel984 = workspace.prefabs.defind:clone()
newmodel984:PivotTo(CFrame.new(-58.843804948577926, 6.540959708000001, 35.08694314430436) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel984.Parent = workspace.devices.definds
newmodel984.RandBr.Value = 0.43436941927155387
newmodel985 = workspace.prefabs.defind:clone()
newmodel985:PivotTo(CFrame.new(-59.025717243240344, 6.868000292000001, 34.981534488487156) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel985.Parent = workspace.devices.definds
newmodel985.RandBr.Value = 0.23840717829716898
newmodel986 = workspace.prefabs.defind:clone()
newmodel986:PivotTo(CFrame.new(-59.025717243240344, 6.758987348, 34.981534488487156) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel986.Parent = workspace.devices.definds
newmodel986.RandBr.Value = 0.04839466295815326
newmodel987 = workspace.prefabs.defind:clone()
newmodel987:PivotTo(CFrame.new(-59.025717243240344, 6.649973528, 34.981534488487156) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel987.Parent = workspace.devices.definds
newmodel987.RandBr.Value = 0.31760835526679737
newmodel988 = workspace.prefabs.defind:clone()
newmodel988:PivotTo(CFrame.new(-59.025717243240344, 6.540959708000001, 34.981534488487156) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel988.Parent = workspace.devices.definds
newmodel988.RandBr.Value = 0.04756832320584183
newmodel989 = workspace.prefabs.defind:clone()
newmodel989:PivotTo(CFrame.new(-59.207624310388326, 6.868000292000001, 34.876128459428514) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel989.Parent = workspace.devices.definds
newmodel989.RandBr.Value = 0.06501838412316237
newmodel990 = workspace.prefabs.defind:clone()
newmodel990:PivotTo(CFrame.new(-59.207624310388326, 6.758987348, 34.876128459428514) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel990.Parent = workspace.devices.definds
newmodel990.RandBr.Value = 0.16186774317798222
newmodel991 = workspace.prefabs.defind:clone()
newmodel991:PivotTo(CFrame.new(-59.207624310388326, 6.649973528, 34.876128459428514) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel991.Parent = workspace.devices.definds
newmodel991.RandBr.Value = 0.36335321663678516
newmodel992 = workspace.prefabs.defind:clone()
newmodel992:PivotTo(CFrame.new(-59.207624310388326, 6.540959708000001, 34.876128459428514) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel992.Parent = workspace.devices.definds
newmodel992.RandBr.Value = 0.24110646819171544
newmodel993 = workspace.prefabs.defind:clone()
newmodel993:PivotTo(CFrame.new(-60.15136765607031, 6.897200292000001, 34.305199060804135) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel993.Parent = workspace.devices.definds
newmodel993.RandBr.Value = 0.2724132491800174
newmodel994 = workspace.prefabs.defind:clone()
newmodel994:PivotTo(CFrame.new(-60.15136765607031, 6.787700584000001, 34.305199060804135) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel994.Parent = workspace.devices.definds
newmodel994.RandBr.Value = 0.1839959247588814
newmodel995 = workspace.prefabs.defind:clone()
newmodel995:PivotTo(CFrame.new(-60.15136765607031, 6.678200292000001, 34.305199060804135) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel995.Parent = workspace.devices.definds
newmodel995.RandBr.Value = 0.41579214720352436
newmodel996 = workspace.prefabs.defind:clone()
newmodel996:PivotTo(CFrame.new(-60.15136765607031, 6.5686997080000005, 34.305199060804135) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel996.Parent = workspace.devices.definds
newmodel996.RandBr.Value = 0.4248214459503708
newmodel997 = workspace.prefabs.defind_y:clone()
newmodel997:PivotTo(CFrame.new(-60.15136765607031, 6.4592, 34.305199060804135) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel997.Parent = workspace.devices.definds
newmodel997.RandBr.Value = 0.21093130452685488
newmodel998 = workspace.prefabs.defind:clone()
newmodel998:PivotTo(CFrame.new(-60.32525920232279, 6.897200292000001, 34.18189377268393) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel998.Parent = workspace.devices.definds
newmodel998.RandBr.Value = 0.23218455823394615
newmodel999 = workspace.prefabs.defind:clone()
newmodel999:PivotTo(CFrame.new(-60.32525920232279, 6.787700584000001, 34.18189377268393) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel999.Parent = workspace.devices.definds
newmodel999.RandBr.Value = 0.017987539570388834
newmodel1000 = workspace.prefabs.defind:clone()
newmodel1000:PivotTo(CFrame.new(-60.32525920232279, 6.678200292000001, 34.18189377268393) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1000.Parent = workspace.devices.definds
newmodel1000.RandBr.Value = 0.24635422432190318
newmodel1001 = workspace.prefabs.defind:clone()
newmodel1001:PivotTo(CFrame.new(-60.32525920232279, 6.5686997080000005, 34.18189377268393) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1001.Parent = workspace.devices.definds
newmodel1001.RandBr.Value = 0.2342454541960523
newmodel1002 = workspace.prefabs.defind_y:clone()
newmodel1002:PivotTo(CFrame.new(-60.32525920232279, 6.4592, 34.18189377268393) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1002.Parent = workspace.devices.definds
newmodel1002.RandBr.Value = 0.22512643869799714
newmodel1003 = workspace.prefabs.defind:clone()
newmodel1003:PivotTo(CFrame.new(-60.49913396439924, 6.897200292000001, 34.05859883915399) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1003.Parent = workspace.devices.definds
newmodel1003.RandBr.Value = 0.3788517866249473
newmodel1004 = workspace.prefabs.defind:clone()
newmodel1004:PivotTo(CFrame.new(-60.49913396439924, 6.787700584000001, 34.05859883915399) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1004.Parent = workspace.devices.definds
newmodel1004.RandBr.Value = 0.016467859256716476
newmodel1005 = workspace.prefabs.defind:clone()
newmodel1005:PivotTo(CFrame.new(-60.49913396439924, 6.678200292000001, 34.05859883915399) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1005.Parent = workspace.devices.definds
newmodel1005.RandBr.Value = 0.11344775181064054
newmodel1006 = workspace.prefabs.defind:clone()
newmodel1006:PivotTo(CFrame.new(-60.49913396439924, 6.5686997080000005, 34.05859883915399) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1006.Parent = workspace.devices.definds
newmodel1006.RandBr.Value = 0.47531391020974706
newmodel1007 = workspace.prefabs.defind:clone()
newmodel1007:PivotTo(CFrame.new(-60.49913396439924, 6.4592, 34.05859883915399) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1007.Parent = workspace.devices.definds
newmodel1007.RandBr.Value = 0.5620897196026796
newmodel1008 = workspace.prefabs.defind:clone()
newmodel1008:PivotTo(CFrame.new(-60.67301708037784, 6.897200292000001, 33.93530054230073) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1008.Parent = workspace.devices.definds
newmodel1008.RandBr.Value = 0.15892895999392534
newmodel1009 = workspace.prefabs.defind:clone()
newmodel1009:PivotTo(CFrame.new(-60.67301708037784, 6.787700584000001, 33.93530054230073) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1009.Parent = workspace.devices.definds
newmodel1009.RandBr.Value = 0.5954899726375135
newmodel1010 = workspace.prefabs.defind:clone()
newmodel1010:PivotTo(CFrame.new(-60.67301708037784, 6.678200292000001, 33.93530054230073) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1010.Parent = workspace.devices.definds
newmodel1010.RandBr.Value = 0.4272746544205953
newmodel1011 = workspace.prefabs.defind:clone()
newmodel1011:PivotTo(CFrame.new(-60.67301708037784, 6.5686997080000005, 33.93530054230073) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1011.Parent = workspace.devices.definds
newmodel1011.RandBr.Value = 0.2850507935176345
newmodel1012 = workspace.prefabs.defind:clone()
newmodel1012:PivotTo(CFrame.new(-60.67301708037784, 6.4592, 33.93530054230073) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1012.Parent = workspace.devices.definds
newmodel1012.RandBr.Value = 0.1007373060592239
newmodel1013 = workspace.prefabs.defind:clone()
newmodel1013:PivotTo(CFrame.new(-60.846897482773166, 6.897200292000001, 33.812008010111) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1013.Parent = workspace.devices.definds
newmodel1013.RandBr.Value = 0.5876861565112844
newmodel1014 = workspace.prefabs.defind:clone()
newmodel1014:PivotTo(CFrame.new(-60.846897482773166, 6.787700584000001, 33.812008010111) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1014.Parent = workspace.devices.definds
newmodel1014.RandBr.Value = 0.23971393138732272
newmodel1015 = workspace.prefabs.defind_y:clone()
newmodel1015:PivotTo(CFrame.new(-60.846897482773166, 6.678200292000001, 33.812008010111) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1015.Parent = workspace.devices.definds
newmodel1015.RandBr.Value = 0.4685418628304286
newmodel1016 = workspace.prefabs.defind:clone()
newmodel1016:PivotTo(CFrame.new(-60.846897482773166, 6.5686997080000005, 33.812008010111) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1016.Parent = workspace.devices.definds
newmodel1016.RandBr.Value = 0.3282498260992602
newmodel1017 = workspace.prefabs.defind:clone()
newmodel1017:PivotTo(CFrame.new(-60.846897482773166, 6.4592, 33.812008010111) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1017.Parent = workspace.devices.definds
newmodel1017.RandBr.Value = 0.4857509001076139
newmodel1018 = workspace.prefabs.defind:clone()
newmodel1018:PivotTo(CFrame.new(-61.02078307414235, 6.897200292000001, 33.688704117497295) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1018.Parent = workspace.devices.definds
newmodel1018.RandBr.Value = 0.2890109927785171
newmodel1019 = workspace.prefabs.defind:clone()
newmodel1019:PivotTo(CFrame.new(-61.02078307414235, 6.787700584000001, 33.688704117497295) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1019.Parent = workspace.devices.definds
newmodel1019.RandBr.Value = 0.12689679896362238
newmodel1020 = workspace.prefabs.defind_y:clone()
newmodel1020:PivotTo(CFrame.new(-61.02078307414235, 6.678200292000001, 33.688704117497295) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1020.Parent = workspace.devices.definds
newmodel1020.RandBr.Value = 0.5120265186129507
newmodel1021 = workspace.prefabs.defind:clone()
newmodel1021:PivotTo(CFrame.new(-61.02078307414235, 6.5686997080000005, 33.688704117497295) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1021.Parent = workspace.devices.definds
newmodel1021.RandBr.Value = 0.5018480536556006
newmodel1022 = workspace.prefabs.defind:clone()
newmodel1022:PivotTo(CFrame.new(-61.02078307414235, 6.4592, 33.688704117497295) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1022.Parent = workspace.devices.definds
newmodel1022.RandBr.Value = 0.5706874805675913
newmodel1023 = workspace.prefabs.defind:clone()
newmodel1023:PivotTo(CFrame.new(-60.15136765607031, 6.237280000000001, 34.305199060804135) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1023.Parent = workspace.devices.definds
newmodel1023.RandBr.Value = 0.5051552968311717
newmodel1024 = workspace.prefabs.defind:clone()
newmodel1024:PivotTo(CFrame.new(-60.15136765607031, 6.128072, 34.305199060804135) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1024.Parent = workspace.devices.definds
newmodel1024.RandBr.Value = 0.35394294153774647
newmodel1025 = workspace.prefabs.defind:clone()
newmodel1025:PivotTo(CFrame.new(-60.15136765607031, 6.018864000000001, 34.305199060804135) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1025.Parent = workspace.devices.definds
newmodel1025.RandBr.Value = 0.49975158799735364
newmodel1026 = workspace.prefabs.defind:clone()
newmodel1026:PivotTo(CFrame.new(-60.15136765607031, 5.909656000000001, 34.305199060804135) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1026.Parent = workspace.devices.definds
newmodel1026.RandBr.Value = 0.12920065951992776
newmodel1027 = workspace.prefabs.defind_y:clone()
newmodel1027:PivotTo(CFrame.new(-60.15136765607031, 5.800448, 34.305199060804135) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1027.Parent = workspace.devices.definds
newmodel1027.RandBr.Value = 0.47668100301342375
newmodel1028 = workspace.prefabs.defind_y:clone()
newmodel1028:PivotTo(CFrame.new(-60.15136765607031, 5.691239708, 34.305199060804135) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1028.Parent = workspace.devices.definds
newmodel1028.RandBr.Value = 0.11104426007408459
newmodel1029 = workspace.prefabs.defind:clone()
newmodel1029:PivotTo(CFrame.new(-60.32525920232279, 6.237280000000001, 34.18189377268393) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1029.Parent = workspace.devices.definds
newmodel1029.RandBr.Value = 0.20859653415459672
newmodel1030 = workspace.prefabs.defind:clone()
newmodel1030:PivotTo(CFrame.new(-60.32525920232279, 6.128072, 34.18189377268393) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1030.Parent = workspace.devices.definds
newmodel1030.RandBr.Value = 0.06459604441484525
newmodel1031 = workspace.prefabs.defind:clone()
newmodel1031:PivotTo(CFrame.new(-60.32525920232279, 6.018864000000001, 34.18189377268393) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1031.Parent = workspace.devices.definds
newmodel1031.RandBr.Value = 0.07147379698055975
newmodel1032 = workspace.prefabs.defind:clone()
newmodel1032:PivotTo(CFrame.new(-60.32525920232279, 5.909656000000001, 34.18189377268393) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1032.Parent = workspace.devices.definds
newmodel1032.RandBr.Value = 0.3193219597009226
newmodel1033 = workspace.prefabs.defind_y:clone()
newmodel1033:PivotTo(CFrame.new(-60.32525920232279, 5.800448, 34.18189377268393) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1033.Parent = workspace.devices.definds
newmodel1033.RandBr.Value = 0.1669201705591111
newmodel1034 = workspace.prefabs.defind_y:clone()
newmodel1034:PivotTo(CFrame.new(-60.32525920232279, 5.691239708, 34.18189377268393) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1034.Parent = workspace.devices.definds
newmodel1034.RandBr.Value = 0.37555422265900484
newmodel1035 = workspace.prefabs.defind:clone()
newmodel1035:PivotTo(CFrame.new(-60.49913396439924, 6.237280000000001, 34.05859883915399) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1035.Parent = workspace.devices.definds
newmodel1035.RandBr.Value = 0.5684754272656133
newmodel1036 = workspace.prefabs.defind:clone()
newmodel1036:PivotTo(CFrame.new(-60.49913396439924, 6.128072, 34.05859883915399) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1036.Parent = workspace.devices.definds
newmodel1036.RandBr.Value = 0.40219026480126596
newmodel1037 = workspace.prefabs.defind:clone()
newmodel1037:PivotTo(CFrame.new(-60.49913396439924, 6.018864000000001, 34.05859883915399) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1037.Parent = workspace.devices.definds
newmodel1037.RandBr.Value = 0.09415331804954867
newmodel1038 = workspace.prefabs.defind:clone()
newmodel1038:PivotTo(CFrame.new(-60.49913396439924, 5.909656000000001, 34.05859883915399) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1038.Parent = workspace.devices.definds
newmodel1038.RandBr.Value = 0.4614182257059012
newmodel1039 = workspace.prefabs.defind_y:clone()
newmodel1039:PivotTo(CFrame.new(-60.49913396439924, 5.800448, 34.05859883915399) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1039.Parent = workspace.devices.definds
newmodel1039.RandBr.Value = 0.4495638810152747
newmodel1040 = workspace.prefabs.defind_y:clone()
newmodel1040:PivotTo(CFrame.new(-60.49913396439924, 5.691239708, 34.05859883915399) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1040.Parent = workspace.devices.definds
newmodel1040.RandBr.Value = 0.5442346599716047
newmodel1041 = workspace.prefabs.defind:clone()
newmodel1041:PivotTo(CFrame.new(-60.67301708037784, 6.237280000000001, 33.93530054230073) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1041.Parent = workspace.devices.definds
newmodel1041.RandBr.Value = 0.1405795264454829
newmodel1042 = workspace.prefabs.defind:clone()
newmodel1042:PivotTo(CFrame.new(-60.67301708037784, 6.128072, 33.93530054230073) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1042.Parent = workspace.devices.definds
newmodel1042.RandBr.Value = 0.04914845747242471
newmodel1043 = workspace.prefabs.defind:clone()
newmodel1043:PivotTo(CFrame.new(-60.67301708037784, 6.018864000000001, 33.93530054230073) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1043.Parent = workspace.devices.definds
newmodel1043.RandBr.Value = 0.1539196902879702
newmodel1044 = workspace.prefabs.defind:clone()
newmodel1044:PivotTo(CFrame.new(-60.67301708037784, 5.909656000000001, 33.93530054230073) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1044.Parent = workspace.devices.definds
newmodel1044.RandBr.Value = 0.050756843486462054
newmodel1045 = workspace.prefabs.defind_y:clone()
newmodel1045:PivotTo(CFrame.new(-60.67301708037784, 5.800448, 33.93530054230073) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1045.Parent = workspace.devices.definds
newmodel1045.RandBr.Value = 0.02165136958243934
newmodel1046 = workspace.prefabs.defind_y:clone()
newmodel1046:PivotTo(CFrame.new(-60.67301708037784, 5.691239708, 33.93530054230073) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1046.Parent = workspace.devices.definds
newmodel1046.RandBr.Value = 0.11352456747684762
newmodel1047 = workspace.prefabs.defind_y:clone()
newmodel1047:PivotTo(CFrame.new(-60.846897482773166, 6.237280000000001, 33.812008010111) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1047.Parent = workspace.devices.definds
newmodel1047.RandBr.Value = 0.5651718804119522
newmodel1048 = workspace.prefabs.defind:clone()
newmodel1048:PivotTo(CFrame.new(-60.846897482773166, 6.128072, 33.812008010111) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1048.Parent = workspace.devices.definds
newmodel1048.RandBr.Value = 0.28429648570433835
newmodel1049 = workspace.prefabs.defind:clone()
newmodel1049:PivotTo(CFrame.new(-60.846897482773166, 6.018864000000001, 33.812008010111) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1049.Parent = workspace.devices.definds
newmodel1049.RandBr.Value = 0.40816547709993933
newmodel1050 = workspace.prefabs.defind:clone()
newmodel1050:PivotTo(CFrame.new(-60.846897482773166, 5.909656000000001, 33.812008010111) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1050.Parent = workspace.devices.definds
newmodel1050.RandBr.Value = 0.33352388989767884
newmodel1051 = workspace.prefabs.defind_y:clone()
newmodel1051:PivotTo(CFrame.new(-60.846897482773166, 5.800448, 33.812008010111) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1051.Parent = workspace.devices.definds
newmodel1051.RandBr.Value = 0.5448628544173065
newmodel1052 = workspace.prefabs.defind_y:clone()
newmodel1052:PivotTo(CFrame.new(-60.846897482773166, 5.691239708, 33.812008010111) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1052.Parent = workspace.devices.definds
newmodel1052.RandBr.Value = 0.5253602647801852
newmodel1053 = workspace.prefabs.defind_y:clone()
newmodel1053:PivotTo(CFrame.new(-61.02078307414235, 6.237280000000001, 33.688704117497295) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1053.Parent = workspace.devices.definds
newmodel1053.RandBr.Value = 0.4604458221849097
newmodel1054 = workspace.prefabs.defind:clone()
newmodel1054:PivotTo(CFrame.new(-61.02078307414235, 6.128072, 33.688704117497295) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1054.Parent = workspace.devices.definds
newmodel1054.RandBr.Value = 0.09659796541020038
newmodel1055 = workspace.prefabs.defind:clone()
newmodel1055:PivotTo(CFrame.new(-61.02078307414235, 6.018864000000001, 33.688704117497295) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1055.Parent = workspace.devices.definds
newmodel1055.RandBr.Value = 0.0713875343926896
newmodel1056 = workspace.prefabs.defind:clone()
newmodel1056:PivotTo(CFrame.new(-61.02078307414235, 5.909656000000001, 33.688704117497295) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1056.Parent = workspace.devices.definds
newmodel1056.RandBr.Value = 0.43783375446917666
newmodel1057 = workspace.prefabs.defind_y:clone()
newmodel1057:PivotTo(CFrame.new(-61.02078307414235, 5.800448, 33.688704117497295) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1057.Parent = workspace.devices.definds
newmodel1057.RandBr.Value = 0.3516106272887553
newmodel1058 = workspace.prefabs.defind_y:clone()
newmodel1058:PivotTo(CFrame.new(-61.02078307414235, 5.691239708, 33.688704117497295) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1058.Parent = workspace.devices.definds
newmodel1058.RandBr.Value = 0.11457260556800432
newmodel1059 = workspace.prefabs.defind:clone()
newmodel1059:PivotTo(CFrame.new(-61.36379282121264, 6.897200292000001, 33.44549042402929) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1059.Parent = workspace.devices.definds
newmodel1059.RandBr.Value = 0.4578465049685361
newmodel1060 = workspace.prefabs.defind:clone()
newmodel1060:PivotTo(CFrame.new(-61.36379282121264, 6.787700584000001, 33.44549042402929) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1060.Parent = workspace.devices.definds
newmodel1060.RandBr.Value = 0.27223260729475907
newmodel1061 = workspace.prefabs.defind:clone()
newmodel1061:PivotTo(CFrame.new(-61.36379282121264, 6.678200292000001, 33.44549042402929) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1061.Parent = workspace.devices.definds
newmodel1061.RandBr.Value = 0.12714927545100577
newmodel1062 = workspace.prefabs.defind:clone()
newmodel1062:PivotTo(CFrame.new(-61.36379282121264, 6.5686997080000005, 33.44549042402929) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1062.Parent = workspace.devices.definds
newmodel1062.RandBr.Value = 0.22060043001305465
newmodel1063 = workspace.prefabs.defind_y:clone()
newmodel1063:PivotTo(CFrame.new(-61.36379282121264, 6.4592, 33.44549042402929) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1063.Parent = workspace.devices.definds
newmodel1063.RandBr.Value = 0.16020836634786276
newmodel1064 = workspace.prefabs.defind:clone()
newmodel1064:PivotTo(CFrame.new(-61.537680311876485, 6.897200292000001, 33.32218870510236) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1064.Parent = workspace.devices.definds
newmodel1064.RandBr.Value = 0.018183596294835656
newmodel1065 = workspace.prefabs.defind:clone()
newmodel1065:PivotTo(CFrame.new(-61.537680311876485, 6.787700584000001, 33.32218870510236) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1065.Parent = workspace.devices.definds
newmodel1065.RandBr.Value = 0.200581563044234
newmodel1066 = workspace.prefabs.defind:clone()
newmodel1066:PivotTo(CFrame.new(-61.537680311876485, 6.678200292000001, 33.32218870510236) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1066.Parent = workspace.devices.definds
newmodel1066.RandBr.Value = 0.09443474708215195
newmodel1067 = workspace.prefabs.defind_y:clone()
newmodel1067:PivotTo(CFrame.new(-61.537680311876485, 6.5686997080000005, 33.32218870510236) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1067.Parent = workspace.devices.definds
newmodel1067.RandBr.Value = 0.3911630562386946
newmodel1068 = workspace.prefabs.defind_y:clone()
newmodel1068:PivotTo(CFrame.new(-61.537680311876485, 6.4592, 33.32218870510236) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1068.Parent = workspace.devices.definds
newmodel1068.RandBr.Value = 0.05198619411910097
newmodel1069 = workspace.prefabs.defind:clone()
newmodel1069:PivotTo(CFrame.new(-61.71155254822679, 6.897200292000001, 33.19889929634652) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1069.Parent = workspace.devices.definds
newmodel1069.RandBr.Value = 0.5375082599756582
newmodel1070 = workspace.prefabs.defind:clone()
newmodel1070:PivotTo(CFrame.new(-61.71155254822679, 6.787700584000001, 33.19889929634652) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1070.Parent = workspace.devices.definds
newmodel1070.RandBr.Value = 0.48448868128182704
newmodel1071 = workspace.prefabs.defind:clone()
newmodel1071:PivotTo(CFrame.new(-61.71155254822679, 6.678200292000001, 33.19889929634652) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1071.Parent = workspace.devices.definds
newmodel1071.RandBr.Value = 0.41506333988233846
newmodel1072 = workspace.prefabs.defind_y:clone()
newmodel1072:PivotTo(CFrame.new(-61.71155254822679, 6.5686997080000005, 33.19889929634652) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1072.Parent = workspace.devices.definds
newmodel1072.RandBr.Value = 0.41305955333613703
newmodel1073 = workspace.prefabs.defind_y:clone()
newmodel1073:PivotTo(CFrame.new(-61.71155254822679, 6.4592, 33.19889929634652) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1073.Parent = workspace.devices.definds
newmodel1073.RandBr.Value = 0.5260275605682291
newmodel1074 = workspace.prefabs.defind:clone()
newmodel1074:PivotTo(CFrame.new(-61.8854438302498, 6.897200292000001, 33.07559787605851) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1074.Parent = workspace.devices.definds
newmodel1074.RandBr.Value = 0.07953708798891736
newmodel1075 = workspace.prefabs.defind:clone()
newmodel1075:PivotTo(CFrame.new(-61.8854438302498, 6.787700584000001, 33.07559787605851) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1075.Parent = workspace.devices.definds
newmodel1075.RandBr.Value = 0.07780434729146643
newmodel1076 = workspace.prefabs.defind:clone()
newmodel1076:PivotTo(CFrame.new(-61.8854438302498, 6.678200292000001, 33.07559787605851) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1076.Parent = workspace.devices.definds
newmodel1076.RandBr.Value = 0.5872263667947861
newmodel1077 = workspace.prefabs.defind:clone()
newmodel1077:PivotTo(CFrame.new(-61.8854438302498, 6.5686997080000005, 33.07559787605851) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1077.Parent = workspace.devices.definds
newmodel1077.RandBr.Value = 0.2377808231129095
newmodel1078 = workspace.prefabs.defind_y:clone()
newmodel1078:PivotTo(CFrame.new(-61.8854438302498, 6.4592, 33.07559787605851) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1078.Parent = workspace.devices.definds
newmodel1078.RandBr.Value = 0.5986864172848866
newmodel1079 = workspace.prefabs.defind:clone()
newmodel1079:PivotTo(CFrame.new(-62.059322866337396, 6.897200292000001, 32.952299378477974) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1079.Parent = workspace.devices.definds
newmodel1079.RandBr.Value = 0.2762073776774945
newmodel1080 = workspace.prefabs.defind:clone()
newmodel1080:PivotTo(CFrame.new(-62.059322866337396, 6.787700584000001, 32.952299378477974) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1080.Parent = workspace.devices.definds
newmodel1080.RandBr.Value = 0.2018993034881313
newmodel1081 = workspace.prefabs.defind:clone()
newmodel1081:PivotTo(CFrame.new(-62.059322866337396, 6.678200292000001, 32.952299378477974) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1081.Parent = workspace.devices.definds
newmodel1081.RandBr.Value = 0.585685426871205
newmodel1082 = workspace.prefabs.defind:clone()
newmodel1082:PivotTo(CFrame.new(-62.059322866337396, 6.5686997080000005, 32.952299378477974) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1082.Parent = workspace.devices.definds
newmodel1082.RandBr.Value = 0.49858443886717296
newmodel1083 = workspace.prefabs.defind:clone()
newmodel1083:PivotTo(CFrame.new(-62.059322866337396, 6.4592, 32.952299378477974) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1083.Parent = workspace.devices.definds
newmodel1083.RandBr.Value = 0.025486092719349696
newmodel1084 = workspace.prefabs.defind:clone()
newmodel1084:PivotTo(CFrame.new(-62.23320375138155, 6.897200292000001, 32.82900298359431) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1084.Parent = workspace.devices.definds
newmodel1084.RandBr.Value = 0.532901492398278
newmodel1085 = workspace.prefabs.defind:clone()
newmodel1085:PivotTo(CFrame.new(-62.23320375138155, 6.787700584000001, 32.82900298359431) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1085.Parent = workspace.devices.definds
newmodel1085.RandBr.Value = 0.4873179519091916
newmodel1086 = workspace.prefabs.defind:clone()
newmodel1086:PivotTo(CFrame.new(-62.23320375138155, 6.678200292000001, 32.82900298359431) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1086.Parent = workspace.devices.definds
newmodel1086.RandBr.Value = 0.5443160439538102
newmodel1087 = workspace.prefabs.defind:clone()
newmodel1087:PivotTo(CFrame.new(-62.23320375138155, 6.5686997080000005, 32.82900298359431) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1087.Parent = workspace.devices.definds
newmodel1087.RandBr.Value = 0.11214263043819324
newmodel1088 = workspace.prefabs.defind:clone()
newmodel1088:PivotTo(CFrame.new(-62.23320375138155, 6.4592, 32.82900298359431) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1088.Parent = workspace.devices.definds
newmodel1088.RandBr.Value = 0.4990010443545534
newmodel1089 = workspace.prefabs.defind:clone()
newmodel1089:PivotTo(CFrame.new(-61.36379282121264, 6.237280000000001, 33.44549042402929) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1089.Parent = workspace.devices.definds
newmodel1089.RandBr.Value = 0.5510848834509061
newmodel1090 = workspace.prefabs.defind_y:clone()
newmodel1090:PivotTo(CFrame.new(-61.36379282121264, 6.128072, 33.44549042402929) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1090.Parent = workspace.devices.definds
newmodel1090.RandBr.Value = 0.07726681172418733
newmodel1091 = workspace.prefabs.defind:clone()
newmodel1091:PivotTo(CFrame.new(-61.36379282121264, 6.018864000000001, 33.44549042402929) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1091.Parent = workspace.devices.definds
newmodel1091.RandBr.Value = 0.04354043849982758
newmodel1092 = workspace.prefabs.defind:clone()
newmodel1092:PivotTo(CFrame.new(-61.36379282121264, 5.909656000000001, 33.44549042402929) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1092.Parent = workspace.devices.definds
newmodel1092.RandBr.Value = 0.46301133068330347
newmodel1093 = workspace.prefabs.defind_y:clone()
newmodel1093:PivotTo(CFrame.new(-61.36379282121264, 5.800448, 33.44549042402929) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1093.Parent = workspace.devices.definds
newmodel1093.RandBr.Value = 0.06629786293636057
newmodel1094 = workspace.prefabs.defind:clone()
newmodel1094:PivotTo(CFrame.new(-61.36379282121264, 5.691239708, 33.44549042402929) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1094.Parent = workspace.devices.definds
newmodel1094.RandBr.Value = 0.529619072494081
newmodel1095 = workspace.prefabs.defind:clone()
newmodel1095:PivotTo(CFrame.new(-61.537680311876485, 6.237280000000001, 33.32218870510236) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1095.Parent = workspace.devices.definds
newmodel1095.RandBr.Value = 0.5041895838612565
newmodel1096 = workspace.prefabs.defind_y:clone()
newmodel1096:PivotTo(CFrame.new(-61.537680311876485, 6.128072, 33.32218870510236) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1096.Parent = workspace.devices.definds
newmodel1096.RandBr.Value = 0.20645910020779842
newmodel1097 = workspace.prefabs.defind:clone()
newmodel1097:PivotTo(CFrame.new(-61.537680311876485, 6.018864000000001, 33.32218870510236) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1097.Parent = workspace.devices.definds
newmodel1097.RandBr.Value = 0.31927841283875663
newmodel1098 = workspace.prefabs.defind:clone()
newmodel1098:PivotTo(CFrame.new(-61.537680311876485, 5.909656000000001, 33.32218870510236) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1098.Parent = workspace.devices.definds
newmodel1098.RandBr.Value = 0.03911179569609784
newmodel1099 = workspace.prefabs.defind_y:clone()
newmodel1099:PivotTo(CFrame.new(-61.537680311876485, 5.800448, 33.32218870510236) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1099.Parent = workspace.devices.definds
newmodel1099.RandBr.Value = 0.15178253132368014
newmodel1100 = workspace.prefabs.defind:clone()
newmodel1100:PivotTo(CFrame.new(-61.537680311876485, 5.691239708, 33.32218870510236) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1100.Parent = workspace.devices.definds
newmodel1100.RandBr.Value = 0.551448061774856
newmodel1101 = workspace.prefabs.defind:clone()
newmodel1101:PivotTo(CFrame.new(-61.71155254822679, 6.237280000000001, 33.19889929634652) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1101.Parent = workspace.devices.definds
newmodel1101.RandBr.Value = 0.44664995144683756
newmodel1102 = workspace.prefabs.defind:clone()
newmodel1102:PivotTo(CFrame.new(-61.71155254822679, 6.128072, 33.19889929634652) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1102.Parent = workspace.devices.definds
newmodel1102.RandBr.Value = 0.481860057980599
newmodel1103 = workspace.prefabs.defind:clone()
newmodel1103:PivotTo(CFrame.new(-61.71155254822679, 6.018864000000001, 33.19889929634652) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1103.Parent = workspace.devices.definds
newmodel1103.RandBr.Value = 0.575222870946101
newmodel1104 = workspace.prefabs.defind:clone()
newmodel1104:PivotTo(CFrame.new(-61.71155254822679, 5.909656000000001, 33.19889929634652) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1104.Parent = workspace.devices.definds
newmodel1104.RandBr.Value = 0.07770080406724363
newmodel1105 = workspace.prefabs.defind_y:clone()
newmodel1105:PivotTo(CFrame.new(-61.71155254822679, 5.800448, 33.19889929634652) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1105.Parent = workspace.devices.definds
newmodel1105.RandBr.Value = 0.2517376729336542
newmodel1106 = workspace.prefabs.defind_y:clone()
newmodel1106:PivotTo(CFrame.new(-61.71155254822679, 5.691239708, 33.19889929634652) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1106.Parent = workspace.devices.definds
newmodel1106.RandBr.Value = 0.12455314344089964
newmodel1107 = workspace.prefabs.defind:clone()
newmodel1107:PivotTo(CFrame.new(-61.8854438302498, 6.237280000000001, 33.07559787605851) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1107.Parent = workspace.devices.definds
newmodel1107.RandBr.Value = 0.33200638169873303
newmodel1108 = workspace.prefabs.defind:clone()
newmodel1108:PivotTo(CFrame.new(-61.8854438302498, 6.128072, 33.07559787605851) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1108.Parent = workspace.devices.definds
newmodel1108.RandBr.Value = 6.575388710270413e-05
newmodel1109 = workspace.prefabs.defind:clone()
newmodel1109:PivotTo(CFrame.new(-61.8854438302498, 6.018864000000001, 33.07559787605851) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1109.Parent = workspace.devices.definds
newmodel1109.RandBr.Value = 0.4909877358937659
newmodel1110 = workspace.prefabs.defind:clone()
newmodel1110:PivotTo(CFrame.new(-61.8854438302498, 5.909656000000001, 33.07559787605851) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1110.Parent = workspace.devices.definds
newmodel1110.RandBr.Value = 0.15825372192948456
newmodel1111 = workspace.prefabs.defind_y:clone()
newmodel1111:PivotTo(CFrame.new(-61.8854438302498, 5.800448, 33.07559787605851) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1111.Parent = workspace.devices.definds
newmodel1111.RandBr.Value = 0.471521516598664
newmodel1112 = workspace.prefabs.defind:clone()
newmodel1112:PivotTo(CFrame.new(-61.8854438302498, 5.691239708, 33.07559787605851) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1112.Parent = workspace.devices.definds
newmodel1112.RandBr.Value = 0.13581368068369193
newmodel1113 = workspace.prefabs.defind:clone()
newmodel1113:PivotTo(CFrame.new(-62.059322866337396, 6.237280000000001, 32.952299378477974) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1113.Parent = workspace.devices.definds
newmodel1113.RandBr.Value = 0.13783269564938197
newmodel1114 = workspace.prefabs.defind:clone()
newmodel1114:PivotTo(CFrame.new(-62.059322866337396, 6.128072, 32.952299378477974) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1114.Parent = workspace.devices.definds
newmodel1114.RandBr.Value = 0.30708576623893014
newmodel1115 = workspace.prefabs.defind:clone()
newmodel1115:PivotTo(CFrame.new(-62.059322866337396, 6.018864000000001, 32.952299378477974) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1115.Parent = workspace.devices.definds
newmodel1115.RandBr.Value = 0.39876434129196286
newmodel1116 = workspace.prefabs.defind:clone()
newmodel1116:PivotTo(CFrame.new(-62.059322866337396, 5.909656000000001, 32.952299378477974) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1116.Parent = workspace.devices.definds
newmodel1116.RandBr.Value = 0.4520274066658568
newmodel1117 = workspace.prefabs.defind_y:clone()
newmodel1117:PivotTo(CFrame.new(-62.059322866337396, 5.800448, 32.952299378477974) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1117.Parent = workspace.devices.definds
newmodel1117.RandBr.Value = 0.20698129370409096
newmodel1118 = workspace.prefabs.defind:clone()
newmodel1118:PivotTo(CFrame.new(-62.059322866337396, 5.691239708, 32.952299378477974) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1118.Parent = workspace.devices.definds
newmodel1118.RandBr.Value = 0.36048633740092645
newmodel1119 = workspace.prefabs.defind:clone()
newmodel1119:PivotTo(CFrame.new(-62.23320375138155, 6.237280000000001, 32.82900298359431) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1119.Parent = workspace.devices.definds
newmodel1119.RandBr.Value = 0.374721824135623
newmodel1120 = workspace.prefabs.defind:clone()
newmodel1120:PivotTo(CFrame.new(-62.23320375138155, 6.128072, 32.82900298359431) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1120.Parent = workspace.devices.definds
newmodel1120.RandBr.Value = 0.39793993743504297
newmodel1121 = workspace.prefabs.defind:clone()
newmodel1121:PivotTo(CFrame.new(-62.23320375138155, 6.018864000000001, 32.82900298359431) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1121.Parent = workspace.devices.definds
newmodel1121.RandBr.Value = 0.07983734121813146
newmodel1122 = workspace.prefabs.defind:clone()
newmodel1122:PivotTo(CFrame.new(-62.23320375138155, 5.909656000000001, 32.82900298359431) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1122.Parent = workspace.devices.definds
newmodel1122.RandBr.Value = 0.2031022922477193
newmodel1123 = workspace.prefabs.defind:clone()
newmodel1123:PivotTo(CFrame.new(-62.23320375138155, 5.800448, 32.82900298359431) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1123.Parent = workspace.devices.definds
newmodel1123.RandBr.Value = 0.08640528261725464
newmodel1124 = workspace.prefabs.defind:clone()
newmodel1124:PivotTo(CFrame.new(-62.23320375138155, 5.691239708, 32.82900298359431) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel1124.Parent = workspace.devices.definds
newmodel1124.RandBr.Value = 0.06824510137359603
newmodel1125 = workspace.prefabs.defind:clone()
newmodel1125:PivotTo(CFrame.new(-62.78527925330658, 6.897200292000001, 32.40803045534216) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1125.Parent = workspace.devices.definds
newmodel1125.RandBr.Value = 0.5415506863569424
newmodel1126 = workspace.prefabs.defind_y:clone()
newmodel1126:PivotTo(CFrame.new(-62.78527925330658, 6.791107056, 32.40803045534216) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1126.Parent = workspace.devices.definds
newmodel1126.RandBr.Value = 0.5040507987917116
newmodel1127 = workspace.prefabs.defind:clone()
newmodel1127:PivotTo(CFrame.new(-62.78527925330658, 6.685013820000001, 32.40803045534216) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1127.Parent = workspace.devices.definds
newmodel1127.RandBr.Value = 0.09778165965886809
newmodel1128 = workspace.prefabs.defind_y:clone()
newmodel1128:PivotTo(CFrame.new(-62.78527925330658, 6.578920292, 32.40803045534216) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1128.Parent = workspace.devices.definds
newmodel1128.RandBr.Value = 0.24467498755530065
newmodel1129 = workspace.prefabs.defind_y:clone()
newmodel1129:PivotTo(CFrame.new(-62.94182315532414, 6.897200292000001, 32.27390179008506) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1129.Parent = workspace.devices.definds
newmodel1129.RandBr.Value = 0.43614583267667634
newmodel1130 = workspace.prefabs.defind:clone()
newmodel1130:PivotTo(CFrame.new(-62.94182315532414, 6.791107056, 32.27390179008506) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1130.Parent = workspace.devices.definds
newmodel1130.RandBr.Value = 0.34973545675522716
newmodel1131 = workspace.prefabs.defind:clone()
newmodel1131:PivotTo(CFrame.new(-62.94182315532414, 6.685013820000001, 32.27390179008506) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1131.Parent = workspace.devices.definds
newmodel1131.RandBr.Value = 0.44478359578028664
newmodel1132 = workspace.prefabs.defind_y:clone()
newmodel1132:PivotTo(CFrame.new(-62.94182315532414, 6.578920292, 32.27390179008506) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1132.Parent = workspace.devices.definds
newmodel1132.RandBr.Value = 0.5527512714938179
newmodel1133 = workspace.prefabs.defind:clone()
newmodel1133:PivotTo(CFrame.new(-63.09837061125251, 6.897200292000001, 32.13976879062361) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1133.Parent = workspace.devices.definds
newmodel1133.RandBr.Value = 0.15457163698762427
newmodel1134 = workspace.prefabs.defind:clone()
newmodel1134:PivotTo(CFrame.new(-63.09837061125251, 6.791107056, 32.13976879062361) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1134.Parent = workspace.devices.definds
newmodel1134.RandBr.Value = 0.47353915658152856
newmodel1135 = workspace.prefabs.defind_y:clone()
newmodel1135:PivotTo(CFrame.new(-63.09837061125251, 6.685013820000001, 32.13976879062361) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1135.Parent = workspace.devices.definds
newmodel1135.RandBr.Value = 0.509312764355522
newmodel1136 = workspace.prefabs.defind_y:clone()
newmodel1136:PivotTo(CFrame.new(-63.09837061125251, 6.578920292, 32.13976879062361) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1136.Parent = workspace.devices.definds
newmodel1136.RandBr.Value = 0.4049098776589949
newmodel1137 = workspace.prefabs.defind:clone()
newmodel1137:PivotTo(CFrame.new(-63.25492099291272, 6.897200292000001, 32.00564548890861) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1137.Parent = workspace.devices.definds
newmodel1137.RandBr.Value = 0.36887871899152497
newmodel1138 = workspace.prefabs.defind:clone()
newmodel1138:PivotTo(CFrame.new(-63.25492099291272, 6.791107056, 32.00564548890861) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1138.Parent = workspace.devices.definds
newmodel1138.RandBr.Value = 0.5976577383963978
newmodel1139 = workspace.prefabs.defind:clone()
newmodel1139:PivotTo(CFrame.new(-63.25492099291272, 6.685013820000001, 32.00564548890861) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1139.Parent = workspace.devices.definds
newmodel1139.RandBr.Value = 0.010232302332582655
newmodel1140 = workspace.prefabs.defind_y:clone()
newmodel1140:PivotTo(CFrame.new(-63.25492099291272, 6.578920292, 32.00564548890861) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1140.Parent = workspace.devices.definds
newmodel1140.RandBr.Value = 0.07919439028807436
newmodel1141 = workspace.prefabs.defind:clone()
newmodel1141:PivotTo(CFrame.new(-63.41146809949182, 6.897200292000001, 31.87150849140773) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1141.Parent = workspace.devices.definds
newmodel1141.RandBr.Value = 0.08392577870196116
newmodel1142 = workspace.prefabs.defind:clone()
newmodel1142:PivotTo(CFrame.new(-63.41146809949182, 6.791107056, 31.87150849140773) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1142.Parent = workspace.devices.definds
newmodel1142.RandBr.Value = 0.20139253685744898
newmodel1143 = workspace.prefabs.defind:clone()
newmodel1143:PivotTo(CFrame.new(-63.41146809949182, 6.685013820000001, 31.87150849140773) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1143.Parent = workspace.devices.definds
newmodel1143.RandBr.Value = 0.37750913226263394
newmodel1144 = workspace.prefabs.defind_y:clone()
newmodel1144:PivotTo(CFrame.new(-63.41146809949182, 6.578920292, 31.87150849140773) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1144.Parent = workspace.devices.definds
newmodel1144.RandBr.Value = 0.29842897767273097
newmodel1145 = workspace.prefabs.defind:clone()
newmodel1145:PivotTo(CFrame.new(-63.56802115095103, 6.897200292000001, 31.737373046916687) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1145.Parent = workspace.devices.definds
newmodel1145.RandBr.Value = 0.2974626226226918
newmodel1146 = workspace.prefabs.defind:clone()
newmodel1146:PivotTo(CFrame.new(-63.56802115095103, 6.791107056, 31.737373046916687) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1146.Parent = workspace.devices.definds
newmodel1146.RandBr.Value = 0.5292183872713927
newmodel1147 = workspace.prefabs.defind:clone()
newmodel1147:PivotTo(CFrame.new(-63.56802115095103, 6.685013820000001, 31.737373046916687) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1147.Parent = workspace.devices.definds
newmodel1147.RandBr.Value = 0.14495753902096867
newmodel1148 = workspace.prefabs.defind_y:clone()
newmodel1148:PivotTo(CFrame.new(-63.56802115095103, 6.578920292, 31.737373046916687) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1148.Parent = workspace.devices.definds
newmodel1148.RandBr.Value = 0.28825419635966215
newmodel1149 = workspace.prefabs.defind:clone()
newmodel1149:PivotTo(CFrame.new(-63.88733127684375, 6.897200292000001, 31.46378150475268) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1149.Parent = workspace.devices.definds
newmodel1149.RandBr.Value = 0.2524112655781567
newmodel1150 = workspace.prefabs.defind:clone()
newmodel1150:PivotTo(CFrame.new(-63.88733127684375, 6.791107056, 31.46378150475268) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1150.Parent = workspace.devices.definds
newmodel1150.RandBr.Value = 0.38000824028389546
newmodel1151 = workspace.prefabs.defind:clone()
newmodel1151:PivotTo(CFrame.new(-63.88733127684375, 6.685013820000001, 31.46378150475268) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1151.Parent = workspace.devices.definds
newmodel1151.RandBr.Value = 0.3407244610150015
newmodel1152 = workspace.prefabs.defind:clone()
newmodel1152:PivotTo(CFrame.new(-63.88733127684375, 6.578920292, 31.46378150475268) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1152.Parent = workspace.devices.definds
newmodel1152.RandBr.Value = 0.0662816855338615
newmodel1153 = workspace.prefabs.defind:clone()
newmodel1153:PivotTo(CFrame.new(-64.04387774722314, 6.897200292000001, 31.32965857472012) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1153.Parent = workspace.devices.definds
newmodel1153.RandBr.Value = 0.012265609261305887
newmodel1154 = workspace.prefabs.defind:clone()
newmodel1154:PivotTo(CFrame.new(-64.04387774722314, 6.791107056, 31.32965857472012) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1154.Parent = workspace.devices.definds
newmodel1154.RandBr.Value = 0.06545548495850417
newmodel1155 = workspace.prefabs.defind:clone()
newmodel1155:PivotTo(CFrame.new(-64.04387774722314, 6.685013820000001, 31.32965857472012) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1155.Parent = workspace.devices.definds
newmodel1155.RandBr.Value = 0.33036282860761174
newmodel1156 = workspace.prefabs.defind:clone()
newmodel1156:PivotTo(CFrame.new(-64.04387774722314, 6.578920292, 31.32965857472012) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1156.Parent = workspace.devices.definds
newmodel1156.RandBr.Value = 0.27148617858222457
newmodel1157 = workspace.prefabs.defind:clone()
newmodel1157:PivotTo(CFrame.new(-64.20042463205992, 6.897200292000001, 31.195521767204365) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1157.Parent = workspace.devices.definds
newmodel1157.RandBr.Value = 0.4872569511372099
newmodel1158 = workspace.prefabs.defind:clone()
newmodel1158:PivotTo(CFrame.new(-64.20042463205992, 6.791107056, 31.195521767204365) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1158.Parent = workspace.devices.definds
newmodel1158.RandBr.Value = 0.24704729888494692
newmodel1159 = workspace.prefabs.defind:clone()
newmodel1159:PivotTo(CFrame.new(-64.20042463205992, 6.685013820000001, 31.195521767204365) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1159.Parent = workspace.devices.definds
newmodel1159.RandBr.Value = 0.2566204857262235
newmodel1160 = workspace.prefabs.defind_y:clone()
newmodel1160:PivotTo(CFrame.new(-64.20042463205992, 6.578920292, 31.195521767204365) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1160.Parent = workspace.devices.definds
newmodel1160.RandBr.Value = 0.20505604903648392
newmodel1161 = workspace.prefabs.defind:clone()
newmodel1161:PivotTo(CFrame.new(-64.35697094651967, 6.897200292000001, 31.061394616102618) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1161.Parent = workspace.devices.definds
newmodel1161.RandBr.Value = 0.008820146284798769
newmodel1162 = workspace.prefabs.defind:clone()
newmodel1162:PivotTo(CFrame.new(-64.35697094651967, 6.791107056, 31.061394616102618) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1162.Parent = workspace.devices.definds
newmodel1162.RandBr.Value = 0.35655953612908253
newmodel1163 = workspace.prefabs.defind:clone()
newmodel1163:PivotTo(CFrame.new(-64.35697094651967, 6.685013820000001, 31.061394616102618) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1163.Parent = workspace.devices.definds
newmodel1163.RandBr.Value = 0.3869540068034892
newmodel1164 = workspace.prefabs.defind:clone()
newmodel1164:PivotTo(CFrame.new(-64.35697094651967, 6.578920292, 31.061394616102618) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1164.Parent = workspace.devices.definds
newmodel1164.RandBr.Value = 0.1275328158191585
newmodel1165 = workspace.prefabs.defind:clone()
newmodel1165:PivotTo(CFrame.new(-64.51352840016304, 6.897200292000001, 30.927262963180908) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1165.Parent = workspace.devices.definds
newmodel1165.RandBr.Value = 0.5637693014197775
newmodel1166 = workspace.prefabs.defind:clone()
newmodel1166:PivotTo(CFrame.new(-64.51352840016304, 6.791107056, 30.927262963180908) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1166.Parent = workspace.devices.definds
newmodel1166.RandBr.Value = 0.46761698725373346
newmodel1167 = workspace.prefabs.defind:clone()
newmodel1167:PivotTo(CFrame.new(-64.51352840016304, 6.685013820000001, 30.927262963180908) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1167.Parent = workspace.devices.definds
newmodel1167.RandBr.Value = 0.42563297166911085
newmodel1168 = workspace.prefabs.defind_y:clone()
newmodel1168:PivotTo(CFrame.new(-64.51352840016304, 6.578920292, 30.927262963180908) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1168.Parent = workspace.devices.definds
newmodel1168.RandBr.Value = 0.09999635138834344
newmodel1169 = workspace.prefabs.defind:clone()
newmodel1169:PivotTo(CFrame.new(-64.67007170870174, 6.897200292000001, 30.793126469529078) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1169.Parent = workspace.devices.definds
newmodel1169.RandBr.Value = 0.2584503418263957
newmodel1170 = workspace.prefabs.defind:clone()
newmodel1170:PivotTo(CFrame.new(-64.67007170870174, 6.791107056, 30.793126469529078) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1170.Parent = workspace.devices.definds
newmodel1170.RandBr.Value = 0.31423431660754564
newmodel1171 = workspace.prefabs.defind:clone()
newmodel1171:PivotTo(CFrame.new(-64.67007170870174, 6.685013820000001, 30.793126469529078) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1171.Parent = workspace.devices.definds
newmodel1171.RandBr.Value = 0.08964061642580524
newmodel1172 = workspace.prefabs.defind_y:clone()
newmodel1172:PivotTo(CFrame.new(-64.67007170870174, 6.578920292, 30.793126469529078) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1172.Parent = workspace.devices.definds
newmodel1172.RandBr.Value = 0.13156001841889736
newmodel1173 = workspace.prefabs.defind_y:clone()
newmodel1173:PivotTo(CFrame.new(-63.57245316620281, 7.0723994452, 31.73357363061434) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1173.Parent = workspace.devices.definds
newmodel1173.RandBr.Value = 0.5660126834492533
newmodel1174 = workspace.prefabs.defind_r:clone()
newmodel1174:PivotTo(CFrame.new(-63.88289986099339, 7.0723994452, 31.467584762150643) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel1174.Parent = workspace.devices.definds
newmodel1174.RandBr.Value = 0.22221265379626398
newmodel1175 = workspace.prefabs.defind:clone()
newmodel1175:PivotTo(CFrame.new(-67.42576658820714, 6.897200292000001, 27.982674589486223) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1175.Parent = workspace.devices.definds
newmodel1175.RandBr.Value = 0.11133744431200517
newmodel1176 = workspace.prefabs.defind:clone()
newmodel1176:PivotTo(CFrame.new(-67.42576658820714, 6.790828488, 27.982674589486223) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1176.Parent = workspace.devices.definds
newmodel1176.RandBr.Value = 0.5210818337889194
newmodel1177 = workspace.prefabs.defind:clone()
newmodel1177:PivotTo(CFrame.new(-67.42576658820714, 6.684457560000001, 27.982674589486223) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1177.Parent = workspace.devices.definds
newmodel1177.RandBr.Value = 0.11591981496156158
newmodel1178 = workspace.prefabs.defind:clone()
newmodel1178:PivotTo(CFrame.new(-67.42576658820714, 6.578086340000001, 27.982674589486223) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1178.Parent = workspace.devices.definds
newmodel1178.RandBr.Value = 0.28206325817514066
newmodel1179 = workspace.prefabs.defind:clone()
newmodel1179:PivotTo(CFrame.new(-67.42576658820714, 6.471714536000001, 27.982674589486223) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1179.Parent = workspace.devices.definds
newmodel1179.RandBr.Value = 0.4707386472113707
newmodel1180 = workspace.prefabs.defind:clone()
newmodel1180:PivotTo(CFrame.new(-67.42576658820714, 6.365342148000001, 27.982674589486223) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1180.Parent = workspace.devices.definds
newmodel1180.RandBr.Value = 0.34107780271560256
newmodel1181 = workspace.prefabs.defind:clone()
newmodel1181:PivotTo(CFrame.new(-67.42576658820714, 6.258970928, 27.982674589486223) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1181.Parent = workspace.devices.definds
newmodel1181.RandBr.Value = 0.43788856016263195
newmodel1182 = workspace.prefabs.defind:clone()
newmodel1182:PivotTo(CFrame.new(-67.42576658820714, 6.152600000000001, 27.982674589486223) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1182.Parent = workspace.devices.definds
newmodel1182.RandBr.Value = 0.2419507534599572
newmodel1183 = workspace.prefabs.defind:clone()
newmodel1183:PivotTo(CFrame.new(-67.55597627420036, 6.897200292000001, 27.82134799686958) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1183.Parent = workspace.devices.definds
newmodel1183.RandBr.Value = 0.21624878974995837
newmodel1184 = workspace.prefabs.defind:clone()
newmodel1184:PivotTo(CFrame.new(-67.55597627420036, 6.790828488, 27.82134799686958) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1184.Parent = workspace.devices.definds
newmodel1184.RandBr.Value = 0.3134429779694546
newmodel1185 = workspace.prefabs.defind:clone()
newmodel1185:PivotTo(CFrame.new(-67.55597627420036, 6.684457560000001, 27.82134799686958) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1185.Parent = workspace.devices.definds
newmodel1185.RandBr.Value = 0.5165185450755325
newmodel1186 = workspace.prefabs.defind:clone()
newmodel1186:PivotTo(CFrame.new(-67.55597627420036, 6.578086340000001, 27.82134799686958) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1186.Parent = workspace.devices.definds
newmodel1186.RandBr.Value = 0.16234672385657148
newmodel1187 = workspace.prefabs.defind:clone()
newmodel1187:PivotTo(CFrame.new(-67.55597627420036, 6.471714536000001, 27.82134799686958) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1187.Parent = workspace.devices.definds
newmodel1187.RandBr.Value = 0.4414944555961969
newmodel1188 = workspace.prefabs.defind:clone()
newmodel1188:PivotTo(CFrame.new(-67.55597627420036, 6.365342148000001, 27.82134799686958) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1188.Parent = workspace.devices.definds
newmodel1188.RandBr.Value = 0.020718778484468126
newmodel1189 = workspace.prefabs.defind:clone()
newmodel1189:PivotTo(CFrame.new(-67.55597627420036, 6.258970928, 27.82134799686958) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1189.Parent = workspace.devices.definds
newmodel1189.RandBr.Value = 0.17759038311938505
newmodel1190 = workspace.prefabs.defind:clone()
newmodel1190:PivotTo(CFrame.new(-67.55597627420036, 6.152600000000001, 27.82134799686958) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1190.Parent = workspace.devices.definds
newmodel1190.RandBr.Value = 0.046416299031353005
newmodel1191 = workspace.prefabs.defind:clone()
newmodel1191:PivotTo(CFrame.new(-67.68619585232626, 6.897200292000001, 27.66002743771273) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1191.Parent = workspace.devices.definds
newmodel1191.RandBr.Value = 0.04998893448452244
newmodel1192 = workspace.prefabs.defind:clone()
newmodel1192:PivotTo(CFrame.new(-67.68619585232626, 6.790828488, 27.66002743771273) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1192.Parent = workspace.devices.definds
newmodel1192.RandBr.Value = 0.19771369964770613
newmodel1193 = workspace.prefabs.defind:clone()
newmodel1193:PivotTo(CFrame.new(-67.68619585232626, 6.684457560000001, 27.66002743771273) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1193.Parent = workspace.devices.definds
newmodel1193.RandBr.Value = 0.5432549755006874
newmodel1194 = workspace.prefabs.defind:clone()
newmodel1194:PivotTo(CFrame.new(-67.68619585232626, 6.578086340000001, 27.66002743771273) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1194.Parent = workspace.devices.definds
newmodel1194.RandBr.Value = 0.12095411831983728
newmodel1195 = workspace.prefabs.defind:clone()
newmodel1195:PivotTo(CFrame.new(-67.68619585232626, 6.471714536000001, 27.66002743771273) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1195.Parent = workspace.devices.definds
newmodel1195.RandBr.Value = 0.590127558811793
newmodel1196 = workspace.prefabs.defind:clone()
newmodel1196:PivotTo(CFrame.new(-67.68619585232626, 6.365342148000001, 27.66002743771273) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1196.Parent = workspace.devices.definds
newmodel1196.RandBr.Value = 0.5514030107598357
newmodel1197 = workspace.prefabs.defind:clone()
newmodel1197:PivotTo(CFrame.new(-67.68619585232626, 6.258970928, 27.66002743771273) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1197.Parent = workspace.devices.definds
newmodel1197.RandBr.Value = 0.024412324418592046
newmodel1198 = workspace.prefabs.defind:clone()
newmodel1198:PivotTo(CFrame.new(-67.68619585232626, 6.152600000000001, 27.66002743771273) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1198.Parent = workspace.devices.definds
newmodel1198.RandBr.Value = 0.19032324515921617
newmodel1199 = workspace.prefabs.defind:clone()
newmodel1199:PivotTo(CFrame.new(-67.81641880243123, 6.897200292000001, 27.498696466379403) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1199.Parent = workspace.devices.definds
newmodel1199.RandBr.Value = 0.4545847798768025
newmodel1200 = workspace.prefabs.defind:clone()
newmodel1200:PivotTo(CFrame.new(-67.81641880243123, 6.790828488, 27.498696466379403) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1200.Parent = workspace.devices.definds
newmodel1200.RandBr.Value = 0.003118716830536172
newmodel1201 = workspace.prefabs.defind:clone()
newmodel1201:PivotTo(CFrame.new(-67.81641880243123, 6.684457560000001, 27.498696466379403) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1201.Parent = workspace.devices.definds
newmodel1201.RandBr.Value = 0.34784702582418103
newmodel1202 = workspace.prefabs.defind:clone()
newmodel1202:PivotTo(CFrame.new(-67.81641880243123, 6.578086340000001, 27.498696466379403) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1202.Parent = workspace.devices.definds
newmodel1202.RandBr.Value = 0.29635729911039055
newmodel1203 = workspace.prefabs.defind:clone()
newmodel1203:PivotTo(CFrame.new(-67.81641880243123, 6.471714536000001, 27.498696466379403) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1203.Parent = workspace.devices.definds
newmodel1203.RandBr.Value = 0.1665233553061586
newmodel1204 = workspace.prefabs.defind:clone()
newmodel1204:PivotTo(CFrame.new(-67.81641880243123, 6.365342148000001, 27.498696466379403) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1204.Parent = workspace.devices.definds
newmodel1204.RandBr.Value = 0.4240563157734425
newmodel1205 = workspace.prefabs.defind:clone()
newmodel1205:PivotTo(CFrame.new(-67.81641880243123, 6.258970928, 27.498696466379403) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1205.Parent = workspace.devices.definds
newmodel1205.RandBr.Value = 0.5490967228615321
newmodel1206 = workspace.prefabs.defind:clone()
newmodel1206:PivotTo(CFrame.new(-67.81641880243123, 6.152600000000001, 27.498696466379403) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1206.Parent = workspace.devices.definds
newmodel1206.RandBr.Value = 0.3931339091842835
newmodel1207 = workspace.prefabs.defind:clone()
newmodel1207:PivotTo(CFrame.new(-67.94664277378119, 6.897200292000001, 27.337371572978192) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1207.Parent = workspace.devices.definds
newmodel1207.RandBr.Value = 0.2832206735481776
newmodel1208 = workspace.prefabs.defind:clone()
newmodel1208:PivotTo(CFrame.new(-67.94664277378119, 6.790828488, 27.337371572978192) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1208.Parent = workspace.devices.definds
newmodel1208.RandBr.Value = 0.43111501520415146
newmodel1209 = workspace.prefabs.defind:clone()
newmodel1209:PivotTo(CFrame.new(-67.94664277378119, 6.684457560000001, 27.337371572978192) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1209.Parent = workspace.devices.definds
newmodel1209.RandBr.Value = 0.2665850309420546
newmodel1210 = workspace.prefabs.defind:clone()
newmodel1210:PivotTo(CFrame.new(-67.94664277378119, 6.578086340000001, 27.337371572978192) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1210.Parent = workspace.devices.definds
newmodel1210.RandBr.Value = 0.28249486346243685
newmodel1211 = workspace.prefabs.defind:clone()
newmodel1211:PivotTo(CFrame.new(-67.94664277378119, 6.471714536000001, 27.337371572978192) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1211.Parent = workspace.devices.definds
newmodel1211.RandBr.Value = 0.049796861186485006
newmodel1212 = workspace.prefabs.defind:clone()
newmodel1212:PivotTo(CFrame.new(-67.94664277378119, 6.365342148000001, 27.337371572978192) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1212.Parent = workspace.devices.definds
newmodel1212.RandBr.Value = 0.22146042854705122
newmodel1213 = workspace.prefabs.defind:clone()
newmodel1213:PivotTo(CFrame.new(-67.94664277378119, 6.258970928, 27.337371572978192) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1213.Parent = workspace.devices.definds
newmodel1213.RandBr.Value = 0.4265847543347449
newmodel1214 = workspace.prefabs.defind:clone()
newmodel1214:PivotTo(CFrame.new(-67.94664277378119, 6.152600000000001, 27.337371572978192) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1214.Parent = workspace.devices.definds
newmodel1214.RandBr.Value = 0.24309023925639017
newmodel1215 = workspace.prefabs.defind:clone()
newmodel1215:PivotTo(CFrame.new(-68.0768523608063, 6.897200292000001, 27.176053831590682) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1215.Parent = workspace.devices.definds
newmodel1215.RandBr.Value = 0.16613074408716957
newmodel1216 = workspace.prefabs.defind:clone()
newmodel1216:PivotTo(CFrame.new(-68.0768523608063, 6.790828488, 27.176053831590682) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1216.Parent = workspace.devices.definds
newmodel1216.RandBr.Value = 0.22587455754063612
newmodel1217 = workspace.prefabs.defind:clone()
newmodel1217:PivotTo(CFrame.new(-68.0768523608063, 6.684457560000001, 27.176053831590682) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1217.Parent = workspace.devices.definds
newmodel1217.RandBr.Value = 0.38910531314964675
newmodel1218 = workspace.prefabs.defind:clone()
newmodel1218:PivotTo(CFrame.new(-68.0768523608063, 6.578086340000001, 27.176053831590682) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1218.Parent = workspace.devices.definds
newmodel1218.RandBr.Value = 0.06061778258497092
newmodel1219 = workspace.prefabs.defind:clone()
newmodel1219:PivotTo(CFrame.new(-68.0768523608063, 6.471714536000001, 27.176053831590682) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1219.Parent = workspace.devices.definds
newmodel1219.RandBr.Value = 0.4866086037558587
newmodel1220 = workspace.prefabs.defind:clone()
newmodel1220:PivotTo(CFrame.new(-68.0768523608063, 6.365342148000001, 27.176053831590682) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1220.Parent = workspace.devices.definds
newmodel1220.RandBr.Value = 0.5199812157637796
newmodel1221 = workspace.prefabs.defind:clone()
newmodel1221:PivotTo(CFrame.new(-68.0768523608063, 6.258970928, 27.176053831590682) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1221.Parent = workspace.devices.definds
newmodel1221.RandBr.Value = 0.027321320853641518
newmodel1222 = workspace.prefabs.defind:clone()
newmodel1222:PivotTo(CFrame.new(-68.0768523608063, 6.152600000000001, 27.176053831590682) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1222.Parent = workspace.devices.definds
newmodel1222.RandBr.Value = 0.5078154455970431
newmodel1223 = workspace.prefabs.defind:clone()
newmodel1223:PivotTo(CFrame.new(-68.33728856857144, 6.897200292000001, 26.853412209583077) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1223.Parent = workspace.devices.definds
newmodel1223.RandBr.Value = 0.0158363509979069
newmodel1224 = workspace.prefabs.defind:clone()
newmodel1224:PivotTo(CFrame.new(-68.33728856857144, 6.790828488, 26.853412209583077) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1224.Parent = workspace.devices.definds
newmodel1224.RandBr.Value = 0.5215690223227097
newmodel1225 = workspace.prefabs.defind:clone()
newmodel1225:PivotTo(CFrame.new(-68.33728856857144, 6.684457560000001, 26.853412209583077) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1225.Parent = workspace.devices.definds
newmodel1225.RandBr.Value = 0.4108283726607372
newmodel1226 = workspace.prefabs.defind:clone()
newmodel1226:PivotTo(CFrame.new(-68.33728856857144, 6.578086340000001, 26.853412209583077) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1226.Parent = workspace.devices.definds
newmodel1226.RandBr.Value = 0.48566331518196926
newmodel1227 = workspace.prefabs.defind:clone()
newmodel1227:PivotTo(CFrame.new(-68.33728856857144, 6.471714536000001, 26.853412209583077) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1227.Parent = workspace.devices.definds
newmodel1227.RandBr.Value = 0.5853659226278071
newmodel1228 = workspace.prefabs.defind:clone()
newmodel1228:PivotTo(CFrame.new(-68.33728856857144, 6.365342148000001, 26.853412209583077) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1228.Parent = workspace.devices.definds
newmodel1228.RandBr.Value = 0.0583888655053596
newmodel1229 = workspace.prefabs.defind:clone()
newmodel1229:PivotTo(CFrame.new(-68.33728856857144, 6.258970928, 26.853412209583077) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1229.Parent = workspace.devices.definds
newmodel1229.RandBr.Value = 0.32349815124061726
newmodel1230 = workspace.prefabs.defind:clone()
newmodel1230:PivotTo(CFrame.new(-68.33728856857144, 6.152600000000001, 26.853412209583077) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1230.Parent = workspace.devices.definds
newmodel1230.RandBr.Value = 0.021804185384099693
newmodel1231 = workspace.prefabs.defind:clone()
newmodel1231:PivotTo(CFrame.new(-68.46750814669583, 6.897200292000001, 26.692091650425024) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1231.Parent = workspace.devices.definds
newmodel1231.RandBr.Value = 0.25024471110397056
newmodel1232 = workspace.prefabs.defind:clone()
newmodel1232:PivotTo(CFrame.new(-68.46750814669583, 6.790828488, 26.692091650425024) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1232.Parent = workspace.devices.definds
newmodel1232.RandBr.Value = 0.44779802542696556
newmodel1233 = workspace.prefabs.defind:clone()
newmodel1233:PivotTo(CFrame.new(-68.46750814669583, 6.684457560000001, 26.692091650425024) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1233.Parent = workspace.devices.definds
newmodel1233.RandBr.Value = 0.4999237962518037
newmodel1234 = workspace.prefabs.defind:clone()
newmodel1234:PivotTo(CFrame.new(-68.46750814669583, 6.578086340000001, 26.692091650425024) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1234.Parent = workspace.devices.definds
newmodel1234.RandBr.Value = 0.27424504468673255
newmodel1235 = workspace.prefabs.defind:clone()
newmodel1235:PivotTo(CFrame.new(-68.46750814669583, 6.471714536000001, 26.692091650425024) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1235.Parent = workspace.devices.definds
newmodel1235.RandBr.Value = 0.18837477220482707
newmodel1236 = workspace.prefabs.defind:clone()
newmodel1236:PivotTo(CFrame.new(-68.46750814669583, 6.365342148000001, 26.692091650425024) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1236.Parent = workspace.devices.definds
newmodel1236.RandBr.Value = 0.37465859627133113
newmodel1237 = workspace.prefabs.defind:clone()
newmodel1237:PivotTo(CFrame.new(-68.46750814669583, 6.258970928, 26.692091650425024) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1237.Parent = workspace.devices.definds
newmodel1237.RandBr.Value = 0.5135648994184664
newmodel1238 = workspace.prefabs.defind:clone()
newmodel1238:PivotTo(CFrame.new(-68.46750814669583, 6.152600000000001, 26.692091650425024) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1238.Parent = workspace.devices.definds
newmodel1238.RandBr.Value = 0.13502811590594402
newmodel1239 = workspace.prefabs.defind:clone()
newmodel1239:PivotTo(CFrame.new(-68.5977167124763, 6.897200292000001, 26.530767831105663) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1239.Parent = workspace.devices.definds
newmodel1239.RandBr.Value = 0.5816617785941138
newmodel1240 = workspace.prefabs.defind:clone()
newmodel1240:PivotTo(CFrame.new(-68.5977167124763, 6.790828488, 26.530767831105663) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1240.Parent = workspace.devices.definds
newmodel1240.RandBr.Value = 0.08775054093854995
newmodel1241 = workspace.prefabs.defind:clone()
newmodel1241:PivotTo(CFrame.new(-68.5977167124763, 6.684457560000001, 26.530767831105663) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1241.Parent = workspace.devices.definds
newmodel1241.RandBr.Value = 0.2550463393152369
newmodel1242 = workspace.prefabs.defind:clone()
newmodel1242:PivotTo(CFrame.new(-68.5977167124763, 6.578086340000001, 26.530767831105663) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1242.Parent = workspace.devices.definds
newmodel1242.RandBr.Value = 0.36397667180804477
newmodel1243 = workspace.prefabs.defind:clone()
newmodel1243:PivotTo(CFrame.new(-68.5977167124763, 6.471714536000001, 26.530767831105663) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1243.Parent = workspace.devices.definds
newmodel1243.RandBr.Value = 0.07461298354216736
newmodel1244 = workspace.prefabs.defind:clone()
newmodel1244:PivotTo(CFrame.new(-68.5977167124763, 6.365342148000001, 26.530767831105663) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1244.Parent = workspace.devices.definds
newmodel1244.RandBr.Value = 0.0712797047831721
newmodel1245 = workspace.prefabs.defind:clone()
newmodel1245:PivotTo(CFrame.new(-68.5977167124763, 6.258970928, 26.530767831105663) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1245.Parent = workspace.devices.definds
newmodel1245.RandBr.Value = 0.22664488517424533
newmodel1246 = workspace.prefabs.defind:clone()
newmodel1246:PivotTo(CFrame.new(-68.5977167124763, 6.152600000000001, 26.530767831105663) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1246.Parent = workspace.devices.definds
newmodel1246.RandBr.Value = 0.32347269597901646
newmodel1247 = workspace.prefabs.defind:clone()
newmodel1247:PivotTo(CFrame.new(-68.72793823758205, 6.897200292000001, 26.369442088899977) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1247.Parent = workspace.devices.definds
newmodel1247.RandBr.Value = 0.4909979345011964
newmodel1248 = workspace.prefabs.defind:clone()
newmodel1248:PivotTo(CFrame.new(-68.72793823758205, 6.790828488, 26.369442088899977) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1248.Parent = workspace.devices.definds
newmodel1248.RandBr.Value = 0.5240566650106133
newmodel1249 = workspace.prefabs.defind:clone()
newmodel1249:PivotTo(CFrame.new(-68.72793823758205, 6.684457560000001, 26.369442088899977) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1249.Parent = workspace.devices.definds
newmodel1249.RandBr.Value = 0.15682726375988043
newmodel1250 = workspace.prefabs.defind:clone()
newmodel1250:PivotTo(CFrame.new(-68.72793823758205, 6.578086340000001, 26.369442088899977) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1250.Parent = workspace.devices.definds
newmodel1250.RandBr.Value = 0.4275423600962058
newmodel1251 = workspace.prefabs.defind:clone()
newmodel1251:PivotTo(CFrame.new(-68.72793823758205, 6.471714536000001, 26.369442088899977) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1251.Parent = workspace.devices.definds
newmodel1251.RandBr.Value = 0.3196698340076407
newmodel1252 = workspace.prefabs.defind:clone()
newmodel1252:PivotTo(CFrame.new(-68.72793823758205, 6.365342148000001, 26.369442088899977) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1252.Parent = workspace.devices.definds
newmodel1252.RandBr.Value = 0.5618160979396477
newmodel1253 = workspace.prefabs.defind:clone()
newmodel1253:PivotTo(CFrame.new(-68.72793823758205, 6.258970928, 26.369442088899977) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1253.Parent = workspace.devices.definds
newmodel1253.RandBr.Value = 0.007977114082928737
newmodel1254 = workspace.prefabs.defind:clone()
newmodel1254:PivotTo(CFrame.new(-68.72793823758205, 6.152600000000001, 26.369442088899977) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1254.Parent = workspace.devices.definds
newmodel1254.RandBr.Value = 0.22232921612173107
newmodel1255 = workspace.prefabs.defind:clone()
newmodel1255:PivotTo(CFrame.new(-68.85816111997185, 6.897200292000001, 26.208111062907875) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1255.Parent = workspace.devices.definds
newmodel1255.RandBr.Value = 0.5600470672165432
newmodel1256 = workspace.prefabs.defind:clone()
newmodel1256:PivotTo(CFrame.new(-68.85816111997185, 6.790828488, 26.208111062907875) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1256.Parent = workspace.devices.definds
newmodel1256.RandBr.Value = 0.35226395920944364
newmodel1257 = workspace.prefabs.defind:clone()
newmodel1257:PivotTo(CFrame.new(-68.85816111997185, 6.684457560000001, 26.208111062907875) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1257.Parent = workspace.devices.definds
newmodel1257.RandBr.Value = 0.19730005357603173
newmodel1258 = workspace.prefabs.defind:clone()
newmodel1258:PivotTo(CFrame.new(-68.85816111997185, 6.578086340000001, 26.208111062907875) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1258.Parent = workspace.devices.definds
newmodel1258.RandBr.Value = 0.35738047705373904
newmodel1259 = workspace.prefabs.defind:clone()
newmodel1259:PivotTo(CFrame.new(-68.85816111997185, 6.471714536000001, 26.208111062907875) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1259.Parent = workspace.devices.definds
newmodel1259.RandBr.Value = 0.18068993331612365
newmodel1260 = workspace.prefabs.defind:clone()
newmodel1260:PivotTo(CFrame.new(-68.85816111997185, 6.365342148000001, 26.208111062907875) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1260.Parent = workspace.devices.definds
newmodel1260.RandBr.Value = 0.1351516233581584
newmodel1261 = workspace.prefabs.defind:clone()
newmodel1261:PivotTo(CFrame.new(-68.85816111997185, 6.258970928, 26.208111062907875) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1261.Parent = workspace.devices.definds
newmodel1261.RandBr.Value = 0.3596933340110505
newmodel1262 = workspace.prefabs.defind:clone()
newmodel1262:PivotTo(CFrame.new(-68.85816111997185, 6.152600000000001, 26.208111062907875) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1262.Parent = workspace.devices.definds
newmodel1262.RandBr.Value = 0.03892981467972545
newmodel1263 = workspace.prefabs.defind:clone()
newmodel1263:PivotTo(CFrame.new(-68.98838160365244, 6.897200292000001, 26.046796863556455) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1263.Parent = workspace.devices.definds
newmodel1263.RandBr.Value = 0.13507112987058792
newmodel1264 = workspace.prefabs.defind:clone()
newmodel1264:PivotTo(CFrame.new(-68.98838160365244, 6.790828488, 26.046796863556455) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1264.Parent = workspace.devices.definds
newmodel1264.RandBr.Value = 0.4548995997403621
newmodel1265 = workspace.prefabs.defind:clone()
newmodel1265:PivotTo(CFrame.new(-68.98838160365244, 6.684457560000001, 26.046796863556455) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1265.Parent = workspace.devices.definds
newmodel1265.RandBr.Value = 0.14364265960380743
newmodel1266 = workspace.prefabs.defind:clone()
newmodel1266:PivotTo(CFrame.new(-68.98838160365244, 6.578086340000001, 26.046796863556455) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1266.Parent = workspace.devices.definds
newmodel1266.RandBr.Value = 0.3309897744747843
newmodel1267 = workspace.prefabs.defind:clone()
newmodel1267:PivotTo(CFrame.new(-68.98838160365244, 6.471714536000001, 26.046796863556455) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1267.Parent = workspace.devices.definds
newmodel1267.RandBr.Value = 0.13349073849967177
newmodel1268 = workspace.prefabs.defind:clone()
newmodel1268:PivotTo(CFrame.new(-68.98838160365244, 6.365342148000001, 26.046796863556455) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1268.Parent = workspace.devices.definds
newmodel1268.RandBr.Value = 0.5019814098083105
newmodel1269 = workspace.prefabs.defind:clone()
newmodel1269:PivotTo(CFrame.new(-68.98838160365244, 6.258970928, 26.046796863556455) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1269.Parent = workspace.devices.definds
newmodel1269.RandBr.Value = 0.009268763030320492
newmodel1270 = workspace.prefabs.defind:clone()
newmodel1270:PivotTo(CFrame.new(-68.98838160365244, 6.152600000000001, 26.046796863556455) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0))
newmodel1270.Parent = workspace.devices.definds
newmodel1270.RandBr.Value = 0.42193972002699964
newmodel1271 = workspace.prefabs.defind:clone()
newmodel1271:PivotTo(CFrame.new(-69.70322113927627, 6.897200292000001, 25.04994545347434) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1271.Parent = workspace.devices.definds
newmodel1271.RandBr.Value = 0.2746245802935711
newmodel1272 = workspace.prefabs.defind:clone()
newmodel1272:PivotTo(CFrame.new(-69.70322113927627, 6.78624, 25.04994545347434) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1272.Parent = workspace.devices.definds
newmodel1272.RandBr.Value = 0.4073157285734734
newmodel1273 = workspace.prefabs.defind:clone()
newmodel1273:PivotTo(CFrame.new(-69.82044568999258, 6.897200292000001, 24.873906656250544) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1273.Parent = workspace.devices.definds
newmodel1273.RandBr.Value = 0.14826130015229208
newmodel1274 = workspace.prefabs.defind:clone()
newmodel1274:PivotTo(CFrame.new(-69.82044568999258, 6.78624, 24.873906656250544) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1274.Parent = workspace.devices.definds
newmodel1274.RandBr.Value = 0.51287315393512
newmodel1275 = workspace.prefabs.defind:clone()
newmodel1275:PivotTo(CFrame.new(-69.93766602930314, 6.897200292000001, 24.697878736501984) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1275.Parent = workspace.devices.definds
newmodel1275.RandBr.Value = 0.2853483553382397
newmodel1276 = workspace.prefabs.defind:clone()
newmodel1276:PivotTo(CFrame.new(-69.93766602930314, 6.78624, 24.697878736501984) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1276.Parent = workspace.devices.definds
newmodel1276.RandBr.Value = 0.34389018740522564
newmodel1277 = workspace.prefabs.defind:clone()
newmodel1277:PivotTo(CFrame.new(-70.05489468503207, 6.897200292000001, 24.521829692590092) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1277.Parent = workspace.devices.definds
newmodel1277.RandBr.Value = 0.41298249300708617
newmodel1278 = workspace.prefabs.defind:clone()
newmodel1278:PivotTo(CFrame.new(-70.05489468503207, 6.78624, 24.521829692590092) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1278.Parent = workspace.devices.definds
newmodel1278.RandBr.Value = 0.06668622693509181
newmodel1279 = workspace.prefabs.defind:clone()
newmodel1279:PivotTo(CFrame.new(-70.17211054018716, 6.897200292000001, 24.345812117872676) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1279.Parent = workspace.devices.definds
newmodel1279.RandBr.Value = 0.48273671429800197
newmodel1280 = workspace.prefabs.defind:clone()
newmodel1280:PivotTo(CFrame.new(-70.17211054018716, 6.78624, 24.345812117872676) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1280.Parent = workspace.devices.definds
newmodel1280.RandBr.Value = 0.27794593676573975
newmodel1281 = workspace.prefabs.defind:clone()
newmodel1281:PivotTo(CFrame.new(-70.28933861753266, 6.897200292000001, 24.16976865270993) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1281.Parent = workspace.devices.definds
newmodel1281.RandBr.Value = 0.43326073055051717
newmodel1282 = workspace.prefabs.defind:clone()
newmodel1282:PivotTo(CFrame.new(-70.28933861753266, 6.78624, 24.16976865270993) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1282.Parent = workspace.devices.definds
newmodel1282.RandBr.Value = 0.021219723546248303
newmodel1283 = workspace.prefabs.defind:clone()
newmodel1283:PivotTo(CFrame.new(-70.40655591918618, 6.897200292000001, 23.993740113429016) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1283.Parent = workspace.devices.definds
newmodel1283.RandBr.Value = 0.3307397441840101
newmodel1284 = workspace.prefabs.defind:clone()
newmodel1284:PivotTo(CFrame.new(-70.40655591918618, 6.78624, 23.993740113429016) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1284.Parent = workspace.devices.definds
newmodel1284.RandBr.Value = 0.23581927441447825
newmodel1285 = workspace.prefabs.defind:clone()
newmodel1285:PivotTo(CFrame.new(-70.52377264245519, 6.897200292000001, 23.817717152896545) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1285.Parent = workspace.devices.definds
newmodel1285.RandBr.Value = 0.021062706839612533
newmodel1286 = workspace.prefabs.defind:clone()
newmodel1286:PivotTo(CFrame.new(-70.52377264245519, 6.78624, 23.817717152896545) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1286.Parent = workspace.devices.definds
newmodel1286.RandBr.Value = 0.13394993393153606
newmodel1287 = workspace.prefabs.defind:clone()
newmodel1287:PivotTo(CFrame.new(-69.70322113927627, 6.57308, 25.04994545347434) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1287.Parent = workspace.devices.definds
newmodel1287.RandBr.Value = 0.3785985000459889
newmodel1288 = workspace.prefabs.defind:clone()
newmodel1288:PivotTo(CFrame.new(-69.70322113927627, 6.462119708, 25.04994545347434) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1288.Parent = workspace.devices.definds
newmodel1288.RandBr.Value = 0.2589258113466022
newmodel1289 = workspace.prefabs.defind:clone()
newmodel1289:PivotTo(CFrame.new(-69.70322113927627, 6.351160292000001, 25.04994545347434) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1289.Parent = workspace.devices.definds
newmodel1289.RandBr.Value = 0.15199519901681016
newmodel1290 = workspace.prefabs.defind:clone()
newmodel1290:PivotTo(CFrame.new(-69.82044568999258, 6.57308, 24.873906656250544) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1290.Parent = workspace.devices.definds
newmodel1290.RandBr.Value = 0.1437506268682017
newmodel1291 = workspace.prefabs.defind:clone()
newmodel1291:PivotTo(CFrame.new(-69.82044568999258, 6.462119708, 24.873906656250544) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1291.Parent = workspace.devices.definds
newmodel1291.RandBr.Value = 0.5176189069799443
newmodel1292 = workspace.prefabs.defind:clone()
newmodel1292:PivotTo(CFrame.new(-69.82044568999258, 6.351160292000001, 24.873906656250544) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1292.Parent = workspace.devices.definds
newmodel1292.RandBr.Value = 0.11115490751585204
newmodel1293 = workspace.prefabs.defind:clone()
newmodel1293:PivotTo(CFrame.new(-69.93766602930314, 6.57308, 24.697878736501984) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1293.Parent = workspace.devices.definds
newmodel1293.RandBr.Value = 0.24484136167663711
newmodel1294 = workspace.prefabs.defind:clone()
newmodel1294:PivotTo(CFrame.new(-69.93766602930314, 6.462119708, 24.697878736501984) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1294.Parent = workspace.devices.definds
newmodel1294.RandBr.Value = 0.5664619773177402
newmodel1295 = workspace.prefabs.defind:clone()
newmodel1295:PivotTo(CFrame.new(-69.93766602930314, 6.351160292000001, 24.697878736501984) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1295.Parent = workspace.devices.definds
newmodel1295.RandBr.Value = 0.3534890422090959
newmodel1296 = workspace.prefabs.defind:clone()
newmodel1296:PivotTo(CFrame.new(-70.05489468503207, 6.57308, 24.521829692590092) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1296.Parent = workspace.devices.definds
newmodel1296.RandBr.Value = 0.5208692298006278
newmodel1297 = workspace.prefabs.defind:clone()
newmodel1297:PivotTo(CFrame.new(-70.05489468503207, 6.462119708, 24.521829692590092) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1297.Parent = workspace.devices.definds
newmodel1297.RandBr.Value = 0.13125846265177207
newmodel1298 = workspace.prefabs.defind:clone()
newmodel1298:PivotTo(CFrame.new(-70.05489468503207, 6.351160292000001, 24.521829692590092) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1298.Parent = workspace.devices.definds
newmodel1298.RandBr.Value = 0.41243707241270355
newmodel1299 = workspace.prefabs.defind:clone()
newmodel1299:PivotTo(CFrame.new(-70.17211054018716, 6.57308, 24.345812117872676) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1299.Parent = workspace.devices.definds
newmodel1299.RandBr.Value = 0.2828910586728475
newmodel1300 = workspace.prefabs.defind:clone()
newmodel1300:PivotTo(CFrame.new(-70.17211054018716, 6.462119708, 24.345812117872676) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1300.Parent = workspace.devices.definds
newmodel1300.RandBr.Value = 0.26757272831881185
newmodel1301 = workspace.prefabs.defind:clone()
newmodel1301:PivotTo(CFrame.new(-70.17211054018716, 6.351160292000001, 24.345812117872676) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1301.Parent = workspace.devices.definds
newmodel1301.RandBr.Value = 0.321087164876032
newmodel1302 = workspace.prefabs.defind:clone()
newmodel1302:PivotTo(CFrame.new(-70.28933861753266, 6.57308, 24.16976865270993) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1302.Parent = workspace.devices.definds
newmodel1302.RandBr.Value = 0.36341611394110224
newmodel1303 = workspace.prefabs.defind:clone()
newmodel1303:PivotTo(CFrame.new(-70.28933861753266, 6.462119708, 24.16976865270993) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1303.Parent = workspace.devices.definds
newmodel1303.RandBr.Value = 0.5669130518877913
newmodel1304 = workspace.prefabs.defind:clone()
newmodel1304:PivotTo(CFrame.new(-70.28933861753266, 6.351160292000001, 24.16976865270993) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1304.Parent = workspace.devices.definds
newmodel1304.RandBr.Value = 0.492387675700234
newmodel1305 = workspace.prefabs.defind:clone()
newmodel1305:PivotTo(CFrame.new(-70.40655591918618, 6.57308, 23.993740113429016) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1305.Parent = workspace.devices.definds
newmodel1305.RandBr.Value = 0.05275457217429382
newmodel1306 = workspace.prefabs.defind:clone()
newmodel1306:PivotTo(CFrame.new(-70.40655591918618, 6.462119708, 23.993740113429016) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1306.Parent = workspace.devices.definds
newmodel1306.RandBr.Value = 0.03341116551346106
newmodel1307 = workspace.prefabs.defind:clone()
newmodel1307:PivotTo(CFrame.new(-70.40655591918618, 6.351160292000001, 23.993740113429016) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1307.Parent = workspace.devices.definds
newmodel1307.RandBr.Value = 0.04489278453197645
newmodel1308 = workspace.prefabs.defind:clone()
newmodel1308:PivotTo(CFrame.new(-70.52377264245519, 6.57308, 23.817717152896545) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1308.Parent = workspace.devices.definds
newmodel1308.RandBr.Value = 0.4885859951085524
newmodel1309 = workspace.prefabs.defind:clone()
newmodel1309:PivotTo(CFrame.new(-70.52377264245519, 6.462119708, 23.817717152896545) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1309.Parent = workspace.devices.definds
newmodel1309.RandBr.Value = 0.2816368553144347
newmodel1310 = workspace.prefabs.defind:clone()
newmodel1310:PivotTo(CFrame.new(-70.52377264245519, 6.351160292000001, 23.817717152896545) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1310.Parent = workspace.devices.definds
newmodel1310.RandBr.Value = 0.30724099088497525
newmodel1311 = workspace.prefabs.defind:clone()
newmodel1311:PivotTo(CFrame.new(-69.70403363373512, 6.120480292000001, 25.048718730702227) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1311.Parent = workspace.devices.definds
newmodel1311.RandBr.Value = 0.016828052517380777
newmodel1312 = workspace.prefabs.defind:clone()
newmodel1312:PivotTo(CFrame.new(-69.70403558598059, 6.00952, 25.048724591349195) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1312.Parent = workspace.devices.definds
newmodel1312.RandBr.Value = 0.3325429408558917
newmodel1313 = workspace.prefabs.defind:clone()
newmodel1313:PivotTo(CFrame.new(-69.8212565036757, 6.120480292000001, 24.872691092852218) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1313.Parent = workspace.devices.definds
newmodel1313.RandBr.Value = 0.2582419784624661
newmodel1314 = workspace.prefabs.defind:clone()
newmodel1314:PivotTo(CFrame.new(-69.8212565036757, 6.00952, 24.872691092852218) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1314.Parent = workspace.devices.definds
newmodel1314.RandBr.Value = 0.3945369554913942
newmodel1315 = workspace.prefabs.defind:clone()
newmodel1315:PivotTo(CFrame.new(-69.93847378834933, 6.120480292000001, 24.69666289308188) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1315.Parent = workspace.devices.definds
newmodel1315.RandBr.Value = 0.3308784075728504
newmodel1316 = workspace.prefabs.defind:clone()
newmodel1316:PivotTo(CFrame.new(-69.93847378834933, 6.00952, 24.69666289308188) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1316.Parent = workspace.devices.definds
newmodel1316.RandBr.Value = 0.5170262963312864
newmodel1317 = workspace.prefabs.defind:clone()
newmodel1317:PivotTo(CFrame.new(-70.05570202754, 6.120480292000001, 24.520619184875656) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1317.Parent = workspace.devices.definds
newmodel1317.RandBr.Value = 0.15238450386639962
newmodel1318 = workspace.prefabs.defind:clone()
newmodel1318:PivotTo(CFrame.new(-70.05570202754, 6.00952, 24.520619184875656) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1318.Parent = workspace.devices.definds
newmodel1318.RandBr.Value = 0.4744425259527428
newmodel1319 = workspace.prefabs.defind:clone()
newmodel1319:PivotTo(CFrame.new(-70.17291875080902, 6.120480292000001, 24.344596224343185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1319.Parent = workspace.devices.definds
newmodel1319.RandBr.Value = 0.30988702518491157
newmodel1320 = workspace.prefabs.defind:clone()
newmodel1320:PivotTo(CFrame.new(-70.17291875080902, 6.00952, 24.344596224343185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1320.Parent = workspace.devices.definds
newmodel1320.RandBr.Value = 0.3232233174114421
newmodel1321 = workspace.prefabs.defind:clone()
newmodel1321:PivotTo(CFrame.new(-70.29014458617988, 6.120480292000001, 24.168546705600242) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1321.Parent = workspace.devices.definds
newmodel1321.RandBr.Value = 0.4235111105460989
newmodel1322 = workspace.prefabs.defind:clone()
newmodel1322:PivotTo(CFrame.new(-70.29014458617988, 6.00952, 24.168546705600242) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1322.Parent = workspace.devices.definds
newmodel1322.RandBr.Value = 0.47223297332702185
newmodel1323 = workspace.prefabs.defind:clone()
newmodel1323:PivotTo(CFrame.new(-70.40736382309667, 6.120480292000001, 23.992524366475358) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1323.Parent = workspace.devices.definds
newmodel1323.RandBr.Value = 0.41124791254986054
newmodel1324 = workspace.prefabs.defind:clone()
newmodel1324:PivotTo(CFrame.new(-70.40736382309667, 6.00952, 23.992524366475358) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1324.Parent = workspace.devices.definds
newmodel1324.RandBr.Value = 0.17895943489874314
newmodel1325 = workspace.prefabs.defind:clone()
newmodel1325:PivotTo(CFrame.new(-70.52458765056434, 6.120480292000001, 23.81649105153368) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1325.Parent = workspace.devices.definds
newmodel1325.RandBr.Value = 0.15441871436320168
newmodel1326 = workspace.prefabs.defind:clone()
newmodel1326:PivotTo(CFrame.new(-70.52458765056434, 6.00952, 23.81649105153368) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1326.Parent = workspace.devices.definds
newmodel1326.RandBr.Value = 0.21295778180717184
newmodel1327 = workspace.prefabs.defind:clone()
newmodel1327:PivotTo(CFrame.new(-69.70403363373512, 5.787599416000001, 25.048718730702227) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1327.Parent = workspace.devices.definds
newmodel1327.RandBr.Value = 0.06841676471682963
newmodel1328 = workspace.prefabs.defind:clone()
newmodel1328:PivotTo(CFrame.new(-69.70403558598059, 5.6766397080000015, 25.048724591349195) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1328.Parent = workspace.devices.definds
newmodel1328.RandBr.Value = 0.2869033575537408
newmodel1329 = workspace.prefabs.defind:clone()
newmodel1329:PivotTo(CFrame.new(-69.70403558598059, 5.565679708, 25.048724591349195) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1329.Parent = workspace.devices.definds
newmodel1329.RandBr.Value = 0.40261971657643597
newmodel1330 = workspace.prefabs.defind:clone()
newmodel1330:PivotTo(CFrame.new(-69.70403558598059, 5.454719124, 25.048724591349195) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1330.Parent = workspace.devices.definds
newmodel1330.RandBr.Value = 0.15775354106414158
newmodel1331 = workspace.prefabs.defind:clone()
newmodel1331:PivotTo(CFrame.new(-69.8212565036757, 5.787599416000001, 24.872691092852218) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1331.Parent = workspace.devices.definds
newmodel1331.RandBr.Value = 0.08731604113996871
newmodel1332 = workspace.prefabs.defind:clone()
newmodel1332:PivotTo(CFrame.new(-69.8212565036757, 5.6766397080000015, 24.872691092852218) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1332.Parent = workspace.devices.definds
newmodel1332.RandBr.Value = 0.38425925601617295
newmodel1333 = workspace.prefabs.defind:clone()
newmodel1333:PivotTo(CFrame.new(-69.8212565036757, 5.565679708, 24.872691092852218) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1333.Parent = workspace.devices.definds
newmodel1333.RandBr.Value = 0.4748613467114039
newmodel1334 = workspace.prefabs.defind:clone()
newmodel1334:PivotTo(CFrame.new(-69.8212565036757, 5.454719124, 24.872691092852218) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1334.Parent = workspace.devices.definds
newmodel1334.RandBr.Value = 0.581318483242954
newmodel1335 = workspace.prefabs.defind:clone()
newmodel1335:PivotTo(CFrame.new(-69.93847378834933, 5.787599416000001, 24.69666289308188) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1335.Parent = workspace.devices.definds
newmodel1335.RandBr.Value = 0.1917518113995702
newmodel1336 = workspace.prefabs.defind:clone()
newmodel1336:PivotTo(CFrame.new(-69.93847378834933, 5.6766397080000015, 24.69666289308188) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1336.Parent = workspace.devices.definds
newmodel1336.RandBr.Value = 0.4349203643503894
newmodel1337 = workspace.prefabs.defind:clone()
newmodel1337:PivotTo(CFrame.new(-69.93847378834933, 5.565679708, 24.69666289308188) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1337.Parent = workspace.devices.definds
newmodel1337.RandBr.Value = 0.055318723483201035
newmodel1338 = workspace.prefabs.defind:clone()
newmodel1338:PivotTo(CFrame.new(-69.93847378834933, 5.454719124, 24.69666289308188) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1338.Parent = workspace.devices.definds
newmodel1338.RandBr.Value = 0.25271888794151925
newmodel1339 = workspace.prefabs.defind:clone()
newmodel1339:PivotTo(CFrame.new(-70.05570202754, 5.787599416000001, 24.520619184875656) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1339.Parent = workspace.devices.definds
newmodel1339.RandBr.Value = 0.47898415744116946
newmodel1340 = workspace.prefabs.defind:clone()
newmodel1340:PivotTo(CFrame.new(-70.05570202754, 5.6766397080000015, 24.520619184875656) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1340.Parent = workspace.devices.definds
newmodel1340.RandBr.Value = 0.1809040694262876
newmodel1341 = workspace.prefabs.defind:clone()
newmodel1341:PivotTo(CFrame.new(-70.05570202754, 5.565679708, 24.520619184875656) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1341.Parent = workspace.devices.definds
newmodel1341.RandBr.Value = 0.2668143667407104
newmodel1342 = workspace.prefabs.defind:clone()
newmodel1342:PivotTo(CFrame.new(-70.05570202754, 5.454719124, 24.520619184875656) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1342.Parent = workspace.devices.definds
newmodel1342.RandBr.Value = 0.5837740904122843
newmodel1343 = workspace.prefabs.defind:clone()
newmodel1343:PivotTo(CFrame.new(-70.17291875080902, 5.787599416000001, 24.344596224343185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1343.Parent = workspace.devices.definds
newmodel1343.RandBr.Value = 0.48636293551213894
newmodel1344 = workspace.prefabs.defind:clone()
newmodel1344:PivotTo(CFrame.new(-70.17291875080902, 5.6766397080000015, 24.344596224343185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1344.Parent = workspace.devices.definds
newmodel1344.RandBr.Value = 0.4098544972546845
newmodel1345 = workspace.prefabs.defind:clone()
newmodel1345:PivotTo(CFrame.new(-70.17291875080902, 5.565679708, 24.344596224343185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1345.Parent = workspace.devices.definds
newmodel1345.RandBr.Value = 0.5999230506664094
newmodel1346 = workspace.prefabs.defind:clone()
newmodel1346:PivotTo(CFrame.new(-70.17291875080902, 5.454719124, 24.344596224343185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1346.Parent = workspace.devices.definds
newmodel1346.RandBr.Value = 0.5655975250179428
newmodel1347 = workspace.prefabs.defind:clone()
newmodel1347:PivotTo(CFrame.new(-70.29014458617988, 5.787599416000001, 24.168546705600242) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1347.Parent = workspace.devices.definds
newmodel1347.RandBr.Value = 0.4127639396596501
newmodel1348 = workspace.prefabs.defind:clone()
newmodel1348:PivotTo(CFrame.new(-70.29014458617988, 5.6766397080000015, 24.168546705600242) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1348.Parent = workspace.devices.definds
newmodel1348.RandBr.Value = 0.5228476690101578
newmodel1349 = workspace.prefabs.defind:clone()
newmodel1349:PivotTo(CFrame.new(-70.29014458617988, 5.565679708, 24.168546705600242) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1349.Parent = workspace.devices.definds
newmodel1349.RandBr.Value = 0.15370601779336374
newmodel1350 = workspace.prefabs.defind:clone()
newmodel1350:PivotTo(CFrame.new(-70.29014458617988, 5.454719124, 24.168546705600242) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1350.Parent = workspace.devices.definds
newmodel1350.RandBr.Value = 0.5523838193039262
newmodel1351 = workspace.prefabs.defind:clone()
newmodel1351:PivotTo(CFrame.new(-70.40736382309667, 5.787599416000001, 23.992524366475358) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1351.Parent = workspace.devices.definds
newmodel1351.RandBr.Value = 0.3478232150485999
newmodel1352 = workspace.prefabs.defind:clone()
newmodel1352:PivotTo(CFrame.new(-70.40736382309667, 5.6766397080000015, 23.992524366475358) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1352.Parent = workspace.devices.definds
newmodel1352.RandBr.Value = 0.0773685296235885
newmodel1353 = workspace.prefabs.defind:clone()
newmodel1353:PivotTo(CFrame.new(-70.40736382309667, 5.565679708, 23.992524366475358) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1353.Parent = workspace.devices.definds
newmodel1353.RandBr.Value = 0.21668121930456044
newmodel1354 = workspace.prefabs.defind:clone()
newmodel1354:PivotTo(CFrame.new(-70.40736382309667, 5.454719124, 23.992524366475358) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1354.Parent = workspace.devices.definds
newmodel1354.RandBr.Value = 0.5692137959086724
newmodel1355 = workspace.prefabs.defind:clone()
newmodel1355:PivotTo(CFrame.new(-70.52458765056434, 5.787599416000001, 23.81649105153368) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1355.Parent = workspace.devices.definds
newmodel1355.RandBr.Value = 0.19072302723343904
newmodel1356 = workspace.prefabs.defind:clone()
newmodel1356:PivotTo(CFrame.new(-70.52458765056434, 5.6766397080000015, 23.81649105153368) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1356.Parent = workspace.devices.definds
newmodel1356.RandBr.Value = 0.1997003203709333
newmodel1357 = workspace.prefabs.defind:clone()
newmodel1357:PivotTo(CFrame.new(-70.52458765056434, 5.565679708, 23.81649105153368) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1357.Parent = workspace.devices.definds
newmodel1357.RandBr.Value = 0.2646013657837524
newmodel1358 = workspace.prefabs.defind:clone()
newmodel1358:PivotTo(CFrame.new(-70.52458765056434, 5.454719124, 23.81649105153368) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel1358.Parent = workspace.devices.definds
newmodel1358.RandBr.Value = 0.2647137135039797
newmodel1359 = workspace.prefabs.defind:clone()
newmodel1359:PivotTo(CFrame.new(-71.42358637004747, 6.897200000000001, 22.340410499651043) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1359.Parent = workspace.devices.definds
newmodel1359.RandBr.Value = 0.47172337168222445
newmodel1360 = workspace.prefabs.defind:clone()
newmodel1360:PivotTo(CFrame.new(-71.42358476576932, 6.78624, 22.340404320145904) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1360.Parent = workspace.devices.definds
newmodel1360.RandBr.Value = 0.5543205331317654
newmodel1361 = workspace.prefabs.defind:clone()
newmodel1361:PivotTo(CFrame.new(-71.42358476576932, 6.675280292, 22.340404320145904) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1361.Parent = workspace.devices.definds
newmodel1361.RandBr.Value = 0.4269340966733821
newmodel1362 = workspace.prefabs.defind:clone()
newmodel1362:PivotTo(CFrame.new(-71.52420787552715, 6.897200292000001, 22.15439106190234) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1362.Parent = workspace.devices.definds
newmodel1362.RandBr.Value = 0.058191965763601014
newmodel1363 = workspace.prefabs.defind:clone()
newmodel1363:PivotTo(CFrame.new(-71.52420787552715, 6.78624, 22.15439106190234) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1363.Parent = workspace.devices.definds
newmodel1363.RandBr.Value = 0.5259276919084775
newmodel1364 = workspace.prefabs.defind:clone()
newmodel1364:PivotTo(CFrame.new(-71.52420787552715, 6.675280292, 22.15439106190234) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1364.Parent = workspace.devices.definds
newmodel1364.RandBr.Value = 0.15999856106477958
newmodel1365 = workspace.prefabs.defind:clone()
newmodel1365:PivotTo(CFrame.new(-71.62483306389849, 6.897200292000001, 21.968366644692818) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1365.Parent = workspace.devices.definds
newmodel1365.RandBr.Value = 0.20526634644798825
newmodel1366 = workspace.prefabs.defind:clone()
newmodel1366:PivotTo(CFrame.new(-71.62483306389849, 6.78624, 21.968366644692818) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1366.Parent = workspace.devices.definds
newmodel1366.RandBr.Value = 0.1895986986545439
newmodel1367 = workspace.prefabs.defind:clone()
newmodel1367:PivotTo(CFrame.new(-71.62483306389849, 6.675280292, 21.968366644692818) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1367.Parent = workspace.devices.definds
newmodel1367.RandBr.Value = 0.14223520123586844
newmodel1368 = workspace.prefabs.defind:clone()
newmodel1368:PivotTo(CFrame.new(-71.7254559471385, 6.897200292000001, 21.78234795220714) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1368.Parent = workspace.devices.definds
newmodel1368.RandBr.Value = 0.4326954490200162
newmodel1369 = workspace.prefabs.defind:clone()
newmodel1369:PivotTo(CFrame.new(-71.7254559471385, 6.78624, 21.78234795220714) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1369.Parent = workspace.devices.definds
newmodel1369.RandBr.Value = 0.3175860109506109
newmodel1370 = workspace.prefabs.defind:clone()
newmodel1370:PivotTo(CFrame.new(-71.7254559471385, 6.675280292, 21.78234795220714) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1370.Parent = workspace.devices.definds
newmodel1370.RandBr.Value = 0.210574038184979
newmodel1371 = workspace.prefabs.defind:clone()
newmodel1371:PivotTo(CFrame.new(-71.82607583947573, 6.897200292000001, 21.596329301782074) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1371.Parent = workspace.devices.definds
newmodel1371.RandBr.Value = 0.09795681087820522
newmodel1372 = workspace.prefabs.defind:clone()
newmodel1372:PivotTo(CFrame.new(-71.82607583947573, 6.78624, 21.596329301782074) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1372.Parent = workspace.devices.definds
newmodel1372.RandBr.Value = 0.3063205098615407
newmodel1373 = workspace.prefabs.defind:clone()
newmodel1373:PivotTo(CFrame.new(-71.82607583947573, 6.675280292, 21.596329301782074) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1373.Parent = workspace.devices.definds
newmodel1373.RandBr.Value = 0.4391336667221245
newmodel1374 = workspace.prefabs.defind:clone()
newmodel1374:PivotTo(CFrame.new(-71.9267038656652, 6.897200292000001, 21.41030475970485) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1374.Parent = workspace.devices.definds
newmodel1374.RandBr.Value = 0.4347019990978536
newmodel1375 = workspace.prefabs.defind:clone()
newmodel1375:PivotTo(CFrame.new(-71.9267038656652, 6.78624, 21.41030475970485) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1375.Parent = workspace.devices.definds
newmodel1375.RandBr.Value = 0.5377772605114755
newmodel1376 = workspace.prefabs.defind:clone()
newmodel1376:PivotTo(CFrame.new(-71.9267038656652, 6.675280292, 21.41030475970485) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1376.Parent = workspace.devices.definds
newmodel1376.RandBr.Value = 0.5963993655077392
newmodel1377 = workspace.prefabs.defind:clone()
newmodel1377:PivotTo(CFrame.new(-72.02732107326892, 6.897200292000001, 21.224286316954572) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1377.Parent = workspace.devices.definds
newmodel1377.RandBr.Value = 0.5932611981770191
newmodel1378 = workspace.prefabs.defind:clone()
newmodel1378:PivotTo(CFrame.new(-72.02732107326892, 6.78624, 21.224286316954572) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1378.Parent = workspace.devices.definds
newmodel1378.RandBr.Value = 0.2425088375247109
newmodel1379 = workspace.prefabs.defind:clone()
newmodel1379:PivotTo(CFrame.new(-72.02732107326892, 6.675280292, 21.224286316954572) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1379.Parent = workspace.devices.definds
newmodel1379.RandBr.Value = 0.010106764577803929
newmodel1380 = workspace.prefabs.defind:clone()
newmodel1380:PivotTo(CFrame.new(-72.12794371583355, 6.897200292000001, 21.03826185058655) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1380.Parent = workspace.devices.definds
newmodel1380.RandBr.Value = 0.3240963063007112
newmodel1381 = workspace.prefabs.defind:clone()
newmodel1381:PivotTo(CFrame.new(-72.12794371583355, 6.78624, 21.03826185058655) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1381.Parent = workspace.devices.definds
newmodel1381.RandBr.Value = 0.13955660731855749
newmodel1382 = workspace.prefabs.defind:clone()
newmodel1382:PivotTo(CFrame.new(-72.12794371583355, 6.675280292, 21.03826185058655) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel1382.Parent = workspace.devices.definds
newmodel1382.RandBr.Value = 0.03907846430669204
