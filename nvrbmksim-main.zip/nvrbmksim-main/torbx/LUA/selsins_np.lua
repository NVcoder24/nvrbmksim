newmodel0 = workspace.prefabs.sel_np:clone()
newmodel0:PivotTo(CFrame.new(-16.55453642341398, 9.02588, 30.390498117818236) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel0.Parent = workspace.devices.sel_np
newmodel0.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_0-8"
newmodel1 = workspace.prefabs.sel_np:clone()
newmodel1:PivotTo(CFrame.new(-16.98039841122487, 9.02588, 30.756926550396493) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel1.Parent = workspace.devices.sel_np
newmodel1.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_0-10"
newmodel2 = workspace.prefabs.sel_np:clone()
newmodel2:PivotTo(CFrame.new(-17.40626039903576, 9.02588, 31.123354982974746) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel2.Parent = workspace.devices.sel_np
newmodel2.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_0-12"
newmodel3 = workspace.prefabs.sel_np:clone()
newmodel3:PivotTo(CFrame.new(-17.83212238684665, 9.02588, 31.489783415553006) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel3.Parent = workspace.devices.sel_np
newmodel3.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_0-14"
newmodel4 = workspace.prefabs.sel_np:clone()
newmodel4:PivotTo(CFrame.new(-15.82673750945495, 8.819582, 29.732017849874836) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel4.Parent = workspace.devices.sel_np
newmodel4.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_1-5"
newmodel5 = workspace.prefabs.sel_np:clone()
newmodel5:PivotTo(CFrame.new(-16.341605429508533, 8.819582, 30.20728390152911) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel5.Parent = workspace.devices.sel_np
newmodel5.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_1-7"
newmodel6 = workspace.prefabs.sel_np:clone()
newmodel6:PivotTo(CFrame.new(-16.767467417319423, 8.819582, 30.573712334107363) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel6.Parent = workspace.devices.sel_np
newmodel6.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_1-9"
newmodel7 = workspace.prefabs.sel_np:clone()
newmodel7:PivotTo(CFrame.new(-17.193329405130314, 8.819582, 30.940140766685623) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel7.Parent = workspace.devices.sel_np
newmodel7.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_1-11"
newmodel8 = workspace.prefabs.sel_np:clone()
newmodel8:PivotTo(CFrame.new(-17.619191392941204, 8.819582, 31.306569199263876) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel8.Parent = workspace.devices.sel_np
newmodel8.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_1-13"
newmodel9 = workspace.prefabs.sel_np:clone()
newmodel9:PivotTo(CFrame.new(-18.045053380752094, 8.819582, 31.672997631842133) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel9.Parent = workspace.devices.sel_np
newmodel9.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_1-15"
newmodel10 = workspace.prefabs.sel_np:clone()
newmodel10:PivotTo(CFrame.new(-18.5720985119902, 8.819582, 32.10798186758533) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel10.Parent = workspace.devices.sel_np
newmodel10.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_1-17"
newmodel11 = workspace.prefabs.sel_np:clone()
newmodel11:PivotTo(CFrame.new(-15.631464173843138, 8.613284, 29.530088699886438) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel11.Parent = workspace.devices.sel_np
newmodel11.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_2-4"
newmodel12 = workspace.prefabs.sel_np:clone()
newmodel12:PivotTo(CFrame.new(-16.128674435603088, 8.613284, 30.02406968523998) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel12.Parent = workspace.devices.sel_np
newmodel12.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_2-6"
newmodel13 = workspace.prefabs.sel_np:clone()
newmodel13:PivotTo(CFrame.new(-16.55453642341398, 8.613284, 30.390498117818236) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel13.Parent = workspace.devices.sel_np
newmodel13.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_2-8"
newmodel14 = workspace.prefabs.sel_np:clone()
newmodel14:PivotTo(CFrame.new(-16.98039841122487, 8.613284, 30.756926550396493) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel14.Parent = workspace.devices.sel_np
newmodel14.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_2-10"
newmodel15 = workspace.prefabs.sel_np:clone()
newmodel15:PivotTo(CFrame.new(-17.40626039903576, 8.613284, 31.123354982974746) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel15.Parent = workspace.devices.sel_np
newmodel15.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_2-12"
newmodel16 = workspace.prefabs.sel_np:clone()
newmodel16:PivotTo(CFrame.new(-17.83212238684665, 8.613284, 31.489783415553006) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel16.Parent = workspace.devices.sel_np
newmodel16.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_2-14"
newmodel17 = workspace.prefabs.sel_np:clone()
newmodel17:PivotTo(CFrame.new(-18.25798437465754, 8.613284, 31.85621184813126) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel17.Parent = workspace.devices.sel_np
newmodel17.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_2-16"
newmodel18 = workspace.prefabs.sel_np:clone()
newmodel18:PivotTo(CFrame.new(-18.800900642307216, 8.613284, 32.27094395636182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel18.Parent = workspace.devices.sel_np
newmodel18.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_2-18"
newmodel19 = workspace.prefabs.sel_np:clone()
newmodel19:PivotTo(CFrame.new(-15.436190838231328, 8.406986, 29.32815954989804) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel19.Parent = workspace.devices.sel_np
newmodel19.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_3-3"
newmodel20 = workspace.prefabs.sel_np:clone()
newmodel20:PivotTo(CFrame.new(-15.82673750945495, 8.406986, 29.732017849874836) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel20.Parent = workspace.devices.sel_np
newmodel20.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_3-5"
newmodel21 = workspace.prefabs.sel_np:clone()
newmodel21:PivotTo(CFrame.new(-16.341605429508533, 8.366106, 30.20728390152911) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel21.Parent = workspace.devices.sel_np
newmodel21.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_3-7"
newmodel22 = workspace.prefabs.sel_np:clone()
newmodel22:PivotTo(CFrame.new(-16.767467417319423, 8.406986, 30.573712334107363) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel22.Parent = workspace.devices.sel_np
newmodel22.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_3-9"
newmodel23 = workspace.prefabs.sel_np:clone()
newmodel23:PivotTo(CFrame.new(-17.193329405130314, 8.406986, 30.940140766685623) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel23.Parent = workspace.devices.sel_np
newmodel23.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_3-11"
newmodel24 = workspace.prefabs.sel_np:clone()
newmodel24:PivotTo(CFrame.new(-17.619191392941204, 8.406986, 31.306569199263876) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel24.Parent = workspace.devices.sel_np
newmodel24.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_3-13"
newmodel25 = workspace.prefabs.sel_np:clone()
newmodel25:PivotTo(CFrame.new(-18.045053380752094, 8.366106, 31.672997631842133) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel25.Parent = workspace.devices.sel_np
newmodel25.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_3-15"
newmodel26 = workspace.prefabs.sel_np:clone()
newmodel26:PivotTo(CFrame.new(-18.5720985119902, 8.406986, 32.10798186758533) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel26.Parent = workspace.devices.sel_np
newmodel26.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_3-17"
newmodel27 = workspace.prefabs.sel_np:clone()
newmodel27:PivotTo(CFrame.new(-19.029702772624226, 8.406986, 32.43390604513831) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel27.Parent = workspace.devices.sel_np
newmodel27.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_3-19"
newmodel28 = workspace.prefabs.sel_np:clone()
newmodel28:PivotTo(CFrame.new(-15.240917502619517, 8.200688, 29.12623039990964) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel28.Parent = workspace.devices.sel_np
newmodel28.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_4-2"
newmodel29 = workspace.prefabs.sel_np:clone()
newmodel29:PivotTo(CFrame.new(-15.631464173843138, 8.200688, 29.530088699886438) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel29.Parent = workspace.devices.sel_np
newmodel29.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_4-4"
newmodel30 = workspace.prefabs.sel_np:clone()
newmodel30:PivotTo(CFrame.new(-16.128674435603088, 8.200688, 30.02406968523998) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel30.Parent = workspace.devices.sel_np
newmodel30.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_4-6"
newmodel31 = workspace.prefabs.sel_np:clone()
newmodel31:PivotTo(CFrame.new(-16.55453642341398, 8.200688, 30.390498117818236) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel31.Parent = workspace.devices.sel_np
newmodel31.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_4-8"
newmodel32 = workspace.prefabs.sel_np:clone()
newmodel32:PivotTo(CFrame.new(-16.98039841122487, 8.200688, 30.756926550396493) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel32.Parent = workspace.devices.sel_np
newmodel32.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_4-10"
newmodel33 = workspace.prefabs.sel_np:clone()
newmodel33:PivotTo(CFrame.new(-17.40626039903576, 8.200688, 31.123354982974746) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel33.Parent = workspace.devices.sel_np
newmodel33.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_4-12"
newmodel34 = workspace.prefabs.sel_np:clone()
newmodel34:PivotTo(CFrame.new(-17.83212238684665, 8.200688, 31.489783415553006) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel34.Parent = workspace.devices.sel_np
newmodel34.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_4-14"
newmodel35 = workspace.prefabs.sel_np:clone()
newmodel35:PivotTo(CFrame.new(-18.25798437465754, 8.200688, 31.85621184813126) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel35.Parent = workspace.devices.sel_np
newmodel35.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_4-16"
newmodel36 = workspace.prefabs.sel_np:clone()
newmodel36:PivotTo(CFrame.new(-18.800900642307216, 8.200688, 32.27094395636182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel36.Parent = workspace.devices.sel_np
newmodel36.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_4-18"
newmodel37 = workspace.prefabs.sel_np:clone()
newmodel37:PivotTo(CFrame.new(-19.25850490294124, 8.200688, 32.596868133914796) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel37.Parent = workspace.devices.sel_np
newmodel37.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_4-20"
newmodel38 = workspace.prefabs.sel_np:clone()
newmodel38:PivotTo(CFrame.new(-15.045644167007707, 7.99439, 28.924301249921243) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel38.Parent = workspace.devices.sel_np
newmodel38.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_5-1"
newmodel39 = workspace.prefabs.sel_np:clone()
newmodel39:PivotTo(CFrame.new(-15.436190838231328, 7.99439, 29.32815954989804) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel39.Parent = workspace.devices.sel_np
newmodel39.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_5-3"
newmodel40 = workspace.prefabs.sel_np:clone()
newmodel40:PivotTo(CFrame.new(-15.82673750945495, 7.99439, 29.732017849874836) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel40.Parent = workspace.devices.sel_np
newmodel40.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_5-5"
newmodel41 = workspace.prefabs.sel_np:clone()
newmodel41:PivotTo(CFrame.new(-16.341605429508533, 7.99439, 30.20728390152911) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel41.Parent = workspace.devices.sel_np
newmodel41.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_5-7"
newmodel42 = workspace.prefabs.sel_np:clone()
newmodel42:PivotTo(CFrame.new(-16.767467417319423, 7.99439, 30.573712334107363) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel42.Parent = workspace.devices.sel_np
newmodel42.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_5-9"
newmodel43 = workspace.prefabs.sel_np:clone()
newmodel43:PivotTo(CFrame.new(-17.193329405130314, 7.99439, 30.940140766685623) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel43.Parent = workspace.devices.sel_np
newmodel43.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_5-11"
newmodel44 = workspace.prefabs.sel_np:clone()
newmodel44:PivotTo(CFrame.new(-17.619191392941204, 7.99439, 31.306569199263876) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel44.Parent = workspace.devices.sel_np
newmodel44.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_5-13"
newmodel45 = workspace.prefabs.sel_np:clone()
newmodel45:PivotTo(CFrame.new(-18.045053380752094, 7.99439, 31.672997631842133) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel45.Parent = workspace.devices.sel_np
newmodel45.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_5-15"
newmodel46 = workspace.prefabs.sel_np:clone()
newmodel46:PivotTo(CFrame.new(-18.5720985119902, 7.99439, 32.10798186758533) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel46.Parent = workspace.devices.sel_np
newmodel46.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_5-17"
newmodel47 = workspace.prefabs.sel_np:clone()
newmodel47:PivotTo(CFrame.new(-19.029702772624226, 7.99439, 32.43390604513831) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel47.Parent = workspace.devices.sel_np
newmodel47.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_5-19"
newmodel48 = workspace.prefabs.sel_np:clone()
newmodel48:PivotTo(CFrame.new(-19.487307033258258, 7.99439, 32.759830222691285) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel48.Parent = workspace.devices.sel_np
newmodel48.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_5-21"
newmodel49 = workspace.prefabs.sel_np:clone()
newmodel49:PivotTo(CFrame.new(-15.240917502619517, 7.788092, 29.12623039990964) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel49.Parent = workspace.devices.sel_np
newmodel49.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_6-2"
newmodel50 = workspace.prefabs.sel_np:clone()
newmodel50:PivotTo(CFrame.new(-15.631464173843138, 7.788092, 29.530088699886438) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel50.Parent = workspace.devices.sel_np
newmodel50.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_6-4"
newmodel51 = workspace.prefabs.sel_np:clone()
newmodel51:PivotTo(CFrame.new(-16.128674435603088, 7.788092, 30.02406968523998) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel51.Parent = workspace.devices.sel_np
newmodel51.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_6-6"
newmodel52 = workspace.prefabs.sel_np:clone()
newmodel52:PivotTo(CFrame.new(-16.55453642341398, 7.788092, 30.390498117818236) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel52.Parent = workspace.devices.sel_np
newmodel52.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_6-8"
newmodel53 = workspace.prefabs.sel_np:clone()
newmodel53:PivotTo(CFrame.new(-16.98039841122487, 7.788092, 30.756926550396493) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel53.Parent = workspace.devices.sel_np
newmodel53.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_6-10"
newmodel54 = workspace.prefabs.sel_np:clone()
newmodel54:PivotTo(CFrame.new(-17.40626039903576, 7.788092, 31.123354982974746) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel54.Parent = workspace.devices.sel_np
newmodel54.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_6-12"
newmodel55 = workspace.prefabs.sel_np:clone()
newmodel55:PivotTo(CFrame.new(-17.83212238684665, 7.788092, 31.489783415553006) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel55.Parent = workspace.devices.sel_np
newmodel55.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_6-14"
newmodel56 = workspace.prefabs.sel_np:clone()
newmodel56:PivotTo(CFrame.new(-18.25798437465754, 7.788092, 31.85621184813126) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel56.Parent = workspace.devices.sel_np
newmodel56.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_6-16"
newmodel57 = workspace.prefabs.sel_np:clone()
newmodel57:PivotTo(CFrame.new(-18.800900642307216, 7.788092, 32.27094395636182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel57.Parent = workspace.devices.sel_np
newmodel57.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_6-18"
newmodel58 = workspace.prefabs.sel_np:clone()
newmodel58:PivotTo(CFrame.new(-19.25850490294124, 7.788092, 32.596868133914796) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel58.Parent = workspace.devices.sel_np
newmodel58.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_6-20"
newmodel59 = workspace.prefabs.sel_np:clone()
newmodel59:PivotTo(CFrame.new(-15.045644167007707, 7.5817939999999995, 28.924301249921243) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel59.Parent = workspace.devices.sel_np
newmodel59.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_7-1"
newmodel60 = workspace.prefabs.sel_np:clone()
newmodel60:PivotTo(CFrame.new(-15.436190838231328, 7.540914, 29.32815954989804) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel60.Parent = workspace.devices.sel_np
newmodel60.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_7-3"
newmodel61 = workspace.prefabs.sel_np:clone()
newmodel61:PivotTo(CFrame.new(-15.82673750945495, 7.5817939999999995, 29.732017849874836) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel61.Parent = workspace.devices.sel_np
newmodel61.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_7-5"
newmodel62 = workspace.prefabs.sel_np:clone()
newmodel62:PivotTo(CFrame.new(-16.341605429508533, 7.5817939999999995, 30.20728390152911) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel62.Parent = workspace.devices.sel_np
newmodel62.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_7-7"
newmodel63 = workspace.prefabs.sel_np:clone()
newmodel63:PivotTo(CFrame.new(-16.767467417319423, 7.5817939999999995, 30.573712334107363) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel63.Parent = workspace.devices.sel_np
newmodel63.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_7-9"
newmodel64 = workspace.prefabs.sel_np:clone()
newmodel64:PivotTo(CFrame.new(-17.193329405130314, 7.540914, 30.940140766685623) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel64.Parent = workspace.devices.sel_np
newmodel64.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_7-11"
newmodel65 = workspace.prefabs.sel_np:clone()
newmodel65:PivotTo(CFrame.new(-17.619191392941204, 7.5817939999999995, 31.306569199263876) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel65.Parent = workspace.devices.sel_np
newmodel65.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_7-13"
newmodel66 = workspace.prefabs.sel_np:clone()
newmodel66:PivotTo(CFrame.new(-18.045053380752094, 7.5817939999999995, 31.672997631842133) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel66.Parent = workspace.devices.sel_np
newmodel66.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_7-15"
newmodel67 = workspace.prefabs.sel_np:clone()
newmodel67:PivotTo(CFrame.new(-18.5720985119902, 7.5817939999999995, 32.10798186758533) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel67.Parent = workspace.devices.sel_np
newmodel67.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_7-17"
newmodel68 = workspace.prefabs.sel_np:clone()
newmodel68:PivotTo(CFrame.new(-19.029702772624226, 7.540914, 32.43390604513831) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel68.Parent = workspace.devices.sel_np
newmodel68.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_7-19"
newmodel69 = workspace.prefabs.sel_np:clone()
newmodel69:PivotTo(CFrame.new(-19.487307033258258, 7.5817939999999995, 32.759830222691285) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel69.Parent = workspace.devices.sel_np
newmodel69.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_7-21"
newmodel70 = workspace.prefabs.sel_np:clone()
newmodel70:PivotTo(CFrame.new(-14.850370831395896, 7.375496, 28.722372099932844) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel70.Parent = workspace.devices.sel_np
newmodel70.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_8-0"
newmodel71 = workspace.prefabs.sel_np:clone()
newmodel71:PivotTo(CFrame.new(-15.240917502619517, 7.375496, 29.12623039990964) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel71.Parent = workspace.devices.sel_np
newmodel71.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_8-2"
newmodel72 = workspace.prefabs.sel_np:clone()
newmodel72:PivotTo(CFrame.new(-15.631464173843138, 7.375496, 29.530088699886438) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel72.Parent = workspace.devices.sel_np
newmodel72.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_8-4"
newmodel73 = workspace.prefabs.sel_np:clone()
newmodel73:PivotTo(CFrame.new(-16.128674435603088, 7.375496, 30.02406968523998) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel73.Parent = workspace.devices.sel_np
newmodel73.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_8-6"
newmodel74 = workspace.prefabs.sel_np:clone()
newmodel74:PivotTo(CFrame.new(-16.55453642341398, 7.375496, 30.390498117818236) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel74.Parent = workspace.devices.sel_np
newmodel74.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_8-8"
newmodel75 = workspace.prefabs.sel_np:clone()
newmodel75:PivotTo(CFrame.new(-16.98039841122487, 7.375496, 30.756926550396493) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel75.Parent = workspace.devices.sel_np
newmodel75.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_8-10"
newmodel76 = workspace.prefabs.sel_np:clone()
newmodel76:PivotTo(CFrame.new(-17.40626039903576, 7.375496, 31.123354982974746) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel76.Parent = workspace.devices.sel_np
newmodel76.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_8-12"
newmodel77 = workspace.prefabs.sel_np:clone()
newmodel77:PivotTo(CFrame.new(-17.83212238684665, 7.375496, 31.489783415553006) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel77.Parent = workspace.devices.sel_np
newmodel77.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_8-14"
newmodel78 = workspace.prefabs.sel_np:clone()
newmodel78:PivotTo(CFrame.new(-18.25798437465754, 7.375496, 31.85621184813126) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel78.Parent = workspace.devices.sel_np
newmodel78.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_8-16"
newmodel79 = workspace.prefabs.sel_np:clone()
newmodel79:PivotTo(CFrame.new(-18.800900642307216, 7.375496, 32.27094395636182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel79.Parent = workspace.devices.sel_np
newmodel79.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_8-18"
newmodel80 = workspace.prefabs.sel_np:clone()
newmodel80:PivotTo(CFrame.new(-19.25850490294124, 7.375496, 32.596868133914796) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel80.Parent = workspace.devices.sel_np
newmodel80.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_8-20"
newmodel81 = workspace.prefabs.sel_np:clone()
newmodel81:PivotTo(CFrame.new(-19.716109163575272, 7.375496, 32.922792311467774) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel81.Parent = workspace.devices.sel_np
newmodel81.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_8-22"
newmodel82 = workspace.prefabs.sel_np:clone()
newmodel82:PivotTo(CFrame.new(-15.045644167007707, 7.169198, 28.924301249921243) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel82.Parent = workspace.devices.sel_np
newmodel82.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_9-1"
newmodel83 = workspace.prefabs.sel_np:clone()
newmodel83:PivotTo(CFrame.new(-15.436190838231328, 7.169198, 29.32815954989804) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel83.Parent = workspace.devices.sel_np
newmodel83.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_9-3"
newmodel84 = workspace.prefabs.sel_np:clone()
newmodel84:PivotTo(CFrame.new(-15.82673750945495, 7.169198, 29.732017849874836) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel84.Parent = workspace.devices.sel_np
newmodel84.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_9-5"
newmodel85 = workspace.prefabs.sel_np:clone()
newmodel85:PivotTo(CFrame.new(-16.341605429508533, 7.169198, 30.20728390152911) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel85.Parent = workspace.devices.sel_np
newmodel85.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_9-7"
newmodel86 = workspace.prefabs.sel_np:clone()
newmodel86:PivotTo(CFrame.new(-16.767467417319423, 7.169198, 30.573712334107363) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel86.Parent = workspace.devices.sel_np
newmodel86.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_9-9"
newmodel87 = workspace.prefabs.sel_np:clone()
newmodel87:PivotTo(CFrame.new(-17.193329405130314, 7.169198, 30.940140766685623) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel87.Parent = workspace.devices.sel_np
newmodel87.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_9-11"
newmodel88 = workspace.prefabs.sel_np:clone()
newmodel88:PivotTo(CFrame.new(-17.619191392941204, 7.169198, 31.306569199263876) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel88.Parent = workspace.devices.sel_np
newmodel88.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_9-13"
newmodel89 = workspace.prefabs.sel_np:clone()
newmodel89:PivotTo(CFrame.new(-18.045053380752094, 7.169198, 31.672997631842133) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel89.Parent = workspace.devices.sel_np
newmodel89.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_9-15"
newmodel90 = workspace.prefabs.sel_np:clone()
newmodel90:PivotTo(CFrame.new(-18.5720985119902, 7.169198, 32.10798186758533) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel90.Parent = workspace.devices.sel_np
newmodel90.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_9-17"
newmodel91 = workspace.prefabs.sel_np:clone()
newmodel91:PivotTo(CFrame.new(-19.029702772624226, 7.169198, 32.43390604513831) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel91.Parent = workspace.devices.sel_np
newmodel91.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_9-19"
newmodel92 = workspace.prefabs.sel_np:clone()
newmodel92:PivotTo(CFrame.new(-19.487307033258258, 7.169198, 32.759830222691285) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel92.Parent = workspace.devices.sel_np
newmodel92.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_9-21"
newmodel93 = workspace.prefabs.sel_np:clone()
newmodel93:PivotTo(CFrame.new(-14.850370831395896, 6.962899999999999, 28.722372099932844) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel93.Parent = workspace.devices.sel_np
newmodel93.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_10-0"
newmodel94 = workspace.prefabs.sel_np:clone()
newmodel94:PivotTo(CFrame.new(-15.240917502619517, 6.962899999999999, 29.12623039990964) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel94.Parent = workspace.devices.sel_np
newmodel94.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_10-2"
newmodel95 = workspace.prefabs.sel_np:clone()
newmodel95:PivotTo(CFrame.new(-15.631464173843138, 6.962899999999999, 29.530088699886438) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel95.Parent = workspace.devices.sel_np
newmodel95.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_10-4"
newmodel96 = workspace.prefabs.sel_np:clone()
newmodel96:PivotTo(CFrame.new(-16.128674435603088, 6.962899999999999, 30.02406968523998) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel96.Parent = workspace.devices.sel_np
newmodel96.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_10-6"
newmodel97 = workspace.prefabs.sel_np:clone()
newmodel97:PivotTo(CFrame.new(-16.55453642341398, 6.962899999999999, 30.390498117818236) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel97.Parent = workspace.devices.sel_np
newmodel97.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_10-8"
newmodel98 = workspace.prefabs.sel_np:clone()
newmodel98:PivotTo(CFrame.new(-16.98039841122487, 6.962899999999999, 30.756926550396493) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel98.Parent = workspace.devices.sel_np
newmodel98.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_10-10"
newmodel99 = workspace.prefabs.sel_np:clone()
newmodel99:PivotTo(CFrame.new(-17.40626039903576, 6.962899999999999, 31.123354982974746) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel99.Parent = workspace.devices.sel_np
newmodel99.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_10-12"
newmodel100 = workspace.prefabs.sel_np:clone()
newmodel100:PivotTo(CFrame.new(-17.83212238684665, 6.962899999999999, 31.489783415553006) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel100.Parent = workspace.devices.sel_np
newmodel100.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_10-14"
newmodel101 = workspace.prefabs.sel_np:clone()
newmodel101:PivotTo(CFrame.new(-18.25798437465754, 6.962899999999999, 31.85621184813126) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel101.Parent = workspace.devices.sel_np
newmodel101.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_10-16"
newmodel102 = workspace.prefabs.sel_np:clone()
newmodel102:PivotTo(CFrame.new(-18.800900642307216, 6.962899999999999, 32.27094395636182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel102.Parent = workspace.devices.sel_np
newmodel102.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_10-18"
newmodel103 = workspace.prefabs.sel_np:clone()
newmodel103:PivotTo(CFrame.new(-19.25850490294124, 6.962899999999999, 32.596868133914796) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel103.Parent = workspace.devices.sel_np
newmodel103.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_10-20"
newmodel104 = workspace.prefabs.sel_np:clone()
newmodel104:PivotTo(CFrame.new(-19.716109163575272, 6.962899999999999, 32.922792311467774) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel104.Parent = workspace.devices.sel_np
newmodel104.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_10-22"
newmodel105 = workspace.prefabs.sel_np:clone()
newmodel105:PivotTo(CFrame.new(-15.045644167007707, 6.756601999999999, 28.924301249921243) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel105.Parent = workspace.devices.sel_np
newmodel105.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_11-1"
newmodel106 = workspace.prefabs.sel_np:clone()
newmodel106:PivotTo(CFrame.new(-15.436190838231328, 6.756601999999999, 29.32815954989804) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel106.Parent = workspace.devices.sel_np
newmodel106.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_11-3"
newmodel107 = workspace.prefabs.sel_np:clone()
newmodel107:PivotTo(CFrame.new(-15.82673750945495, 6.756601999999999, 29.732017849874836) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel107.Parent = workspace.devices.sel_np
newmodel107.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_11-5"
newmodel108 = workspace.prefabs.sel_np:clone()
newmodel108:PivotTo(CFrame.new(-16.341605429508533, 6.7157219999999995, 30.20728390152911) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel108.Parent = workspace.devices.sel_np
newmodel108.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_11-7"
newmodel109 = workspace.prefabs.sel_np:clone()
newmodel109:PivotTo(CFrame.new(-16.767467417319423, 6.756601999999999, 30.573712334107363) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel109.Parent = workspace.devices.sel_np
newmodel109.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_11-9"
newmodel110 = workspace.prefabs.sel_np:clone()
newmodel110:PivotTo(CFrame.new(-17.193329405130314, 6.756601999999999, 30.940140766685623) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel110.Parent = workspace.devices.sel_np
newmodel110.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_11-11"
newmodel111 = workspace.prefabs.sel_np:clone()
newmodel111:PivotTo(CFrame.new(-17.619191392941204, 6.756601999999999, 31.306569199263876) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel111.Parent = workspace.devices.sel_np
newmodel111.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_11-13"
newmodel112 = workspace.prefabs.sel_np:clone()
newmodel112:PivotTo(CFrame.new(-18.045053380752094, 6.7157219999999995, 31.672997631842133) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel112.Parent = workspace.devices.sel_np
newmodel112.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_11-15"
newmodel113 = workspace.prefabs.sel_np:clone()
newmodel113:PivotTo(CFrame.new(-18.5720985119902, 6.756601999999999, 32.10798186758533) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel113.Parent = workspace.devices.sel_np
newmodel113.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_11-17"
newmodel114 = workspace.prefabs.sel_np:clone()
newmodel114:PivotTo(CFrame.new(-19.029702772624226, 6.756601999999999, 32.43390604513831) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel114.Parent = workspace.devices.sel_np
newmodel114.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_11-19"
newmodel115 = workspace.prefabs.sel_np:clone()
newmodel115:PivotTo(CFrame.new(-19.487307033258258, 6.756601999999999, 32.759830222691285) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel115.Parent = workspace.devices.sel_np
newmodel115.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_11-21"
newmodel116 = workspace.prefabs.sel_np:clone()
newmodel116:PivotTo(CFrame.new(-14.850370831395896, 6.550303999999999, 28.722372099932844) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel116.Parent = workspace.devices.sel_np
newmodel116.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_12-0"
newmodel117 = workspace.prefabs.sel_np:clone()
newmodel117:PivotTo(CFrame.new(-15.240917502619517, 6.550303999999999, 29.12623039990964) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel117.Parent = workspace.devices.sel_np
newmodel117.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_12-2"
newmodel118 = workspace.prefabs.sel_np:clone()
newmodel118:PivotTo(CFrame.new(-15.631464173843138, 6.550303999999999, 29.530088699886438) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel118.Parent = workspace.devices.sel_np
newmodel118.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_12-4"
newmodel119 = workspace.prefabs.sel_np:clone()
newmodel119:PivotTo(CFrame.new(-16.128674435603088, 6.550303999999999, 30.02406968523998) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel119.Parent = workspace.devices.sel_np
newmodel119.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_12-6"
newmodel120 = workspace.prefabs.sel_np:clone()
newmodel120:PivotTo(CFrame.new(-16.55453642341398, 6.550303999999999, 30.390498117818236) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel120.Parent = workspace.devices.sel_np
newmodel120.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_12-8"
newmodel121 = workspace.prefabs.sel_np:clone()
newmodel121:PivotTo(CFrame.new(-16.98039841122487, 6.550303999999999, 30.756926550396493) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel121.Parent = workspace.devices.sel_np
newmodel121.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_12-10"
newmodel122 = workspace.prefabs.sel_np:clone()
newmodel122:PivotTo(CFrame.new(-17.40626039903576, 6.550303999999999, 31.123354982974746) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel122.Parent = workspace.devices.sel_np
newmodel122.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_12-12"
newmodel123 = workspace.prefabs.sel_np:clone()
newmodel123:PivotTo(CFrame.new(-17.83212238684665, 6.550303999999999, 31.489783415553006) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel123.Parent = workspace.devices.sel_np
newmodel123.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_12-14"
newmodel124 = workspace.prefabs.sel_np:clone()
newmodel124:PivotTo(CFrame.new(-18.25798437465754, 6.550303999999999, 31.85621184813126) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel124.Parent = workspace.devices.sel_np
newmodel124.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_12-16"
newmodel125 = workspace.prefabs.sel_np:clone()
newmodel125:PivotTo(CFrame.new(-18.800900642307216, 6.550303999999999, 32.27094395636182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel125.Parent = workspace.devices.sel_np
newmodel125.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_12-18"
newmodel126 = workspace.prefabs.sel_np:clone()
newmodel126:PivotTo(CFrame.new(-19.25850490294124, 6.550303999999999, 32.596868133914796) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel126.Parent = workspace.devices.sel_np
newmodel126.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_12-20"
newmodel127 = workspace.prefabs.sel_np:clone()
newmodel127:PivotTo(CFrame.new(-19.716109163575272, 6.550303999999999, 32.922792311467774) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel127.Parent = workspace.devices.sel_np
newmodel127.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_12-22"
newmodel128 = workspace.prefabs.sel_np:clone()
newmodel128:PivotTo(CFrame.new(-15.045644167007707, 6.344006, 28.924301249921243) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel128.Parent = workspace.devices.sel_np
newmodel128.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_13-1"
newmodel129 = workspace.prefabs.sel_np:clone()
newmodel129:PivotTo(CFrame.new(-15.436190838231328, 6.344006, 29.32815954989804) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel129.Parent = workspace.devices.sel_np
newmodel129.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_13-3"
newmodel130 = workspace.prefabs.sel_np:clone()
newmodel130:PivotTo(CFrame.new(-15.82673750945495, 6.344006, 29.732017849874836) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel130.Parent = workspace.devices.sel_np
newmodel130.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_13-5"
newmodel131 = workspace.prefabs.sel_np:clone()
newmodel131:PivotTo(CFrame.new(-16.341605429508533, 6.344006, 30.20728390152911) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel131.Parent = workspace.devices.sel_np
newmodel131.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_13-7"
newmodel132 = workspace.prefabs.sel_np:clone()
newmodel132:PivotTo(CFrame.new(-16.767467417319423, 6.344006, 30.573712334107363) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel132.Parent = workspace.devices.sel_np
newmodel132.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_13-9"
newmodel133 = workspace.prefabs.sel_np:clone()
newmodel133:PivotTo(CFrame.new(-17.193329405130314, 6.344006, 30.940140766685623) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel133.Parent = workspace.devices.sel_np
newmodel133.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_13-11"
newmodel134 = workspace.prefabs.sel_np:clone()
newmodel134:PivotTo(CFrame.new(-17.619191392941204, 6.344006, 31.306569199263876) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel134.Parent = workspace.devices.sel_np
newmodel134.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_13-13"
newmodel135 = workspace.prefabs.sel_np:clone()
newmodel135:PivotTo(CFrame.new(-18.045053380752094, 6.344006, 31.672997631842133) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel135.Parent = workspace.devices.sel_np
newmodel135.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_13-15"
newmodel136 = workspace.prefabs.sel_np:clone()
newmodel136:PivotTo(CFrame.new(-18.5720985119902, 6.344006, 32.10798186758533) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel136.Parent = workspace.devices.sel_np
newmodel136.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_13-17"
newmodel137 = workspace.prefabs.sel_np:clone()
newmodel137:PivotTo(CFrame.new(-19.029702772624226, 6.344006, 32.43390604513831) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel137.Parent = workspace.devices.sel_np
newmodel137.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_13-19"
newmodel138 = workspace.prefabs.sel_np:clone()
newmodel138:PivotTo(CFrame.new(-19.487307033258258, 6.344006, 32.759830222691285) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel138.Parent = workspace.devices.sel_np
newmodel138.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_13-21"
newmodel139 = workspace.prefabs.sel_np:clone()
newmodel139:PivotTo(CFrame.new(-14.850370831395896, 6.137708, 28.722372099932844) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel139.Parent = workspace.devices.sel_np
newmodel139.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_14-0"
newmodel140 = workspace.prefabs.sel_np:clone()
newmodel140:PivotTo(CFrame.new(-15.240917502619517, 6.137708, 29.12623039990964) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel140.Parent = workspace.devices.sel_np
newmodel140.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_14-2"
newmodel141 = workspace.prefabs.sel_np:clone()
newmodel141:PivotTo(CFrame.new(-15.631464173843138, 6.137708, 29.530088699886438) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel141.Parent = workspace.devices.sel_np
newmodel141.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_14-4"
newmodel142 = workspace.prefabs.sel_np:clone()
newmodel142:PivotTo(CFrame.new(-16.128674435603088, 6.137708, 30.02406968523998) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel142.Parent = workspace.devices.sel_np
newmodel142.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_14-6"
newmodel143 = workspace.prefabs.sel_np:clone()
newmodel143:PivotTo(CFrame.new(-16.55453642341398, 6.137708, 30.390498117818236) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel143.Parent = workspace.devices.sel_np
newmodel143.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_14-8"
newmodel144 = workspace.prefabs.sel_np:clone()
newmodel144:PivotTo(CFrame.new(-16.98039841122487, 6.137708, 30.756926550396493) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel144.Parent = workspace.devices.sel_np
newmodel144.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_14-10"
newmodel145 = workspace.prefabs.sel_np:clone()
newmodel145:PivotTo(CFrame.new(-17.40626039903576, 6.137708, 31.123354982974746) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel145.Parent = workspace.devices.sel_np
newmodel145.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_14-12"
newmodel146 = workspace.prefabs.sel_np:clone()
newmodel146:PivotTo(CFrame.new(-17.83212238684665, 6.137708, 31.489783415553006) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel146.Parent = workspace.devices.sel_np
newmodel146.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_14-14"
newmodel147 = workspace.prefabs.sel_np:clone()
newmodel147:PivotTo(CFrame.new(-18.25798437465754, 6.137708, 31.85621184813126) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel147.Parent = workspace.devices.sel_np
newmodel147.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_14-16"
newmodel148 = workspace.prefabs.sel_np:clone()
newmodel148:PivotTo(CFrame.new(-18.800900642307216, 6.137708, 32.27094395636182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel148.Parent = workspace.devices.sel_np
newmodel148.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_14-18"
newmodel149 = workspace.prefabs.sel_np:clone()
newmodel149:PivotTo(CFrame.new(-19.25850490294124, 6.137708, 32.596868133914796) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel149.Parent = workspace.devices.sel_np
newmodel149.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_14-20"
newmodel150 = workspace.prefabs.sel_np:clone()
newmodel150:PivotTo(CFrame.new(-19.716109163575272, 6.137708, 32.922792311467774) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel150.Parent = workspace.devices.sel_np
newmodel150.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_14-22"
newmodel151 = workspace.prefabs.sel_np:clone()
newmodel151:PivotTo(CFrame.new(-15.045644167007707, 5.9314100000000005, 28.924301249921243) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel151.Parent = workspace.devices.sel_np
newmodel151.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_15-1"
newmodel152 = workspace.prefabs.sel_np:clone()
newmodel152:PivotTo(CFrame.new(-15.436190838231328, 5.89053, 29.32815954989804) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel152.Parent = workspace.devices.sel_np
newmodel152.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_15-3"
newmodel153 = workspace.prefabs.sel_np:clone()
newmodel153:PivotTo(CFrame.new(-15.82673750945495, 5.9314100000000005, 29.732017849874836) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel153.Parent = workspace.devices.sel_np
newmodel153.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_15-5"
newmodel154 = workspace.prefabs.sel_np:clone()
newmodel154:PivotTo(CFrame.new(-16.341605429508533, 5.9314100000000005, 30.20728390152911) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel154.Parent = workspace.devices.sel_np
newmodel154.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_15-7"
newmodel155 = workspace.prefabs.sel_np:clone()
newmodel155:PivotTo(CFrame.new(-16.767467417319423, 5.9314100000000005, 30.573712334107363) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel155.Parent = workspace.devices.sel_np
newmodel155.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_15-9"
newmodel156 = workspace.prefabs.sel_np:clone()
newmodel156:PivotTo(CFrame.new(-17.193329405130314, 5.89053, 30.940140766685623) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel156.Parent = workspace.devices.sel_np
newmodel156.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_15-11"
newmodel157 = workspace.prefabs.sel_np:clone()
newmodel157:PivotTo(CFrame.new(-17.619191392941204, 5.9314100000000005, 31.306569199263876) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel157.Parent = workspace.devices.sel_np
newmodel157.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_15-13"
newmodel158 = workspace.prefabs.sel_np:clone()
newmodel158:PivotTo(CFrame.new(-18.045053380752094, 5.9314100000000005, 31.672997631842133) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel158.Parent = workspace.devices.sel_np
newmodel158.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_15-15"
newmodel159 = workspace.prefabs.sel_np:clone()
newmodel159:PivotTo(CFrame.new(-18.5720985119902, 5.9314100000000005, 32.10798186758533) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel159.Parent = workspace.devices.sel_np
newmodel159.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_15-17"
newmodel160 = workspace.prefabs.sel_np:clone()
newmodel160:PivotTo(CFrame.new(-19.029702772624226, 5.89053, 32.43390604513831) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel160.Parent = workspace.devices.sel_np
newmodel160.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_15-19"
newmodel161 = workspace.prefabs.sel_np:clone()
newmodel161:PivotTo(CFrame.new(-19.487307033258258, 5.9314100000000005, 32.759830222691285) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel161.Parent = workspace.devices.sel_np
newmodel161.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_15-21"
newmodel162 = workspace.prefabs.sel_np:clone()
newmodel162:PivotTo(CFrame.new(-15.240917502619517, 5.725112, 29.12623039990964) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel162.Parent = workspace.devices.sel_np
newmodel162.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_16-2"
newmodel163 = workspace.prefabs.sel_np:clone()
newmodel163:PivotTo(CFrame.new(-15.631464173843138, 5.725112, 29.530088699886438) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel163.Parent = workspace.devices.sel_np
newmodel163.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_16-4"
newmodel164 = workspace.prefabs.sel_np:clone()
newmodel164:PivotTo(CFrame.new(-16.128674435603088, 5.725112, 30.02406968523998) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel164.Parent = workspace.devices.sel_np
newmodel164.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_16-6"
newmodel165 = workspace.prefabs.sel_np:clone()
newmodel165:PivotTo(CFrame.new(-16.55453642341398, 5.725112, 30.390498117818236) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel165.Parent = workspace.devices.sel_np
newmodel165.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_16-8"
newmodel166 = workspace.prefabs.sel_np:clone()
newmodel166:PivotTo(CFrame.new(-16.98039841122487, 5.725112, 30.756926550396493) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel166.Parent = workspace.devices.sel_np
newmodel166.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_16-10"
newmodel167 = workspace.prefabs.sel_np:clone()
newmodel167:PivotTo(CFrame.new(-17.40626039903576, 5.725112, 31.123354982974746) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel167.Parent = workspace.devices.sel_np
newmodel167.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_16-12"
newmodel168 = workspace.prefabs.sel_np:clone()
newmodel168:PivotTo(CFrame.new(-17.83212238684665, 5.725112, 31.489783415553006) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel168.Parent = workspace.devices.sel_np
newmodel168.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_16-14"
newmodel169 = workspace.prefabs.sel_np:clone()
newmodel169:PivotTo(CFrame.new(-18.25798437465754, 5.725112, 31.85621184813126) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel169.Parent = workspace.devices.sel_np
newmodel169.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_16-16"
newmodel170 = workspace.prefabs.sel_np:clone()
newmodel170:PivotTo(CFrame.new(-18.800900642307216, 5.725112, 32.27094395636182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel170.Parent = workspace.devices.sel_np
newmodel170.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_16-18"
newmodel171 = workspace.prefabs.sel_np:clone()
newmodel171:PivotTo(CFrame.new(-19.25850490294124, 5.725112, 32.596868133914796) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel171.Parent = workspace.devices.sel_np
newmodel171.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_16-20"
newmodel172 = workspace.prefabs.sel_np:clone()
newmodel172:PivotTo(CFrame.new(-19.716109163575272, 5.725112, 32.922792311467774) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel172.Parent = workspace.devices.sel_np
newmodel172.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_16-22"
newmodel173 = workspace.prefabs.sel_np:clone()
newmodel173:PivotTo(CFrame.new(-15.045644167007707, 5.518814, 28.924301249921243) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel173.Parent = workspace.devices.sel_np
newmodel173.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_17-1"
newmodel174 = workspace.prefabs.sel_np:clone()
newmodel174:PivotTo(CFrame.new(-15.436190838231328, 5.518814, 29.32815954989804) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel174.Parent = workspace.devices.sel_np
newmodel174.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_17-3"
newmodel175 = workspace.prefabs.sel_np:clone()
newmodel175:PivotTo(CFrame.new(-15.82673750945495, 5.518814, 29.732017849874836) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel175.Parent = workspace.devices.sel_np
newmodel175.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_17-5"
newmodel176 = workspace.prefabs.sel_np:clone()
newmodel176:PivotTo(CFrame.new(-16.341605429508533, 5.518814, 30.20728390152911) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel176.Parent = workspace.devices.sel_np
newmodel176.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_17-7"
newmodel177 = workspace.prefabs.sel_np:clone()
newmodel177:PivotTo(CFrame.new(-16.767467417319423, 5.518814, 30.573712334107363) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel177.Parent = workspace.devices.sel_np
newmodel177.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_17-9"
newmodel178 = workspace.prefabs.sel_np:clone()
newmodel178:PivotTo(CFrame.new(-17.193329405130314, 5.518814, 30.940140766685623) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel178.Parent = workspace.devices.sel_np
newmodel178.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_17-11"
newmodel179 = workspace.prefabs.sel_np:clone()
newmodel179:PivotTo(CFrame.new(-17.619191392941204, 5.518814, 31.306569199263876) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel179.Parent = workspace.devices.sel_np
newmodel179.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_17-13"
newmodel180 = workspace.prefabs.sel_np:clone()
newmodel180:PivotTo(CFrame.new(-18.045053380752094, 5.518814, 31.672997631842133) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel180.Parent = workspace.devices.sel_np
newmodel180.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_17-15"
newmodel181 = workspace.prefabs.sel_np:clone()
newmodel181:PivotTo(CFrame.new(-18.5720985119902, 5.518814, 32.10798186758533) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel181.Parent = workspace.devices.sel_np
newmodel181.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_17-17"
newmodel182 = workspace.prefabs.sel_np:clone()
newmodel182:PivotTo(CFrame.new(-19.029702772624226, 5.518814, 32.43390604513831) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel182.Parent = workspace.devices.sel_np
newmodel182.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_17-19"
newmodel183 = workspace.prefabs.sel_np:clone()
newmodel183:PivotTo(CFrame.new(-19.487307033258258, 5.518814, 32.759830222691285) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel183.Parent = workspace.devices.sel_np
newmodel183.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_17-21"
newmodel184 = workspace.prefabs.sel_np:clone()
newmodel184:PivotTo(CFrame.new(-15.240917502619517, 5.312516, 29.12623039990964) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel184.Parent = workspace.devices.sel_np
newmodel184.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_18-2"
newmodel185 = workspace.prefabs.sel_np:clone()
newmodel185:PivotTo(CFrame.new(-15.631464173843138, 5.312516, 29.530088699886438) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel185.Parent = workspace.devices.sel_np
newmodel185.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_18-4"
newmodel186 = workspace.prefabs.sel_np:clone()
newmodel186:PivotTo(CFrame.new(-16.128674435603088, 5.312516, 30.02406968523998) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel186.Parent = workspace.devices.sel_np
newmodel186.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_18-6"
newmodel187 = workspace.prefabs.sel_np:clone()
newmodel187:PivotTo(CFrame.new(-16.55453642341398, 5.312516, 30.390498117818236) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel187.Parent = workspace.devices.sel_np
newmodel187.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_18-8"
newmodel188 = workspace.prefabs.sel_np:clone()
newmodel188:PivotTo(CFrame.new(-16.98039841122487, 5.312516, 30.756926550396493) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel188.Parent = workspace.devices.sel_np
newmodel188.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_18-10"
newmodel189 = workspace.prefabs.sel_np:clone()
newmodel189:PivotTo(CFrame.new(-17.40626039903576, 5.312516, 31.123354982974746) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel189.Parent = workspace.devices.sel_np
newmodel189.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_18-12"
newmodel190 = workspace.prefabs.sel_np:clone()
newmodel190:PivotTo(CFrame.new(-17.83212238684665, 5.312516, 31.489783415553006) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel190.Parent = workspace.devices.sel_np
newmodel190.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_18-14"
newmodel191 = workspace.prefabs.sel_np:clone()
newmodel191:PivotTo(CFrame.new(-18.25798437465754, 5.312516, 31.85621184813126) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel191.Parent = workspace.devices.sel_np
newmodel191.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_18-16"
newmodel192 = workspace.prefabs.sel_np:clone()
newmodel192:PivotTo(CFrame.new(-18.800900642307216, 5.312516, 32.27094395636182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel192.Parent = workspace.devices.sel_np
newmodel192.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_18-18"
newmodel193 = workspace.prefabs.sel_np:clone()
newmodel193:PivotTo(CFrame.new(-19.25850490294124, 5.312516, 32.596868133914796) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel193.Parent = workspace.devices.sel_np
newmodel193.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_18-20"
newmodel194 = workspace.prefabs.sel_np:clone()
newmodel194:PivotTo(CFrame.new(-15.436190838231328, 5.106217999999999, 29.32815954989804) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel194.Parent = workspace.devices.sel_np
newmodel194.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_19-3"
newmodel195 = workspace.prefabs.sel_np:clone()
newmodel195:PivotTo(CFrame.new(-15.82673750945495, 5.106217999999999, 29.732017849874836) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel195.Parent = workspace.devices.sel_np
newmodel195.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_19-5"
newmodel196 = workspace.prefabs.sel_np:clone()
newmodel196:PivotTo(CFrame.new(-16.341605429508533, 5.065338, 30.20728390152911) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel196.Parent = workspace.devices.sel_np
newmodel196.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_19-7"
newmodel197 = workspace.prefabs.sel_np:clone()
newmodel197:PivotTo(CFrame.new(-16.767467417319423, 5.106217999999999, 30.573712334107363) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel197.Parent = workspace.devices.sel_np
newmodel197.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_19-9"
newmodel198 = workspace.prefabs.sel_np:clone()
newmodel198:PivotTo(CFrame.new(-17.193329405130314, 5.106217999999999, 30.940140766685623) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel198.Parent = workspace.devices.sel_np
newmodel198.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_19-11"
newmodel199 = workspace.prefabs.sel_np:clone()
newmodel199:PivotTo(CFrame.new(-17.619191392941204, 5.106217999999999, 31.306569199263876) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel199.Parent = workspace.devices.sel_np
newmodel199.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_19-13"
newmodel200 = workspace.prefabs.sel_np:clone()
newmodel200:PivotTo(CFrame.new(-18.045053380752094, 5.065338, 31.672997631842133) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel200.Parent = workspace.devices.sel_np
newmodel200.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_19-15"
newmodel201 = workspace.prefabs.sel_np:clone()
newmodel201:PivotTo(CFrame.new(-18.5720985119902, 5.106217999999999, 32.10798186758533) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel201.Parent = workspace.devices.sel_np
newmodel201.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_19-17"
newmodel202 = workspace.prefabs.sel_np:clone()
newmodel202:PivotTo(CFrame.new(-19.029702772624226, 5.106217999999999, 32.43390604513831) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel202.Parent = workspace.devices.sel_np
newmodel202.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_19-19"
newmodel203 = workspace.prefabs.sel_np:clone()
newmodel203:PivotTo(CFrame.new(-15.631464173843138, 4.89992, 29.530088699886438) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel203.Parent = workspace.devices.sel_np
newmodel203.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_20-4"
newmodel204 = workspace.prefabs.sel_np:clone()
newmodel204:PivotTo(CFrame.new(-16.128674435603088, 4.89992, 30.02406968523998) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel204.Parent = workspace.devices.sel_np
newmodel204.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_20-6"
newmodel205 = workspace.prefabs.sel_np:clone()
newmodel205:PivotTo(CFrame.new(-16.55453642341398, 4.89992, 30.390498117818236) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel205.Parent = workspace.devices.sel_np
newmodel205.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_20-8"
newmodel206 = workspace.prefabs.sel_np:clone()
newmodel206:PivotTo(CFrame.new(-16.98039841122487, 4.89992, 30.756926550396493) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel206.Parent = workspace.devices.sel_np
newmodel206.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_20-10"
newmodel207 = workspace.prefabs.sel_np:clone()
newmodel207:PivotTo(CFrame.new(-17.40626039903576, 4.89992, 31.123354982974746) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel207.Parent = workspace.devices.sel_np
newmodel207.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_20-12"
newmodel208 = workspace.prefabs.sel_np:clone()
newmodel208:PivotTo(CFrame.new(-17.83212238684665, 4.89992, 31.489783415553006) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel208.Parent = workspace.devices.sel_np
newmodel208.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_20-14"
newmodel209 = workspace.prefabs.sel_np:clone()
newmodel209:PivotTo(CFrame.new(-18.25798437465754, 4.89992, 31.85621184813126) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel209.Parent = workspace.devices.sel_np
newmodel209.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_20-16"
newmodel210 = workspace.prefabs.sel_np:clone()
newmodel210:PivotTo(CFrame.new(-18.800900642307216, 4.89992, 32.27094395636182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel210.Parent = workspace.devices.sel_np
newmodel210.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_20-18"
newmodel211 = workspace.prefabs.sel_np:clone()
newmodel211:PivotTo(CFrame.new(-15.82673750945495, 4.6936219999999995, 29.732017849874836) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel211.Parent = workspace.devices.sel_np
newmodel211.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_21-5"
newmodel212 = workspace.prefabs.sel_np:clone()
newmodel212:PivotTo(CFrame.new(-16.341605429508533, 4.6936219999999995, 30.20728390152911) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel212.Parent = workspace.devices.sel_np
newmodel212.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_21-7"
newmodel213 = workspace.prefabs.sel_np:clone()
newmodel213:PivotTo(CFrame.new(-16.767467417319423, 4.6936219999999995, 30.573712334107363) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel213.Parent = workspace.devices.sel_np
newmodel213.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_21-9"
newmodel214 = workspace.prefabs.sel_np:clone()
newmodel214:PivotTo(CFrame.new(-17.193329405130314, 4.6936219999999995, 30.940140766685623) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel214.Parent = workspace.devices.sel_np
newmodel214.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_21-11"
newmodel215 = workspace.prefabs.sel_np:clone()
newmodel215:PivotTo(CFrame.new(-17.619191392941204, 4.6936219999999995, 31.306569199263876) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel215.Parent = workspace.devices.sel_np
newmodel215.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_21-13"
newmodel216 = workspace.prefabs.sel_np:clone()
newmodel216:PivotTo(CFrame.new(-18.045053380752094, 4.6936219999999995, 31.672997631842133) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel216.Parent = workspace.devices.sel_np
newmodel216.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_21-15"
newmodel217 = workspace.prefabs.sel_np:clone()
newmodel217:PivotTo(CFrame.new(-18.5720985119902, 4.6936219999999995, 32.10798186758533) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel217.Parent = workspace.devices.sel_np
newmodel217.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_21-17"
newmodel218 = workspace.prefabs.sel_np:clone()
newmodel218:PivotTo(CFrame.new(-16.55453642341398, 4.487323999999999, 30.390498117818236) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel218.Parent = workspace.devices.sel_np
newmodel218.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_22-8"
newmodel219 = workspace.prefabs.sel_np:clone()
newmodel219:PivotTo(CFrame.new(-16.98039841122487, 4.487323999999999, 30.756926550396493) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel219.Parent = workspace.devices.sel_np
newmodel219.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_22-10"
newmodel220 = workspace.prefabs.sel_np:clone()
newmodel220:PivotTo(CFrame.new(-17.40626039903576, 4.487323999999999, 31.123354982974746) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel220.Parent = workspace.devices.sel_np
newmodel220.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_22-12"
newmodel221 = workspace.prefabs.sel_np:clone()
newmodel221:PivotTo(CFrame.new(-17.83212238684665, 4.487323999999999, 31.489783415553006) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel221.Parent = workspace.devices.sel_np
newmodel221.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_22-14"
newmodel222 = workspace.prefabs.sel_np:clone()
newmodel222:PivotTo(CFrame.new(-18.25798437465754, 4.487323999999999, 31.85621184813126) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel222.Parent = workspace.devices.sel_np
newmodel222.Body1.Decal.Texture = "rbxgameasset://Images/SEL_NP_22-16"
