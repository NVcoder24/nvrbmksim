newmodel0 = workspace.prefabs.wwerselsin:clone()
newmodel0:PivotTo(CFrame.new(-16.59880482131532, 9.167499999999999, 30.42858839147502) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel0.Parent = workspace.devices.selsins
newmodel1 = workspace.prefabs.wwerselsin:clone()
newmodel1:PivotTo(CFrame.new(-17.02466680912621, 9.167499999999999, 30.795016824053278) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel1.Parent = workspace.devices.selsins
newmodel2 = workspace.prefabs.wwerselsin:clone()
newmodel2:PivotTo(CFrame.new(-17.4505287969371, 9.167499999999999, 31.16144525663153) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel2.Parent = workspace.devices.selsins
newmodel3 = workspace.prefabs.wwerselsin:clone()
newmodel3:PivotTo(CFrame.new(-17.87639078474799, 9.167499999999999, 31.527873689209784) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel3.Parent = workspace.devices.selsins
newmodel4 = workspace.prefabs.wwerselsin:clone()
newmodel4.usp.Value = true
newmodel4:PivotTo(CFrame.new(-15.867334876526012, 8.961202, 29.773998962138535) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel4.Parent = workspace.devices.selsins
newmodel5 = workspace.prefabs.wwerselsin:clone()
newmodel5:PivotTo(CFrame.new(-16.385873827409874, 8.961202, 30.245374175185894) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel5.Parent = workspace.devices.selsins
newmodel6 = workspace.prefabs.wwerselsin:clone()
newmodel6.usp.Value = true
newmodel6:PivotTo(CFrame.new(-16.811735815220764, 8.961202, 30.611802607764147) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel6.Parent = workspace.devices.selsins
newmodel7 = workspace.prefabs.wwerselsin:clone()
newmodel7:PivotTo(CFrame.new(-17.237597803031655, 8.961202, 30.9782310403424) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel7.Parent = workspace.devices.selsins
newmodel8 = workspace.prefabs.wwerselsin:clone()
newmodel8.usp.Value = true
newmodel8:PivotTo(CFrame.new(-17.663459790842545, 8.961202, 31.34465947292066) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel8.Parent = workspace.devices.selsins
newmodel9 = workspace.prefabs.wwerselsin:clone()
newmodel9:PivotTo(CFrame.new(-18.089321778653435, 8.961202, 31.711087905498914) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel9.Parent = workspace.devices.selsins
newmodel10 = workspace.prefabs.wwerselsin:clone()
newmodel10.usp.Value = true
newmodel10:PivotTo(CFrame.new(-18.61966652245112, 8.961202, 32.14186171972182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel10.Parent = workspace.devices.selsins
newmodel11 = workspace.prefabs.wwerselsin:clone()
newmodel11:PivotTo(CFrame.new(-15.6720615409142, 8.754904, 29.57206981215014) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel11.Parent = workspace.devices.selsins
newmodel12 = workspace.prefabs.wwerselsin:clone()
newmodel12:PivotTo(CFrame.new(-16.17294283350443, 8.754904, 30.062159958896764) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel12.Parent = workspace.devices.selsins
newmodel13 = workspace.prefabs.wwerselsin:clone()
newmodel13:PivotTo(CFrame.new(-16.59880482131532, 8.754904, 30.42858839147502) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel13.Parent = workspace.devices.selsins
newmodel14 = workspace.prefabs.wwerselsin:clone()
newmodel14:PivotTo(CFrame.new(-17.02466680912621, 8.754904, 30.795016824053278) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel14.Parent = workspace.devices.selsins
newmodel15 = workspace.prefabs.wwerselsin:clone()
newmodel15:PivotTo(CFrame.new(-17.4505287969371, 8.754904, 31.16144525663153) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel15.Parent = workspace.devices.selsins
newmodel16 = workspace.prefabs.wwerselsin:clone()
newmodel16:PivotTo(CFrame.new(-17.87639078474799, 8.754904, 31.527873689209784) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel16.Parent = workspace.devices.selsins
newmodel17 = workspace.prefabs.wwerselsin:clone()
newmodel17:PivotTo(CFrame.new(-18.30225277255888, 8.754904, 31.894302121788044) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel17.Parent = workspace.devices.selsins
newmodel18 = workspace.prefabs.wwerselsin:clone()
newmodel18:PivotTo(CFrame.new(-18.848468652768133, 8.754904, 32.3048238084983) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel18.Parent = workspace.devices.selsins
newmodel19 = workspace.prefabs.wwerselsin:clone()
newmodel19:PivotTo(CFrame.new(-15.476788205302391, 8.548606, 29.370140662161738) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel19.Parent = workspace.devices.selsins
newmodel20 = workspace.prefabs.wwerselsin:clone()
newmodel20:PivotTo(CFrame.new(-15.867334876526012, 8.548606, 29.773998962138535) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel20.Parent = workspace.devices.selsins
newmodel21 = workspace.prefabs.wwerselsin:clone()
newmodel21:PivotTo(CFrame.new(-16.811735815220764, 8.548606, 30.611802607764147) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel21.Parent = workspace.devices.selsins
newmodel22 = workspace.prefabs.wwerselsin:clone()
newmodel22:PivotTo(CFrame.new(-17.237597803031655, 8.548606, 30.9782310403424) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel22.Parent = workspace.devices.selsins
newmodel23 = workspace.prefabs.wwerselsin:clone()
newmodel23:PivotTo(CFrame.new(-17.663459790842545, 8.548606, 31.34465947292066) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel23.Parent = workspace.devices.selsins
newmodel24 = workspace.prefabs.wwerselsin:clone()
newmodel24:PivotTo(CFrame.new(-18.61966652245112, 8.548606, 32.14186171972182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel24.Parent = workspace.devices.selsins
newmodel25 = workspace.prefabs.wwerselsin:clone()
newmodel25:PivotTo(CFrame.new(-19.077270783085147, 8.548606, 32.467785897274794) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel25.Parent = workspace.devices.selsins
newmodel26 = workspace.prefabs.wwerselsin:clone()
newmodel26:PivotTo(CFrame.new(-15.281514869690579, 8.342308, 29.168211512173343) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel26.Parent = workspace.devices.selsins
newmodel27 = workspace.prefabs.wwerselsin:clone()
newmodel27:PivotTo(CFrame.new(-15.6720615409142, 8.342308, 29.57206981215014) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel27.Parent = workspace.devices.selsins
newmodel28 = workspace.prefabs.wwerselsin:clone()
newmodel28:PivotTo(CFrame.new(-16.17294283350443, 8.342308, 30.062159958896764) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel28.Parent = workspace.devices.selsins
newmodel29 = workspace.prefabs.wwerselsin:clone()
newmodel29:PivotTo(CFrame.new(-16.59880482131532, 8.342308, 30.42858839147502) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel29.Parent = workspace.devices.selsins
newmodel30 = workspace.prefabs.wwerselsin:clone()
newmodel30:PivotTo(CFrame.new(-17.02466680912621, 8.342308, 30.795016824053278) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel30.Parent = workspace.devices.selsins
newmodel31 = workspace.prefabs.wwerselsin:clone()
newmodel31:PivotTo(CFrame.new(-17.4505287969371, 8.342308, 31.16144525663153) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel31.Parent = workspace.devices.selsins
newmodel32 = workspace.prefabs.wwerselsin:clone()
newmodel32:PivotTo(CFrame.new(-17.87639078474799, 8.342308, 31.527873689209784) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel32.Parent = workspace.devices.selsins
newmodel33 = workspace.prefabs.wwerselsin:clone()
newmodel33:PivotTo(CFrame.new(-18.30225277255888, 8.342308, 31.894302121788044) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel33.Parent = workspace.devices.selsins
newmodel34 = workspace.prefabs.wwerselsin:clone()
newmodel34:PivotTo(CFrame.new(-18.848468652768133, 8.342308, 32.3048238084983) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel34.Parent = workspace.devices.selsins
newmodel35 = workspace.prefabs.wwerselsin:clone()
newmodel35:PivotTo(CFrame.new(-19.30607291340216, 8.342308, 32.630747986051276) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel35.Parent = workspace.devices.selsins
newmodel36 = workspace.prefabs.wwerselsin:clone()
newmodel36.usp.Value = true
newmodel36:PivotTo(CFrame.new(-15.08624153407877, 8.13601, 28.96628236218494) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel36.Parent = workspace.devices.selsins
newmodel37 = workspace.prefabs.wwerselsin:clone()
newmodel37:PivotTo(CFrame.new(-15.476788205302391, 8.13601, 29.370140662161738) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel37.Parent = workspace.devices.selsins
newmodel38 = workspace.prefabs.wwerselsin:clone()
newmodel38.usp.Value = true
newmodel38:PivotTo(CFrame.new(-15.867334876526012, 8.13601, 29.773998962138535) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel38.Parent = workspace.devices.selsins
newmodel39 = workspace.prefabs.wwerselsin:clone()
newmodel39:PivotTo(CFrame.new(-16.385873827409874, 8.13601, 30.245374175185894) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel39.Parent = workspace.devices.selsins
newmodel40 = workspace.prefabs.wwerselsin:clone()
newmodel40.usp.Value = true
newmodel40:PivotTo(CFrame.new(-16.811735815220764, 8.13601, 30.611802607764147) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel40.Parent = workspace.devices.selsins
newmodel41 = workspace.prefabs.wwerselsin:clone()
newmodel41:PivotTo(CFrame.new(-17.237597803031655, 8.13601, 30.9782310403424) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel41.Parent = workspace.devices.selsins
newmodel42 = workspace.prefabs.wwerselsin:clone()
newmodel42.usp.Value = true
newmodel42:PivotTo(CFrame.new(-17.663459790842545, 8.13601, 31.34465947292066) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel42.Parent = workspace.devices.selsins
newmodel43 = workspace.prefabs.wwerselsin:clone()
newmodel43:PivotTo(CFrame.new(-18.089321778653435, 8.13601, 31.711087905498914) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel43.Parent = workspace.devices.selsins
newmodel44 = workspace.prefabs.wwerselsin:clone()
newmodel44.usp.Value = true
newmodel44:PivotTo(CFrame.new(-18.61966652245112, 8.13601, 32.14186171972182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel44.Parent = workspace.devices.selsins
newmodel45 = workspace.prefabs.wwerselsin:clone()
newmodel45:PivotTo(CFrame.new(-19.077270783085147, 8.13601, 32.467785897274794) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel45.Parent = workspace.devices.selsins
newmodel46 = workspace.prefabs.wwerselsin:clone()
newmodel46.usp.Value = true
newmodel46:PivotTo(CFrame.new(-19.534875043719175, 8.13601, 32.793710074827764) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel46.Parent = workspace.devices.selsins
newmodel47 = workspace.prefabs.wwerselsin:clone()
newmodel47:PivotTo(CFrame.new(-15.281514869690579, 7.9297119999999985, 29.168211512173343) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel47.Parent = workspace.devices.selsins
newmodel48 = workspace.prefabs.wwerselsin:clone()
newmodel48:PivotTo(CFrame.new(-15.6720615409142, 7.9297119999999985, 29.57206981215014) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel48.Parent = workspace.devices.selsins
newmodel49 = workspace.prefabs.wwerselsin:clone()
newmodel49:PivotTo(CFrame.new(-16.17294283350443, 7.9297119999999985, 30.062159958896764) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel49.Parent = workspace.devices.selsins
newmodel50 = workspace.prefabs.wwerselsin:clone()
newmodel50:PivotTo(CFrame.new(-16.59880482131532, 7.9297119999999985, 30.42858839147502) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel50.Parent = workspace.devices.selsins
newmodel51 = workspace.prefabs.wwerselsin:clone()
newmodel51:PivotTo(CFrame.new(-17.02466680912621, 7.9297119999999985, 30.795016824053278) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel51.Parent = workspace.devices.selsins
newmodel52 = workspace.prefabs.wwerselsin:clone()
newmodel52:PivotTo(CFrame.new(-17.4505287969371, 7.9297119999999985, 31.16144525663153) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel52.Parent = workspace.devices.selsins
newmodel53 = workspace.prefabs.wwerselsin:clone()
newmodel53:PivotTo(CFrame.new(-17.87639078474799, 7.9297119999999985, 31.527873689209784) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel53.Parent = workspace.devices.selsins
newmodel54 = workspace.prefabs.wwerselsin:clone()
newmodel54:PivotTo(CFrame.new(-18.30225277255888, 7.9297119999999985, 31.894302121788044) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel54.Parent = workspace.devices.selsins
newmodel55 = workspace.prefabs.wwerselsin:clone()
newmodel55:PivotTo(CFrame.new(-18.848468652768133, 7.9297119999999985, 32.3048238084983) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel55.Parent = workspace.devices.selsins
newmodel56 = workspace.prefabs.wwerselsin:clone()
newmodel56:PivotTo(CFrame.new(-19.30607291340216, 7.9297119999999985, 32.630747986051276) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel56.Parent = workspace.devices.selsins
newmodel57 = workspace.prefabs.wwerselsin:clone()
newmodel57:PivotTo(CFrame.new(-15.08624153407877, 7.723414, 28.96628236218494) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel57.Parent = workspace.devices.selsins
newmodel58 = workspace.prefabs.wwerselsin:clone()
newmodel58:PivotTo(CFrame.new(-15.867334876526012, 7.723414, 29.773998962138535) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel58.Parent = workspace.devices.selsins
newmodel59 = workspace.prefabs.wwerselsin:clone()
newmodel59:PivotTo(CFrame.new(-16.385873827409874, 7.723414, 30.245374175185894) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel59.Parent = workspace.devices.selsins
newmodel60 = workspace.prefabs.wwerselsin:clone()
newmodel60:PivotTo(CFrame.new(-16.811735815220764, 7.723414, 30.611802607764147) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel60.Parent = workspace.devices.selsins
newmodel61 = workspace.prefabs.wwerselsin:clone()
newmodel61:PivotTo(CFrame.new(-17.663459790842545, 7.723414, 31.34465947292066) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel61.Parent = workspace.devices.selsins
newmodel62 = workspace.prefabs.wwerselsin:clone()
newmodel62:PivotTo(CFrame.new(-18.089321778653435, 7.723414, 31.711087905498914) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel62.Parent = workspace.devices.selsins
newmodel63 = workspace.prefabs.wwerselsin:clone()
newmodel63:PivotTo(CFrame.new(-18.61966652245112, 7.723414, 32.14186171972182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel63.Parent = workspace.devices.selsins
newmodel64 = workspace.prefabs.wwerselsin:clone()
newmodel64:PivotTo(CFrame.new(-19.534875043719175, 7.723414, 32.793710074827764) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel64.Parent = workspace.devices.selsins
newmodel65 = workspace.prefabs.wwerselsin:clone()
newmodel65:PivotTo(CFrame.new(-14.890968198466958, 7.517116, 28.764353212196546) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel65.Parent = workspace.devices.selsins
newmodel66 = workspace.prefabs.wwerselsin:clone()
newmodel66:PivotTo(CFrame.new(-15.281514869690579, 7.517116, 29.168211512173343) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel66.Parent = workspace.devices.selsins
newmodel67 = workspace.prefabs.wwerselsin:clone()
newmodel67:PivotTo(CFrame.new(-15.6720615409142, 7.517116, 29.57206981215014) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel67.Parent = workspace.devices.selsins
newmodel68 = workspace.prefabs.wwerselsin:clone()
newmodel68:PivotTo(CFrame.new(-16.17294283350443, 7.517116, 30.062159958896764) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel68.Parent = workspace.devices.selsins
newmodel69 = workspace.prefabs.wwerselsin:clone()
newmodel69:PivotTo(CFrame.new(-16.59880482131532, 7.517116, 30.42858839147502) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel69.Parent = workspace.devices.selsins
newmodel70 = workspace.prefabs.wwerselsin:clone()
newmodel70:PivotTo(CFrame.new(-17.02466680912621, 7.517116, 30.795016824053278) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel70.Parent = workspace.devices.selsins
newmodel71 = workspace.prefabs.wwerselsin:clone()
newmodel71:PivotTo(CFrame.new(-17.4505287969371, 7.517116, 31.16144525663153) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel71.Parent = workspace.devices.selsins
newmodel72 = workspace.prefabs.wwerselsin:clone()
newmodel72:PivotTo(CFrame.new(-17.87639078474799, 7.517116, 31.527873689209784) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel72.Parent = workspace.devices.selsins
newmodel73 = workspace.prefabs.wwerselsin:clone()
newmodel73:PivotTo(CFrame.new(-18.30225277255888, 7.517116, 31.894302121788044) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel73.Parent = workspace.devices.selsins
newmodel74 = workspace.prefabs.wwerselsin:clone()
newmodel74:PivotTo(CFrame.new(-18.848468652768133, 7.517116, 32.3048238084983) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel74.Parent = workspace.devices.selsins
newmodel75 = workspace.prefabs.wwerselsin:clone()
newmodel75:PivotTo(CFrame.new(-19.30607291340216, 7.517116, 32.630747986051276) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel75.Parent = workspace.devices.selsins
newmodel76 = workspace.prefabs.wwerselsin:clone()
newmodel76:PivotTo(CFrame.new(-19.76367717403619, 7.517116, 32.95667216360425) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel76.Parent = workspace.devices.selsins
newmodel77 = workspace.prefabs.wwerselsin:clone()
newmodel77.usp.Value = true
newmodel77:PivotTo(CFrame.new(-15.08624153407877, 7.310817999999999, 28.96628236218494) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel77.Parent = workspace.devices.selsins
newmodel78 = workspace.prefabs.wwerselsin:clone()
newmodel78:PivotTo(CFrame.new(-15.476788205302391, 7.310817999999999, 29.370140662161738) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel78.Parent = workspace.devices.selsins
newmodel79 = workspace.prefabs.wwerselsin:clone()
newmodel79.usp.Value = true
newmodel79:PivotTo(CFrame.new(-15.867334876526012, 7.310817999999999, 29.773998962138535) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel79.Parent = workspace.devices.selsins
newmodel80 = workspace.prefabs.wwerselsin:clone()
newmodel80:PivotTo(CFrame.new(-16.385873827409874, 7.310817999999999, 30.245374175185894) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel80.Parent = workspace.devices.selsins
newmodel81 = workspace.prefabs.wwerselsin:clone()
newmodel81.usp.Value = true
newmodel81:PivotTo(CFrame.new(-16.811735815220764, 7.310817999999999, 30.611802607764147) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel81.Parent = workspace.devices.selsins
newmodel82 = workspace.prefabs.wwerselsin:clone()
newmodel82:PivotTo(CFrame.new(-17.237597803031655, 7.310817999999999, 30.9782310403424) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel82.Parent = workspace.devices.selsins
newmodel83 = workspace.prefabs.wwerselsin:clone()
newmodel83.usp.Value = true
newmodel83:PivotTo(CFrame.new(-17.663459790842545, 7.310817999999999, 31.34465947292066) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel83.Parent = workspace.devices.selsins
newmodel84 = workspace.prefabs.wwerselsin:clone()
newmodel84:PivotTo(CFrame.new(-18.089321778653435, 7.310817999999999, 31.711087905498914) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel84.Parent = workspace.devices.selsins
newmodel85 = workspace.prefabs.wwerselsin:clone()
newmodel85.usp.Value = true
newmodel85:PivotTo(CFrame.new(-18.61966652245112, 7.310817999999999, 32.14186171972182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel85.Parent = workspace.devices.selsins
newmodel86 = workspace.prefabs.wwerselsin:clone()
newmodel86:PivotTo(CFrame.new(-19.077270783085147, 7.310817999999999, 32.467785897274794) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel86.Parent = workspace.devices.selsins
newmodel87 = workspace.prefabs.wwerselsin:clone()
newmodel87.usp.Value = true
newmodel87:PivotTo(CFrame.new(-19.534875043719175, 7.310817999999999, 32.793710074827764) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel87.Parent = workspace.devices.selsins
newmodel88 = workspace.prefabs.wwerselsin:clone()
newmodel88:PivotTo(CFrame.new(-14.890968198466958, 7.10452, 28.764353212196546) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel88.Parent = workspace.devices.selsins
newmodel89 = workspace.prefabs.wwerselsin:clone()
newmodel89:PivotTo(CFrame.new(-15.281514869690579, 7.10452, 29.168211512173343) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel89.Parent = workspace.devices.selsins
newmodel90 = workspace.prefabs.wwerselsin:clone()
newmodel90:PivotTo(CFrame.new(-15.6720615409142, 7.10452, 29.57206981215014) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel90.Parent = workspace.devices.selsins
newmodel91 = workspace.prefabs.wwerselsin:clone()
newmodel91:PivotTo(CFrame.new(-16.17294283350443, 7.10452, 30.062159958896764) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel91.Parent = workspace.devices.selsins
newmodel92 = workspace.prefabs.wwerselsin:clone()
newmodel92:PivotTo(CFrame.new(-16.59880482131532, 7.10452, 30.42858839147502) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel92.Parent = workspace.devices.selsins
newmodel93 = workspace.prefabs.wwerselsin:clone()
newmodel93:PivotTo(CFrame.new(-17.02466680912621, 7.10452, 30.795016824053278) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel93.Parent = workspace.devices.selsins
newmodel94 = workspace.prefabs.wwerselsin:clone()
newmodel94:PivotTo(CFrame.new(-17.4505287969371, 7.10452, 31.16144525663153) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel94.Parent = workspace.devices.selsins
newmodel95 = workspace.prefabs.wwerselsin:clone()
newmodel95:PivotTo(CFrame.new(-17.87639078474799, 7.10452, 31.527873689209784) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel95.Parent = workspace.devices.selsins
newmodel96 = workspace.prefabs.wwerselsin:clone()
newmodel96:PivotTo(CFrame.new(-18.30225277255888, 7.10452, 31.894302121788044) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel96.Parent = workspace.devices.selsins
newmodel97 = workspace.prefabs.wwerselsin:clone()
newmodel97:PivotTo(CFrame.new(-18.848468652768133, 7.10452, 32.3048238084983) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel97.Parent = workspace.devices.selsins
newmodel98 = workspace.prefabs.wwerselsin:clone()
newmodel98:PivotTo(CFrame.new(-19.30607291340216, 7.10452, 32.630747986051276) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel98.Parent = workspace.devices.selsins
newmodel99 = workspace.prefabs.wwerselsin:clone()
newmodel99:PivotTo(CFrame.new(-19.76367717403619, 7.10452, 32.95667216360425) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel99.Parent = workspace.devices.selsins
newmodel100 = workspace.prefabs.wwerselsin:clone()
newmodel100:PivotTo(CFrame.new(-15.08624153407877, 6.898222, 28.96628236218494) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel100.Parent = workspace.devices.selsins
newmodel101 = workspace.prefabs.wwerselsin:clone()
newmodel101:PivotTo(CFrame.new(-15.476788205302391, 6.898222, 29.370140662161738) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel101.Parent = workspace.devices.selsins
newmodel102 = workspace.prefabs.wwerselsin:clone()
newmodel102:PivotTo(CFrame.new(-15.867334876526012, 6.898222, 29.773998962138535) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel102.Parent = workspace.devices.selsins
newmodel103 = workspace.prefabs.wwerselsin:clone()
newmodel103:PivotTo(CFrame.new(-16.811735815220764, 6.898222, 30.611802607764147) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel103.Parent = workspace.devices.selsins
newmodel104 = workspace.prefabs.wwerselsin:clone()
newmodel104:PivotTo(CFrame.new(-17.237597803031655, 6.898222, 30.9782310403424) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel104.Parent = workspace.devices.selsins
newmodel105 = workspace.prefabs.wwerselsin:clone()
newmodel105:PivotTo(CFrame.new(-17.663459790842545, 6.898222, 31.34465947292066) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel105.Parent = workspace.devices.selsins
newmodel106 = workspace.prefabs.wwerselsin:clone()
newmodel106:PivotTo(CFrame.new(-18.61966652245112, 6.898222, 32.14186171972182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel106.Parent = workspace.devices.selsins
newmodel107 = workspace.prefabs.wwerselsin:clone()
newmodel107:PivotTo(CFrame.new(-19.077270783085147, 6.898222, 32.467785897274794) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel107.Parent = workspace.devices.selsins
newmodel108 = workspace.prefabs.wwerselsin:clone()
newmodel108:PivotTo(CFrame.new(-19.534875043719175, 6.898222, 32.793710074827764) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel108.Parent = workspace.devices.selsins
newmodel109 = workspace.prefabs.wwerselsin:clone()
newmodel109:PivotTo(CFrame.new(-14.890968198466958, 6.691923999999999, 28.764353212196546) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel109.Parent = workspace.devices.selsins
newmodel110 = workspace.prefabs.wwerselsin:clone()
newmodel110:PivotTo(CFrame.new(-15.281514869690579, 6.691923999999999, 29.168211512173343) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel110.Parent = workspace.devices.selsins
newmodel111 = workspace.prefabs.wwerselsin:clone()
newmodel111:PivotTo(CFrame.new(-15.6720615409142, 6.691923999999999, 29.57206981215014) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel111.Parent = workspace.devices.selsins
newmodel112 = workspace.prefabs.wwerselsin:clone()
newmodel112:PivotTo(CFrame.new(-16.17294283350443, 6.691923999999999, 30.062159958896764) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel112.Parent = workspace.devices.selsins
newmodel113 = workspace.prefabs.wwerselsin:clone()
newmodel113:PivotTo(CFrame.new(-16.59880482131532, 6.691923999999999, 30.42858839147502) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel113.Parent = workspace.devices.selsins
newmodel114 = workspace.prefabs.wwerselsin:clone()
newmodel114:PivotTo(CFrame.new(-17.02466680912621, 6.691923999999999, 30.795016824053278) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel114.Parent = workspace.devices.selsins
newmodel115 = workspace.prefabs.wwerselsin:clone()
newmodel115:PivotTo(CFrame.new(-17.4505287969371, 6.691923999999999, 31.16144525663153) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel115.Parent = workspace.devices.selsins
newmodel116 = workspace.prefabs.wwerselsin:clone()
newmodel116:PivotTo(CFrame.new(-17.87639078474799, 6.691923999999999, 31.527873689209784) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel116.Parent = workspace.devices.selsins
newmodel117 = workspace.prefabs.wwerselsin:clone()
newmodel117:PivotTo(CFrame.new(-18.30225277255888, 6.691923999999999, 31.894302121788044) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel117.Parent = workspace.devices.selsins
newmodel118 = workspace.prefabs.wwerselsin:clone()
newmodel118:PivotTo(CFrame.new(-18.848468652768133, 6.691923999999999, 32.3048238084983) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel118.Parent = workspace.devices.selsins
newmodel119 = workspace.prefabs.wwerselsin:clone()
newmodel119:PivotTo(CFrame.new(-19.30607291340216, 6.691923999999999, 32.630747986051276) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel119.Parent = workspace.devices.selsins
newmodel120 = workspace.prefabs.wwerselsin:clone()
newmodel120:PivotTo(CFrame.new(-19.76367717403619, 6.691923999999999, 32.95667216360425) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel120.Parent = workspace.devices.selsins
newmodel121 = workspace.prefabs.wwerselsin:clone()
newmodel121.usp.Value = true
newmodel121:PivotTo(CFrame.new(-15.08624153407877, 6.485626000000001, 28.96628236218494) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel121.Parent = workspace.devices.selsins
newmodel122 = workspace.prefabs.wwerselsin:clone()
newmodel122:PivotTo(CFrame.new(-15.476788205302391, 6.485626000000001, 29.370140662161738) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel122.Parent = workspace.devices.selsins
newmodel123 = workspace.prefabs.wwerselsin:clone()
newmodel123.usp.Value = true
newmodel123:PivotTo(CFrame.new(-15.867334876526012, 6.485626000000001, 29.773998962138535) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel123.Parent = workspace.devices.selsins
newmodel124 = workspace.prefabs.wwerselsin:clone()
newmodel124:PivotTo(CFrame.new(-16.385873827409874, 6.485626000000001, 30.245374175185894) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel124.Parent = workspace.devices.selsins
newmodel125 = workspace.prefabs.wwerselsin:clone()
newmodel125.usp.Value = true
newmodel125:PivotTo(CFrame.new(-16.811735815220764, 6.485626000000001, 30.611802607764147) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel125.Parent = workspace.devices.selsins
newmodel126 = workspace.prefabs.wwerselsin:clone()
newmodel126:PivotTo(CFrame.new(-17.237597803031655, 6.485626000000001, 30.9782310403424) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel126.Parent = workspace.devices.selsins
newmodel127 = workspace.prefabs.wwerselsin:clone()
newmodel127.usp.Value = true
newmodel127:PivotTo(CFrame.new(-17.663459790842545, 6.485626000000001, 31.34465947292066) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel127.Parent = workspace.devices.selsins
newmodel128 = workspace.prefabs.wwerselsin:clone()
newmodel128:PivotTo(CFrame.new(-18.089321778653435, 6.485626000000001, 31.711087905498914) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel128.Parent = workspace.devices.selsins
newmodel129 = workspace.prefabs.wwerselsin:clone()
newmodel129.usp.Value = true
newmodel129:PivotTo(CFrame.new(-18.61966652245112, 6.485626000000001, 32.14186171972182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel129.Parent = workspace.devices.selsins
newmodel130 = workspace.prefabs.wwerselsin:clone()
newmodel130:PivotTo(CFrame.new(-19.077270783085147, 6.485626000000001, 32.467785897274794) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel130.Parent = workspace.devices.selsins
newmodel131 = workspace.prefabs.wwerselsin:clone()
newmodel131.usp.Value = true
newmodel131:PivotTo(CFrame.new(-19.534875043719175, 6.485626000000001, 32.793710074827764) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel131.Parent = workspace.devices.selsins
newmodel132 = workspace.prefabs.wwerselsin:clone()
newmodel132:PivotTo(CFrame.new(-14.890968198466958, 6.279327999999999, 28.764353212196546) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel132.Parent = workspace.devices.selsins
newmodel133 = workspace.prefabs.wwerselsin:clone()
newmodel133:PivotTo(CFrame.new(-15.281514869690579, 6.279327999999999, 29.168211512173343) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel133.Parent = workspace.devices.selsins
newmodel134 = workspace.prefabs.wwerselsin:clone()
newmodel134:PivotTo(CFrame.new(-15.6720615409142, 6.279327999999999, 29.57206981215014) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel134.Parent = workspace.devices.selsins
newmodel135 = workspace.prefabs.wwerselsin:clone()
newmodel135:PivotTo(CFrame.new(-16.17294283350443, 6.279327999999999, 30.062159958896764) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel135.Parent = workspace.devices.selsins
newmodel136 = workspace.prefabs.wwerselsin:clone()
newmodel136:PivotTo(CFrame.new(-16.59880482131532, 6.279327999999999, 30.42858839147502) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel136.Parent = workspace.devices.selsins
newmodel137 = workspace.prefabs.wwerselsin:clone()
newmodel137:PivotTo(CFrame.new(-17.02466680912621, 6.279327999999999, 30.795016824053278) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel137.Parent = workspace.devices.selsins
newmodel138 = workspace.prefabs.wwerselsin:clone()
newmodel138:PivotTo(CFrame.new(-17.4505287969371, 6.279327999999999, 31.16144525663153) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel138.Parent = workspace.devices.selsins
newmodel139 = workspace.prefabs.wwerselsin:clone()
newmodel139:PivotTo(CFrame.new(-17.87639078474799, 6.279327999999999, 31.527873689209784) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel139.Parent = workspace.devices.selsins
newmodel140 = workspace.prefabs.wwerselsin:clone()
newmodel140:PivotTo(CFrame.new(-18.30225277255888, 6.279327999999999, 31.894302121788044) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel140.Parent = workspace.devices.selsins
newmodel141 = workspace.prefabs.wwerselsin:clone()
newmodel141:PivotTo(CFrame.new(-18.848468652768133, 6.279327999999999, 32.3048238084983) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel141.Parent = workspace.devices.selsins
newmodel142 = workspace.prefabs.wwerselsin:clone()
newmodel142:PivotTo(CFrame.new(-19.30607291340216, 6.279327999999999, 32.630747986051276) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel142.Parent = workspace.devices.selsins
newmodel143 = workspace.prefabs.wwerselsin:clone()
newmodel143:PivotTo(CFrame.new(-19.76367717403619, 6.279327999999999, 32.95667216360425) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel143.Parent = workspace.devices.selsins
newmodel144 = workspace.prefabs.wwerselsin:clone()
newmodel144:PivotTo(CFrame.new(-15.08624153407877, 6.07303, 28.96628236218494) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel144.Parent = workspace.devices.selsins
newmodel145 = workspace.prefabs.wwerselsin:clone()
newmodel145:PivotTo(CFrame.new(-15.867334876526012, 6.07303, 29.773998962138535) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel145.Parent = workspace.devices.selsins
newmodel146 = workspace.prefabs.wwerselsin:clone()
newmodel146:PivotTo(CFrame.new(-16.385873827409874, 6.07303, 30.245374175185894) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel146.Parent = workspace.devices.selsins
newmodel147 = workspace.prefabs.wwerselsin:clone()
newmodel147:PivotTo(CFrame.new(-16.811735815220764, 6.07303, 30.611802607764147) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel147.Parent = workspace.devices.selsins
newmodel148 = workspace.prefabs.wwerselsin:clone()
newmodel148:PivotTo(CFrame.new(-17.663459790842545, 6.07303, 31.34465947292066) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel148.Parent = workspace.devices.selsins
newmodel149 = workspace.prefabs.wwerselsin:clone()
newmodel149:PivotTo(CFrame.new(-18.089321778653435, 6.07303, 31.711087905498914) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel149.Parent = workspace.devices.selsins
newmodel150 = workspace.prefabs.wwerselsin:clone()
newmodel150:PivotTo(CFrame.new(-18.61966652245112, 6.07303, 32.14186171972182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel150.Parent = workspace.devices.selsins
newmodel151 = workspace.prefabs.wwerselsin:clone()
newmodel151:PivotTo(CFrame.new(-19.534875043719175, 6.07303, 32.793710074827764) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel151.Parent = workspace.devices.selsins
newmodel152 = workspace.prefabs.wwerselsin:clone()
newmodel152:PivotTo(CFrame.new(-15.281514869690579, 5.866732, 29.168211512173343) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel152.Parent = workspace.devices.selsins
newmodel153 = workspace.prefabs.wwerselsin:clone()
newmodel153:PivotTo(CFrame.new(-15.6720615409142, 5.866732, 29.57206981215014) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel153.Parent = workspace.devices.selsins
newmodel154 = workspace.prefabs.wwerselsin:clone()
newmodel154:PivotTo(CFrame.new(-16.17294283350443, 5.866732, 30.062159958896764) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel154.Parent = workspace.devices.selsins
newmodel155 = workspace.prefabs.wwerselsin:clone()
newmodel155:PivotTo(CFrame.new(-16.59880482131532, 5.866732, 30.42858839147502) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel155.Parent = workspace.devices.selsins
newmodel156 = workspace.prefabs.wwerselsin:clone()
newmodel156:PivotTo(CFrame.new(-17.02466680912621, 5.866732, 30.795016824053278) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel156.Parent = workspace.devices.selsins
newmodel157 = workspace.prefabs.wwerselsin:clone()
newmodel157:PivotTo(CFrame.new(-17.4505287969371, 5.866732, 31.16144525663153) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel157.Parent = workspace.devices.selsins
newmodel158 = workspace.prefabs.wwerselsin:clone()
newmodel158:PivotTo(CFrame.new(-17.87639078474799, 5.866732, 31.527873689209784) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel158.Parent = workspace.devices.selsins
newmodel159 = workspace.prefabs.wwerselsin:clone()
newmodel159:PivotTo(CFrame.new(-18.30225277255888, 5.866732, 31.894302121788044) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel159.Parent = workspace.devices.selsins
newmodel160 = workspace.prefabs.wwerselsin:clone()
newmodel160:PivotTo(CFrame.new(-18.848468652768133, 5.866732, 32.3048238084983) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel160.Parent = workspace.devices.selsins
newmodel161 = workspace.prefabs.wwerselsin:clone()
newmodel161:PivotTo(CFrame.new(-19.30607291340216, 5.866732, 32.630747986051276) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel161.Parent = workspace.devices.selsins
newmodel162 = workspace.prefabs.wwerselsin:clone()
newmodel162:PivotTo(CFrame.new(-19.76367717403619, 5.866732, 32.95667216360425) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel162.Parent = workspace.devices.selsins
newmodel163 = workspace.prefabs.wwerselsin:clone()
newmodel163.usp.Value = true
newmodel163:PivotTo(CFrame.new(-15.08624153407877, 5.6604339999999995, 28.96628236218494) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel163.Parent = workspace.devices.selsins
newmodel164 = workspace.prefabs.wwerselsin:clone()
newmodel164:PivotTo(CFrame.new(-15.476788205302391, 5.6604339999999995, 29.370140662161738) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel164.Parent = workspace.devices.selsins
newmodel165 = workspace.prefabs.wwerselsin:clone()
newmodel165.usp.Value = true
newmodel165:PivotTo(CFrame.new(-15.867334876526012, 5.6604339999999995, 29.773998962138535) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel165.Parent = workspace.devices.selsins
newmodel166 = workspace.prefabs.wwerselsin:clone()
newmodel166:PivotTo(CFrame.new(-16.385873827409874, 5.6604339999999995, 30.245374175185894) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel166.Parent = workspace.devices.selsins
newmodel167 = workspace.prefabs.wwerselsin:clone()
newmodel167.usp.Value = true
newmodel167:PivotTo(CFrame.new(-16.811735815220764, 5.6604339999999995, 30.611802607764147) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel167.Parent = workspace.devices.selsins
newmodel168 = workspace.prefabs.wwerselsin:clone()
newmodel168:PivotTo(CFrame.new(-17.237597803031655, 5.6604339999999995, 30.9782310403424) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel168.Parent = workspace.devices.selsins
newmodel169 = workspace.prefabs.wwerselsin:clone()
newmodel169.usp.Value = true
newmodel169:PivotTo(CFrame.new(-17.663459790842545, 5.6604339999999995, 31.34465947292066) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel169.Parent = workspace.devices.selsins
newmodel170 = workspace.prefabs.wwerselsin:clone()
newmodel170:PivotTo(CFrame.new(-18.089321778653435, 5.6604339999999995, 31.711087905498914) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel170.Parent = workspace.devices.selsins
newmodel171 = workspace.prefabs.wwerselsin:clone()
newmodel171.usp.Value = true
newmodel171:PivotTo(CFrame.new(-18.61966652245112, 5.6604339999999995, 32.14186171972182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel171.Parent = workspace.devices.selsins
newmodel172 = workspace.prefabs.wwerselsin:clone()
newmodel172:PivotTo(CFrame.new(-19.077270783085147, 5.6604339999999995, 32.467785897274794) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel172.Parent = workspace.devices.selsins
newmodel173 = workspace.prefabs.wwerselsin:clone()
newmodel173.usp.Value = true
newmodel173:PivotTo(CFrame.new(-19.534875043719175, 5.6604339999999995, 32.793710074827764) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel173.Parent = workspace.devices.selsins
newmodel174 = workspace.prefabs.wwerselsin:clone()
newmodel174:PivotTo(CFrame.new(-15.281514869690579, 5.454136, 29.168211512173343) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel174.Parent = workspace.devices.selsins
newmodel175 = workspace.prefabs.wwerselsin:clone()
newmodel175:PivotTo(CFrame.new(-15.6720615409142, 5.454136, 29.57206981215014) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel175.Parent = workspace.devices.selsins
newmodel176 = workspace.prefabs.wwerselsin:clone()
newmodel176:PivotTo(CFrame.new(-16.17294283350443, 5.454136, 30.062159958896764) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel176.Parent = workspace.devices.selsins
newmodel177 = workspace.prefabs.wwerselsin:clone()
newmodel177:PivotTo(CFrame.new(-16.59880482131532, 5.454136, 30.42858839147502) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel177.Parent = workspace.devices.selsins
newmodel178 = workspace.prefabs.wwerselsin:clone()
newmodel178:PivotTo(CFrame.new(-17.02466680912621, 5.454136, 30.795016824053278) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel178.Parent = workspace.devices.selsins
newmodel179 = workspace.prefabs.wwerselsin:clone()
newmodel179:PivotTo(CFrame.new(-17.4505287969371, 5.454136, 31.16144525663153) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel179.Parent = workspace.devices.selsins
newmodel180 = workspace.prefabs.wwerselsin:clone()
newmodel180:PivotTo(CFrame.new(-17.87639078474799, 5.454136, 31.527873689209784) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel180.Parent = workspace.devices.selsins
newmodel181 = workspace.prefabs.wwerselsin:clone()
newmodel181:PivotTo(CFrame.new(-18.30225277255888, 5.454136, 31.894302121788044) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel181.Parent = workspace.devices.selsins
newmodel182 = workspace.prefabs.wwerselsin:clone()
newmodel182:PivotTo(CFrame.new(-18.848468652768133, 5.454136, 32.3048238084983) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel182.Parent = workspace.devices.selsins
newmodel183 = workspace.prefabs.wwerselsin:clone()
newmodel183:PivotTo(CFrame.new(-19.30607291340216, 5.454136, 32.630747986051276) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel183.Parent = workspace.devices.selsins
newmodel184 = workspace.prefabs.wwerselsin:clone()
newmodel184:PivotTo(CFrame.new(-15.476788205302391, 5.247838, 29.370140662161738) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel184.Parent = workspace.devices.selsins
newmodel185 = workspace.prefabs.wwerselsin:clone()
newmodel185:PivotTo(CFrame.new(-15.867334876526012, 5.247838, 29.773998962138535) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel185.Parent = workspace.devices.selsins
newmodel186 = workspace.prefabs.wwerselsin:clone()
newmodel186:PivotTo(CFrame.new(-16.811735815220764, 5.247838, 30.611802607764147) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel186.Parent = workspace.devices.selsins
newmodel187 = workspace.prefabs.wwerselsin:clone()
newmodel187:PivotTo(CFrame.new(-17.237597803031655, 5.247838, 30.9782310403424) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel187.Parent = workspace.devices.selsins
newmodel188 = workspace.prefabs.wwerselsin:clone()
newmodel188:PivotTo(CFrame.new(-17.663459790842545, 5.247838, 31.34465947292066) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel188.Parent = workspace.devices.selsins
newmodel189 = workspace.prefabs.wwerselsin:clone()
newmodel189:PivotTo(CFrame.new(-18.61966652245112, 5.247838, 32.14186171972182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel189.Parent = workspace.devices.selsins
newmodel190 = workspace.prefabs.wwerselsin:clone()
newmodel190:PivotTo(CFrame.new(-19.077270783085147, 5.247838, 32.467785897274794) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel190.Parent = workspace.devices.selsins
newmodel191 = workspace.prefabs.wwerselsin:clone()
newmodel191:PivotTo(CFrame.new(-15.6720615409142, 5.0415399999999995, 29.57206981215014) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel191.Parent = workspace.devices.selsins
newmodel192 = workspace.prefabs.wwerselsin:clone()
newmodel192:PivotTo(CFrame.new(-16.17294283350443, 5.0415399999999995, 30.062159958896764) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel192.Parent = workspace.devices.selsins
newmodel193 = workspace.prefabs.wwerselsin:clone()
newmodel193:PivotTo(CFrame.new(-16.59880482131532, 5.0415399999999995, 30.42858839147502) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel193.Parent = workspace.devices.selsins
newmodel194 = workspace.prefabs.wwerselsin:clone()
newmodel194:PivotTo(CFrame.new(-17.02466680912621, 5.0415399999999995, 30.795016824053278) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel194.Parent = workspace.devices.selsins
newmodel195 = workspace.prefabs.wwerselsin:clone()
newmodel195:PivotTo(CFrame.new(-17.4505287969371, 5.0415399999999995, 31.16144525663153) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel195.Parent = workspace.devices.selsins
newmodel196 = workspace.prefabs.wwerselsin:clone()
newmodel196:PivotTo(CFrame.new(-17.87639078474799, 5.0415399999999995, 31.527873689209784) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel196.Parent = workspace.devices.selsins
newmodel197 = workspace.prefabs.wwerselsin:clone()
newmodel197:PivotTo(CFrame.new(-18.30225277255888, 5.0415399999999995, 31.894302121788044) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel197.Parent = workspace.devices.selsins
newmodel198 = workspace.prefabs.wwerselsin:clone()
newmodel198:PivotTo(CFrame.new(-18.848468652768133, 5.0415399999999995, 32.3048238084983) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel198.Parent = workspace.devices.selsins
newmodel199 = workspace.prefabs.wwerselsin:clone()
newmodel199.usp.Value = true
newmodel199:PivotTo(CFrame.new(-15.867334876526012, 4.835241999999999, 29.773998962138535) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel199.Parent = workspace.devices.selsins
newmodel200 = workspace.prefabs.wwerselsin:clone()
newmodel200:PivotTo(CFrame.new(-16.385873827409874, 4.835241999999999, 30.245374175185894) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel200.Parent = workspace.devices.selsins
newmodel201 = workspace.prefabs.wwerselsin:clone()
newmodel201.usp.Value = true
newmodel201:PivotTo(CFrame.new(-16.811735815220764, 4.835241999999999, 30.611802607764147) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel201.Parent = workspace.devices.selsins
newmodel202 = workspace.prefabs.wwerselsin:clone()
newmodel202:PivotTo(CFrame.new(-17.237597803031655, 4.835241999999999, 30.9782310403424) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel202.Parent = workspace.devices.selsins
newmodel203 = workspace.prefabs.wwerselsin:clone()
newmodel203.usp.Value = true
newmodel203:PivotTo(CFrame.new(-17.663459790842545, 4.835241999999999, 31.34465947292066) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel203.Parent = workspace.devices.selsins
newmodel204 = workspace.prefabs.wwerselsin:clone()
newmodel204:PivotTo(CFrame.new(-18.089321778653435, 4.835241999999999, 31.711087905498914) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel204.Parent = workspace.devices.selsins
newmodel205 = workspace.prefabs.wwerselsin:clone()
newmodel205.usp.Value = true
newmodel205:PivotTo(CFrame.new(-18.61966652245112, 4.835241999999999, 32.14186171972182) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel205.Parent = workspace.devices.selsins
newmodel206 = workspace.prefabs.wwerselsin:clone()
newmodel206:PivotTo(CFrame.new(-16.59880482131532, 4.628944, 30.42858839147502) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel206.Parent = workspace.devices.selsins
newmodel207 = workspace.prefabs.wwerselsin:clone()
newmodel207:PivotTo(CFrame.new(-17.02466680912621, 4.628944, 30.795016824053278) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel207.Parent = workspace.devices.selsins
newmodel208 = workspace.prefabs.wwerselsin:clone()
newmodel208:PivotTo(CFrame.new(-17.4505287969371, 4.628944, 31.16144525663153) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel208.Parent = workspace.devices.selsins
newmodel209 = workspace.prefabs.wwerselsin:clone()
newmodel209:PivotTo(CFrame.new(-17.87639078474799, 4.628944, 31.527873689209784) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel209.Parent = workspace.devices.selsins
newmodel210 = workspace.prefabs.wwerselsin:clone()
newmodel210:PivotTo(CFrame.new(-18.30225277255888, 4.628944, 31.894302121788044) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel210.Parent = workspace.devices.selsins
