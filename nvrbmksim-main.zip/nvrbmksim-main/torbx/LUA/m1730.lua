newmodel0 = workspace.prefabs.m1730:clone()
newmodel0:PivotTo(CFrame.new(-28.783759928370102, 3.6035809339230993, 32.63343621407589) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel0.Parent = workspace.devices.m1730
newmodel1 = workspace.prefabs.m1730:clone()
newmodel1:PivotTo(CFrame.new(-28.7900875574124, 3.511560497481639, 32.61849519711499) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel1.Parent = workspace.devices.m1730
newmodel2 = workspace.prefabs.m1730:clone()
newmodel2:PivotTo(CFrame.new(-29.32247173608747, 3.511560497481639, 32.8439637578867) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel2.Parent = workspace.devices.m1730
newmodel3 = workspace.prefabs.m1730:clone()
newmodel3:PivotTo(CFrame.new(-29.335126994172054, 3.3275196245987173, 32.814081723964875) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel3.Parent = workspace.devices.m1730
newmodel4 = workspace.prefabs.m1730:clone()
newmodel4:PivotTo(CFrame.new(-29.347782252256643, 3.1434787517157963, 32.78419969004306) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel4.Parent = workspace.devices.m1730
newmodel5 = workspace.prefabs.m1730:clone()
newmodel5:PivotTo(CFrame.new(-29.31614410704517, 3.6035809339230993, 32.85890477484761) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel5.Parent = workspace.devices.m1730
newmodel6 = workspace.prefabs.m1730:clone()
newmodel6:PivotTo(CFrame.new(-29.32879936512976, 3.4195400610401783, 32.829022740925794) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel6.Parent = workspace.devices.m1730
newmodel7 = workspace.prefabs.m1730:clone()
newmodel7:PivotTo(CFrame.new(-29.341454623214346, 3.235499188157257, 32.79914070700397) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel7.Parent = workspace.devices.m1730
newmodel8 = workspace.prefabs.m1730:clone()
newmodel8:PivotTo(CFrame.new(-28.796415186454688, 3.4195400610401783, 32.60355418015408) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel8.Parent = workspace.devices.m1730
newmodel9 = workspace.prefabs.m1730:clone()
newmodel9:PivotTo(CFrame.new(-28.802742815496984, 3.3275196245987173, 32.588613163193166) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel9.Parent = workspace.devices.m1730
newmodel10 = workspace.prefabs.m1730:clone()
newmodel10:PivotTo(CFrame.new(-28.809070444539273, 3.235499188157257, 32.573672146232255) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel10.Parent = workspace.devices.m1730
newmodel11 = workspace.prefabs.m1730:clone()
newmodel11:PivotTo(CFrame.new(-28.815398073581573, 3.1434787517157963, 32.558731129271344) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel11.Parent = workspace.devices.m1730
newmodel12 = workspace.prefabs.m1730:clone()
newmodel12:PivotTo(CFrame.new(-28.239992951175182, 3.1434787517157963, 32.31504288682111) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel12.Parent = workspace.devices.m1730
newmodel13 = workspace.prefabs.m1730:clone()
newmodel13:PivotTo(CFrame.new(-28.233665322132886, 3.235499188157257, 32.32998390378202) * CFrame.fromEulerAngles(0, math.rad(-67.04699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel13.Parent = workspace.devices.m1730
newmodel14 = workspace.prefabs.m1730:clone()
newmodel14:PivotTo(CFrame.new(-48.741786567191056, 3.6035809339230993, 34.49465745984994) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel14.Parent = workspace.devices.m1730
newmodel15 = workspace.prefabs.m1730:clone()
newmodel15:PivotTo(CFrame.new(-48.73787041050449, 3.512710752937157, 34.47912053903569) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel15.Parent = workspace.devices.m1730
newmodel16 = workspace.prefabs.m1730:clone()
newmodel16:PivotTo(CFrame.new(-48.733954253817934, 3.421840571951215, 34.463583618221435) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel16.Parent = workspace.devices.m1730
newmodel17 = workspace.prefabs.m1730:clone()
newmodel17:PivotTo(CFrame.new(-48.73003809713138, 3.330970390965272, 34.44804669740718) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel17.Parent = workspace.devices.m1730
newmodel18 = workspace.prefabs.m1730:clone()
newmodel18:PivotTo(CFrame.new(-48.72612194044482, 3.24010020997933, 34.43250977659292) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel18.Parent = workspace.devices.m1730
newmodel19 = workspace.prefabs.m1730:clone()
newmodel19:PivotTo(CFrame.new(-49.38627058345861, 3.512710752937157, 34.31568811228667) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel19.Parent = workspace.devices.m1730
newmodel20 = workspace.prefabs.m1730:clone()
newmodel20:PivotTo(CFrame.new(-49.378438270085496, 3.330970390965272, 34.28461427065816) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel20.Parent = workspace.devices.m1730
newmodel21 = workspace.prefabs.m1730:clone()
newmodel21:PivotTo(CFrame.new(-49.390186740145175, 3.6035809339230993, 34.33122503310092) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel21.Parent = workspace.devices.m1730
newmodel22 = workspace.prefabs.m1730:clone()
newmodel22:PivotTo(CFrame.new(-49.382354426772054, 3.421840571951215, 34.300151191472416) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel22.Parent = workspace.devices.m1730
newmodel23 = workspace.prefabs.m1730:clone()
newmodel23:PivotTo(CFrame.new(-49.37452211339893, 3.24010020997933, 34.269077349843904) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel23.Parent = workspace.devices.m1730
newmodel24 = workspace.prefabs.m1730:clone()
newmodel24:PivotTo(CFrame.new(-49.37060595671238, 3.1492300289933874, 34.253540429029655) * CFrame.fromEulerAngles(0, math.rad(-104.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel24.Parent = workspace.devices.m1730
newmodel25 = workspace.prefabs.m1730:clone()
newmodel25:PivotTo(CFrame.new(-18.096805006516973, 3.525938690675617, 24.857198653026813) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel25.Parent = workspace.devices.m1730
newmodel26 = workspace.prefabs.m1730:clone()
newmodel26:PivotTo(CFrame.new(-18.109134466058848, 3.4339182542341566, 24.846650795209783) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel26.Parent = workspace.devices.m1730
newmodel27 = workspace.prefabs.m1730:clone()
newmodel27:PivotTo(CFrame.new(-18.121463925600725, 3.3418978177926957, 24.83610293739275) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel27.Parent = workspace.devices.m1730
newmodel28 = workspace.prefabs.m1730:clone()
newmodel28:PivotTo(CFrame.new(-18.133793385142603, 3.249877381351235, 24.825555079575718) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel28.Parent = workspace.devices.m1730
newmodel29 = workspace.prefabs.m1730:clone()
newmodel29:PivotTo(CFrame.new(-18.146122844684477, 3.1578569449097746, 24.815007221758684) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel29.Parent = workspace.devices.m1730
newmodel30 = workspace.prefabs.m1730:clone()
newmodel30:PivotTo(CFrame.new(-18.158452304226355, 3.0658365084683137, 24.804459363941653) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel30.Parent = workspace.devices.m1730
newmodel31 = workspace.prefabs.m1730:clone()
newmodel31:PivotTo(CFrame.new(-17.71126333969718, 3.2441261040736435, 24.330096973672138) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel31.Parent = workspace.devices.m1730
newmodel32 = workspace.prefabs.m1730:clone()
newmodel32:PivotTo(CFrame.new(-17.735151667559563, 3.0658365084683137, 24.309660499151637) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel32.Parent = workspace.devices.m1730
newmodel33 = workspace.prefabs.m1730:clone()
newmodel33:PivotTo(CFrame.new(-17.72320750362837, 3.154981306270979, 24.319878736411887) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel33.Parent = workspace.devices.m1730
newmodel34 = workspace.prefabs.m1730:clone()
newmodel34:PivotTo(CFrame.new(-16.883644157693944, 3.2441261040736435, 23.362687533993) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel34.Parent = workspace.devices.m1730
newmodel35 = workspace.prefabs.m1730:clone()
newmodel35:PivotTo(CFrame.new(-16.90753248555633, 3.0658365084683137, 23.342251059472503) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel35.Parent = workspace.devices.m1730
newmodel36 = workspace.prefabs.m1730:clone()
newmodel36:PivotTo(CFrame.new(-16.895588321625137, 3.154981306270979, 23.35246929673275) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel36.Parent = workspace.devices.m1730
newmodel37 = workspace.prefabs.m1730:clone()
newmodel37:PivotTo(CFrame.new(-31.772618902122275, 3.5144361361204344, 33.759090217884534) * CFrame.fromEulerAngles(0, math.rad(-72.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel37.Parent = workspace.devices.m1730
newmodel38 = workspace.prefabs.m1730:clone()
newmodel38:PivotTo(CFrame.new(-31.77753936812691, 3.422415699678974, 33.74362859146878) * CFrame.fromEulerAngles(0, math.rad(-72.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel38.Parent = workspace.devices.m1730
newmodel39 = workspace.prefabs.m1730:clone()
newmodel39:PivotTo(CFrame.new(-31.782459834131547, 3.3303952632375133, 33.72816696505302) * CFrame.fromEulerAngles(0, math.rad(-72.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel39.Parent = workspace.devices.m1730
newmodel40 = workspace.prefabs.m1730:clone()
newmodel40:PivotTo(CFrame.new(-31.787380300136178, 3.238374826796052, 33.71270533863727) * CFrame.fromEulerAngles(0, math.rad(-72.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel40.Parent = workspace.devices.m1730
newmodel41 = workspace.prefabs.m1730:clone()
newmodel41:PivotTo(CFrame.new(-31.792300766140812, 3.146354390354592, 33.697243712221514) * CFrame.fromEulerAngles(0, math.rad(-72.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel41.Parent = workspace.devices.m1730
newmodel42 = workspace.prefabs.m1730:clone()
newmodel42:PivotTo(CFrame.new(-32.612288972730994, 3.422415699678974, 34.0092770388825) * CFrame.fromEulerAngles(0, math.rad(-72.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel42.Parent = workspace.devices.m1730
newmodel43 = workspace.prefabs.m1730:clone()
newmodel43:PivotTo(CFrame.new(-32.62212990474026, 3.238374826796052, 33.978353786050995) * CFrame.fromEulerAngles(0, math.rad(-72.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel43.Parent = workspace.devices.m1730
newmodel44 = workspace.prefabs.m1730:clone()
newmodel44:PivotTo(CFrame.new(-32.60736850672636, 3.5144361361204344, 34.02473866529826) * CFrame.fromEulerAngles(0, math.rad(-72.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel44.Parent = workspace.devices.m1730
newmodel45 = workspace.prefabs.m1730:clone()
newmodel45:PivotTo(CFrame.new(-32.617209438735635, 3.3303952632375133, 33.993815412466745) * CFrame.fromEulerAngles(0, math.rad(-72.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel45.Parent = workspace.devices.m1730
newmodel46 = workspace.prefabs.m1730:clone()
newmodel46:PivotTo(CFrame.new(-32.6270503707449, 3.146354390354592, 33.96289215963524) * CFrame.fromEulerAngles(0, math.rad(-72.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel46.Parent = workspace.devices.m1730
newmodel47 = workspace.prefabs.m1730:clone()
newmodel47:PivotTo(CFrame.new(-50.944339986369684, 3.6035809339230993, 33.85592840134066) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel47.Parent = workspace.devices.m1730
newmodel48 = workspace.prefabs.m1730:clone()
newmodel48:PivotTo(CFrame.new(-50.939022299477884, 3.5129983168010366, 33.84086745577146) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel48.Parent = workspace.devices.m1730
newmodel49 = workspace.prefabs.m1730:clone()
newmodel49:PivotTo(CFrame.new(-50.93370461258608, 3.422415699678974, 33.825806510202256) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel49.Parent = workspace.devices.m1730
newmodel50 = workspace.prefabs.m1730:clone()
newmodel50:PivotTo(CFrame.new(-18.780478133702943, 3.2556286586288263, 25.547565173251108) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel50.Parent = workspace.devices.m1730
newmodel51 = workspace.prefabs.m1730:clone()
newmodel51:PivotTo(CFrame.new(-19.598781442092573, 3.6208347657558737, 26.431777671463898) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel51.Parent = workspace.devices.m1730
newmodel52 = workspace.prefabs.m1730:clone()
newmodel52:PivotTo(CFrame.new(-19.610083878057193, 3.5288143293144127, 26.420136029896284) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel52.Parent = workspace.devices.m1730
newmodel53 = workspace.prefabs.m1730:clone()
newmodel53:PivotTo(CFrame.new(-19.621386314021816, 3.4367938928729522, 26.408494388328677) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel53.Parent = workspace.devices.m1730
newmodel54 = workspace.prefabs.m1730:clone()
newmodel54:PivotTo(CFrame.new(-19.632688749986436, 3.3447734564314917, 26.396852746761066) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel54.Parent = workspace.devices.m1730
newmodel55 = workspace.prefabs.m1730:clone()
newmodel55:PivotTo(CFrame.new(-19.64399118595106, 3.2527530199900303, 26.385211105193456) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel55.Parent = workspace.devices.m1730
newmodel56 = workspace.prefabs.m1730:clone()
newmodel56:PivotTo(CFrame.new(-19.655293621915682, 3.1607325835485702, 26.373569463625845) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel56.Parent = workspace.devices.m1730
newmodel57 = workspace.prefabs.m1730:clone()
newmodel57:PivotTo(CFrame.new(-19.666596057880305, 3.0687121471071093, 26.361927822058234) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel57.Parent = workspace.devices.m1730
newmodel58 = workspace.prefabs.m1730:clone()
newmodel58:PivotTo(CFrame.new(-20.14977911404808, 3.6208347657558737, 26.96672077787766) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel58.Parent = workspace.devices.m1730
newmodel59 = workspace.prefabs.m1730:clone()
newmodel59:PivotTo(CFrame.new(-20.172383985977326, 3.4367938928729522, 26.94343749474244) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel59.Parent = workspace.devices.m1730
newmodel60 = workspace.prefabs.m1730:clone()
newmodel60:PivotTo(CFrame.new(-20.19498885790657, 3.2527530199900303, 26.92015421160722) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel60.Parent = workspace.devices.m1730
newmodel61 = workspace.prefabs.m1730:clone()
newmodel61:PivotTo(CFrame.new(-20.217593729835812, 3.0687121471071093, 26.896870928471998) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel61.Parent = workspace.devices.m1730
newmodel62 = workspace.prefabs.m1730:clone()
newmodel62:PivotTo(CFrame.new(-20.161081550012703, 3.5288143293144127, 26.955079136310047) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel62.Parent = workspace.devices.m1730
newmodel63 = workspace.prefabs.m1730:clone()
newmodel63:PivotTo(CFrame.new(-20.183686421941946, 3.3447734564314917, 26.93179585317483) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel63.Parent = workspace.devices.m1730
newmodel64 = workspace.prefabs.m1730:clone()
newmodel64:PivotTo(CFrame.new(-20.20629129387119, 3.1607325835485702, 26.908512570039612) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel64.Parent = workspace.devices.m1730
newmodel65 = workspace.prefabs.m1730:clone()
newmodel65:PivotTo(CFrame.new(-18.791603969105616, 3.1650460415067636, 25.53610543233299) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel65.Parent = workspace.devices.m1730
newmodel66 = workspace.prefabs.m1730:clone()
newmodel66:PivotTo(CFrame.new(-34.81435639887607, 3.600705381553463, 34.60026426845795) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel66.Parent = workspace.devices.m1730
newmodel67 = workspace.prefabs.m1730:clone()
newmodel67:PivotTo(CFrame.new(-34.81779148904509, 3.5096429928809036, 34.584579257447324) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel67.Parent = workspace.devices.m1730
newmodel68 = workspace.prefabs.m1730:clone()
newmodel68:PivotTo(CFrame.new(-34.82122648700957, 3.418583048501187, 34.56889466745311) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel68.Parent = workspace.devices.m1730
newmodel69 = workspace.prefabs.m1730:clone()
newmodel69:PivotTo(CFrame.new(-34.82466162707752, 3.327519337034853, 34.55320942859831) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel69.Parent = workspace.devices.m1730
newmodel70 = workspace.prefabs.m1730:clone()
newmodel70:PivotTo(CFrame.new(-34.83153171195674, 3.1453970902517367, 34.52183984245287) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel70.Parent = workspace.devices.m1730
newmodel71 = workspace.prefabs.m1730:clone()
newmodel71:PivotTo(CFrame.new(-34.83496625985024, 3.0543339539131313, 34.50615457772315) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel71.Parent = workspace.devices.m1730
newmodel72 = workspace.prefabs.m1730:clone()
newmodel72:PivotTo(CFrame.new(-35.47040840896261, 3.6007054678226225, 34.74394271745216) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel72.Parent = workspace.devices.m1730
newmodel73 = workspace.prefabs.m1730:clone()
newmodel73:PivotTo(CFrame.new(-35.477272945662186, 3.4186773694485395, 34.71258891058666) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel73.Parent = workspace.devices.m1730
newmodel74 = workspace.prefabs.m1730:clone()
newmodel74:PivotTo(CFrame.new(-35.484149168318304, 3.236362167312759, 34.68118583903513) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel74.Parent = workspace.devices.m1730
newmodel75 = workspace.prefabs.m1730:clone()
newmodel75:PivotTo(CFrame.new(-35.49101685784048, 3.054333666349267, 34.64983264998259) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel75.Parent = workspace.devices.m1730
newmodel76 = workspace.prefabs.m1730:clone()
newmodel76:PivotTo(CFrame.new(-35.473843973744394, 3.509547320383391, 34.72824052534761) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel76.Parent = workspace.devices.m1730
newmodel77 = workspace.prefabs.m1730:clone()
newmodel77:PivotTo(CFrame.new(-35.48757812721898, 3.1454925614545446, 34.66553428371179) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel77.Parent = workspace.devices.m1730
newmodel78 = workspace.prefabs.m1730:clone()
newmodel78:PivotTo(CFrame.new(-52.65109071612589, 3.5978296566455086, 33.22007876608383) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel78.Parent = workspace.devices.m1730
newmodel79 = workspace.prefabs.m1730:clone()
newmodel79:PivotTo(CFrame.new(-53.46520623259037, 3.5978296566455086, 32.84481805744012) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel79.Parent = workspace.devices.m1730
newmodel80 = workspace.prefabs.m1730:clone()
newmodel80:PivotTo(CFrame.new(-54.28197359112802, 3.5978296566455086, 32.46833500121126) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel80.Parent = workspace.devices.m1730
newmodel81 = workspace.prefabs.m1730:clone()
newmodel81:PivotTo(CFrame.new(-54.27518132134759, 3.505809220204047, 32.453599399820305) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel81.Parent = workspace.devices.m1730
newmodel82 = workspace.prefabs.m1730:clone()
newmodel82:PivotTo(CFrame.new(-54.26838905156716, 3.4137887837625867, 32.43886379842935) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel82.Parent = workspace.devices.m1730
newmodel83 = workspace.prefabs.m1730:clone()
newmodel83:PivotTo(CFrame.new(-54.261596781786736, 3.321768347321126, 32.4241281970384) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel83.Parent = workspace.devices.m1730
newmodel84 = workspace.prefabs.m1730:clone()
newmodel84:PivotTo(CFrame.new(-54.25480451200631, 3.229747910879665, 32.409392595647454) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel84.Parent = workspace.devices.m1730
newmodel85 = workspace.prefabs.m1730:clone()
newmodel85:PivotTo(CFrame.new(-54.24801224222588, 3.137727474438205, 32.3946569942565) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel85.Parent = workspace.devices.m1730
newmodel86 = workspace.prefabs.m1730:clone()
newmodel86:PivotTo(CFrame.new(-53.4583874305061, 3.505449765374198, 32.83002489510624) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel86.Parent = workspace.devices.m1730
newmodel87 = workspace.prefabs.m1730:clone()
newmodel87:PivotTo(CFrame.new(-53.45156862842185, 3.413069874102888, 32.815231732772354) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel87.Parent = workspace.devices.m1730
newmodel88 = workspace.prefabs.m1730:clone()
newmodel88:PivotTo(CFrame.new(-53.44474982633759, 3.3206899828315777, 32.80043857043847) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel88.Parent = workspace.devices.m1730
newmodel89 = workspace.prefabs.m1730:clone()
newmodel89:PivotTo(CFrame.new(-53.43793102425334, 3.228310091560267, 32.78564540810459) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel89.Parent = workspace.devices.m1730
newmodel90 = workspace.prefabs.m1730:clone()
newmodel90:PivotTo(CFrame.new(-53.43111222216908, 3.1359302002889575, 32.770852245770705) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel90.Parent = workspace.devices.m1730
newmodel91 = workspace.prefabs.m1730:clone()
newmodel91:PivotTo(CFrame.new(-53.42429342008482, 3.0435503090176472, 32.756059083436824) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel91.Parent = workspace.devices.m1730
newmodel92 = workspace.prefabs.m1730:clone()
newmodel92:PivotTo(CFrame.new(-53.417474618000554, 2.9511704177463374, 32.741265921102936) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel92.Parent = workspace.devices.m1730
newmodel93 = workspace.prefabs.m1730:clone()
newmodel93:PivotTo(CFrame.new(-53.41065581591631, 2.858790526475027, 32.72647275876906) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel93.Parent = workspace.devices.m1730
newmodel94 = workspace.prefabs.m1730:clone()
newmodel94:PivotTo(CFrame.new(-52.644245381737804, 3.5050903105443485, 33.20522804280702) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel94.Parent = workspace.devices.m1730
newmodel95 = workspace.prefabs.m1730:clone()
newmodel95:PivotTo(CFrame.new(-52.637400047349715, 3.412350964443189, 33.1903773195302) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel95.Parent = workspace.devices.m1730
newmodel96 = workspace.prefabs.m1730:clone()
newmodel96:PivotTo(CFrame.new(-52.63055471296163, 3.3196116183420297, 33.175526596253384) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel96.Parent = workspace.devices.m1730
newmodel97 = workspace.prefabs.m1730:clone()
newmodel97:PivotTo(CFrame.new(-52.623709378573544, 3.2268722722408696, 33.16067587297657) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel97.Parent = workspace.devices.m1730
newmodel98 = workspace.prefabs.m1730:clone()
newmodel98:PivotTo(CFrame.new(-20.86848104789662, 3.612207849839487, 27.625718374839327) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel98.Parent = workspace.devices.m1730
newmodel99 = workspace.prefabs.m1730:clone()
newmodel99:PivotTo(CFrame.new(-20.87887198098984, 3.518269362425949, 27.612819112973682) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel99.Parent = workspace.devices.m1730
newmodel100 = workspace.prefabs.m1730:clone()
newmodel100:PivotTo(CFrame.new(-20.889262595996517, 3.4243337506510505, 27.59992024597937) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel100.Parent = workspace.devices.m1730
newmodel101 = workspace.prefabs.m1730:clone()
newmodel101:PivotTo(CFrame.new(-21.823725852341596, 3.5489437997859823, 28.380886548660037) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel101.Parent = workspace.devices.m1730
newmodel102 = workspace.prefabs.m1730:clone()
newmodel102:PivotTo(CFrame.new(-21.84503765070832, 3.356276010986674, 28.35443016928641) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel102.Parent = workspace.devices.m1730
newmodel103 = workspace.prefabs.m1730:clone()
newmodel103:PivotTo(CFrame.new(-21.81322899642963, 3.6438398748662384, 28.39391730267988) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel103.Parent = workspace.devices.m1730
newmodel104 = workspace.prefabs.m1730:clone()
newmodel104:PivotTo(CFrame.new(-21.834540794796354, 3.4511720860669306, 28.367460923306254) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel104.Parent = workspace.devices.m1730
newmodel105 = workspace.prefabs.m1730:clone()
newmodel105:PivotTo(CFrame.new(-21.90483792075226, 2.8156559468930924, 28.280194358506684) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel105.Parent = workspace.devices.m1730
newmodel106 = workspace.prefabs.m1730:clone()
newmodel106:PivotTo(CFrame.new(-21.87302926647357, 3.103219810772657, 28.319681491900155) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel106.Parent = workspace.devices.m1730
newmodel107 = workspace.prefabs.m1730:clone()
newmodel107:PivotTo(CFrame.new(-21.894341064840294, 2.9105520219733485, 28.293225112526528) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel107.Parent = workspace.devices.m1730
newmodel108 = workspace.prefabs.m1730:clone()
newmodel108:PivotTo(CFrame.new(-21.88352612238554, 3.008323735692401, 28.30665073788031) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel108.Parent = workspace.devices.m1730
newmodel109 = workspace.prefabs.m1730:clone()
newmodel109:PivotTo(CFrame.new(-20.899653529089736, 3.3303952632375133, 27.587020984113725) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel109.Parent = workspace.devices.m1730
newmodel110 = workspace.prefabs.m1730:clone()
newmodel110:PivotTo(CFrame.new(-20.92944774129296, 3.0610428188574414, 27.55003457087806) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel110.Parent = workspace.devices.m1730
newmodel111 = workspace.prefabs.m1730:clone()
newmodel111:PivotTo(CFrame.new(-20.95022928939286, 2.8731687196690054, 27.524236442018108) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel111.Parent = workspace.devices.m1730
newmodel112 = workspace.prefabs.m1730:clone()
newmodel112:PivotTo(CFrame.new(-21.40637739599299, 3.241250465434848, 27.975025518282248) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel112.Parent = workspace.devices.m1730
newmodel113 = workspace.prefabs.m1730:clone()
newmodel113:PivotTo(CFrame.new(-21.42705302127414, 3.0543339539131313, 27.949358881576494) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel113.Parent = workspace.devices.m1730
newmodel114 = workspace.prefabs.m1730:clone()
newmodel114:PivotTo(CFrame.new(-21.36534423197348, 3.612207849839487, 28.02596392035983) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel114.Parent = workspace.devices.m1730
newmodel115 = workspace.prefabs.m1730:clone()
newmodel115:PivotTo(CFrame.new(-21.38601985725463, 3.425291338317769, 28.00029728365407) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel115.Parent = workspace.devices.m1730
newmodel116 = workspace.prefabs.m1730:clone()
newmodel116:PivotTo(CFrame.new(-21.375841087885448, 3.5173117747592304, 28.01293316633998) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel116.Parent = workspace.devices.m1730
newmodel117 = workspace.prefabs.m1730:clone()
newmodel117:PivotTo(CFrame.new(-21.41687425190496, 3.146354390354592, 27.961994764262403) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel117.Parent = workspace.devices.m1730
newmodel118 = workspace.prefabs.m1730:clone()
newmodel118:PivotTo(CFrame.new(-20.939838356299635, 2.967107207082543, 27.53713570388375) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel118.Parent = workspace.devices.m1730
newmodel119 = workspace.prefabs.m1730:clone()
newmodel119:PivotTo(CFrame.new(-37.437992796388784, 3.6064570901768502, 35.060071649160356) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel119.Parent = workspace.devices.m1730
newmodel120 = workspace.prefabs.m1730:clone()
newmodel120:PivotTo(CFrame.new(-37.43999605185261, 3.514024804769541, 35.04389692369543) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel120.Parent = workspace.devices.m1730
newmodel121 = workspace.prefabs.m1730:clone()
newmodel121:PivotTo(CFrame.new(-37.441995536305214, 3.4215926919005506, 35.0277217623224) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel121.Parent = workspace.devices.m1730
newmodel122 = workspace.prefabs.m1730:clone()
newmodel122:PivotTo(CFrame.new(-37.44400019589425, 3.3291624769530612, 35.0115475784425) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel122.Parent = workspace.devices.m1730
newmodel123 = workspace.prefabs.m1730:clone()
newmodel123:PivotTo(CFrame.new(-37.44599760449644, 3.2367325495694357, 34.995372548536) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel123.Parent = workspace.devices.m1730
newmodel124 = workspace.prefabs.m1730:clone()
newmodel124:PivotTo(CFrame.new(-37.4480008338112, 3.1443014719303557, 34.979198034421714) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel124.Parent = workspace.devices.m1730
newmodel125 = workspace.prefabs.m1730:clone()
newmodel125:PivotTo(CFrame.new(-37.450000320754185, 3.051869244035819, 34.96302285292005) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel125.Parent = workspace.devices.m1730
newmodel126 = workspace.prefabs.m1730:clone()
newmodel126:PivotTo(CFrame.new(-37.452002964262114, 2.9594384539606025, 34.946848317419494) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel126.Parent = workspace.devices.m1730
newmodel127 = workspace.prefabs.m1730:clone()
newmodel127:PivotTo(CFrame.new(-38.30647096880347, 3.5138610083926753, 35.15107125076257) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel127.Parent = workspace.devices.m1730
newmodel128 = workspace.prefabs.m1730:clone()
newmodel128:PivotTo(CFrame.new(-38.310468040937394, 3.329245007781995, 35.118764795852236) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel128.Parent = workspace.devices.m1730
newmodel129 = workspace.prefabs.m1730:clone()
newmodel129:PivotTo(CFrame.new(-38.31447133904038, 3.144341443307435, 35.086408019361045) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel129.Parent = workspace.devices.m1730
newmodel130 = workspace.prefabs.m1730:clone()
newmodel130:PivotTo(CFrame.new(-38.31847463714337, 2.959437878832875, 35.05405124286986) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel130.Parent = workspace.devices.m1730
newmodel131 = workspace.prefabs.m1730:clone()
newmodel131:PivotTo(CFrame.new(-38.304466206767444, 3.6064565725618953, 35.1672747997986) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel131.Parent = workspace.devices.m1730
newmodel132 = workspace.prefabs.m1730:clone()
newmodel132:PivotTo(CFrame.new(-38.30846950487043, 3.421553008087335, 35.13491802330741) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel132.Parent = workspace.devices.m1730
newmodel133 = workspace.prefabs.m1730:clone()
newmodel133:PivotTo(CFrame.new(-38.31247280297342, 3.236649443612775, 35.102561246816215) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel133.Parent = workspace.devices.m1730
newmodel134 = workspace.prefabs.m1730:clone()
newmodel134:PivotTo(CFrame.new(-38.316476101076404, 3.051745879138215, 35.070204470325024) * CFrame.fromEulerAngles(0, math.rad(-82.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel134.Parent = workspace.devices.m1730
newmodel135 = workspace.prefabs.m1730:clone()
newmodel135:PivotTo(CFrame.new(-39.54257676203015, 3.6007052952843037, 35.27963905317928) * CFrame.fromEulerAngles(0, math.rad(-88.24699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel135.Parent = workspace.devices.m1730
newmodel136 = workspace.prefabs.m1730:clone()
newmodel136:PivotTo(CFrame.new(-41.12447606298363, 3.6007052952843037, 35.32805362993967) * CFrame.fromEulerAngles(0, math.rad(-88.24699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel136.Parent = workspace.devices.m1730
newmodel137 = workspace.prefabs.m1730:clone()
newmodel137:PivotTo(CFrame.new(-41.124956912049754, 3.511560497481639, 35.312342353451186) * CFrame.fromEulerAngles(0, math.rad(-88.24699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel137.Parent = workspace.devices.m1730
newmodel138 = workspace.prefabs.m1730:clone()
newmodel138:PivotTo(CFrame.new(-41.12543776111586, 3.422415699678974, 35.2966310769627) * CFrame.fromEulerAngles(0, math.rad(-88.24699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel138.Parent = workspace.devices.m1730
newmodel139 = workspace.prefabs.m1730:clone()
newmodel139:PivotTo(CFrame.new(-39.54305761109626, 3.511560497481639, 35.26392777669081) * CFrame.fromEulerAngles(0, math.rad(-88.24699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel139.Parent = workspace.devices.m1730
newmodel140 = workspace.prefabs.m1730:clone()
newmodel140:PivotTo(CFrame.new(-39.54353846016238, 3.422415699678974, 35.24821650020231) * CFrame.fromEulerAngles(0, math.rad(-88.24699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel140.Parent = workspace.devices.m1730
newmodel141 = workspace.prefabs.m1730:clone()
newmodel141:PivotTo(CFrame.new(-39.544019309228496, 3.3332709018763085, 35.23250522371384) * CFrame.fromEulerAngles(0, math.rad(-88.24699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel141.Parent = workspace.devices.m1730
newmodel142 = workspace.prefabs.m1730:clone()
newmodel142:PivotTo(CFrame.new(-39.54450015829462, 3.2441261040736435, 35.21679394722535) * CFrame.fromEulerAngles(0, math.rad(-88.24699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel142.Parent = workspace.devices.m1730
newmodel143 = workspace.prefabs.m1730:clone()
newmodel143:PivotTo(CFrame.new(-58.300797648028755, 3.6035809339230993, 30.12746710064607) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel143.Parent = workspace.devices.m1730
newmodel144 = workspace.prefabs.m1730:clone()
newmodel144:PivotTo(CFrame.new(-58.29152799191174, 3.512710752937157, 30.114397836433632) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel144.Parent = workspace.devices.m1730
newmodel145 = workspace.prefabs.m1730:clone()
newmodel145:PivotTo(CFrame.new(-58.282258335794744, 3.421840571951215, 30.101328572221195) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel145.Parent = workspace.devices.m1730
newmodel146 = workspace.prefabs.m1730:clone()
newmodel146:PivotTo(CFrame.new(-58.27298867967774, 3.330970390965272, 30.08825930800876) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel146.Parent = workspace.devices.m1730
newmodel147 = workspace.prefabs.m1730:clone()
newmodel147:PivotTo(CFrame.new(-58.26371902356073, 3.24010020997933, 30.075190043796315) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel147.Parent = workspace.devices.m1730
newmodel148 = workspace.prefabs.m1730:clone()
newmodel148:PivotTo(CFrame.new(-58.83694579232648, 3.512710752937157, 29.727548556492785) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel148.Parent = workspace.devices.m1730
newmodel149 = workspace.prefabs.m1730:clone()
newmodel149:PivotTo(CFrame.new(-58.81840648009247, 3.330970390965272, 29.701410028067905) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel149.Parent = workspace.devices.m1730
newmodel150 = workspace.prefabs.m1730:clone()
newmodel150:PivotTo(CFrame.new(-58.846215448443495, 3.6035809339230993, 29.740617820705218) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel150.Parent = workspace.devices.m1730
newmodel151 = workspace.prefabs.m1730:clone()
newmodel151:PivotTo(CFrame.new(-58.82767613620948, 3.421840571951215, 29.714479292280345) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel151.Parent = workspace.devices.m1730
newmodel152 = workspace.prefabs.m1730:clone()
newmodel152:PivotTo(CFrame.new(-58.809136823975464, 3.24010020997933, 29.688340763855464) * CFrame.fromEulerAngles(0, math.rad(-125.34699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel152.Parent = workspace.devices.m1730
newmodel153 = workspace.prefabs.m1730:clone()
newmodel153:PivotTo(CFrame.new(-44.02321432126946, 3.6064565725618953, 35.233086515743956) * CFrame.fromEulerAngles(0, math.rad(-93.547), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel153.Parent = workspace.devices.m1730
newmodel154 = workspace.prefabs.m1730:clone()
newmodel154:PivotTo(CFrame.new(-44.0222104820068, 3.5144361361204344, 35.21689191220272) * CFrame.fromEulerAngles(0, math.rad(-93.547), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel154.Parent = workspace.devices.m1730
newmodel155 = workspace.prefabs.m1730:clone()
newmodel155:PivotTo(CFrame.new(-60.12328653734504, 3.6035809339230993, 28.735474232463364) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel155.Parent = workspace.devices.m1730
newmodel156 = workspace.prefabs.m1730:clone()
newmodel156:PivotTo(CFrame.new(-60.112882323321905, 3.5129983168010366, 28.723355560676463) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel156.Parent = workspace.devices.m1730
newmodel157 = workspace.prefabs.m1730:clone()
newmodel157:PivotTo(CFrame.new(-60.102478109298765, 3.422415699678974, 28.71123688888956) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel157.Parent = workspace.devices.m1730
newmodel158 = workspace.prefabs.m1730:clone()
newmodel158:PivotTo(CFrame.new(-61.484628003758644, 3.5978296566455086, 27.525449099487886) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel158.Parent = workspace.devices.m1730
newmodel159 = workspace.prefabs.m1730:clone()
newmodel159:PivotTo(CFrame.new(-62.10794378426535, 3.5978296566455086, 26.88118043551973) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel159.Parent = workspace.devices.m1730
newmodel160 = workspace.prefabs.m1730:clone()
newmodel160:PivotTo(CFrame.new(-62.73328990933397, 3.5978296566455086, 26.23481317655493) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel160.Parent = workspace.devices.m1730
newmodel161 = workspace.prefabs.m1730:clone()
newmodel161:PivotTo(CFrame.new(-62.721628559035494, 3.505809220204047, 26.223531076292158) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel161.Parent = workspace.devices.m1730
newmodel162 = workspace.prefabs.m1730:clone()
newmodel162:PivotTo(CFrame.new(-62.70996720873701, 3.4137887837625867, 26.212248976029382) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel162.Parent = workspace.devices.m1730
newmodel163 = workspace.prefabs.m1730:clone()
newmodel163:PivotTo(CFrame.new(-62.69830585843854, 3.321768347321126, 26.200966875766603) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel163.Parent = workspace.devices.m1730
newmodel164 = workspace.prefabs.m1730:clone()
newmodel164:PivotTo(CFrame.new(-62.68664450814007, 3.229747910879665, 26.189684775503824) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel164.Parent = workspace.devices.m1730
newmodel165 = workspace.prefabs.m1730:clone()
newmodel165:PivotTo(CFrame.new(-62.674983157841595, 3.137727474438205, 26.17840267524104) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel165.Parent = workspace.devices.m1730
newmodel166 = workspace.prefabs.m1730:clone()
newmodel166:PivotTo(CFrame.new(-62.09623688181727, 3.505449765374198, 26.869854264552803) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel166.Parent = workspace.devices.m1730
newmodel167 = workspace.prefabs.m1730:clone()
newmodel167:PivotTo(CFrame.new(-62.084529979369194, 3.413069874102888, 26.858528093585875) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel167.Parent = workspace.devices.m1730
newmodel168 = workspace.prefabs.m1730:clone()
newmodel168:PivotTo(CFrame.new(-62.07282307692112, 3.3206899828315777, 26.847201922618943) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel168.Parent = workspace.devices.m1730
newmodel169 = workspace.prefabs.m1730:clone()
newmodel169:PivotTo(CFrame.new(-62.06111617447304, 3.228310091560267, 26.835875751652015) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel169.Parent = workspace.devices.m1730
newmodel170 = workspace.prefabs.m1730:clone()
newmodel170:PivotTo(CFrame.new(-62.049409272024974, 3.1359302002889575, 26.824549580685087) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel170.Parent = workspace.devices.m1730
newmodel171 = workspace.prefabs.m1730:clone()
newmodel171:PivotTo(CFrame.new(-62.03770236957689, 3.0435503090176472, 26.81322340971815) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel171.Parent = workspace.devices.m1730
newmodel172 = workspace.prefabs.m1730:clone()
newmodel172:PivotTo(CFrame.new(-62.02599546712881, 2.9511704177463374, 26.801897238751224) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel172.Parent = workspace.devices.m1730
newmodel173 = workspace.prefabs.m1730:clone()
newmodel173:PivotTo(CFrame.new(-62.01428856468073, 2.858790526475027, 26.790571067784295) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel173.Parent = workspace.devices.m1730
newmodel174 = workspace.prefabs.m1730:clone()
newmodel174:PivotTo(CFrame.new(-61.47287554916096, 3.5050903105443485, 27.514078857816806) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel174.Parent = workspace.devices.m1730
newmodel175 = workspace.prefabs.m1730:clone()
newmodel175:PivotTo(CFrame.new(-61.46112309456328, 3.412350964443189, 27.502708616145725) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel175.Parent = workspace.devices.m1730
newmodel176 = workspace.prefabs.m1730:clone()
newmodel176:PivotTo(CFrame.new(-61.4493706399656, 3.3196116183420297, 27.491338374474644) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel176.Parent = workspace.devices.m1730
newmodel177 = workspace.prefabs.m1730:clone()
newmodel177:PivotTo(CFrame.new(-61.437618185367924, 3.2268722722408696, 27.479968132803563) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel177.Parent = workspace.devices.m1730
newmodel178 = workspace.prefabs.m1730:clone()
newmodel178:PivotTo(CFrame.new(-63.42506456066625, 3.589202884511053, 25.48714980621069) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel178.Parent = workspace.devices.m1730
newmodel179 = workspace.prefabs.m1730:clone()
newmodel179:PivotTo(CFrame.new(-63.41228171729317, 3.4962257518508513, 25.476884596568002) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel179.Parent = workspace.devices.m1730
newmodel180 = workspace.prefabs.m1730:clone()
newmodel180:PivotTo(CFrame.new(-63.39949771670179, 3.4032452546934424, 25.466619880894406) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel180.Parent = workspace.devices.m1730
newmodel181 = workspace.prefabs.m1730:clone()
newmodel181:PivotTo(CFrame.new(-63.38670887151295, 3.310266080329807, 25.456361573432595) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel181.Parent = workspace.devices.m1730
newmodel182 = workspace.prefabs.m1730:clone()
newmodel182:PivotTo(CFrame.new(-63.77785881860703, 3.4963201303109765, 25.021460408726497) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel182.Parent = workspace.devices.m1730
newmodel183 = workspace.prefabs.m1730:clone()
newmodel183:PivotTo(CFrame.new(-63.75227359514178, 3.3102657927659433, 25.00092613987743) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel183.Parent = workspace.devices.m1730
newmodel184 = workspace.prefabs.m1730:clone()
newmodel184:PivotTo(CFrame.new(-63.79063233085719, 3.589203085805758, 25.031710714830798) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel184.Parent = workspace.devices.m1730
newmodel185 = workspace.prefabs.m1730:clone()
newmodel185:PivotTo(CFrame.new(-63.76508517191207, 3.403436197099058, 25.01120999470727) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel185.Parent = workspace.devices.m1730
newmodel186 = workspace.prefabs.m1730:clone()
newmodel186:PivotTo(CFrame.new(-64.30424432759125, 3.589202855754667, 24.391832002861648) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel186.Parent = workspace.devices.m1730
newmodel187 = workspace.prefabs.m1730:clone()
newmodel187:PivotTo(CFrame.new(-64.2914615207745, 3.496225723094465, 24.381566747675606) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel187.Parent = workspace.devices.m1730
newmodel188 = workspace.prefabs.m1730:clone()
newmodel188:PivotTo(CFrame.new(-64.27867616558115, 3.4032446795657147, 24.371303565713497) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel188.Parent = workspace.devices.m1730
newmodel189 = workspace.prefabs.m1730:clone()
newmodel189:PivotTo(CFrame.new(-64.26588708576253, 3.3102657927659433, 24.361045631566427) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel189.Parent = workspace.devices.m1730
newmodel190 = workspace.prefabs.m1730:clone()
newmodel190:PivotTo(CFrame.new(-64.65703992976437, 3.496320705438704, 23.92614110078557) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel190.Parent = workspace.devices.m1730
newmodel191 = workspace.prefabs.m1730:clone()
newmodel191:PivotTo(CFrame.new(-64.63145353052447, 3.3102657927659433, 23.905608134757315) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel191.Parent = workspace.devices.m1730
newmodel192 = workspace.prefabs.m1730:clone()
newmodel192:PivotTo(CFrame.new(-64.66981207554979, 3.589203028292985, 23.936392931079453) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel192.Parent = workspace.devices.m1730
newmodel193 = workspace.prefabs.m1730:clone()
newmodel193:PivotTo(CFrame.new(-64.64426628306941, 3.403436772226786, 23.915890686766332) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel193.Parent = workspace.devices.m1730
newmodel194 = workspace.prefabs.m1730:clone()
newmodel194:PivotTo(CFrame.new(-63.540625927242665, 3.1003441721338616, 25.205472866725025) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel194.Parent = workspace.devices.m1730
newmodel195 = workspace.prefabs.m1730:clone()
newmodel195:PivotTo(CFrame.new(-63.52797229850738, 3.008323735692401, 25.19531616662347) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel195.Parent = workspace.devices.m1730
newmodel196 = workspace.prefabs.m1730:clone()
newmodel196:PivotTo(CFrame.new(-63.51531866977211, 2.9163032992509397, 25.185159466521924) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel196.Parent = workspace.devices.m1730
newmodel197 = workspace.prefabs.m1730:clone()
newmodel197:PivotTo(CFrame.new(-64.40715168554534, 3.008323735692401, 24.09999884465346) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel197.Parent = workspace.devices.m1730
newmodel198 = workspace.prefabs.m1730:clone()
newmodel198:PivotTo(CFrame.new(-64.41980531428061, 3.1003441721338616, 24.11015554475501) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel198.Parent = workspace.devices.m1730
newmodel199 = workspace.prefabs.m1730:clone()
newmodel199:PivotTo(CFrame.new(-64.39449805681008, 2.9163032992509397, 24.08984214455191) * CFrame.fromEulerAngles(0, math.rad(-141.247), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel199.Parent = workspace.devices.m1730
newmodel200 = workspace.prefabs.m1730:clone()
newmodel200:PivotTo(CFrame.new(-65.24232626707361, 3.3620272882642652, 23.113989780441266) * CFrame.fromEulerAngles(0, math.rad(-146.547), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel200.Parent = workspace.devices.m1730
newmodel201 = workspace.prefabs.m1730:clone()
newmodel201:PivotTo(CFrame.new(-65.22857702933084, 3.268569032503407, 23.104905569323584) * CFrame.fromEulerAngles(0, math.rad(-146.547), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel201.Parent = workspace.devices.m1730
newmodel202 = workspace.prefabs.m1730:clone()
newmodel202:PivotTo(CFrame.new(-65.21482779158805, 3.1751107767425486, 23.095821358205903) * CFrame.fromEulerAngles(0, math.rad(-146.547), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel202.Parent = workspace.devices.m1730
newmodel203 = workspace.prefabs.m1730:clone()
newmodel203:PivotTo(CFrame.new(-66.25158186870925, 3.3620272882642652, 21.58644985095756) * CFrame.fromEulerAngles(0, math.rad(-146.547), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel203.Parent = workspace.devices.m1730
newmodel204 = workspace.prefabs.m1730:clone()
newmodel204:PivotTo(CFrame.new(-66.2240833932237, 3.1751107767425486, 21.568281428722194) * CFrame.fromEulerAngles(0, math.rad(-146.547), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel204.Parent = workspace.devices.m1730
newmodel205 = workspace.prefabs.m1730:clone()
newmodel205:PivotTo(CFrame.new(-66.23804415770098, 3.2700068518228043, 21.577505396934) * CFrame.fromEulerAngles(0, math.rad(-146.547), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel205.Parent = workspace.devices.m1730
newmodel206 = workspace.prefabs.m1730:clone()
newmodel206:PivotTo(CFrame.new(-13.20401489560813, 7.364400292, 26.897682809814494) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel206.Parent = workspace.devices.m1730
newmodel207 = workspace.prefabs.m1730:clone()
newmodel207:PivotTo(CFrame.new(-13.20401489560813, 7.271933528000001, 26.897682809814494) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel207.Parent = workspace.devices.m1730
newmodel208 = workspace.prefabs.m1730:clone()
newmodel208:PivotTo(CFrame.new(-13.20401489560813, 7.179467055999999, 26.897682809814494) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel208.Parent = workspace.devices.m1730
newmodel209 = workspace.prefabs.m1730:clone()
newmodel209:PivotTo(CFrame.new(-13.20401489560813, 7.087000292, 26.897682809814494) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel209.Parent = workspace.devices.m1730
newmodel210 = workspace.prefabs.m1730:clone()
newmodel210:PivotTo(CFrame.new(-13.20401489560813, 6.906550424, 26.897682809814494) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel210.Parent = workspace.devices.m1730
newmodel211 = workspace.prefabs.m1730:clone()
newmodel211:PivotTo(CFrame.new(-13.20401489560813, 6.81408366, 26.897682809814494) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel211.Parent = workspace.devices.m1730
newmodel212 = workspace.prefabs.m1730:clone()
newmodel212:PivotTo(CFrame.new(-13.20401489560813, 6.721616603999999, 26.897682809814494) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel212.Parent = workspace.devices.m1730
newmodel213 = workspace.prefabs.m1730:clone()
newmodel213:PivotTo(CFrame.new(-13.20401489560813, 6.62914984, 26.897682809814494) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel213.Parent = workspace.devices.m1730
newmodel214 = workspace.prefabs.m1730:clone()
newmodel214:PivotTo(CFrame.new(-13.20401489560813, 6.448702600000001, 26.897682809814494) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel214.Parent = workspace.devices.m1730
newmodel215 = workspace.prefabs.m1730:clone()
newmodel215:PivotTo(CFrame.new(-13.20401489560813, 6.356234959999999, 26.897682809814494) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel215.Parent = workspace.devices.m1730
newmodel216 = workspace.prefabs.m1730:clone()
newmodel216:PivotTo(CFrame.new(-13.20401489560813, 6.26377024, 26.897682809814494) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel216.Parent = workspace.devices.m1730
newmodel217 = workspace.prefabs.m1730:clone()
newmodel217:PivotTo(CFrame.new(-13.20401489560813, 6.1713026, 26.897682809814494) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel217.Parent = workspace.devices.m1730
newmodel218 = workspace.prefabs.m1730:clone()
newmodel218:PivotTo(CFrame.new(-69.51628648881601, 4.529079416000001, 25.330669249930207) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel218.Parent = workspace.devices.m1730
newmodel219 = workspace.prefabs.m1730:clone()
newmodel219:PivotTo(CFrame.new(-70.04066817558441, 4.529079416000001, 24.543200019813185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel219.Parent = workspace.devices.m1730
newmodel220 = workspace.prefabs.m1730:clone()
newmodel220:PivotTo(CFrame.new(-70.56504648284584, 4.529079416000001, 23.75573625724035) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel220.Parent = workspace.devices.m1730
newmodel221 = workspace.prefabs.m1730:clone()
newmodel221:PivotTo(CFrame.new(-69.51628648881601, 4.4317564, 25.330669249930207) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel221.Parent = workspace.devices.m1730
newmodel222 = workspace.prefabs.m1730:clone()
newmodel222:PivotTo(CFrame.new(-70.56504648284584, 4.4317564, 23.75573625724035) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel222.Parent = workspace.devices.m1730
newmodel223 = workspace.prefabs.m1730:clone()
newmodel223:PivotTo(CFrame.new(-70.04066817558441, 4.4317564, 24.543200019813185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel223.Parent = workspace.devices.m1730
newmodel224 = workspace.prefabs.m1730:clone()
newmodel224:PivotTo(CFrame.new(-69.51628648881601, 4.334412360000001, 25.330669249930207) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel224.Parent = workspace.devices.m1730
newmodel225 = workspace.prefabs.m1730:clone()
newmodel225:PivotTo(CFrame.new(-70.56504648284584, 4.334412360000001, 23.75573625724035) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel225.Parent = workspace.devices.m1730
newmodel226 = workspace.prefabs.m1730:clone()
newmodel226:PivotTo(CFrame.new(-70.04066817558441, 4.334412360000001, 24.543200019813185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel226.Parent = workspace.devices.m1730
newmodel227 = workspace.prefabs.m1730:clone()
newmodel227:PivotTo(CFrame.new(-69.51628648881601, 4.237080292000001, 25.330669249930207) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel227.Parent = workspace.devices.m1730
newmodel228 = workspace.prefabs.m1730:clone()
newmodel228:PivotTo(CFrame.new(-70.56504648284584, 4.237080292000001, 23.75573625724035) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel228.Parent = workspace.devices.m1730
newmodel229 = workspace.prefabs.m1730:clone()
newmodel229:PivotTo(CFrame.new(-70.04066817558441, 4.237080292000001, 24.543200019813185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel229.Parent = workspace.devices.m1730
newmodel230 = workspace.prefabs.m1730:clone()
newmodel230:PivotTo(CFrame.new(-69.51628648881601, 4.050200000000001, 25.330669249930207) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel230.Parent = workspace.devices.m1730
newmodel231 = workspace.prefabs.m1730:clone()
newmodel231:PivotTo(CFrame.new(-70.04066817558441, 4.050200000000001, 24.543200019813185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel231.Parent = workspace.devices.m1730
newmodel232 = workspace.prefabs.m1730:clone()
newmodel232:PivotTo(CFrame.new(-70.56504648284584, 4.050200000000001, 23.75573625724035) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel232.Parent = workspace.devices.m1730
newmodel233 = workspace.prefabs.m1730:clone()
newmodel233:PivotTo(CFrame.new(-69.51628648881601, 3.95384, 25.330669249930207) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel233.Parent = workspace.devices.m1730
newmodel234 = workspace.prefabs.m1730:clone()
newmodel234:PivotTo(CFrame.new(-70.04066817558441, 3.95384, 24.543200019813185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel234.Parent = workspace.devices.m1730
newmodel235 = workspace.prefabs.m1730:clone()
newmodel235:PivotTo(CFrame.new(-70.56504648284584, 3.95384, 23.75573625724035) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel235.Parent = workspace.devices.m1730
newmodel236 = workspace.prefabs.m1730:clone()
newmodel236:PivotTo(CFrame.new(-69.51628652503219, 3.8574800000000002, 25.330669274046883) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel236.Parent = workspace.devices.m1730
newmodel237 = workspace.prefabs.m1730:clone()
newmodel237:PivotTo(CFrame.new(-70.04066817558441, 3.8574800000000002, 24.543200019813185) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel237.Parent = workspace.devices.m1730
newmodel238 = workspace.prefabs.m1730:clone()
newmodel238:PivotTo(CFrame.new(-70.56504648284584, 3.8574800000000002, 23.75573625724035) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
newmodel238.Parent = workspace.devices.m1730
newmodel239 = workspace.prefabs.m1730:clone()
newmodel239:PivotTo(CFrame.new(-71.25896352798783, 5.52188, 22.64475524664906) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel239.Parent = workspace.devices.m1730
newmodel240 = workspace.prefabs.m1730:clone()
newmodel240:PivotTo(CFrame.new(-71.71324893636101, 5.52188, 21.804913833951563) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel240.Parent = workspace.devices.m1730
newmodel241 = workspace.prefabs.m1730:clone()
newmodel241:PivotTo(CFrame.new(-72.16753952595381, 5.52188, 20.96506659236375) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel241.Parent = workspace.devices.m1730
newmodel242 = workspace.prefabs.m1730:clone()
newmodel242:PivotTo(CFrame.new(-71.25896352798783, 5.431360000000001, 22.64475524664906) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel242.Parent = workspace.devices.m1730
newmodel243 = workspace.prefabs.m1730:clone()
newmodel243:PivotTo(CFrame.new(-71.71324893636101, 5.431360000000001, 21.804913833951563) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel243.Parent = workspace.devices.m1730
newmodel244 = workspace.prefabs.m1730:clone()
newmodel244:PivotTo(CFrame.new(-72.16753952595381, 5.431360000000001, 20.96506659236375) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel244.Parent = workspace.devices.m1730
newmodel245 = workspace.prefabs.m1730:clone()
newmodel245:PivotTo(CFrame.new(-71.25896352798783, 5.340840292000001, 22.64475524664906) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel245.Parent = workspace.devices.m1730
newmodel246 = workspace.prefabs.m1730:clone()
newmodel246:PivotTo(CFrame.new(-71.71324893636101, 5.340840292000001, 21.804913833951563) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel246.Parent = workspace.devices.m1730
newmodel247 = workspace.prefabs.m1730:clone()
newmodel247:PivotTo(CFrame.new(-71.25896352798783, 5.250319416000001, 22.64475524664906) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel247.Parent = workspace.devices.m1730
newmodel248 = workspace.prefabs.m1730:clone()
newmodel248:PivotTo(CFrame.new(-71.71324893636101, 5.250319416000001, 21.804913833951563) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
newmodel248.Parent = workspace.devices.m1730
