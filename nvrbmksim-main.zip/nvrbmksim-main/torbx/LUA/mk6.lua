newmodel0 = workspace.prefabs.mk6:clone()
newmodel0:PivotTo(CFrame.new(-15.867939199792106, 2.7301640395557563, 21.066158443953686) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.mk6
newmodel1 = workspace.prefabs.mk6:clone()
newmodel1:PivotTo(CFrame.new(-15.985899032883065, 2.7301640309617086, 21.233085334566784) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.devices.mk6
newmodel2 = workspace.prefabs.mk6:clone()
newmodel2:PivotTo(CFrame.new(-16.069864509801164, 2.708532096166796, 20.923466873018175) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.mk6
newmodel3 = workspace.prefabs.mk6:clone()
newmodel3:PivotTo(CFrame.new(-16.187824295209357, 2.7085319649696444, 21.090393545932212) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.mk6
newmodel4 = workspace.prefabs.mk6:clone()
newmodel4:PivotTo(CFrame.new(-16.38975250115994, 2.6868998338416943, 20.947702060138173) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.mk6
newmodel5 = workspace.prefabs.mk6:clone()
newmodel5:PivotTo(CFrame.new(-16.271792595955198, 2.6868998338416943, 20.780774111208782) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.mk6
newmodel6 = workspace.prefabs.mk6:clone()
newmodel6:PivotTo(CFrame.new(-16.541995497643146, 2.7301640170499204, 22.020030562421763) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.devices.mk6
newmodel7 = workspace.prefabs.mk6:clone()
newmodel7:PivotTo(CFrame.new(-16.659955402847885, 2.7301640170499204, 22.186958511351154) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.devices.mk6
newmodel8 = workspace.prefabs.mk6:clone()
newmodel8:PivotTo(CFrame.new(-16.7439210520702, 2.708532078409118, 21.877340288922202) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.devices.mk6
newmodel9 = workspace.prefabs.mk6:clone()
newmodel9:PivotTo(CFrame.new(-16.861880593060377, 2.7085319424638294, 22.04426566440028) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.devices.mk6
newmodel10 = workspace.prefabs.mk6:clone()
newmodel10:PivotTo(CFrame.new(-17.063808630497057, 2.686899811335872, 21.90157394013809) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.devices.mk6
newmodel11 = workspace.prefabs.mk6:clone()
newmodel11:PivotTo(CFrame.new(-16.945848958339376, 2.6868998276217178, 21.73464728669015) * CFrame.fromEulerAngles(0, math.rad(54.753), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.devices.mk6
newmodel12 = workspace.prefabs.mk6:clone()
newmodel12:PivotTo(CFrame.new(-48.66076598728667, 2.736271849881208, 33.98523052610245) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.mk6
newmodel13 = workspace.prefabs.mk6:clone()
newmodel13:PivotTo(CFrame.new(-49.045118699555644, 2.7349993760370923, 33.87335320497883) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.mk6
newmodel14 = workspace.prefabs.mk6:clone()
newmodel14:PivotTo(CFrame.new(-47.8987518432268, 2.6489801441748635, 33.14834484360598) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.mk6
newmodel15 = workspace.prefabs.mk6:clone()
newmodel15:PivotTo(CFrame.new(-17.824888013441726, 2.7090409096171295, 23.29124760268412) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.mk6
newmodel16 = workspace.prefabs.mk6:clone()
newmodel16:PivotTo(CFrame.new(-18.796349687128078, 2.7090409096171295, 24.42679546557428) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.mk6
newmodel17 = workspace.prefabs.mk6:clone()
newmodel17:PivotTo(CFrame.new(-32.50457621907307, 2.991069903859627, 33.895182408297174) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel17.Parent = workspace.devices.mk6
newmodel18 = workspace.prefabs.mk6:clone()
newmodel18:PivotTo(CFrame.new(-32.69935112681404, 2.991069903859627, 33.95716704602704) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel18.Parent = workspace.devices.mk6
newmodel19 = workspace.prefabs.mk6:clone()
newmodel19:PivotTo(CFrame.new(-31.323115421160143, 2.7222745898113163, 32.925452219014915) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel19.Parent = workspace.devices.mk6
newmodel20 = workspace.prefabs.mk6:clone()
newmodel20:PivotTo(CFrame.new(-31.59209372716085, 2.7222745776898543, 33.01105114446566) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel20.Parent = workspace.devices.mk6
newmodel21 = workspace.prefabs.mk6:clone()
newmodel21:PivotTo(CFrame.new(-31.861064856872588, 2.722274583638075, 33.09664656749855) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel21.Parent = workspace.devices.mk6
newmodel22 = workspace.prefabs.mk6:clone()
newmodel22:PivotTo(CFrame.new(-32.13004256877734, 2.7222745786160214, 33.182247437307296) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.mk6
newmodel23 = workspace.prefabs.mk6:clone()
newmodel23:PivotTo(CFrame.new(-50.67529180601661, 2.7607511650169863, 33.34086111420642) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel23.Parent = workspace.devices.mk6
newmodel24 = workspace.prefabs.mk6:clone()
newmodel24:PivotTo(CFrame.new(-20.07810298142781, 2.730163975429452, 26.079480597593232) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.mk6
newmodel25 = workspace.prefabs.mk6:clone()
newmodel25:PivotTo(CFrame.new(-19.45806330620405, 2.7072594462353674, 25.112620156117416) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.mk6
newmodel26 = workspace.prefabs.mk6:clone()
newmodel26:PivotTo(CFrame.new(-19.75095104209523, 2.7072594462353674, 25.396973944241537) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.mk6
newmodel27 = workspace.prefabs.mk6:clone()
newmodel27:PivotTo(CFrame.new(-20.80147930325775, 2.6393093429595833, 25.334394504329804) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel27.Parent = workspace.devices.mk6
newmodel28 = workspace.prefabs.mk6:clone()
newmodel28:PivotTo(CFrame.new(-20.255415160190875, 2.662213872153668, 25.16912820424706) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel28.Parent = workspace.devices.mk6
newmodel29 = workspace.prefabs.mk6:clone()
newmodel29:PivotTo(CFrame.new(-20.706617436129914, 2.730163975429452, 26.689681859662166) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel29.Parent = workspace.devices.mk6
newmodel30 = workspace.prefabs.mk6:clone()
newmodel30:PivotTo(CFrame.new(-20.888981214742504, 2.7072594462353674, 26.501845029427688) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel30.Parent = workspace.devices.mk6
newmodel31 = workspace.prefabs.mk6:clone()
newmodel31:PivotTo(CFrame.new(-21.247629979347263, 2.662213872153668, 26.132432596633215) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel31.Parent = workspace.devices.mk6
newmodel32 = workspace.prefabs.mk6:clone()
newmodel32:PivotTo(CFrame.new(-54.162088657642904, 3.0514582581324796, 32.41751308103559) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel32.Parent = workspace.devices.mk6
newmodel33 = workspace.prefabs.mk6:clone()
newmodel33:PivotTo(CFrame.new(-54.400755811016545, 3.051458546384801, 32.30750122391531) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel33.Parent = workspace.devices.mk6
newmodel34 = workspace.prefabs.mk6:clone()
newmodel34:PivotTo(CFrame.new(-36.90960254222978, 2.7240559408449654, 34.336620040469946) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel34.Parent = workspace.devices.mk6
newmodel35 = workspace.prefabs.mk6:clone()
newmodel35:PivotTo(CFrame.new(-37.1713806365631, 2.724055925547801, 34.36900847167764) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel35.Parent = workspace.devices.mk6
newmodel36 = workspace.prefabs.mk6:clone()
newmodel36:PivotTo(CFrame.new(-37.43315996553323, 2.7240559462778653, 34.40139646962008) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel36.Parent = workspace.devices.mk6
newmodel37 = workspace.prefabs.mk6:clone()
newmodel37:PivotTo(CFrame.new(-37.69493379339855, 2.724055956279536, 34.433781442523205) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel37.Parent = workspace.devices.mk6
newmodel38 = workspace.prefabs.mk6:clone()
newmodel38:PivotTo(CFrame.new(-36.54808167313596, 2.723547011645112, 34.286030985900695) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel38.Parent = workspace.devices.mk6
newmodel39 = workspace.prefabs.mk6:clone()
newmodel39:PivotTo(CFrame.new(-36.730647552552526, 2.7235470093550944, 34.3086157701821) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel39.Parent = workspace.devices.mk6
newmodel40 = workspace.prefabs.mk6:clone()
newmodel40:PivotTo(CFrame.new(-36.578442147479834, 2.7019150781783705, 34.04064681398701) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel40.Parent = workspace.devices.mk6
newmodel41 = workspace.prefabs.mk6:clone()
newmodel41:PivotTo(CFrame.new(-36.76100742119124, 2.701915083323208, 34.0632335746938) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel41.Parent = workspace.devices.mk6
newmodel42 = workspace.prefabs.mk6:clone()
newmodel42:PivotTo(CFrame.new(-24.51871493319969, 2.5825569306753895, 27.611533754328036) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel42.Parent = workspace.devices.mk6
newmodel43 = workspace.prefabs.mk6:clone()
newmodel43:PivotTo(CFrame.new(-24.689056860785215, 2.582556925333415, 27.724507698916455) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel43.Parent = workspace.devices.mk6
newmodel44 = workspace.prefabs.mk6:clone()
newmodel44:PivotTo(CFrame.new(-24.85939877556094, 2.58255694946105, 27.837481641303057) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel44.Parent = workspace.devices.mk6
newmodel45 = workspace.prefabs.mk6:clone()
newmodel45:PivotTo(CFrame.new(-24.98802042237849, 2.562197438417345, 27.643547682273443) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel45.Parent = workspace.devices.mk6
newmodel46 = workspace.prefabs.mk6:clone()
newmodel46:PivotTo(CFrame.new(-24.647336805956268, 2.5621974596761357, 27.417599953697273) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel46.Parent = workspace.devices.mk6
newmodel47 = workspace.prefabs.mk6:clone()
newmodel47:PivotTo(CFrame.new(-24.817678881474833, 2.562197458432038, 27.5305736536586) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel47.Parent = workspace.devices.mk6
newmodel48 = workspace.prefabs.mk6:clone()
newmodel48:PivotTo(CFrame.new(-58.04102164241535, 2.736271849881208, 29.681823300518445) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel48.Parent = workspace.devices.mk6
newmodel49 = workspace.prefabs.mk6:clone()
newmodel49:PivotTo(CFrame.new(-58.358905235972195, 2.7349993760370923, 29.43852602688451) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel49.Parent = workspace.devices.mk6
newmodel50 = workspace.prefabs.mk6:clone()
newmodel50:PivotTo(CFrame.new(-57.02793929390482, 2.6489801441748635, 29.17713789707263) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel50.Parent = workspace.devices.mk6
newmodel51 = workspace.prefabs.mk6:clone()
newmodel51:PivotTo(CFrame.new(-43.53597324323607, 2.736271849881208, 34.74799810532908) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel51.Parent = workspace.devices.mk6
newmodel52 = workspace.prefabs.mk6:clone()
newmodel52:PivotTo(CFrame.new(-59.696032219692015, 2.7524993120302463, 28.36050998740531) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel52.Parent = workspace.devices.mk6
newmodel53 = workspace.prefabs.mk6:clone()
newmodel53:PivotTo(CFrame.new(-62.603141133056276, 3.051458018592035, 26.23078276998092) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel53.Parent = workspace.devices.mk6
newmodel54 = workspace.prefabs.mk6:clone()
newmodel54:PivotTo(CFrame.new(-62.78587335775948, 3.0514577008671906, 26.041908363992608) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel54.Parent = workspace.devices.mk6
newmodel55 = workspace.prefabs.mk6:clone()
newmodel55:PivotTo(CFrame.new(-62.313387180472716, 2.6161503584293127, 23.861954506660343) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel55.Parent = workspace.devices.mk6
newmodel56 = workspace.prefabs.mk6:clone()
newmodel56:PivotTo(CFrame.new(-62.109224511350504, 2.5932461004699983, 23.69807826845918) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel56.Parent = workspace.devices.mk6
newmodel57 = workspace.prefabs.mk6:clone()
newmodel57:PivotTo(CFrame.new(-62.93223427400341, 2.664250361307477, 23.969270136892003) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel57.Parent = workspace.devices.mk6
newmodel58 = workspace.prefabs.mk6:clone()
newmodel58:PivotTo(CFrame.new(-63.25889068346196, 2.700897097190581, 24.23147529265735) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel58.Parent = workspace.devices.mk6
newmodel59 = workspace.prefabs.mk6:clone()
newmodel59:PivotTo(CFrame.new(-63.04999780338154, 2.616150541849336, 22.944258396955394) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel59.Parent = workspace.devices.mk6
newmodel60 = workspace.prefabs.mk6:clone()
newmodel60:PivotTo(CFrame.new(-62.8458310623224, 2.593246041780516, 22.780381814795515) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel60.Parent = workspace.devices.mk6
newmodel61 = workspace.prefabs.mk6:clone()
newmodel61:PivotTo(CFrame.new(-63.66884247756277, 2.6642504156422215, 23.051575514262446) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel61.Parent = workspace.devices.mk6
newmodel62 = workspace.prefabs.mk6:clone()
newmodel62:PivotTo(CFrame.new(-63.99549964247268, 2.700897057757943, 23.31377668861199) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel62.Parent = workspace.devices.mk6
newmodel63 = workspace.prefabs.mk6:clone()
newmodel63:PivotTo(CFrame.new(-63.35200568021835, 2.7525595556372027, 25.05882101063301) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel63.Parent = workspace.devices.mk6
newmodel64 = workspace.prefabs.mk6:clone()
newmodel64:PivotTo(CFrame.new(-63.50188824161643, 2.7525595194603407, 24.872092550214077) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel64.Parent = workspace.devices.mk6
newmodel65 = workspace.prefabs.mk6:clone()
newmodel65:PivotTo(CFrame.new(-64.24215670713542, 2.7525597352455073, 23.94984055503454) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel65.Parent = workspace.devices.mk6
newmodel66 = workspace.prefabs.mk6:clone()
newmodel66:PivotTo(CFrame.new(-64.39203066961846, 2.752559261354397, 23.76310848583384) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel66.Parent = workspace.devices.mk6
newmodel67 = workspace.prefabs.mk6:clone()
newmodel67:PivotTo(CFrame.new(-64.96707344404766, 2.6398184804871336, 20.675877179401848) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel67.Parent = workspace.devices.mk6
newmodel68 = workspace.prefabs.mk6:clone()
newmodel68:PivotTo(CFrame.new(-63.9265908211994, 2.6059933651691662, 21.54932425583256) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel68.Parent = workspace.devices.mk6
newmodel69 = workspace.prefabs.mk6:clone()
newmodel69:PivotTo(CFrame.new(-64.80610562504057, 2.6398184550376564, 20.919506481954933) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel69.Parent = workspace.devices.mk6
newmodel70 = workspace.prefabs.mk6:clone()
newmodel70:PivotTo(CFrame.new(-63.92945239329148, 2.5688142919955674, 20.774096955296084) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel70.Parent = workspace.devices.mk6
newmodel71 = workspace.prefabs.mk6:clone()
newmodel71:PivotTo(CFrame.new(-64.07432161840666, 2.5688142919955674, 20.55483285058551) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel71.Parent = workspace.devices.mk6
newmodel72 = workspace.prefabs.mk6:clone()
newmodel72:PivotTo(CFrame.new(-64.28840613996573, 2.5688142919955674, 20.230809229179872) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel72.Parent = workspace.devices.mk6
newmodel73 = workspace.prefabs.mk6:clone()
newmodel73:PivotTo(CFrame.new(-42.98659986790213, 2.1376000000000004, 39.909120103786414) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel73.Parent = workspace.devices.mk6
newmodel74 = workspace.prefabs.mk6:clone()
newmodel74:PivotTo(CFrame.new(-43.1963678725669, 2.1376000000000004, 39.89504026646631) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel74.Parent = workspace.devices.mk6
newmodel75 = workspace.prefabs.mk6:clone()
newmodel75:PivotTo(CFrame.new(-43.40613587723166, 2.1376000000000004, 39.8809604291462) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel75.Parent = workspace.devices.mk6
newmodel76 = workspace.prefabs.mk6:clone()
newmodel76:PivotTo(CFrame.new(-43.615903881896436, 2.1376000000000004, 39.86688059182608) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel76.Parent = workspace.devices.mk6
newmodel77 = workspace.prefabs.mk6:clone()
newmodel77:PivotTo(CFrame.new(-51.38305453285094, 2.0500000000000003, 38.424608570608484) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel77.Parent = workspace.devices.mk6
newmodel78 = workspace.prefabs.mk6:clone()
newmodel78:PivotTo(CFrame.new(-51.60496464906689, 2.0500000000000003, 38.34562425363501) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel78.Parent = workspace.devices.mk6
newmodel79 = workspace.prefabs.mk6:clone()
newmodel79:PivotTo(CFrame.new(-51.82687380304792, 2.0500000000000003, 38.26665421535721) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel79.Parent = workspace.devices.mk6
newmodel80 = workspace.prefabs.mk6:clone()
newmodel80:PivotTo(CFrame.new(-52.04879049093418, 2.0500000000000003, 38.18767747778455) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel80.Parent = workspace.devices.mk6
newmodel81 = workspace.prefabs.mk6:clone()
newmodel81:PivotTo(CFrame.new(-52.363777426679455, 2.0500000000000003, 38.07558071199077) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel81.Parent = workspace.devices.mk6
newmodel82 = workspace.prefabs.mk6:clone()
newmodel82:PivotTo(CFrame.new(-52.59027564654352, 2.0500000000000003, 37.99497101743436) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel82.Parent = workspace.devices.mk6
newmodel83 = workspace.prefabs.mk6:clone()
newmodel83:PivotTo(CFrame.new(-52.81677427907329, 2.0500000000000003, 37.91436422420885) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel83.Parent = workspace.devices.mk6
newmodel84 = workspace.prefabs.mk6:clone()
newmodel84:PivotTo(CFrame.new(-53.043266784378744, 2.0500000000000003, 37.833752406764546) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel84.Parent = workspace.devices.mk6
newmodel85 = workspace.prefabs.mk6:clone()
newmodel85:PivotTo(CFrame.new(-53.35000252429802, 2.0500000000000003, 37.72459329165727) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel85.Parent = workspace.devices.mk6
newmodel86 = workspace.prefabs.mk6:clone()
newmodel86:PivotTo(CFrame.new(-53.572835106787814, 2.0500000000000003, 37.645293508437135) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel86.Parent = workspace.devices.mk6
newmodel87 = workspace.prefabs.mk6:clone()
newmodel87:PivotTo(CFrame.new(-53.7956612285999, 2.0500000000000003, 37.565988634930115) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel87.Parent = workspace.devices.mk6
newmodel88 = workspace.prefabs.mk6:clone()
newmodel88:PivotTo(CFrame.new(-60.084684638926404, 2.0500000000000003, 34.35248517780896) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel88.Parent = workspace.devices.mk6
newmodel89 = workspace.prefabs.mk6:clone()
newmodel89:PivotTo(CFrame.new(-60.27682806129659, 2.0500000000000003, 34.2162361326987) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel89.Parent = workspace.devices.mk6
newmodel90 = workspace.prefabs.mk6:clone()
newmodel90:PivotTo(CFrame.new(-60.46897077588885, 2.0500000000000003, 34.0799949237381) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel90.Parent = workspace.devices.mk6
newmodel91 = workspace.prefabs.mk6:clone()
newmodel91:PivotTo(CFrame.new(-60.66111226795696, 2.0500000000000003, 33.943743913621105) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel91.Parent = workspace.devices.mk6
newmodel92 = workspace.prefabs.mk6:clone()
newmodel92:PivotTo(CFrame.new(-60.93384982646272, 2.0500000000000003, 33.75035009353242) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel92.Parent = workspace.devices.mk6
newmodel93 = workspace.prefabs.mk6:clone()
newmodel93:PivotTo(CFrame.new(-61.12996387005503, 2.0500000000000003, 33.61129419696461) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel93.Parent = workspace.devices.mk6
newmodel94 = workspace.prefabs.mk6:clone()
newmodel94:PivotTo(CFrame.new(-61.326077361630695, 2.0500000000000003, 33.472224396659215) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel94.Parent = workspace.devices.mk6
newmodel95 = workspace.prefabs.mk6:clone()
newmodel95:PivotTo(CFrame.new(-61.52218655511524, 2.0500000000000003, 33.33317983358821) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel95.Parent = workspace.devices.mk6
newmodel96 = workspace.prefabs.mk6:clone()
newmodel96:PivotTo(CFrame.new(-61.78777924580732, 2.0500000000000003, 33.144850858877945) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel96.Parent = workspace.devices.mk6
newmodel97 = workspace.prefabs.mk6:clone()
newmodel97:PivotTo(CFrame.new(-61.98071266845458, 2.0500000000000003, 33.00803664686872) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel97.Parent = workspace.devices.mk6
newmodel98 = workspace.prefabs.mk6:clone()
newmodel98:PivotTo(CFrame.new(-62.17364978901682, 2.0500000000000003, 32.87122664025583) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel98.Parent = workspace.devices.mk6
