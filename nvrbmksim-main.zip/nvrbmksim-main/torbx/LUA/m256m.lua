newmodel0 = workspace.prefabs.m265m:clone()
newmodel0:PivotTo(CFrame.new(-23.402072242946996, 3.449421553314274, 29.55542234710079) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel0.Parent = workspace.devices.pamir
newmodel1 = workspace.prefabs.m265m:clone()
newmodel1:PivotTo(CFrame.new(-23.696278452525917, 3.4494198796529973, 29.75054015596767) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel1.Parent = workspace.devices.pamir
