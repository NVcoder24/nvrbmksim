newmodel0 = workspace.prefabs.skala_output_7:clone()
newmodel0:PivotTo(CFrame.new(-11.957798279250024, 6.491255759999999, 25.344372923246283) * CFrame.fromEulerAngles(0, math.rad(51.260000999999995), 0))
newmodel0.Parent = workspace.devices.skala_output_7
newmodel1 = workspace.prefabs.skala_output_7:clone()
newmodel1:PivotTo(CFrame.new(-11.957798279250024, 6.14085576, 25.344372923246283) * CFrame.fromEulerAngles(0, math.rad(51.260000999999995), 0))
newmodel1.Parent = workspace.devices.skala_output_7
newmodel2 = workspace.prefabs.skala_output_7:clone()
newmodel2:PivotTo(CFrame.new(-20.185843266876834, 6.205160000000001, 33.25735585131555) * CFrame.fromEulerAngles(0, math.rad(35.46), 0))
newmodel2.Parent = workspace.devices.skala_output_7
newmodel3 = workspace.prefabs.skala_output_7:clone()
newmodel3:PivotTo(CFrame.new(-20.185843266876834, 5.8606, 33.25735585131555) * CFrame.fromEulerAngles(0, math.rad(35.46), 0))
newmodel3.Parent = workspace.devices.skala_output_7
newmodel4 = workspace.prefabs.skala_output_7:clone()
newmodel4:PivotTo(CFrame.new(-35.63710244096301, 5.232800000000001, 39.57293530846158) * CFrame.fromEulerAngles(0, math.rad(6.659989999999993), 0))
newmodel4.Parent = workspace.devices.skala_output_7
newmodel5 = workspace.prefabs.skala_output_7:clone()
newmodel5:PivotTo(CFrame.new(-37.48169037101926, 5.232800000000001, 39.78831883311187) * CFrame.fromEulerAngles(0, math.rad(6.659989999999993), 0))
newmodel5.Parent = workspace.devices.skala_output_7
newmodel6 = workspace.prefabs.skala_output_7:clone()
newmodel6:PivotTo(CFrame.new(-37.48169037101926, 4.40936, 39.78831883311187) * CFrame.fromEulerAngles(0, math.rad(6.659989999999993), 0))
newmodel6.Parent = workspace.devices.skala_output_7
newmodel7 = workspace.prefabs.skala_output_7:clone()
newmodel7:PivotTo(CFrame.new(-35.63710244096301, 4.40936, 39.57293530846158) * CFrame.fromEulerAngles(0, math.rad(6.659989999999993), 0))
newmodel7.Parent = workspace.devices.skala_output_7
newmodel8 = workspace.prefabs.skala_output_7:clone()
newmodel8:PivotTo(CFrame.new(-57.43906743716327, 5.206519416000001, 35.90091168780331) * CFrame.fromEulerAngles(0, math.rad(-30.090000000000003), 0))
newmodel8.Parent = workspace.devices.skala_output_7
newmodel9 = workspace.prefabs.skala_output_7:clone()
newmodel9:PivotTo(CFrame.new(-57.43906743716327, 4.388920000000001, 35.90091168780331) * CFrame.fromEulerAngles(0, math.rad(-30.090000000000003), 0))
newmodel9.Parent = workspace.devices.skala_output_7
newmodel10 = workspace.prefabs.skala_output_7:clone()
newmodel10:PivotTo(CFrame.new(-59.030760716075136, 5.206519416000001, 34.97861166316013) * CFrame.fromEulerAngles(0, math.rad(-30.090000000000003), 0))
newmodel10.Parent = workspace.devices.skala_output_7
newmodel11 = workspace.prefabs.skala_output_7:clone()
newmodel11:PivotTo(CFrame.new(-59.030760716075136, 4.388920000000001, 34.97861166316013) * CFrame.fromEulerAngles(0, math.rad(-30.090000000000003), 0))
newmodel11.Parent = workspace.devices.skala_output_7
