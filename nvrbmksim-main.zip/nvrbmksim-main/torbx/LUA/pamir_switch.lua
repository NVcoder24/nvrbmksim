newmodel0 = workspace.prefabs.pamir_switch:clone()
newmodel0:PivotTo(CFrame.new(-23.622787692972878, 3.013750746944915, 29.603783668538462) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel0.Parent = workspace.devices.pamir
newmodel1 = workspace.prefabs.pamir_switch:clone()
newmodel1:PivotTo(CFrame.new(-23.869287579028665, 3.016337811061471, 29.767814885620886) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel1.Parent = workspace.devices.pamir
