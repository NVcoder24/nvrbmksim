newmodel0 = workspace.prefabs.lar_sw:clone()
newmodel0:PivotTo(CFrame.new(-24.179195535779073, 2.699839805772055, 28.91197084021792) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel1 = workspace.prefabs.lar_sw:clone()
newmodel1:PivotTo(CFrame.new(-24.09125008345947, 2.7137604969606994, 29.04457211367772) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel2 = workspace.prefabs.lar_sw:clone()
newmodel2:PivotTo(CFrame.new(-24.30451738720174, 2.6998398070394005, 28.995086035014122) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel3 = workspace.prefabs.lar_sw:clone()
newmodel3:PivotTo(CFrame.new(-24.217825336056162, 2.671768890486745, 28.552586024566633) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel4 = workspace.prefabs.lar_sw:clone()
newmodel4:PivotTo(CFrame.new(-24.1298791016343, 2.6856897451959716, 28.68518956315795) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel5 = workspace.prefabs.lar_sw:clone()
newmodel5:PivotTo(CFrame.new(-23.95254274467461, 2.713760513401767, 28.95258116268179) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel6 = workspace.prefabs.lar_sw:clone()
newmodel6:PivotTo(CFrame.new(-23.904700525229707, 2.6998396463274923, 28.729918740258437) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel7 = workspace.prefabs.lar_sw:clone()
newmodel7:PivotTo(CFrame.new(-23.994092849683675, 2.685689749408982, 28.59513489212545) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel8 = workspace.prefabs.lar_sw:clone()
newmodel8:PivotTo(CFrame.new(-24.040488137936023, 2.6998396562948415, 28.819978440162533) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel9 = workspace.prefabs.lar_sw:clone()
newmodel9:PivotTo(CFrame.new(-24.393910632868703, 2.6856899000165493, 28.86029901593362) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel10 = workspace.prefabs.lar_sw:clone()
newmodel10:PivotTo(CFrame.new(-24.26858693659434, 2.6856897506763273, 28.7771835968188) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.RBMKSYS.viur.larcorrector
newmodel11 = workspace.prefabs.lar_sw:clone()
newmodel11:PivotTo(CFrame.new(-24.356533174500157, 2.6717688879520547, 28.644580058826325) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.RBMKSYS.viur.larcorrector
