newmodel0 = workspace.prefabs.dumb_lamp:clone()
newmodel0:PivotTo(CFrame.new(-62.55632071107782, 2.6688310415367926, 24.52124205175464) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.dumb_lamp
newmodel1 = workspace.prefabs.dumb_lamp:clone()
newmodel1:PivotTo(CFrame.new(-55.071826667888885, 6.0387200000000005, 37.02616134633928) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel1.Parent = workspace.devices.dumb_lamp
newmodel2 = workspace.prefabs.dumb_lamp:clone()
newmodel2:PivotTo(CFrame.new(-55.191307822310335, 6.0387200000000005, 36.97085137562402) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel2.Parent = workspace.devices.dumb_lamp
newmodel3 = workspace.prefabs.dumb_lamp:clone()
newmodel3:PivotTo(CFrame.new(-55.31079633229687, 6.0387200000000005, 36.91553713687699) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel3.Parent = workspace.devices.dumb_lamp
newmodel4 = workspace.prefabs.dumb_lamp:clone()
newmodel4:PivotTo(CFrame.new(-55.430283435367166, 6.0387200000000005, 36.86022680982063) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel4.Parent = workspace.devices.dumb_lamp
newmodel5 = workspace.prefabs.dumb_lamp:clone()
newmodel5:PivotTo(CFrame.new(-55.54976489133106, 6.0387200000000005, 36.804916795412105) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel5.Parent = workspace.devices.dumb_lamp
newmodel6 = workspace.prefabs.dumb_lamp:clone()
newmodel6:PivotTo(CFrame.new(-55.66924604575238, 6.0387200000000005, 36.749606824696585) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel6.Parent = workspace.devices.dumb_lamp
newmodel7 = workspace.prefabs.dumb_lamp:clone()
newmodel7:PivotTo(CFrame.new(-55.78873429075297, 6.0387200000000005, 36.69429270861352) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel7.Parent = workspace.devices.dumb_lamp
newmodel8 = workspace.prefabs.dumb_lamp:clone()
newmodel8:PivotTo(CFrame.new(-55.90821460478692, 6.0387200000000005, 36.63898648323249) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel8.Parent = workspace.devices.dumb_lamp
newmodel9 = workspace.prefabs.dumb_lamp:clone()
newmodel9:PivotTo(CFrame.new(-56.02770141497768, 6.0387200000000005, 36.583669962717366) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel9.Parent = workspace.devices.dumb_lamp
newmodel10 = workspace.prefabs.dumb_lamp:clone()
newmodel10:PivotTo(CFrame.new(-56.14718146402594, 6.0387200000000005, 36.52836386000084) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel10.Parent = workspace.devices.dumb_lamp
newmodel11 = workspace.prefabs.dumb_lamp:clone()
newmodel11:PivotTo(CFrame.new(-56.266668293236656, 6.0387200000000005, 36.4730571119204) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel11.Parent = workspace.devices.dumb_lamp
newmodel12 = workspace.prefabs.dumb_lamp:clone()
newmodel12:PivotTo(CFrame.new(-56.386146349609334, 6.0387200000000005, 36.417742533976494) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel12.Parent = workspace.devices.dumb_lamp
newmodel13 = workspace.prefabs.dumb_lamp:clone()
newmodel13:PivotTo(CFrame.new(-54.87072415017301, 5.53648, 37.10959784290712) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel13.Parent = workspace.devices.dumb_lamp
newmodel14 = workspace.prefabs.dumb_lamp:clone()
newmodel14:PivotTo(CFrame.new(-55.298020328554514, 5.53648, 36.91180546903388) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel14.Parent = workspace.devices.dumb_lamp
newmodel15 = workspace.prefabs.dumb_lamp:clone()
newmodel15:PivotTo(CFrame.new(-55.726628521692014, 5.53648, 36.71339064353593) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel15.Parent = workspace.devices.dumb_lamp
newmodel16 = workspace.prefabs.dumb_lamp:clone()
newmodel16:PivotTo(CFrame.new(-56.15391768200127, 5.53648, 36.515592840315506) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel16.Parent = workspace.devices.dumb_lamp
newmodel17 = workspace.prefabs.dumb_lamp:clone()
newmodel17:PivotTo(CFrame.new(-56.58121152948631, 5.53648, 36.317801687021166) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel17.Parent = workspace.devices.dumb_lamp
newmodel18 = workspace.prefabs.dumb_lamp:clone()
newmodel18:PivotTo(CFrame.new(-63.25536753514953, 6.0387200000000005, 32.005253379728295) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel18.Parent = workspace.devices.dumb_lamp
newmodel19 = workspace.prefabs.dumb_lamp:clone()
newmodel19:PivotTo(CFrame.new(-63.35534978448004, 6.0387200000000005, 31.919587950109033) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel19.Parent = workspace.devices.dumb_lamp
newmodel20 = workspace.prefabs.dumb_lamp:clone()
newmodel20:PivotTo(CFrame.new(-63.45533755835236, 6.0387200000000005, 31.83391595351627) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel20.Parent = workspace.devices.dumb_lamp
newmodel21 = workspace.prefabs.dumb_lamp:clone()
newmodel21:PivotTo(CFrame.new(-63.55532299683641, 6.0387200000000005, 31.74824527030595) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel21.Parent = workspace.devices.dumb_lamp
newmodel22 = workspace.prefabs.dumb_lamp:clone()
newmodel22:PivotTo(CFrame.new(-63.65530508104766, 6.0387200000000005, 31.662580096758436) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel22.Parent = workspace.devices.dumb_lamp
newmodel23 = workspace.prefabs.dumb_lamp:clone()
newmodel23:PivotTo(CFrame.new(-63.755285118001204, 6.0387200000000005, 31.576922407121508) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel23.Parent = workspace.devices.dumb_lamp
newmodel24 = workspace.prefabs.dumb_lamp:clone()
newmodel24:PivotTo(CFrame.new(-63.85527931788855, 6.0387200000000005, 31.49124983235994) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel24.Parent = workspace.devices.dumb_lamp
newmodel25 = workspace.prefabs.dumb_lamp:clone()
newmodel25:PivotTo(CFrame.new(-63.955262025210466, 6.0387200000000005, 31.40559077151895) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel25.Parent = workspace.devices.dumb_lamp
newmodel26 = workspace.prefabs.dumb_lamp:clone()
newmodel26:PivotTo(CFrame.new(-64.05524934109144, 6.0387200000000005, 31.319912406148013) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel26.Parent = workspace.devices.dumb_lamp
newmodel27 = workspace.prefabs.dumb_lamp:clone()
newmodel27:PivotTo(CFrame.new(-64.15522527764863, 6.0387200000000005, 31.23424768686562) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel27.Parent = workspace.devices.dumb_lamp
newmodel28 = workspace.prefabs.dumb_lamp:clone()
newmodel28:PivotTo(CFrame.new(-64.25520588023893, 6.0387200000000005, 31.148579886494353) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel28.Parent = workspace.devices.dumb_lamp
newmodel29 = workspace.prefabs.dumb_lamp:clone()
newmodel29:PivotTo(CFrame.new(-64.35518984269912, 6.0387200000000005, 31.06292318814178) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel29.Parent = workspace.devices.dumb_lamp
newmodel30 = workspace.prefabs.dumb_lamp:clone()
newmodel30:PivotTo(CFrame.new(-63.084469470948356, 5.53648, 32.140136001562844) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel30.Parent = workspace.devices.dumb_lamp
newmodel31 = workspace.prefabs.dumb_lamp:clone()
newmodel31:PivotTo(CFrame.new(-63.442026006823035, 5.53648, 31.83378694171941) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel31.Parent = workspace.devices.dumb_lamp
newmodel32 = workspace.prefabs.dumb_lamp:clone()
newmodel32:PivotTo(CFrame.new(-63.80069033610014, 5.53648, 31.526486435859976) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel32.Parent = workspace.devices.dumb_lamp
newmodel33 = workspace.prefabs.dumb_lamp:clone()
newmodel33:PivotTo(CFrame.new(-64.15823719890926, 5.53648, 31.220126983841745) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel33.Parent = workspace.devices.dumb_lamp
newmodel34 = workspace.prefabs.dumb_lamp:clone()
newmodel34:PivotTo(CFrame.new(-64.51580757389733, 5.53648, 30.913769392749515) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel34.Parent = workspace.devices.dumb_lamp
newmodel35 = workspace.prefabs.dumb_lamp:clone()
newmodel35:PivotTo(CFrame.new(-67.54497680388957, 3.2559600000000004, 27.834979910354704) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel35.Parent = workspace.devices.dumb_lamp
newmodel36 = workspace.prefabs.dumb_lamp:clone()
newmodel36:PivotTo(CFrame.new(-67.65501972716405, 3.2559600000000004, 27.698650914769733) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel36.Parent = workspace.devices.dumb_lamp
newmodel37 = workspace.prefabs.dumb_lamp:clone()
newmodel37:PivotTo(CFrame.new(-68.88750046783825, 3.2559600000000004, 26.171766164218077) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel37.Parent = workspace.devices.dumb_lamp
newmodel38 = workspace.prefabs.dumb_lamp:clone()
newmodel38:PivotTo(CFrame.new(-68.99754339111273, 3.2559600000000004, 26.03543716863311) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel38.Parent = workspace.devices.dumb_lamp
newmodel39 = workspace.prefabs.dumb_lamp:clone()
newmodel39:PivotTo(CFrame.new(-68.94619002691796, 2.69824, 26.09905736657276) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel39.Parent = workspace.devices.dumb_lamp
newmodel40 = workspace.prefabs.dumb_lamp:clone()
newmodel40:PivotTo(CFrame.new(-67.59633016808432, 2.69824, 27.77135971241505) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel40.Parent = workspace.devices.dumb_lamp
