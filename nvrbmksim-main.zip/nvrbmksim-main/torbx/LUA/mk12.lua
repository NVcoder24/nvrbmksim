newmodel0 = workspace.prefabs.mk12:clone()
newmodel0:PivotTo(CFrame.new(-30.57731631627324, 2.5899186299808754, 30.93058132134999) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.mk12
newmodel1 = workspace.prefabs.mk12:clone()
newmodel1:PivotTo(CFrame.new(-49.2687937836703, 2.6762110844389415, 33.12400507125374) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.devices.mk12
newmodel2 = workspace.prefabs.mk12:clone()
newmodel2:PivotTo(CFrame.new(-47.97339054363004, 2.6746841158260026, 33.432518563438535) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.mk12
newmodel3 = workspace.prefabs.mk12:clone()
newmodel3:PivotTo(CFrame.new(-48.35422109851226, 2.6283660679001875, 32.790552207341555) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.mk12
newmodel4 = workspace.prefabs.mk12:clone()
newmodel4:PivotTo(CFrame.new(-48.26748361782718, 2.5973177061037616, 32.446430795229254) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.mk12
newmodel5 = workspace.prefabs.mk12:clone()
newmodel5:PivotTo(CFrame.new(-48.18229412261708, 2.5655058600008664, 32.09291959884452) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.mk12
newmodel6 = workspace.prefabs.mk12:clone()
newmodel6:PivotTo(CFrame.new(-47.74876347946389, 2.5973177061037616, 32.57717673662847) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.devices.mk12
newmodel7 = workspace.prefabs.mk12:clone()
newmodel7:PivotTo(CFrame.new(-48.22822030592642, 2.6746841158260026, 33.36828747869002) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.devices.mk12
newmodel8 = workspace.prefabs.mk12:clone()
newmodel8:PivotTo(CFrame.new(-17.469490249278238, 2.7339813969617994, 23.314343412061145) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.devices.mk12
newmodel9 = workspace.prefabs.mk12:clone()
newmodel9:PivotTo(CFrame.new(-17.747050185128874, 2.7339813969617994, 23.638785024650048) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.devices.mk12
newmodel10 = workspace.prefabs.mk12:clone()
newmodel10:PivotTo(CFrame.new(-17.88583015305419, 2.7339813969617994, 23.8010058309445) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.devices.mk12
newmodel11 = workspace.prefabs.mk12:clone()
newmodel11:PivotTo(CFrame.new(-18.302171955039274, 2.7339813969617994, 24.28767046865685) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.devices.mk12
newmodel12 = workspace.prefabs.mk12:clone()
newmodel12:PivotTo(CFrame.new(-18.57973189088991, 2.7339813969617994, 24.612112081245755) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.mk12
newmodel13 = workspace.prefabs.mk12:clone()
newmodel13:PivotTo(CFrame.new(-18.657569719202762, 2.7090409096171295, 24.264574659279827) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.mk12
newmodel14 = workspace.prefabs.mk12:clone()
newmodel14:PivotTo(CFrame.new(-17.54732807759109, 2.7090409096171295, 22.966805990095217) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.mk12
newmodel15 = workspace.prefabs.mk12:clone()
newmodel15:PivotTo(CFrame.new(-19.276956556500867, 2.730163975429452, 25.301677388876033) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.mk12
newmodel16 = workspace.prefabs.mk12:clone()
newmodel16:PivotTo(CFrame.new(-19.56858726348264, 2.730163975429452, 25.58481077447602) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.mk12
newmodel17 = workspace.prefabs.mk12:clone()
newmodel17:PivotTo(CFrame.new(-20.2604667600404, 2.7072594462353674, 25.891643767358755) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel17.Parent = workspace.devices.mk12
newmodel18 = workspace.prefabs.mk12:clone()
newmodel18:PivotTo(CFrame.new(-53.399782903195906, 2.7360173551123848, 32.30714077923811) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel18.Parent = workspace.devices.mk12
newmodel19 = workspace.prefabs.mk12:clone()
newmodel19:PivotTo(CFrame.new(-53.249222775501224, 2.7034419973089934, 31.9665528905102) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel19.Parent = workspace.devices.mk12
newmodel20 = workspace.prefabs.mk12:clone()
newmodel20:PivotTo(CFrame.new(-53.111624832837, 2.6746841447581806, 31.668036110879285) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel20.Parent = workspace.devices.mk12
newmodel21 = workspace.prefabs.mk12:clone()
newmodel21:PivotTo(CFrame.new(-39.65637995425853, 2.7372898236656127, 34.78123384434547) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel21.Parent = workspace.devices.mk12
newmodel22 = workspace.prefabs.mk12:clone()
newmodel22:PivotTo(CFrame.new(-40.14233432377664, 2.737289824507646, 34.7961097840781) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.mk12
newmodel23 = workspace.prefabs.mk12:clone()
newmodel23:PivotTo(CFrame.new(-40.62828401320194, 2.7372898312053513, 34.810979014778226) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel23.Parent = workspace.devices.mk12
newmodel24 = workspace.prefabs.mk12:clone()
newmodel24:PivotTo(CFrame.new(-41.11424078750788, 2.7372898342788012, 34.82585340120243) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.mk12
newmodel25 = workspace.prefabs.mk12:clone()
newmodel25:PivotTo(CFrame.new(-41.600188072195934, 2.737289830140891, 34.84072415599145) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.mk12
newmodel26 = workspace.prefabs.mk12:clone()
newmodel26:PivotTo(CFrame.new(-39.70603786093083, 2.5952815809874004, 33.15883344905837) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.mk12
newmodel27 = workspace.prefabs.mk12:clone()
newmodel27:PivotTo(CFrame.new(-39.69891545291307, 2.6156412642911606, 33.39143667410704) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel27.Parent = workspace.devices.mk12
newmodel28 = workspace.prefabs.mk12:clone()
newmodel28:PivotTo(CFrame.new(-40.19052936500499, 2.595281578153814, 33.1736588647793) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel28.Parent = workspace.devices.mk12
newmodel29 = workspace.prefabs.mk12:clone()
newmodel29:PivotTo(CFrame.new(-40.18340862051279, 2.6156412564801457, 33.406264174332655) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel29.Parent = workspace.devices.mk12
newmodel30 = workspace.prefabs.mk12:clone()
newmodel30:PivotTo(CFrame.new(-40.67502253335073, 2.5952815757287766, 33.188486365133144) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel30.Parent = workspace.devices.mk12
newmodel31 = workspace.prefabs.mk12:clone()
newmodel31:PivotTo(CFrame.new(-40.667903274551534, 2.615641265095093, 33.42109113931859) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel31.Parent = workspace.devices.mk12
newmodel32 = workspace.prefabs.mk12:clone()
newmodel32:PivotTo(CFrame.new(-58.296460143931014, 2.6762110844389415, 28.65900452028515) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel32.Parent = workspace.devices.mk12
newmodel33 = workspace.prefabs.mk12:clone()
newmodel33:PivotTo(CFrame.new(-57.20029093004563, 2.6746841158260026, 29.415088631807656) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel33.Parent = workspace.devices.mk12
newmodel34 = workspace.prefabs.mk12:clone()
newmodel34:PivotTo(CFrame.new(-57.32319751306171, 2.6283660679001875, 28.678850432755443) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel34.Parent = workspace.devices.mk12
newmodel35 = workspace.prefabs.mk12:clone()
newmodel35:PivotTo(CFrame.new(-57.11788733765038, 2.5973177061037616, 28.389384253897997) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel35.Parent = workspace.devices.mk12
newmodel36 = workspace.prefabs.mk12:clone()
newmodel36:PivotTo(CFrame.new(-56.91062480924063, 2.5655058600008664, 28.09060396609319) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel36.Parent = workspace.devices.mk12
newmodel37 = workspace.prefabs.mk12:clone()
newmodel37:PivotTo(CFrame.new(-56.68155315133295, 2.5973177061037616, 28.698863754005362) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel37.Parent = workspace.devices.mk12
newmodel38 = workspace.prefabs.mk12:clone()
newmodel38:PivotTo(CFrame.new(-57.41464724428455, 2.6746841158260026, 29.263051759484178) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel38.Parent = workspace.devices.mk12
newmodel39 = workspace.prefabs.mk12:clone()
newmodel39:PivotTo(CFrame.new(-43.74216749616759, 2.736271849881208, 34.73521694114054) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel39.Parent = workspace.devices.mk12
newmodel40 = workspace.prefabs.mk12:clone()
newmodel40:PivotTo(CFrame.new(-44.15455600203062, 2.736271849881208, 34.709654612763465) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel40.Parent = workspace.devices.mk12
newmodel41 = workspace.prefabs.mk12:clone()
newmodel41:PivotTo(CFrame.new(-61.852543991493135, 2.7360173551123848, 26.403619110721756) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel41.Parent = workspace.devices.mk12
newmodel42 = workspace.prefabs.mk12:clone()
newmodel42:PivotTo(CFrame.new(-61.58900826856271, 2.7034419848583364, 26.140525065509717) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel42.Parent = workspace.devices.mk12
newmodel43 = workspace.prefabs.mk12:clone()
newmodel43:PivotTo(CFrame.new(-61.35277214310171, 2.674684179362693, 25.91196991623248) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel43.Parent = workspace.devices.mk12
newmodel44 = workspace.prefabs.mk12:clone()
newmodel44:PivotTo(CFrame.new(-62.49119600200225, 2.6153872936997367, 23.626498578663064) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel44.Parent = workspace.devices.mk12
newmodel45 = workspace.prefabs.mk12:clone()
newmodel45:PivotTo(CFrame.new(-62.956689895700755, 2.7008969067789774, 24.60796560074709) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel45.Parent = workspace.devices.mk12
newmodel46 = workspace.prefabs.mk12:clone()
newmodel46:PivotTo(CFrame.new(-63.22780453262827, 2.615387218270253, 22.70880001702502) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel46.Parent = workspace.devices.mk12
newmodel47 = workspace.prefabs.mk12:clone()
newmodel47:PivotTo(CFrame.new(-63.69330110997262, 2.700896904142135, 23.690265481421974) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel47.Parent = workspace.devices.mk12
newmodel48 = workspace.prefabs.mk12:clone()
newmodel48:PivotTo(CFrame.new(-64.75485715256366, 2.709040849973522, 22.432374680704676) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel48.Parent = workspace.devices.mk12
newmodel49 = workspace.prefabs.mk12:clone()
newmodel49:PivotTo(CFrame.new(-65.62729199174223, 2.709040932713151, 21.11192015729119) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel49.Parent = workspace.devices.mk12
newmodel50 = workspace.prefabs.mk12:clone()
newmodel50:PivotTo(CFrame.new(-64.08819903790693, 2.639818322968096, 22.00607574899034) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel50.Parent = workspace.devices.mk12
newmodel51 = workspace.prefabs.mk12:clone()
newmodel51:PivotTo(CFrame.new(-63.76562177317322, 2.6059931667301575, 21.792951312863423) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel51.Parent = workspace.devices.mk12
newmodel52 = workspace.prefabs.mk12:clone()
newmodel52:PivotTo(CFrame.new(-64.64449568091496, 2.605993112243359, 20.46274665598168) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel52.Parent = workspace.devices.mk12
newmodel53 = workspace.prefabs.mk12:clone()
newmodel53:PivotTo(CFrame.new(-64.24916709298043, 2.639818526229315, 21.76245237000262) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel53.Parent = workspace.devices.mk12
newmodel54 = workspace.prefabs.mk12:clone()
newmodel54:PivotTo(CFrame.new(-11.741799498144951, 6.172892920139637, -40.78762028021829) * CFrame.fromEulerAngles(0, math.rad(-60.596999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel54.Parent = workspace.devices.mk12
newmodel55 = workspace.prefabs.mk12:clone()
newmodel55:PivotTo(CFrame.new(-11.463040021786421, 6.144898699164905, -40.94471075508375) * CFrame.fromEulerAngles(0, math.rad(-60.596999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel55.Parent = workspace.devices.mk12
newmodel56 = workspace.prefabs.mk12:clone()
newmodel56:PivotTo(CFrame.new(-10.920722952957469, 6.090436513243026, -41.25033382482377) * CFrame.fromEulerAngles(0, math.rad(-60.596999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel56.Parent = workspace.devices.mk12
newmodel57 = workspace.prefabs.mk12:clone()
newmodel57:PivotTo(CFrame.new(-10.641957837296928, 6.062441732379802, -41.40742732782613) * CFrame.fromEulerAngles(0, math.rad(-60.596999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel57.Parent = workspace.devices.mk12
newmodel58 = workspace.prefabs.mk12:clone()
newmodel58:PivotTo(CFrame.new(-10.099641713106152, 6.007979877301123, -41.713044371287836) * CFrame.fromEulerAngles(0, math.rad(-60.596999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel58.Parent = workspace.devices.mk12
newmodel59 = workspace.prefabs.mk12:clone()
newmodel59:PivotTo(CFrame.new(-9.820879623854385, 5.979985529079006, -41.87013317209626) * CFrame.fromEulerAngles(0, math.rad(-60.596999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel59.Parent = workspace.devices.mk12
newmodel60 = workspace.prefabs.mk12:clone()
newmodel60:PivotTo(CFrame.new(-11.123145877061294, 5.94875229250795, -40.89395776399664) * CFrame.fromEulerAngles(0, math.rad(-60.596999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel60.Parent = workspace.devices.mk12
newmodel61 = workspace.prefabs.mk12:clone()
newmodel61:PivotTo(CFrame.new(-10.844386400702763, 5.920758071533218, -41.05104823886211) * CFrame.fromEulerAngles(0, math.rad(-60.596999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel61.Parent = workspace.devices.mk12
newmodel62 = workspace.prefabs.mk12:clone()
newmodel62:PivotTo(CFrame.new(-10.302069246426175, 5.866295885611339, -41.356671156975565) * CFrame.fromEulerAngles(0, math.rad(-60.596999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel62.Parent = workspace.devices.mk12
newmodel63 = workspace.prefabs.mk12:clone()
newmodel63:PivotTo(CFrame.new(-10.023304130765691, 5.838301104748115, -41.51376465997802) * CFrame.fromEulerAngles(0, math.rad(-60.596999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel63.Parent = workspace.devices.mk12
newmodel64 = workspace.prefabs.mk12:clone()
newmodel64:PivotTo(CFrame.new(-9.480988092022493, 5.783839249669436, -41.8193818550662) * CFrame.fromEulerAngles(0, math.rad(-60.596999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel64.Parent = workspace.devices.mk12
newmodel65 = workspace.prefabs.mk12:clone()
newmodel65:PivotTo(CFrame.new(-9.202226002770725, 5.755844901447318, -41.97647065587462) * CFrame.fromEulerAngles(0, math.rad(-60.596999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel65.Parent = workspace.devices.mk12
newmodel66 = workspace.prefabs.mk12:clone()
newmodel66:PivotTo(CFrame.new(-10.314233168428135, 6.8882413173347405, -42.07073817373926) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel66.Parent = workspace.devices.mk12
newmodel67 = workspace.prefabs.mk12:clone()
newmodel67:PivotTo(CFrame.new(-9.696481425668962, 6.727303626479911, -42.17692063786133) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel67.Parent = workspace.devices.mk12
newmodel68 = workspace.prefabs.mk12:clone()
newmodel68:PivotTo(CFrame.new(-9.211907094603488, 6.680841152772788, -42.394225663737075) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel68.Parent = workspace.devices.mk12
newmodel69 = workspace.prefabs.mk12:clone()
newmodel69:PivotTo(CFrame.new(-8.01335437935347, 6.565920985973464, -42.93169004419255) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel69.Parent = workspace.devices.mk12
newmodel70 = workspace.prefabs.mk12:clone()
newmodel70:PivotTo(CFrame.new(-7.988244426881219, 6.362050560213905, -42.6045553290693) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel70.Parent = workspace.devices.mk12
newmodel71 = workspace.prefabs.mk12:clone()
newmodel71:PivotTo(CFrame.new(-7.0191040410639856, 6.269127037970364, -43.03914402563085) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel71.Parent = workspace.devices.mk12
newmodel72 = workspace.prefabs.mk12:clone()
newmodel72:PivotTo(CFrame.new(-6.7896917116311934, 6.247130393414579, -43.14201970952479) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel72.Parent = workspace.devices.mk12
newmodel73 = workspace.prefabs.mk12:clone()
newmodel73:PivotTo(CFrame.new(-7.760157294242231, 6.340181392087823, -42.706825212039064) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel73.Parent = workspace.devices.mk12
newmodel74 = workspace.prefabs.mk12:clone()
newmodel74:PivotTo(CFrame.new(-7.275758958101173, 6.293736045878642, -42.92404425859648) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel74.Parent = workspace.devices.mk12
newmodel75 = workspace.prefabs.mk12:clone()
newmodel75:PivotTo(CFrame.new(-7.5040227233324615, 6.315622392401619, -42.821688396470236) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel75.Parent = workspace.devices.mk12
newmodel76 = workspace.prefabs.mk12:clone()
newmodel76:PivotTo(CFrame.new(-9.829658837362665, 6.841778843627618, -42.288043199615004) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel76.Parent = workspace.devices.mk12
newmodel77 = workspace.prefabs.mk12:clone()
newmodel77:PivotTo(CFrame.new(-9.345094058109494, 6.795317616944863, -42.50533469106426) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel77.Parent = workspace.devices.mk12
newmodel78 = workspace.prefabs.mk12:clone()
newmodel78:PivotTo(CFrame.new(-8.860518451545438, 6.748855321384078, -42.72263189617654) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel78.Parent = workspace.devices.mk12
newmodel79 = workspace.prefabs.mk12:clone()
newmodel79:PivotTo(CFrame.new(-8.375955766603559, 6.70239419649923, -42.939925214258025) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel79.Parent = workspace.devices.mk12
newmodel80 = workspace.prefabs.mk12:clone()
newmodel80:PivotTo(CFrame.new(-9.090570500705876, 6.569450724775857, -42.28106783907148) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel80.Parent = workspace.devices.mk12
newmodel81 = workspace.prefabs.mk12:clone()
newmodel81:PivotTo(CFrame.new(-8.605996169640402, 6.5229882510687345, -42.49837286494724) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel81.Parent = workspace.devices.mk12
newmodel82 = workspace.prefabs.mk12:clone()
newmodel82:PivotTo(CFrame.new(-8.121431390387224, 6.476527024385979, -42.71566435639649) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel82.Parent = workspace.devices.mk12
newmodel83 = workspace.prefabs.mk12:clone()
newmodel83:PivotTo(CFrame.new(-7.636855783823168, 6.430064728825194, -42.932961561508776) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel83.Parent = workspace.devices.mk12
newmodel84 = workspace.prefabs.mk12:clone()
newmodel84:PivotTo(CFrame.new(-7.1522930988812945, 6.383603603940346, -43.15025487959025) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel84.Parent = workspace.devices.mk12
newmodel85 = workspace.prefabs.mk12:clone()
newmodel85:PivotTo(CFrame.new(-8.24276670878626, 6.587917630529248, -42.82881436029861) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel85.Parent = workspace.devices.mk12
newmodel86 = workspace.prefabs.mk12:clone()
newmodel86:PivotTo(CFrame.new(-7.530619004298685, 6.51963515708538, -43.14816145801625) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel86.Parent = workspace.devices.mk12
newmodel87 = workspace.prefabs.mk12:clone()
newmodel87:PivotTo(CFrame.new(-7.758888200989288, 6.541522038047373, -43.04580277876097) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel87.Parent = workspace.devices.mk12
newmodel88 = workspace.prefabs.mk12:clone()
newmodel88:PivotTo(CFrame.new(-8.9838199619645, 6.6589719846467075, -42.49649554670684) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel88.Parent = workspace.devices.mk12
newmodel89 = workspace.prefabs.mk12:clone()
newmodel89:PivotTo(CFrame.new(-9.468219201359325, 6.705417127260072, -42.279284201726156) * CFrame.fromEulerAngles(0, math.rad(-65.847), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel89.Parent = workspace.devices.mk12
