newmodel0 = workspace.prefabs.pamir_lamp:clone()
newmodel0:PivotTo(CFrame.new(-24.022973210473225, 3.416009728392031, 29.95852453639875) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel0.Parent = workspace.devices.pamir
newmodel1 = workspace.prefabs.pamir_lamp:clone()
newmodel1:PivotTo(CFrame.new(-24.040374940316827, 3.237432771866712, 29.932282595266706) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel1.Parent = workspace.devices.pamir
newmodel2 = workspace.prefabs.pamir_lamp:clone()
newmodel2:PivotTo(CFrame.new(-23.419095119299207, 3.01543629089182, 29.47326548471022) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel2.Parent = workspace.devices.pamir
newmodel3 = workspace.prefabs.pamir_lamp:clone()
newmodel3:PivotTo(CFrame.new(-23.380054879995036, 3.416012983305566, 29.532130457343236) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel3.Parent = workspace.devices.pamir
newmodel4 = workspace.prefabs.pamir_lamp:clone()
newmodel4:PivotTo(CFrame.new(-23.39745709908813, 3.2374355233689895, 29.505886273655996) * CFrame.fromEulerAngles(0, math.rad(33.553), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel4.Parent = workspace.devices.pamir
