newmodel0 = workspace.scam.prefabs.numpart:clone()
newmodel0:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -0.668, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel0:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -0.668, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel0.SurfaceGui.TextLabel.Text = "66-31"
newmodel0.Parent = workspace.scam.selsins.np
newmodel1 = workspace.scam.prefabs.numpart:clone()
newmodel1:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -0.668, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel1:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -0.668, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel1.SurfaceGui.TextLabel.Text = "66-35"
newmodel1.Parent = workspace.scam.selsins.np
newmodel2 = workspace.scam.prefabs.numpart:clone()
newmodel2:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -0.668, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel2:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -0.668, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel2.SurfaceGui.TextLabel.Text = "66-41"
newmodel2.Parent = workspace.scam.selsins.np
newmodel3 = workspace.scam.prefabs.numpart:clone()
newmodel3:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -0.668, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel3:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -0.668, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel3.SurfaceGui.TextLabel.Text = "66-45"
newmodel3.Parent = workspace.scam.selsins.np
newmodel4 = workspace.scam.prefabs.numpart:clone()
newmodel4:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -0.9506, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel4.SurfaceGui.TextLabel.Text = "64-23"
newmodel4.Parent = workspace.scam.selsins.np
newmodel5 = workspace.scam.prefabs.numpart:clone()
newmodel5:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -0.9506, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel5:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -0.9506, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel5.SurfaceGui.TextLabel.Text = "64-27"
newmodel5.Parent = workspace.scam.selsins.np
newmodel6 = workspace.scam.prefabs.numpart:clone()
newmodel6:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -0.9506, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel6:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -0.9506, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel6.SurfaceGui.TextLabel.Text = "64-33"
newmodel6.Parent = workspace.scam.selsins.np
newmodel7 = workspace.scam.prefabs.numpart:clone()
newmodel7:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -0.9506, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel7:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -0.9506, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel7.SurfaceGui.TextLabel.Text = "64-37"
newmodel7.Parent = workspace.scam.selsins.np
newmodel8 = workspace.scam.prefabs.numpart:clone()
newmodel8:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -0.9506, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel8:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -0.9506, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel8.SurfaceGui.TextLabel.Text = "64-43"
newmodel8.Parent = workspace.scam.selsins.np
newmodel9 = workspace.scam.prefabs.numpart:clone()
newmodel9:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -0.9506, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel9:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -0.9506, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel9.SurfaceGui.TextLabel.Text = "64-47"
newmodel9.Parent = workspace.scam.selsins.np
newmodel10 = workspace.scam.prefabs.numpart:clone()
newmodel10:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -0.9506, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel10:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -0.9506, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel10.SurfaceGui.TextLabel.Text = "64-53"
newmodel10.Parent = workspace.scam.selsins.np
newmodel11 = workspace.scam.prefabs.numpart:clone()
newmodel11:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel11.SurfaceGui.TextLabel.Text = "62-21"
newmodel11.Parent = workspace.scam.selsins.np
newmodel12 = workspace.scam.prefabs.numpart:clone()
newmodel12:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel12:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel12.SurfaceGui.TextLabel.Text = "62-25"
newmodel12.Parent = workspace.scam.selsins.np
newmodel13 = workspace.scam.prefabs.numpart:clone()
newmodel13:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel13:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel13.SurfaceGui.TextLabel.Text = "62-31"
newmodel13.Parent = workspace.scam.selsins.np
newmodel14 = workspace.scam.prefabs.numpart:clone()
newmodel14:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel14:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel14.SurfaceGui.TextLabel.Text = "62-35"
newmodel14.Parent = workspace.scam.selsins.np
newmodel15 = workspace.scam.prefabs.numpart:clone()
newmodel15:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel15:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel15.SurfaceGui.TextLabel.Text = "62-41"
newmodel15.Parent = workspace.scam.selsins.np
newmodel16 = workspace.scam.prefabs.numpart:clone()
newmodel16:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel16:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel16.SurfaceGui.TextLabel.Text = "62-45"
newmodel16.Parent = workspace.scam.selsins.np
newmodel17 = workspace.scam.prefabs.numpart:clone()
newmodel17:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel17:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel17.SurfaceGui.TextLabel.Text = "62-51"
newmodel17.Parent = workspace.scam.selsins.np
newmodel18 = workspace.scam.prefabs.numpart:clone()
newmodel18:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel18:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -1.2332, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel18.SurfaceGui.TextLabel.Text = "62-55"
newmodel18.Parent = workspace.scam.selsins.np
newmodel19 = workspace.scam.prefabs.numpart:clone()
newmodel19:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -1.5158000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel19.SurfaceGui.TextLabel.Text = "60-17"
newmodel19.Parent = workspace.scam.selsins.np
newmodel20 = workspace.scam.prefabs.numpart:clone()
newmodel20:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -1.5158000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel20.SurfaceGui.TextLabel.Text = "60-23"
newmodel20.Parent = workspace.scam.selsins.np
newmodel21 = workspace.scam.prefabs.numpart:clone()
newmodel21:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -1.5158000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel21:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -1.5158000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel21.SurfaceGui.TextLabel.Text = "60-33"
newmodel21.Parent = workspace.scam.selsins.np
newmodel22 = workspace.scam.prefabs.numpart:clone()
newmodel22:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -1.5158000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel22:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -1.5158000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel22.SurfaceGui.TextLabel.Text = "60-37"
newmodel22.Parent = workspace.scam.selsins.np
newmodel23 = workspace.scam.prefabs.numpart:clone()
newmodel23:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -1.5158000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel23:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -1.5158000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel23.SurfaceGui.TextLabel.Text = "60-43"
newmodel23.Parent = workspace.scam.selsins.np
newmodel24 = workspace.scam.prefabs.numpart:clone()
newmodel24:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -1.5158000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel24:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -1.5158000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel24.SurfaceGui.TextLabel.Text = "60-53"
newmodel24.Parent = workspace.scam.selsins.np
newmodel25 = workspace.scam.prefabs.numpart:clone()
newmodel25:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -1.5158000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel25:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -1.5158000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel25.SurfaceGui.TextLabel.Text = "60-57"
newmodel25.Parent = workspace.scam.selsins.np
newmodel26 = workspace.scam.prefabs.numpart:clone()
newmodel26:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel26.SurfaceGui.TextLabel.Text = "56-15"
newmodel26.Parent = workspace.scam.selsins.np
newmodel27 = workspace.scam.prefabs.numpart:clone()
newmodel27:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel27.SurfaceGui.TextLabel.Text = "56-21"
newmodel27.Parent = workspace.scam.selsins.np
newmodel28 = workspace.scam.prefabs.numpart:clone()
newmodel28:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel28:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel28.SurfaceGui.TextLabel.Text = "56-25"
newmodel28.Parent = workspace.scam.selsins.np
newmodel29 = workspace.scam.prefabs.numpart:clone()
newmodel29:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel29:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel29.SurfaceGui.TextLabel.Text = "56-31"
newmodel29.Parent = workspace.scam.selsins.np
newmodel30 = workspace.scam.prefabs.numpart:clone()
newmodel30:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel30:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel30.SurfaceGui.TextLabel.Text = "56-35"
newmodel30.Parent = workspace.scam.selsins.np
newmodel31 = workspace.scam.prefabs.numpart:clone()
newmodel31:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel31:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel31.SurfaceGui.TextLabel.Text = "56-41"
newmodel31.Parent = workspace.scam.selsins.np
newmodel32 = workspace.scam.prefabs.numpart:clone()
newmodel32:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel32:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel32.SurfaceGui.TextLabel.Text = "56-45"
newmodel32.Parent = workspace.scam.selsins.np
newmodel33 = workspace.scam.prefabs.numpart:clone()
newmodel33:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel33:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel33.SurfaceGui.TextLabel.Text = "56-51"
newmodel33.Parent = workspace.scam.selsins.np
newmodel34 = workspace.scam.prefabs.numpart:clone()
newmodel34:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel34:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel34.SurfaceGui.TextLabel.Text = "56-55"
newmodel34.Parent = workspace.scam.selsins.np
newmodel35 = workspace.scam.prefabs.numpart:clone()
newmodel35:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel35:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -1.7984000000000002, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel35.SurfaceGui.TextLabel.Text = "56-61"
newmodel35.Parent = workspace.scam.selsins.np
newmodel36 = workspace.scam.prefabs.numpart:clone()
newmodel36:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel36.SurfaceGui.TextLabel.Text = "54-13"
newmodel36.Parent = workspace.scam.selsins.np
newmodel37 = workspace.scam.prefabs.numpart:clone()
newmodel37:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel37.SurfaceGui.TextLabel.Text = "54-17"
newmodel37.Parent = workspace.scam.selsins.np
newmodel38 = workspace.scam.prefabs.numpart:clone()
newmodel38:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel38.SurfaceGui.TextLabel.Text = "54-23"
newmodel38.Parent = workspace.scam.selsins.np
newmodel39 = workspace.scam.prefabs.numpart:clone()
newmodel39:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel39:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel39.SurfaceGui.TextLabel.Text = "54-27"
newmodel39.Parent = workspace.scam.selsins.np
newmodel40 = workspace.scam.prefabs.numpart:clone()
newmodel40:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel40:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel40.SurfaceGui.TextLabel.Text = "54-33"
newmodel40.Parent = workspace.scam.selsins.np
newmodel41 = workspace.scam.prefabs.numpart:clone()
newmodel41:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel41:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel41.SurfaceGui.TextLabel.Text = "54-37"
newmodel41.Parent = workspace.scam.selsins.np
newmodel42 = workspace.scam.prefabs.numpart:clone()
newmodel42:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel42:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel42.SurfaceGui.TextLabel.Text = "54-43"
newmodel42.Parent = workspace.scam.selsins.np
newmodel43 = workspace.scam.prefabs.numpart:clone()
newmodel43:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel43:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel43.SurfaceGui.TextLabel.Text = "54-47"
newmodel43.Parent = workspace.scam.selsins.np
newmodel44 = workspace.scam.prefabs.numpart:clone()
newmodel44:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel44:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel44.SurfaceGui.TextLabel.Text = "54-53"
newmodel44.Parent = workspace.scam.selsins.np
newmodel45 = workspace.scam.prefabs.numpart:clone()
newmodel45:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel45:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel45.SurfaceGui.TextLabel.Text = "54-57"
newmodel45.Parent = workspace.scam.selsins.np
newmodel46 = workspace.scam.prefabs.numpart:clone()
newmodel46:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel46:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -2.081, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel46.SurfaceGui.TextLabel.Text = "54-63"
newmodel46.Parent = workspace.scam.selsins.np
newmodel47 = workspace.scam.prefabs.numpart:clone()
newmodel47:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel47.SurfaceGui.TextLabel.Text = "52-15"
newmodel47.Parent = workspace.scam.selsins.np
newmodel48 = workspace.scam.prefabs.numpart:clone()
newmodel48:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel48.SurfaceGui.TextLabel.Text = "52-21"
newmodel48.Parent = workspace.scam.selsins.np
newmodel49 = workspace.scam.prefabs.numpart:clone()
newmodel49:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel49:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel49.SurfaceGui.TextLabel.Text = "52-25"
newmodel49.Parent = workspace.scam.selsins.np
newmodel50 = workspace.scam.prefabs.numpart:clone()
newmodel50:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel50:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel50.SurfaceGui.TextLabel.Text = "52-31"
newmodel50.Parent = workspace.scam.selsins.np
newmodel51 = workspace.scam.prefabs.numpart:clone()
newmodel51:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel51:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel51.SurfaceGui.TextLabel.Text = "52-35"
newmodel51.Parent = workspace.scam.selsins.np
newmodel52 = workspace.scam.prefabs.numpart:clone()
newmodel52:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel52:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel52.SurfaceGui.TextLabel.Text = "52-41"
newmodel52.Parent = workspace.scam.selsins.np
newmodel53 = workspace.scam.prefabs.numpart:clone()
newmodel53:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel53:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel53.SurfaceGui.TextLabel.Text = "52-45"
newmodel53.Parent = workspace.scam.selsins.np
newmodel54 = workspace.scam.prefabs.numpart:clone()
newmodel54:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel54:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel54.SurfaceGui.TextLabel.Text = "52-51"
newmodel54.Parent = workspace.scam.selsins.np
newmodel55 = workspace.scam.prefabs.numpart:clone()
newmodel55:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel55:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel55.SurfaceGui.TextLabel.Text = "52-55"
newmodel55.Parent = workspace.scam.selsins.np
newmodel56 = workspace.scam.prefabs.numpart:clone()
newmodel56:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel56:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -2.3636000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel56.SurfaceGui.TextLabel.Text = "52-61"
newmodel56.Parent = workspace.scam.selsins.np
newmodel57 = workspace.scam.prefabs.numpart:clone()
newmodel57:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel57.SurfaceGui.TextLabel.Text = "50-13"
newmodel57.Parent = workspace.scam.selsins.np
newmodel58 = workspace.scam.prefabs.numpart:clone()
newmodel58:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel58.SurfaceGui.TextLabel.Text = "50-23"
newmodel58.Parent = workspace.scam.selsins.np
newmodel59 = workspace.scam.prefabs.numpart:clone()
newmodel59:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel59:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel59.SurfaceGui.TextLabel.Text = "50-27"
newmodel59.Parent = workspace.scam.selsins.np
newmodel60 = workspace.scam.prefabs.numpart:clone()
newmodel60:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel60:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel60.SurfaceGui.TextLabel.Text = "50-33"
newmodel60.Parent = workspace.scam.selsins.np
newmodel61 = workspace.scam.prefabs.numpart:clone()
newmodel61:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel61:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel61.SurfaceGui.TextLabel.Text = "50-43"
newmodel61.Parent = workspace.scam.selsins.np
newmodel62 = workspace.scam.prefabs.numpart:clone()
newmodel62:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel62:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel62.SurfaceGui.TextLabel.Text = "50-47"
newmodel62.Parent = workspace.scam.selsins.np
newmodel63 = workspace.scam.prefabs.numpart:clone()
newmodel63:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel63:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel63.SurfaceGui.TextLabel.Text = "50-53"
newmodel63.Parent = workspace.scam.selsins.np
newmodel64 = workspace.scam.prefabs.numpart:clone()
newmodel64:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel64:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -2.6462000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel64.SurfaceGui.TextLabel.Text = "50-63"
newmodel64.Parent = workspace.scam.selsins.np
newmodel65 = workspace.scam.prefabs.numpart:clone()
newmodel65:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.19, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel65.SurfaceGui.TextLabel.Text = "46-11"
newmodel65.Parent = workspace.scam.selsins.np
newmodel66 = workspace.scam.prefabs.numpart:clone()
newmodel66:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel66.SurfaceGui.TextLabel.Text = "46-15"
newmodel66.Parent = workspace.scam.selsins.np
newmodel67 = workspace.scam.prefabs.numpart:clone()
newmodel67:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel67.SurfaceGui.TextLabel.Text = "46-21"
newmodel67.Parent = workspace.scam.selsins.np
newmodel68 = workspace.scam.prefabs.numpart:clone()
newmodel68:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel68:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel68.SurfaceGui.TextLabel.Text = "46-25"
newmodel68.Parent = workspace.scam.selsins.np
newmodel69 = workspace.scam.prefabs.numpart:clone()
newmodel69:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel69:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel69.SurfaceGui.TextLabel.Text = "46-31"
newmodel69.Parent = workspace.scam.selsins.np
newmodel70 = workspace.scam.prefabs.numpart:clone()
newmodel70:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel70:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel70.SurfaceGui.TextLabel.Text = "46-35"
newmodel70.Parent = workspace.scam.selsins.np
newmodel71 = workspace.scam.prefabs.numpart:clone()
newmodel71:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel71:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel71.SurfaceGui.TextLabel.Text = "46-41"
newmodel71.Parent = workspace.scam.selsins.np
newmodel72 = workspace.scam.prefabs.numpart:clone()
newmodel72:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel72:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel72.SurfaceGui.TextLabel.Text = "46-45"
newmodel72.Parent = workspace.scam.selsins.np
newmodel73 = workspace.scam.prefabs.numpart:clone()
newmodel73:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel73:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel73.SurfaceGui.TextLabel.Text = "46-51"
newmodel73.Parent = workspace.scam.selsins.np
newmodel74 = workspace.scam.prefabs.numpart:clone()
newmodel74:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel74:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel74.SurfaceGui.TextLabel.Text = "46-55"
newmodel74.Parent = workspace.scam.selsins.np
newmodel75 = workspace.scam.prefabs.numpart:clone()
newmodel75:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel75:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel75.SurfaceGui.TextLabel.Text = "46-61"
newmodel75.Parent = workspace.scam.selsins.np
newmodel76 = workspace.scam.prefabs.numpart:clone()
newmodel76:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel76:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-2.114, -2.9288000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel76.SurfaceGui.TextLabel.Text = "46-65"
newmodel76.Parent = workspace.scam.selsins.np
newmodel77 = workspace.scam.prefabs.numpart:clone()
newmodel77:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel77.SurfaceGui.TextLabel.Text = "44-13"
newmodel77.Parent = workspace.scam.selsins.np
newmodel78 = workspace.scam.prefabs.numpart:clone()
newmodel78:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel78.SurfaceGui.TextLabel.Text = "44-17"
newmodel78.Parent = workspace.scam.selsins.np
newmodel79 = workspace.scam.prefabs.numpart:clone()
newmodel79:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel79.SurfaceGui.TextLabel.Text = "44-23"
newmodel79.Parent = workspace.scam.selsins.np
newmodel80 = workspace.scam.prefabs.numpart:clone()
newmodel80:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel80:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel80.SurfaceGui.TextLabel.Text = "44-27"
newmodel80.Parent = workspace.scam.selsins.np
newmodel81 = workspace.scam.prefabs.numpart:clone()
newmodel81:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel81:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel81.SurfaceGui.TextLabel.Text = "44-33"
newmodel81.Parent = workspace.scam.selsins.np
newmodel82 = workspace.scam.prefabs.numpart:clone()
newmodel82:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel82:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel82.SurfaceGui.TextLabel.Text = "44-37"
newmodel82.Parent = workspace.scam.selsins.np
newmodel83 = workspace.scam.prefabs.numpart:clone()
newmodel83:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel83:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel83.SurfaceGui.TextLabel.Text = "44-43"
newmodel83.Parent = workspace.scam.selsins.np
newmodel84 = workspace.scam.prefabs.numpart:clone()
newmodel84:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel84:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel84.SurfaceGui.TextLabel.Text = "44-47"
newmodel84.Parent = workspace.scam.selsins.np
newmodel85 = workspace.scam.prefabs.numpart:clone()
newmodel85:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel85:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel85.SurfaceGui.TextLabel.Text = "44-53"
newmodel85.Parent = workspace.scam.selsins.np
newmodel86 = workspace.scam.prefabs.numpart:clone()
newmodel86:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel86:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel86.SurfaceGui.TextLabel.Text = "44-57"
newmodel86.Parent = workspace.scam.selsins.np
newmodel87 = workspace.scam.prefabs.numpart:clone()
newmodel87:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel87:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -3.2114000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel87.SurfaceGui.TextLabel.Text = "44-63"
newmodel87.Parent = workspace.scam.selsins.np
newmodel88 = workspace.scam.prefabs.numpart:clone()
newmodel88:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.19, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel88.SurfaceGui.TextLabel.Text = "42-11"
newmodel88.Parent = workspace.scam.selsins.np
newmodel89 = workspace.scam.prefabs.numpart:clone()
newmodel89:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel89.SurfaceGui.TextLabel.Text = "42-15"
newmodel89.Parent = workspace.scam.selsins.np
newmodel90 = workspace.scam.prefabs.numpart:clone()
newmodel90:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel90.SurfaceGui.TextLabel.Text = "42-21"
newmodel90.Parent = workspace.scam.selsins.np
newmodel91 = workspace.scam.prefabs.numpart:clone()
newmodel91:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel91:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel91.SurfaceGui.TextLabel.Text = "42-25"
newmodel91.Parent = workspace.scam.selsins.np
newmodel92 = workspace.scam.prefabs.numpart:clone()
newmodel92:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel92:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel92.SurfaceGui.TextLabel.Text = "42-31"
newmodel92.Parent = workspace.scam.selsins.np
newmodel93 = workspace.scam.prefabs.numpart:clone()
newmodel93:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel93:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel93.SurfaceGui.TextLabel.Text = "42-35"
newmodel93.Parent = workspace.scam.selsins.np
newmodel94 = workspace.scam.prefabs.numpart:clone()
newmodel94:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel94:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel94.SurfaceGui.TextLabel.Text = "42-41"
newmodel94.Parent = workspace.scam.selsins.np
newmodel95 = workspace.scam.prefabs.numpart:clone()
newmodel95:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel95:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel95.SurfaceGui.TextLabel.Text = "42-45"
newmodel95.Parent = workspace.scam.selsins.np
newmodel96 = workspace.scam.prefabs.numpart:clone()
newmodel96:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel96:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel96.SurfaceGui.TextLabel.Text = "42-51"
newmodel96.Parent = workspace.scam.selsins.np
newmodel97 = workspace.scam.prefabs.numpart:clone()
newmodel97:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel97:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel97.SurfaceGui.TextLabel.Text = "42-55"
newmodel97.Parent = workspace.scam.selsins.np
newmodel98 = workspace.scam.prefabs.numpart:clone()
newmodel98:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel98:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel98.SurfaceGui.TextLabel.Text = "42-61"
newmodel98.Parent = workspace.scam.selsins.np
newmodel99 = workspace.scam.prefabs.numpart:clone()
newmodel99:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel99:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-2.114, -3.494, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel99.SurfaceGui.TextLabel.Text = "42-65"
newmodel99.Parent = workspace.scam.selsins.np
newmodel100 = workspace.scam.prefabs.numpart:clone()
newmodel100:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel100.SurfaceGui.TextLabel.Text = "40-13"
newmodel100.Parent = workspace.scam.selsins.np
newmodel101 = workspace.scam.prefabs.numpart:clone()
newmodel101:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel101.SurfaceGui.TextLabel.Text = "40-17"
newmodel101.Parent = workspace.scam.selsins.np
newmodel102 = workspace.scam.prefabs.numpart:clone()
newmodel102:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel102.SurfaceGui.TextLabel.Text = "40-23"
newmodel102.Parent = workspace.scam.selsins.np
newmodel103 = workspace.scam.prefabs.numpart:clone()
newmodel103:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel103:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel103.SurfaceGui.TextLabel.Text = "40-33"
newmodel103.Parent = workspace.scam.selsins.np
newmodel104 = workspace.scam.prefabs.numpart:clone()
newmodel104:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel104:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel104.SurfaceGui.TextLabel.Text = "40-37"
newmodel104.Parent = workspace.scam.selsins.np
newmodel105 = workspace.scam.prefabs.numpart:clone()
newmodel105:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel105:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel105.SurfaceGui.TextLabel.Text = "40-43"
newmodel105.Parent = workspace.scam.selsins.np
newmodel106 = workspace.scam.prefabs.numpart:clone()
newmodel106:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel106:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel106.SurfaceGui.TextLabel.Text = "40-53"
newmodel106.Parent = workspace.scam.selsins.np
newmodel107 = workspace.scam.prefabs.numpart:clone()
newmodel107:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel107:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel107.SurfaceGui.TextLabel.Text = "40-57"
newmodel107.Parent = workspace.scam.selsins.np
newmodel108 = workspace.scam.prefabs.numpart:clone()
newmodel108:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel108:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -3.7766000000000006, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel108.SurfaceGui.TextLabel.Text = "40-63"
newmodel108.Parent = workspace.scam.selsins.np
newmodel109 = workspace.scam.prefabs.numpart:clone()
newmodel109:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.19, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel109.SurfaceGui.TextLabel.Text = "36-11"
newmodel109.Parent = workspace.scam.selsins.np
newmodel110 = workspace.scam.prefabs.numpart:clone()
newmodel110:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel110.SurfaceGui.TextLabel.Text = "36-15"
newmodel110.Parent = workspace.scam.selsins.np
newmodel111 = workspace.scam.prefabs.numpart:clone()
newmodel111:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel111.SurfaceGui.TextLabel.Text = "36-21"
newmodel111.Parent = workspace.scam.selsins.np
newmodel112 = workspace.scam.prefabs.numpart:clone()
newmodel112:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel112:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel112.SurfaceGui.TextLabel.Text = "36-25"
newmodel112.Parent = workspace.scam.selsins.np
newmodel113 = workspace.scam.prefabs.numpart:clone()
newmodel113:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel113:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel113.SurfaceGui.TextLabel.Text = "36-31"
newmodel113.Parent = workspace.scam.selsins.np
newmodel114 = workspace.scam.prefabs.numpart:clone()
newmodel114:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel114:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel114.SurfaceGui.TextLabel.Text = "36-35"
newmodel114.Parent = workspace.scam.selsins.np
newmodel115 = workspace.scam.prefabs.numpart:clone()
newmodel115:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel115:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel115.SurfaceGui.TextLabel.Text = "36-41"
newmodel115.Parent = workspace.scam.selsins.np
newmodel116 = workspace.scam.prefabs.numpart:clone()
newmodel116:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel116:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel116.SurfaceGui.TextLabel.Text = "36-45"
newmodel116.Parent = workspace.scam.selsins.np
newmodel117 = workspace.scam.prefabs.numpart:clone()
newmodel117:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel117:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel117.SurfaceGui.TextLabel.Text = "36-51"
newmodel117.Parent = workspace.scam.selsins.np
newmodel118 = workspace.scam.prefabs.numpart:clone()
newmodel118:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel118:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel118.SurfaceGui.TextLabel.Text = "36-55"
newmodel118.Parent = workspace.scam.selsins.np
newmodel119 = workspace.scam.prefabs.numpart:clone()
newmodel119:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel119:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel119.SurfaceGui.TextLabel.Text = "36-61"
newmodel119.Parent = workspace.scam.selsins.np
newmodel120 = workspace.scam.prefabs.numpart:clone()
newmodel120:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel120:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-2.114, -4.059200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel120.SurfaceGui.TextLabel.Text = "36-65"
newmodel120.Parent = workspace.scam.selsins.np
newmodel121 = workspace.scam.prefabs.numpart:clone()
newmodel121:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel121.SurfaceGui.TextLabel.Text = "34-13"
newmodel121.Parent = workspace.scam.selsins.np
newmodel122 = workspace.scam.prefabs.numpart:clone()
newmodel122:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel122.SurfaceGui.TextLabel.Text = "34-17"
newmodel122.Parent = workspace.scam.selsins.np
newmodel123 = workspace.scam.prefabs.numpart:clone()
newmodel123:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel123.SurfaceGui.TextLabel.Text = "34-23"
newmodel123.Parent = workspace.scam.selsins.np
newmodel124 = workspace.scam.prefabs.numpart:clone()
newmodel124:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel124:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel124.SurfaceGui.TextLabel.Text = "34-27"
newmodel124.Parent = workspace.scam.selsins.np
newmodel125 = workspace.scam.prefabs.numpart:clone()
newmodel125:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel125:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel125.SurfaceGui.TextLabel.Text = "34-33"
newmodel125.Parent = workspace.scam.selsins.np
newmodel126 = workspace.scam.prefabs.numpart:clone()
newmodel126:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel126:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel126.SurfaceGui.TextLabel.Text = "34-37"
newmodel126.Parent = workspace.scam.selsins.np
newmodel127 = workspace.scam.prefabs.numpart:clone()
newmodel127:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel127:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel127.SurfaceGui.TextLabel.Text = "34-43"
newmodel127.Parent = workspace.scam.selsins.np
newmodel128 = workspace.scam.prefabs.numpart:clone()
newmodel128:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel128:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel128.SurfaceGui.TextLabel.Text = "34-47"
newmodel128.Parent = workspace.scam.selsins.np
newmodel129 = workspace.scam.prefabs.numpart:clone()
newmodel129:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel129:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel129.SurfaceGui.TextLabel.Text = "34-53"
newmodel129.Parent = workspace.scam.selsins.np
newmodel130 = workspace.scam.prefabs.numpart:clone()
newmodel130:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel130:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel130.SurfaceGui.TextLabel.Text = "34-57"
newmodel130.Parent = workspace.scam.selsins.np
newmodel131 = workspace.scam.prefabs.numpart:clone()
newmodel131:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel131:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -4.3418, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel131.SurfaceGui.TextLabel.Text = "34-63"
newmodel131.Parent = workspace.scam.selsins.np
newmodel132 = workspace.scam.prefabs.numpart:clone()
newmodel132:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.19, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel132.SurfaceGui.TextLabel.Text = "32-11"
newmodel132.Parent = workspace.scam.selsins.np
newmodel133 = workspace.scam.prefabs.numpart:clone()
newmodel133:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel133.SurfaceGui.TextLabel.Text = "32-15"
newmodel133.Parent = workspace.scam.selsins.np
newmodel134 = workspace.scam.prefabs.numpart:clone()
newmodel134:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel134.SurfaceGui.TextLabel.Text = "32-21"
newmodel134.Parent = workspace.scam.selsins.np
newmodel135 = workspace.scam.prefabs.numpart:clone()
newmodel135:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel135:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel135.SurfaceGui.TextLabel.Text = "32-25"
newmodel135.Parent = workspace.scam.selsins.np
newmodel136 = workspace.scam.prefabs.numpart:clone()
newmodel136:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel136:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel136.SurfaceGui.TextLabel.Text = "32-31"
newmodel136.Parent = workspace.scam.selsins.np
newmodel137 = workspace.scam.prefabs.numpart:clone()
newmodel137:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel137:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel137.SurfaceGui.TextLabel.Text = "32-35"
newmodel137.Parent = workspace.scam.selsins.np
newmodel138 = workspace.scam.prefabs.numpart:clone()
newmodel138:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel138:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel138.SurfaceGui.TextLabel.Text = "32-41"
newmodel138.Parent = workspace.scam.selsins.np
newmodel139 = workspace.scam.prefabs.numpart:clone()
newmodel139:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel139:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel139.SurfaceGui.TextLabel.Text = "32-45"
newmodel139.Parent = workspace.scam.selsins.np
newmodel140 = workspace.scam.prefabs.numpart:clone()
newmodel140:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel140:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel140.SurfaceGui.TextLabel.Text = "32-51"
newmodel140.Parent = workspace.scam.selsins.np
newmodel141 = workspace.scam.prefabs.numpart:clone()
newmodel141:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel141:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel141.SurfaceGui.TextLabel.Text = "32-55"
newmodel141.Parent = workspace.scam.selsins.np
newmodel142 = workspace.scam.prefabs.numpart:clone()
newmodel142:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel142:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel142.SurfaceGui.TextLabel.Text = "32-61"
newmodel142.Parent = workspace.scam.selsins.np
newmodel143 = workspace.scam.prefabs.numpart:clone()
newmodel143:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel143:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-2.114, -4.6244000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel143.SurfaceGui.TextLabel.Text = "32-65"
newmodel143.Parent = workspace.scam.selsins.np
newmodel144 = workspace.scam.prefabs.numpart:clone()
newmodel144:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel144.SurfaceGui.TextLabel.Text = "30-13"
newmodel144.Parent = workspace.scam.selsins.np
newmodel145 = workspace.scam.prefabs.numpart:clone()
newmodel145:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel145.SurfaceGui.TextLabel.Text = "30-23"
newmodel145.Parent = workspace.scam.selsins.np
newmodel146 = workspace.scam.prefabs.numpart:clone()
newmodel146:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel146:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel146.SurfaceGui.TextLabel.Text = "30-27"
newmodel146.Parent = workspace.scam.selsins.np
newmodel147 = workspace.scam.prefabs.numpart:clone()
newmodel147:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel147:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel147.SurfaceGui.TextLabel.Text = "30-33"
newmodel147.Parent = workspace.scam.selsins.np
newmodel148 = workspace.scam.prefabs.numpart:clone()
newmodel148:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel148:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel148.SurfaceGui.TextLabel.Text = "30-43"
newmodel148.Parent = workspace.scam.selsins.np
newmodel149 = workspace.scam.prefabs.numpart:clone()
newmodel149:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel149:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel149.SurfaceGui.TextLabel.Text = "30-47"
newmodel149.Parent = workspace.scam.selsins.np
newmodel150 = workspace.scam.prefabs.numpart:clone()
newmodel150:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel150:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel150.SurfaceGui.TextLabel.Text = "30-53"
newmodel150.Parent = workspace.scam.selsins.np
newmodel151 = workspace.scam.prefabs.numpart:clone()
newmodel151:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel151:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -4.907, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel151.SurfaceGui.TextLabel.Text = "30-63"
newmodel151.Parent = workspace.scam.selsins.np
newmodel152 = workspace.scam.prefabs.numpart:clone()
newmodel152:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel152.SurfaceGui.TextLabel.Text = "26-15"
newmodel152.Parent = workspace.scam.selsins.np
newmodel153 = workspace.scam.prefabs.numpart:clone()
newmodel153:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel153.SurfaceGui.TextLabel.Text = "26-21"
newmodel153.Parent = workspace.scam.selsins.np
newmodel154 = workspace.scam.prefabs.numpart:clone()
newmodel154:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel154:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel154.SurfaceGui.TextLabel.Text = "26-25"
newmodel154.Parent = workspace.scam.selsins.np
newmodel155 = workspace.scam.prefabs.numpart:clone()
newmodel155:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel155:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel155.SurfaceGui.TextLabel.Text = "26-31"
newmodel155.Parent = workspace.scam.selsins.np
newmodel156 = workspace.scam.prefabs.numpart:clone()
newmodel156:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel156:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel156.SurfaceGui.TextLabel.Text = "26-35"
newmodel156.Parent = workspace.scam.selsins.np
newmodel157 = workspace.scam.prefabs.numpart:clone()
newmodel157:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel157:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel157.SurfaceGui.TextLabel.Text = "26-41"
newmodel157.Parent = workspace.scam.selsins.np
newmodel158 = workspace.scam.prefabs.numpart:clone()
newmodel158:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel158:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel158.SurfaceGui.TextLabel.Text = "26-45"
newmodel158.Parent = workspace.scam.selsins.np
newmodel159 = workspace.scam.prefabs.numpart:clone()
newmodel159:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel159:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel159.SurfaceGui.TextLabel.Text = "26-51"
newmodel159.Parent = workspace.scam.selsins.np
newmodel160 = workspace.scam.prefabs.numpart:clone()
newmodel160:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel160:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel160.SurfaceGui.TextLabel.Text = "26-55"
newmodel160.Parent = workspace.scam.selsins.np
newmodel161 = workspace.scam.prefabs.numpart:clone()
newmodel161:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel161:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel161.SurfaceGui.TextLabel.Text = "26-61"
newmodel161.Parent = workspace.scam.selsins.np
newmodel162 = workspace.scam.prefabs.numpart:clone()
newmodel162:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel162:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-2.114, -5.1896, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel162.SurfaceGui.TextLabel.Text = "26-65"
newmodel162.Parent = workspace.scam.selsins.np
newmodel163 = workspace.scam.prefabs.numpart:clone()
newmodel163:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.5748, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel163.SurfaceGui.TextLabel.Text = "24-13"
newmodel163.Parent = workspace.scam.selsins.np
newmodel164 = workspace.scam.prefabs.numpart:clone()
newmodel164:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel164.SurfaceGui.TextLabel.Text = "24-17"
newmodel164.Parent = workspace.scam.selsins.np
newmodel165 = workspace.scam.prefabs.numpart:clone()
newmodel165:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel165.SurfaceGui.TextLabel.Text = "24-23"
newmodel165.Parent = workspace.scam.selsins.np
newmodel166 = workspace.scam.prefabs.numpart:clone()
newmodel166:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel166:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel166.SurfaceGui.TextLabel.Text = "24-27"
newmodel166.Parent = workspace.scam.selsins.np
newmodel167 = workspace.scam.prefabs.numpart:clone()
newmodel167:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel167:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel167.SurfaceGui.TextLabel.Text = "24-33"
newmodel167.Parent = workspace.scam.selsins.np
newmodel168 = workspace.scam.prefabs.numpart:clone()
newmodel168:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel168:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel168.SurfaceGui.TextLabel.Text = "24-37"
newmodel168.Parent = workspace.scam.selsins.np
newmodel169 = workspace.scam.prefabs.numpart:clone()
newmodel169:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel169:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel169.SurfaceGui.TextLabel.Text = "24-43"
newmodel169.Parent = workspace.scam.selsins.np
newmodel170 = workspace.scam.prefabs.numpart:clone()
newmodel170:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel170:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel170.SurfaceGui.TextLabel.Text = "24-47"
newmodel170.Parent = workspace.scam.selsins.np
newmodel171 = workspace.scam.prefabs.numpart:clone()
newmodel171:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel171:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel171.SurfaceGui.TextLabel.Text = "24-53"
newmodel171.Parent = workspace.scam.selsins.np
newmodel172 = workspace.scam.prefabs.numpart:clone()
newmodel172:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel172:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel172.SurfaceGui.TextLabel.Text = "24-57"
newmodel172.Parent = workspace.scam.selsins.np
newmodel173 = workspace.scam.prefabs.numpart:clone()
newmodel173:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel173:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.7292, -5.472200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel173.SurfaceGui.TextLabel.Text = "24-63"
newmodel173.Parent = workspace.scam.selsins.np
newmodel174 = workspace.scam.prefabs.numpart:clone()
newmodel174:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.9596, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel174.SurfaceGui.TextLabel.Text = "22-15"
newmodel174.Parent = workspace.scam.selsins.np
newmodel175 = workspace.scam.prefabs.numpart:clone()
newmodel175:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel175.SurfaceGui.TextLabel.Text = "22-21"
newmodel175.Parent = workspace.scam.selsins.np
newmodel176 = workspace.scam.prefabs.numpart:clone()
newmodel176:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel176:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel176.SurfaceGui.TextLabel.Text = "22-25"
newmodel176.Parent = workspace.scam.selsins.np
newmodel177 = workspace.scam.prefabs.numpart:clone()
newmodel177:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel177:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel177.SurfaceGui.TextLabel.Text = "22-31"
newmodel177.Parent = workspace.scam.selsins.np
newmodel178 = workspace.scam.prefabs.numpart:clone()
newmodel178:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel178:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel178.SurfaceGui.TextLabel.Text = "22-35"
newmodel178.Parent = workspace.scam.selsins.np
newmodel179 = workspace.scam.prefabs.numpart:clone()
newmodel179:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel179:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel179.SurfaceGui.TextLabel.Text = "22-41"
newmodel179.Parent = workspace.scam.selsins.np
newmodel180 = workspace.scam.prefabs.numpart:clone()
newmodel180:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel180:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel180.SurfaceGui.TextLabel.Text = "22-45"
newmodel180.Parent = workspace.scam.selsins.np
newmodel181 = workspace.scam.prefabs.numpart:clone()
newmodel181:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel181:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel181.SurfaceGui.TextLabel.Text = "22-51"
newmodel181.Parent = workspace.scam.selsins.np
newmodel182 = workspace.scam.prefabs.numpart:clone()
newmodel182:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel182:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel182.SurfaceGui.TextLabel.Text = "22-55"
newmodel182.Parent = workspace.scam.selsins.np
newmodel183 = workspace.scam.prefabs.numpart:clone()
newmodel183:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel183:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.3444, -5.7548, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel183.SurfaceGui.TextLabel.Text = "22-61"
newmodel183.Parent = workspace.scam.selsins.np
newmodel184 = workspace.scam.prefabs.numpart:clone()
newmodel184:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.3444, -6.037400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel184.SurfaceGui.TextLabel.Text = "20-17"
newmodel184.Parent = workspace.scam.selsins.np
newmodel185 = workspace.scam.prefabs.numpart:clone()
newmodel185:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -6.037400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel185.SurfaceGui.TextLabel.Text = "20-23"
newmodel185.Parent = workspace.scam.selsins.np
newmodel186 = workspace.scam.prefabs.numpart:clone()
newmodel186:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -6.037400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel186:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -6.037400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel186.SurfaceGui.TextLabel.Text = "20-33"
newmodel186.Parent = workspace.scam.selsins.np
newmodel187 = workspace.scam.prefabs.numpart:clone()
newmodel187:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -6.037400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel187:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -6.037400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel187.SurfaceGui.TextLabel.Text = "20-37"
newmodel187.Parent = workspace.scam.selsins.np
newmodel188 = workspace.scam.prefabs.numpart:clone()
newmodel188:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -6.037400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel188:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -6.037400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel188.SurfaceGui.TextLabel.Text = "20-43"
newmodel188.Parent = workspace.scam.selsins.np
newmodel189 = workspace.scam.prefabs.numpart:clone()
newmodel189:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -6.037400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel189:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -6.037400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel189.SurfaceGui.TextLabel.Text = "20-53"
newmodel189.Parent = workspace.scam.selsins.np
newmodel190 = workspace.scam.prefabs.numpart:clone()
newmodel190:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -6.037400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel190:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.9596, -6.037400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel190.SurfaceGui.TextLabel.Text = "20-57"
newmodel190.Parent = workspace.scam.selsins.np
newmodel191 = workspace.scam.prefabs.numpart:clone()
newmodel191:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.7292, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel191.SurfaceGui.TextLabel.Text = "16-21"
newmodel191.Parent = workspace.scam.selsins.np
newmodel192 = workspace.scam.prefabs.numpart:clone()
newmodel192:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.19, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel192:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel192.SurfaceGui.TextLabel.Text = "16-25"
newmodel192.Parent = workspace.scam.selsins.np
newmodel193 = workspace.scam.prefabs.numpart:clone()
newmodel193:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel193:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel193.SurfaceGui.TextLabel.Text = "16-31"
newmodel193.Parent = workspace.scam.selsins.np
newmodel194 = workspace.scam.prefabs.numpart:clone()
newmodel194:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel194:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel194.SurfaceGui.TextLabel.Text = "16-35"
newmodel194.Parent = workspace.scam.selsins.np
newmodel195 = workspace.scam.prefabs.numpart:clone()
newmodel195:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel195:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel195.SurfaceGui.TextLabel.Text = "16-41"
newmodel195.Parent = workspace.scam.selsins.np
newmodel196 = workspace.scam.prefabs.numpart:clone()
newmodel196:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel196:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel196.SurfaceGui.TextLabel.Text = "16-45"
newmodel196.Parent = workspace.scam.selsins.np
newmodel197 = workspace.scam.prefabs.numpart:clone()
newmodel197:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel197:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel197.SurfaceGui.TextLabel.Text = "16-51"
newmodel197.Parent = workspace.scam.selsins.np
newmodel198 = workspace.scam.prefabs.numpart:clone()
newmodel198:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel198:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.5748, -6.32, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel198.SurfaceGui.TextLabel.Text = "16-55"
newmodel198.Parent = workspace.scam.selsins.np
newmodel199 = workspace.scam.prefabs.numpart:clone()
newmodel199:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-2.114, -6.602600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel199.SurfaceGui.TextLabel.Text = "14-23"
newmodel199.Parent = workspace.scam.selsins.np
newmodel200 = workspace.scam.prefabs.numpart:clone()
newmodel200:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.5748, -6.602600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel200:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -6.602600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel200.SurfaceGui.TextLabel.Text = "14-27"
newmodel200.Parent = workspace.scam.selsins.np
newmodel201 = workspace.scam.prefabs.numpart:clone()
newmodel201:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.3444, -6.602600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel201:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -6.602600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel201.SurfaceGui.TextLabel.Text = "14-33"
newmodel201.Parent = workspace.scam.selsins.np
newmodel202 = workspace.scam.prefabs.numpart:clone()
newmodel202:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.114, -6.602600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel202:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -6.602600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel202.SurfaceGui.TextLabel.Text = "14-37"
newmodel202.Parent = workspace.scam.selsins.np
newmodel203 = workspace.scam.prefabs.numpart:clone()
newmodel203:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.8836, -6.602600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel203:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.192400000000001, -6.602600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel203.SurfaceGui.TextLabel.Text = "14-43"
newmodel203.Parent = workspace.scam.selsins.np
newmodel204 = workspace.scam.prefabs.numpart:clone()
newmodel204:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.6532000000000004, -6.602600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel204:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.962, -6.602600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel204.SurfaceGui.TextLabel.Text = "14-47"
newmodel204.Parent = workspace.scam.selsins.np
newmodel205 = workspace.scam.prefabs.numpart:clone()
newmodel205:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.4228000000000005, -6.602600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel205:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.19, -6.602600000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel205.SurfaceGui.TextLabel.Text = "14-53"
newmodel205.Parent = workspace.scam.selsins.np
newmodel206 = workspace.scam.prefabs.numpart:clone()
newmodel206:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.9596, -6.885200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel206:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -6.885200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel206.SurfaceGui.TextLabel.Text = "12-31"
newmodel206.Parent = workspace.scam.selsins.np
newmodel207 = workspace.scam.prefabs.numpart:clone()
newmodel207:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.7292, -6.885200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel207:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -6.885200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel207.SurfaceGui.TextLabel.Text = "12-35"
newmodel207.Parent = workspace.scam.selsins.np
newmodel208 = workspace.scam.prefabs.numpart:clone()
newmodel208:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.4988, -6.885200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel208:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.807600000000001, -6.885200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel208.SurfaceGui.TextLabel.Text = "12-41"
newmodel208.Parent = workspace.scam.selsins.np
newmodel209 = workspace.scam.prefabs.numpart:clone()
newmodel209:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.2684, -6.885200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel209:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.5771999999999995, -6.885200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel209.SurfaceGui.TextLabel.Text = "12-45"
newmodel209.Parent = workspace.scam.selsins.np
newmodel210 = workspace.scam.prefabs.numpart:clone()
newmodel210:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.038, -6.885200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel210:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.3468, -6.885200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel210.SurfaceGui.TextLabel.Text = "12-51"
newmodel210.Parent = workspace.scam.selsins.np
