newmodel0 = workspace.prefabs.k_2:clone()
newmodel0:PivotTo(CFrame.new(-17.481439661393058, 2.7039510142406664, 22.800294191186033) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.k_2
newmodel1 = workspace.prefabs.k_2:clone()
newmodel1:PivotTo(CFrame.new(-19.02088726828439, 2.7039510142406664, 24.59976450214883) * CFrame.fromEulerAngles(0, math.rad(49.452998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.devices.k_2
newmodel2 = workspace.prefabs.k_2:clone()
newmodel2:PivotTo(CFrame.new(-19.37917084394678, 2.7021695508589043, 24.954940398494436) * CFrame.fromEulerAngles(0, math.rad(44.153), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.k_2
