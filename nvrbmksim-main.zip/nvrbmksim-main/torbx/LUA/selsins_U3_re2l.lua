newmodel0 = workspace.scam.prefabs.re_2l:clone()
newmodel0:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.8036000000000001, -0.15339999999999998, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel0:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -0.15339999999999998, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel0.Part.SurfaceGui.TextLabel.Text = "68-31"
newmodel0.Parent = workspace.scam.selsins.re2l
newmodel1 = workspace.scam.prefabs.re_2l:clone()
newmodel1:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.5732000000000002, -0.15339999999999998, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel1:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -0.15339999999999998, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel1.Part.SurfaceGui.TextLabel.Text = "68-35"
newmodel1.Parent = workspace.scam.selsins.re2l
newmodel2 = workspace.scam.prefabs.re_2l:clone()
newmodel2:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -0.15339999999999998, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel2:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -0.15339999999999998, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel2.Part.SurfaceGui.TextLabel.Text = "68-41"
newmodel2.Parent = workspace.scam.selsins.re2l
newmodel3 = workspace.scam.prefabs.re_2l:clone()
newmodel3:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -0.15339999999999998, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel3:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -0.15339999999999998, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel3.Part.SurfaceGui.TextLabel.Text = "68-45"
newmodel3.Parent = workspace.scam.selsins.re2l
newmodel4 = workspace.scam.prefabs.re_2l:clone()
newmodel4:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.5732000000000002, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel4.Part.SurfaceGui.TextLabel.Text = "64-21"
newmodel4.Parent = workspace.scam.selsins.re2l
newmodel5 = workspace.scam.prefabs.re_2l:clone()
newmodel5:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.034, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel5:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel5.Part.SurfaceGui.TextLabel.Text = "64-25"
newmodel5.Parent = workspace.scam.selsins.re2l
newmodel6 = workspace.scam.prefabs.re_2l:clone()
newmodel6:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.8036000000000001, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel6:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel6.Part.SurfaceGui.TextLabel.Text = "64-31"
newmodel6.Parent = workspace.scam.selsins.re2l
newmodel7 = workspace.scam.prefabs.re_2l:clone()
newmodel7:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.5732000000000002, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel7:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel7.Part.SurfaceGui.TextLabel.Text = "64-35"
newmodel7.Parent = workspace.scam.selsins.re2l
newmodel8 = workspace.scam.prefabs.re_2l:clone()
newmodel8:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel8:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel8.Part.SurfaceGui.TextLabel.Text = "64-41"
newmodel8.Parent = workspace.scam.selsins.re2l
newmodel9 = workspace.scam.prefabs.re_2l:clone()
newmodel9:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel9:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel9.Part.SurfaceGui.TextLabel.Text = "64-45"
newmodel9.Parent = workspace.scam.selsins.re2l
newmodel10 = workspace.scam.prefabs.re_2l:clone()
newmodel10:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel10:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel10.Part.SurfaceGui.TextLabel.Text = "64-51"
newmodel10.Parent = workspace.scam.selsins.re2l
newmodel11 = workspace.scam.prefabs.re_2l:clone()
newmodel11:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel11:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.41879999999999995, -0.7186, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel11.Part.SurfaceGui.TextLabel.Text = "64-55"
newmodel11.Parent = workspace.scam.selsins.re2l
newmodel12 = workspace.scam.prefabs.re_2l:clone()
newmodel12:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.8036000000000001, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel12.Part.SurfaceGui.TextLabel.Text = "60-15"
newmodel12.Parent = workspace.scam.selsins.re2l
newmodel13 = workspace.scam.prefabs.re_2l:clone()
newmodel13:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.5732000000000002, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel13.Part.SurfaceGui.TextLabel.Text = "60-21"
newmodel13.Parent = workspace.scam.selsins.re2l
newmodel14 = workspace.scam.prefabs.re_2l:clone()
newmodel14:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.034, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel14:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel14.Part.SurfaceGui.TextLabel.Text = "60-25"
newmodel14.Parent = workspace.scam.selsins.re2l
newmodel15 = workspace.scam.prefabs.re_2l:clone()
newmodel15:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.8036000000000001, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel15:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel15.Part.SurfaceGui.TextLabel.Text = "60-31"
newmodel15.Parent = workspace.scam.selsins.re2l
newmodel16 = workspace.scam.prefabs.re_2l:clone()
newmodel16:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.5732000000000002, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel16:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel16.Part.SurfaceGui.TextLabel.Text = "60-35"
newmodel16.Parent = workspace.scam.selsins.re2l
newmodel17 = workspace.scam.prefabs.re_2l:clone()
newmodel17:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel17:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel17.Part.SurfaceGui.TextLabel.Text = "60-41"
newmodel17.Parent = workspace.scam.selsins.re2l
newmodel18 = workspace.scam.prefabs.re_2l:clone()
newmodel18:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel18:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel18.Part.SurfaceGui.TextLabel.Text = "60-45"
newmodel18.Parent = workspace.scam.selsins.re2l
newmodel19 = workspace.scam.prefabs.re_2l:clone()
newmodel19:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel19:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel19.Part.SurfaceGui.TextLabel.Text = "60-51"
newmodel19.Parent = workspace.scam.selsins.re2l
newmodel20 = workspace.scam.prefabs.re_2l:clone()
newmodel20:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel20:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.41879999999999995, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel20.Part.SurfaceGui.TextLabel.Text = "60-55"
newmodel20.Parent = workspace.scam.selsins.re2l
newmodel21 = workspace.scam.prefabs.re_2l:clone()
newmodel21:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel21:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.1884000000000001, -1.2838000000000003, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel21.Part.SurfaceGui.TextLabel.Text = "60-61"
newmodel21.Parent = workspace.scam.selsins.re2l
newmodel22 = workspace.scam.prefabs.re_2l:clone()
newmodel22:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.8036000000000001, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel22.Part.SurfaceGui.TextLabel.Text = "54-15"
newmodel22.Parent = workspace.scam.selsins.re2l
newmodel23 = workspace.scam.prefabs.re_2l:clone()
newmodel23:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.5732000000000002, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel23.Part.SurfaceGui.TextLabel.Text = "54-21"
newmodel23.Parent = workspace.scam.selsins.re2l
newmodel24 = workspace.scam.prefabs.re_2l:clone()
newmodel24:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.034, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel24:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel24.Part.SurfaceGui.TextLabel.Text = "54-25"
newmodel24.Parent = workspace.scam.selsins.re2l
newmodel25 = workspace.scam.prefabs.re_2l:clone()
newmodel25:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.8036000000000001, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel25:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel25.Part.SurfaceGui.TextLabel.Text = "54-31"
newmodel25.Parent = workspace.scam.selsins.re2l
newmodel26 = workspace.scam.prefabs.re_2l:clone()
newmodel26:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.5732000000000002, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel26:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel26.Part.SurfaceGui.TextLabel.Text = "54-35"
newmodel26.Parent = workspace.scam.selsins.re2l
newmodel27 = workspace.scam.prefabs.re_2l:clone()
newmodel27:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel27:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel27.Part.SurfaceGui.TextLabel.Text = "54-41"
newmodel27.Parent = workspace.scam.selsins.re2l
newmodel28 = workspace.scam.prefabs.re_2l:clone()
newmodel28:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel28:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel28.Part.SurfaceGui.TextLabel.Text = "54-45"
newmodel28.Parent = workspace.scam.selsins.re2l
newmodel29 = workspace.scam.prefabs.re_2l:clone()
newmodel29:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel29:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel29.Part.SurfaceGui.TextLabel.Text = "54-51"
newmodel29.Parent = workspace.scam.selsins.re2l
newmodel30 = workspace.scam.prefabs.re_2l:clone()
newmodel30:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel30:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.41879999999999995, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel30.Part.SurfaceGui.TextLabel.Text = "54-55"
newmodel30.Parent = workspace.scam.selsins.re2l
newmodel31 = workspace.scam.prefabs.re_2l:clone()
newmodel31:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel31:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.1884000000000001, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel31.Part.SurfaceGui.TextLabel.Text = "54-61"
newmodel31.Parent = workspace.scam.selsins.re2l
newmodel32 = workspace.scam.prefabs.re_2l:clone()
newmodel32:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel32:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.958, -1.849, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel32.Part.SurfaceGui.TextLabel.Text = "54-65"
newmodel32.Parent = workspace.scam.selsins.re2l
newmodel33 = workspace.scam.prefabs.re_2l:clone()
newmodel33:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.034, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel33.Part.SurfaceGui.TextLabel.Text = "50-11"
newmodel33.Parent = workspace.scam.selsins.re2l
newmodel34 = workspace.scam.prefabs.re_2l:clone()
newmodel34:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.8036000000000001, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel34.Part.SurfaceGui.TextLabel.Text = "50-15"
newmodel34.Parent = workspace.scam.selsins.re2l
newmodel35 = workspace.scam.prefabs.re_2l:clone()
newmodel35:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.5732000000000002, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel35.Part.SurfaceGui.TextLabel.Text = "50-21"
newmodel35.Parent = workspace.scam.selsins.re2l
newmodel36 = workspace.scam.prefabs.re_2l:clone()
newmodel36:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.034, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel36:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel36.Part.SurfaceGui.TextLabel.Text = "50-25"
newmodel36.Parent = workspace.scam.selsins.re2l
newmodel37 = workspace.scam.prefabs.re_2l:clone()
newmodel37:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.8036000000000001, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel37:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel37.Part.SurfaceGui.TextLabel.Text = "50-31"
newmodel37.Parent = workspace.scam.selsins.re2l
newmodel38 = workspace.scam.prefabs.re_2l:clone()
newmodel38:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.5732000000000002, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel38:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel38.Part.SurfaceGui.TextLabel.Text = "50-35"
newmodel38.Parent = workspace.scam.selsins.re2l
newmodel39 = workspace.scam.prefabs.re_2l:clone()
newmodel39:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel39:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel39.Part.SurfaceGui.TextLabel.Text = "50-41"
newmodel39.Parent = workspace.scam.selsins.re2l
newmodel40 = workspace.scam.prefabs.re_2l:clone()
newmodel40:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel40:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel40.Part.SurfaceGui.TextLabel.Text = "50-45"
newmodel40.Parent = workspace.scam.selsins.re2l
newmodel41 = workspace.scam.prefabs.re_2l:clone()
newmodel41:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel41:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel41.Part.SurfaceGui.TextLabel.Text = "50-51"
newmodel41.Parent = workspace.scam.selsins.re2l
newmodel42 = workspace.scam.prefabs.re_2l:clone()
newmodel42:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel42:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.41879999999999995, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel42.Part.SurfaceGui.TextLabel.Text = "50-55"
newmodel42.Parent = workspace.scam.selsins.re2l
newmodel43 = workspace.scam.prefabs.re_2l:clone()
newmodel43:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel43:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.1884000000000001, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel43.Part.SurfaceGui.TextLabel.Text = "50-61"
newmodel43.Parent = workspace.scam.selsins.re2l
newmodel44 = workspace.scam.prefabs.re_2l:clone()
newmodel44:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel44:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.958, -2.4142, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel44.Part.SurfaceGui.TextLabel.Text = "50-65"
newmodel44.Parent = workspace.scam.selsins.re2l
newmodel45 = workspace.scam.prefabs.re_2l:clone()
newmodel45:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.034, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel45.Part.SurfaceGui.TextLabel.Text = "44-11"
newmodel45.Parent = workspace.scam.selsins.re2l
newmodel46 = workspace.scam.prefabs.re_2l:clone()
newmodel46:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.8036000000000001, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel46.Part.SurfaceGui.TextLabel.Text = "44-15"
newmodel46.Parent = workspace.scam.selsins.re2l
newmodel47 = workspace.scam.prefabs.re_2l:clone()
newmodel47:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.5732000000000002, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel47.Part.SurfaceGui.TextLabel.Text = "44-21"
newmodel47.Parent = workspace.scam.selsins.re2l
newmodel48 = workspace.scam.prefabs.re_2l:clone()
newmodel48:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.034, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel48:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel48.Part.SurfaceGui.TextLabel.Text = "44-25"
newmodel48.Parent = workspace.scam.selsins.re2l
newmodel49 = workspace.scam.prefabs.re_2l:clone()
newmodel49:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.8036000000000001, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel49:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel49.Part.SurfaceGui.TextLabel.Text = "44-31"
newmodel49.Parent = workspace.scam.selsins.re2l
newmodel50 = workspace.scam.prefabs.re_2l:clone()
newmodel50:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.5732000000000002, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel50:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel50.Part.SurfaceGui.TextLabel.Text = "44-35"
newmodel50.Parent = workspace.scam.selsins.re2l
newmodel51 = workspace.scam.prefabs.re_2l:clone()
newmodel51:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel51:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel51.Part.SurfaceGui.TextLabel.Text = "44-41"
newmodel51.Parent = workspace.scam.selsins.re2l
newmodel52 = workspace.scam.prefabs.re_2l:clone()
newmodel52:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel52:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel52.Part.SurfaceGui.TextLabel.Text = "44-45"
newmodel52.Parent = workspace.scam.selsins.re2l
newmodel53 = workspace.scam.prefabs.re_2l:clone()
newmodel53:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel53:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel53.Part.SurfaceGui.TextLabel.Text = "44-51"
newmodel53.Parent = workspace.scam.selsins.re2l
newmodel54 = workspace.scam.prefabs.re_2l:clone()
newmodel54:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel54:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.41879999999999995, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel54.Part.SurfaceGui.TextLabel.Text = "44-55"
newmodel54.Parent = workspace.scam.selsins.re2l
newmodel55 = workspace.scam.prefabs.re_2l:clone()
newmodel55:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel55:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.1884000000000001, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel55.Part.SurfaceGui.TextLabel.Text = "44-61"
newmodel55.Parent = workspace.scam.selsins.re2l
newmodel56 = workspace.scam.prefabs.re_2l:clone()
newmodel56:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel56:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.958, -2.9794, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel56.Part.SurfaceGui.TextLabel.Text = "44-65"
newmodel56.Parent = workspace.scam.selsins.re2l
newmodel57 = workspace.scam.prefabs.re_2l:clone()
newmodel57:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.034, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel57.Part.SurfaceGui.TextLabel.Text = "40-11"
newmodel57.Parent = workspace.scam.selsins.re2l
newmodel58 = workspace.scam.prefabs.re_2l:clone()
newmodel58:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.8036000000000001, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel58.Part.SurfaceGui.TextLabel.Text = "40-15"
newmodel58.Parent = workspace.scam.selsins.re2l
newmodel59 = workspace.scam.prefabs.re_2l:clone()
newmodel59:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.5732000000000002, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel59.Part.SurfaceGui.TextLabel.Text = "40-21"
newmodel59.Parent = workspace.scam.selsins.re2l
newmodel60 = workspace.scam.prefabs.re_2l:clone()
newmodel60:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.034, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel60:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel60.Part.SurfaceGui.TextLabel.Text = "40-25"
newmodel60.Parent = workspace.scam.selsins.re2l
newmodel61 = workspace.scam.prefabs.re_2l:clone()
newmodel61:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.8036000000000001, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel61:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel61.Part.SurfaceGui.TextLabel.Text = "40-31"
newmodel61.Parent = workspace.scam.selsins.re2l
newmodel62 = workspace.scam.prefabs.re_2l:clone()
newmodel62:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.5732000000000002, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel62:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel62.Part.SurfaceGui.TextLabel.Text = "40-35"
newmodel62.Parent = workspace.scam.selsins.re2l
newmodel63 = workspace.scam.prefabs.re_2l:clone()
newmodel63:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel63:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel63.Part.SurfaceGui.TextLabel.Text = "40-41"
newmodel63.Parent = workspace.scam.selsins.re2l
newmodel64 = workspace.scam.prefabs.re_2l:clone()
newmodel64:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel64:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel64.Part.SurfaceGui.TextLabel.Text = "40-45"
newmodel64.Parent = workspace.scam.selsins.re2l
newmodel65 = workspace.scam.prefabs.re_2l:clone()
newmodel65:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel65:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel65.Part.SurfaceGui.TextLabel.Text = "40-51"
newmodel65.Parent = workspace.scam.selsins.re2l
newmodel66 = workspace.scam.prefabs.re_2l:clone()
newmodel66:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel66:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.41879999999999995, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel66.Part.SurfaceGui.TextLabel.Text = "40-55"
newmodel66.Parent = workspace.scam.selsins.re2l
newmodel67 = workspace.scam.prefabs.re_2l:clone()
newmodel67:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel67:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.1884000000000001, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel67.Part.SurfaceGui.TextLabel.Text = "40-61"
newmodel67.Parent = workspace.scam.selsins.re2l
newmodel68 = workspace.scam.prefabs.re_2l:clone()
newmodel68:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel68:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.958, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel68.Part.SurfaceGui.TextLabel.Text = "40-65"
newmodel68.Parent = workspace.scam.selsins.re2l
newmodel69 = workspace.scam.prefabs.re_2l:clone()
newmodel69:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.5756000000000006, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel69:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-2.3428000000000004, -3.5446000000000004, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel69.Part.SurfaceGui.TextLabel.Text = "40-67"
newmodel69.Parent = workspace.scam.selsins.re2l
newmodel70 = workspace.scam.prefabs.re_2l:clone()
newmodel70:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.034, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel70.Part.SurfaceGui.TextLabel.Text = "34-11"
newmodel70.Parent = workspace.scam.selsins.re2l
newmodel71 = workspace.scam.prefabs.re_2l:clone()
newmodel71:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.8036000000000001, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel71.Part.SurfaceGui.TextLabel.Text = "34-15"
newmodel71.Parent = workspace.scam.selsins.re2l
newmodel72 = workspace.scam.prefabs.re_2l:clone()
newmodel72:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.5732000000000002, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel72.Part.SurfaceGui.TextLabel.Text = "34-21"
newmodel72.Parent = workspace.scam.selsins.re2l
newmodel73 = workspace.scam.prefabs.re_2l:clone()
newmodel73:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.034, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel73:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel73.Part.SurfaceGui.TextLabel.Text = "34-25"
newmodel73.Parent = workspace.scam.selsins.re2l
newmodel74 = workspace.scam.prefabs.re_2l:clone()
newmodel74:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.8036000000000001, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel74:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel74.Part.SurfaceGui.TextLabel.Text = "34-31"
newmodel74.Parent = workspace.scam.selsins.re2l
newmodel75 = workspace.scam.prefabs.re_2l:clone()
newmodel75:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.5732000000000002, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel75:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel75.Part.SurfaceGui.TextLabel.Text = "34-35"
newmodel75.Parent = workspace.scam.selsins.re2l
newmodel76 = workspace.scam.prefabs.re_2l:clone()
newmodel76:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel76:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel76.Part.SurfaceGui.TextLabel.Text = "34-41"
newmodel76.Parent = workspace.scam.selsins.re2l
newmodel77 = workspace.scam.prefabs.re_2l:clone()
newmodel77:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel77:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel77.Part.SurfaceGui.TextLabel.Text = "34-45"
newmodel77.Parent = workspace.scam.selsins.re2l
newmodel78 = workspace.scam.prefabs.re_2l:clone()
newmodel78:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel78:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel78.Part.SurfaceGui.TextLabel.Text = "34-51"
newmodel78.Parent = workspace.scam.selsins.re2l
newmodel79 = workspace.scam.prefabs.re_2l:clone()
newmodel79:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel79:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.41879999999999995, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel79.Part.SurfaceGui.TextLabel.Text = "34-55"
newmodel79.Parent = workspace.scam.selsins.re2l
newmodel80 = workspace.scam.prefabs.re_2l:clone()
newmodel80:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel80:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.1884000000000001, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel80.Part.SurfaceGui.TextLabel.Text = "34-61"
newmodel80.Parent = workspace.scam.selsins.re2l
newmodel81 = workspace.scam.prefabs.re_2l:clone()
newmodel81:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel81:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.958, -4.1098, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel81.Part.SurfaceGui.TextLabel.Text = "34-65"
newmodel81.Parent = workspace.scam.selsins.re2l
newmodel82 = workspace.scam.prefabs.re_2l:clone()
newmodel82:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.034, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel82.Part.SurfaceGui.TextLabel.Text = "30-11"
newmodel82.Parent = workspace.scam.selsins.re2l
newmodel83 = workspace.scam.prefabs.re_2l:clone()
newmodel83:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.8036000000000001, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel83.Part.SurfaceGui.TextLabel.Text = "30-15"
newmodel83.Parent = workspace.scam.selsins.re2l
newmodel84 = workspace.scam.prefabs.re_2l:clone()
newmodel84:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.5732000000000002, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel84.Part.SurfaceGui.TextLabel.Text = "30-21"
newmodel84.Parent = workspace.scam.selsins.re2l
newmodel85 = workspace.scam.prefabs.re_2l:clone()
newmodel85:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.034, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel85:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel85.Part.SurfaceGui.TextLabel.Text = "30-25"
newmodel85.Parent = workspace.scam.selsins.re2l
newmodel86 = workspace.scam.prefabs.re_2l:clone()
newmodel86:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.8036000000000001, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel86:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel86.Part.SurfaceGui.TextLabel.Text = "30-31"
newmodel86.Parent = workspace.scam.selsins.re2l
newmodel87 = workspace.scam.prefabs.re_2l:clone()
newmodel87:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.5732000000000002, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel87:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel87.Part.SurfaceGui.TextLabel.Text = "30-35"
newmodel87.Parent = workspace.scam.selsins.re2l
newmodel88 = workspace.scam.prefabs.re_2l:clone()
newmodel88:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel88:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel88.Part.SurfaceGui.TextLabel.Text = "30-41"
newmodel88.Parent = workspace.scam.selsins.re2l
newmodel89 = workspace.scam.prefabs.re_2l:clone()
newmodel89:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel89:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel89.Part.SurfaceGui.TextLabel.Text = "30-45"
newmodel89.Parent = workspace.scam.selsins.re2l
newmodel90 = workspace.scam.prefabs.re_2l:clone()
newmodel90:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel90:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel90.Part.SurfaceGui.TextLabel.Text = "30-51"
newmodel90.Parent = workspace.scam.selsins.re2l
newmodel91 = workspace.scam.prefabs.re_2l:clone()
newmodel91:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel91:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.41879999999999995, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel91.Part.SurfaceGui.TextLabel.Text = "30-55"
newmodel91.Parent = workspace.scam.selsins.re2l
newmodel92 = workspace.scam.prefabs.re_2l:clone()
newmodel92:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel92:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.1884000000000001, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel92.Part.SurfaceGui.TextLabel.Text = "30-61"
newmodel92.Parent = workspace.scam.selsins.re2l
newmodel93 = workspace.scam.prefabs.re_2l:clone()
newmodel93:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel93:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.958, -4.675, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel93.Part.SurfaceGui.TextLabel.Text = "30-65"
newmodel93.Parent = workspace.scam.selsins.re2l
newmodel94 = workspace.scam.prefabs.re_2l:clone()
newmodel94:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.034, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel94.Part.SurfaceGui.TextLabel.Text = "24-11"
newmodel94.Parent = workspace.scam.selsins.re2l
newmodel95 = workspace.scam.prefabs.re_2l:clone()
newmodel95:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.8036000000000001, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel95.Part.SurfaceGui.TextLabel.Text = "24-15"
newmodel95.Parent = workspace.scam.selsins.re2l
newmodel96 = workspace.scam.prefabs.re_2l:clone()
newmodel96:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.5732000000000002, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel96.Part.SurfaceGui.TextLabel.Text = "24-21"
newmodel96.Parent = workspace.scam.selsins.re2l
newmodel97 = workspace.scam.prefabs.re_2l:clone()
newmodel97:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.034, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel97:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel97.Part.SurfaceGui.TextLabel.Text = "24-25"
newmodel97.Parent = workspace.scam.selsins.re2l
newmodel98 = workspace.scam.prefabs.re_2l:clone()
newmodel98:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.8036000000000001, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel98:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel98.Part.SurfaceGui.TextLabel.Text = "24-31"
newmodel98.Parent = workspace.scam.selsins.re2l
newmodel99 = workspace.scam.prefabs.re_2l:clone()
newmodel99:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.5732000000000002, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel99:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel99.Part.SurfaceGui.TextLabel.Text = "24-35"
newmodel99.Parent = workspace.scam.selsins.re2l
newmodel100 = workspace.scam.prefabs.re_2l:clone()
newmodel100:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel100:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel100.Part.SurfaceGui.TextLabel.Text = "24-41"
newmodel100.Parent = workspace.scam.selsins.re2l
newmodel101 = workspace.scam.prefabs.re_2l:clone()
newmodel101:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel101:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel101.Part.SurfaceGui.TextLabel.Text = "24-45"
newmodel101.Parent = workspace.scam.selsins.re2l
newmodel102 = workspace.scam.prefabs.re_2l:clone()
newmodel102:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel102:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel102.Part.SurfaceGui.TextLabel.Text = "24-51"
newmodel102.Parent = workspace.scam.selsins.re2l
newmodel103 = workspace.scam.prefabs.re_2l:clone()
newmodel103:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel103:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.41879999999999995, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel103.Part.SurfaceGui.TextLabel.Text = "24-55"
newmodel103.Parent = workspace.scam.selsins.re2l
newmodel104 = workspace.scam.prefabs.re_2l:clone()
newmodel104:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel104:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.1884000000000001, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel104.Part.SurfaceGui.TextLabel.Text = "24-61"
newmodel104.Parent = workspace.scam.selsins.re2l
newmodel105 = workspace.scam.prefabs.re_2l:clone()
newmodel105:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel105:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.958, -5.240200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel105.Part.SurfaceGui.TextLabel.Text = "24-65"
newmodel105.Parent = workspace.scam.selsins.re2l
newmodel106 = workspace.scam.prefabs.re_2l:clone()
newmodel106:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-0.8036000000000001, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel106.Part.SurfaceGui.TextLabel.Text = "20-15"
newmodel106.Parent = workspace.scam.selsins.re2l
newmodel107 = workspace.scam.prefabs.re_2l:clone()
newmodel107:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.5732000000000002, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel107.Part.SurfaceGui.TextLabel.Text = "20-21"
newmodel107.Parent = workspace.scam.selsins.re2l
newmodel108 = workspace.scam.prefabs.re_2l:clone()
newmodel108:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.034, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel108:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel108.Part.SurfaceGui.TextLabel.Text = "20-25"
newmodel108.Parent = workspace.scam.selsins.re2l
newmodel109 = workspace.scam.prefabs.re_2l:clone()
newmodel109:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.8036000000000001, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel109:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel109.Part.SurfaceGui.TextLabel.Text = "20-31"
newmodel109.Parent = workspace.scam.selsins.re2l
newmodel110 = workspace.scam.prefabs.re_2l:clone()
newmodel110:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.5732000000000002, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel110:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel110.Part.SurfaceGui.TextLabel.Text = "20-35"
newmodel110.Parent = workspace.scam.selsins.re2l
newmodel111 = workspace.scam.prefabs.re_2l:clone()
newmodel111:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel111:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel111.Part.SurfaceGui.TextLabel.Text = "20-41"
newmodel111.Parent = workspace.scam.selsins.re2l
newmodel112 = workspace.scam.prefabs.re_2l:clone()
newmodel112:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel112:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel112.Part.SurfaceGui.TextLabel.Text = "20-45"
newmodel112.Parent = workspace.scam.selsins.re2l
newmodel113 = workspace.scam.prefabs.re_2l:clone()
newmodel113:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel113:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel113.Part.SurfaceGui.TextLabel.Text = "20-51"
newmodel113.Parent = workspace.scam.selsins.re2l
newmodel114 = workspace.scam.prefabs.re_2l:clone()
newmodel114:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel114:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.41879999999999995, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel114.Part.SurfaceGui.TextLabel.Text = "20-55"
newmodel114.Parent = workspace.scam.selsins.re2l
newmodel115 = workspace.scam.prefabs.re_2l:clone()
newmodel115:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel115:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-1.1884000000000001, -5.805400000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel115.Part.SurfaceGui.TextLabel.Text = "20-61"
newmodel115.Parent = workspace.scam.selsins.re2l
newmodel116 = workspace.scam.prefabs.re_2l:clone()
newmodel116:PivotTo(CFrame.new(workspace.scam.prefabs.Part1.CFrame.Position + Vector3.new(-1.5732000000000002, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel116.Part.SurfaceGui.TextLabel.Text = "14-21"
newmodel116.Parent = workspace.scam.selsins.re2l
newmodel117 = workspace.scam.prefabs.re_2l:clone()
newmodel117:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.034, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel117:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel117.Part.SurfaceGui.TextLabel.Text = "14-25"
newmodel117.Parent = workspace.scam.selsins.re2l
newmodel118 = workspace.scam.prefabs.re_2l:clone()
newmodel118:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.8036000000000001, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel118:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel118.Part.SurfaceGui.TextLabel.Text = "14-31"
newmodel118.Parent = workspace.scam.selsins.re2l
newmodel119 = workspace.scam.prefabs.re_2l:clone()
newmodel119:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.5732000000000002, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel119:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel119.Part.SurfaceGui.TextLabel.Text = "14-35"
newmodel119.Parent = workspace.scam.selsins.re2l
newmodel120 = workspace.scam.prefabs.re_2l:clone()
newmodel120:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel120:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel120.Part.SurfaceGui.TextLabel.Text = "14-41"
newmodel120.Parent = workspace.scam.selsins.re2l
newmodel121 = workspace.scam.prefabs.re_2l:clone()
newmodel121:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel121:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel121.Part.SurfaceGui.TextLabel.Text = "14-45"
newmodel121.Parent = workspace.scam.selsins.re2l
newmodel122 = workspace.scam.prefabs.re_2l:clone()
newmodel122:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel122:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-6.1908, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel122.Part.SurfaceGui.TextLabel.Text = "14-51"
newmodel122.Parent = workspace.scam.selsins.re2l
newmodel123 = workspace.scam.prefabs.re_2l:clone()
newmodel123:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel123:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.41879999999999995, -6.3706000000000005, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel123.Part.SurfaceGui.TextLabel.Text = "14-55"
newmodel123.Parent = workspace.scam.selsins.re2l
newmodel124 = workspace.scam.prefabs.re_2l:clone()
newmodel124:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.034, -6.653200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel124:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -6.653200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel124.Part.SurfaceGui.TextLabel.Text = "12-25"
newmodel124.Parent = workspace.scam.selsins.re2l
newmodel125 = workspace.scam.prefabs.re_2l:clone()
newmodel125:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -6.653200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel125:PivotTo(CFrame.new(workspace.scam.prefabs.Part3.CFrame.Position + Vector3.new(-0.41879999999999995, -6.653200000000001, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel125.Part.SurfaceGui.TextLabel.Text = "12-55"
newmodel125.Parent = workspace.scam.selsins.re2l
newmodel126 = workspace.scam.prefabs.re_2l:clone()
newmodel126:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-0.8036000000000001, -6.9358, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel126:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -6.9358, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel126.Part.SurfaceGui.TextLabel.Text = "10-31"
newmodel126.Parent = workspace.scam.selsins.re2l
newmodel127 = workspace.scam.prefabs.re_2l:clone()
newmodel127:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-1.5732000000000002, -6.9358, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel127:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.882, -6.9358, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel127.Part.SurfaceGui.TextLabel.Text = "10-35"
newmodel127.Parent = workspace.scam.selsins.re2l
newmodel128 = workspace.scam.prefabs.re_2l:clone()
newmodel128:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-2.3428000000000004, -6.9358, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel128:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-4.6516, -6.9358, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel128.Part.SurfaceGui.TextLabel.Text = "10-41"
newmodel128.Parent = workspace.scam.selsins.re2l
newmodel129 = workspace.scam.prefabs.re_2l:clone()
newmodel129:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-3.1124, -6.9358, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel129:PivotTo(CFrame.new(workspace.scam.prefabs.Part2.CFrame.Position + Vector3.new(-5.4212, -6.9358, 0)) * CFrame.fromEulerAngles(0, math.rad(-90), 0))
newmodel129.Part.SurfaceGui.TextLabel.Text = "10-45"
newmodel129.Parent = workspace.scam.selsins.re2l
