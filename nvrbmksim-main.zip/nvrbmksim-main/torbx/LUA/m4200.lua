newmodel0 = workspace.prefabs.m4200:clone()
newmodel0:PivotTo(CFrame.new(-52.3073815926531, 2.3712000000000004, 38.095649704615845) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel0.Parent = workspace.devices.m4200
newmodel1 = workspace.prefabs.m4200:clone()
newmodel1:PivotTo(CFrame.new(-52.5347947755264, 2.3712000000000004, 38.014715217640884) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel1.Parent = workspace.devices.m4200
newmodel2 = workspace.prefabs.m4200:clone()
newmodel2:PivotTo(CFrame.new(-52.762209717377026, 2.3712000000000004, 37.93378306049179) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel2.Parent = workspace.devices.m4200
newmodel3 = workspace.prefabs.m4200:clone()
newmodel3:PivotTo(CFrame.new(-52.989634079230726, 2.3712000000000004, 37.85284514927619) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel3.Parent = workspace.devices.m4200
newmodel4 = workspace.prefabs.m4200:clone()
newmodel4:PivotTo(CFrame.new(-53.2922306382374, 2.3712000000000004, 37.745152835094984) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel4.Parent = workspace.devices.m4200
newmodel5 = workspace.prefabs.m4200:clone()
newmodel5:PivotTo(CFrame.new(-53.51643750964278, 2.3712000000000004, 37.66536451407619) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel5.Parent = workspace.devices.m4200
newmodel6 = workspace.prefabs.m4200:clone()
newmodel6:PivotTo(CFrame.new(-53.74063544448973, 2.3712000000000004, 37.585571983905396) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel6.Parent = workspace.devices.m4200
newmodel7 = workspace.prefabs.m4200:clone()
newmodel7:PivotTo(CFrame.new(-60.88501391231426, 2.3712000000000004, 33.7849762728381) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel7.Parent = workspace.devices.m4200
newmodel8 = workspace.prefabs.m4200:clone()
newmodel8:PivotTo(CFrame.new(-61.081920998339804, 2.3712000000000004, 33.6453541990287) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel8.Parent = workspace.devices.m4200
newmodel9 = workspace.prefabs.m4200:clone()
newmodel9:PivotTo(CFrame.new(-61.278828084365855, 2.3712000000000004, 33.50573212522003) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel9.Parent = workspace.devices.m4200
newmodel10 = workspace.prefabs.m4200:clone()
newmodel10:PivotTo(CFrame.new(-61.475747070235826, 2.3712000000000004, 33.36610310690308) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel10.Parent = workspace.devices.m4200
newmodel11 = workspace.prefabs.m4200:clone()
newmodel11:PivotTo(CFrame.new(-61.73775156705473, 2.3712000000000004, 33.180313356185806) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel11.Parent = workspace.devices.m4200
newmodel12 = workspace.prefabs.m4200:clone()
newmodel12:PivotTo(CFrame.new(-61.931878193346066, 2.3712000000000004, 33.04266031224301) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel12.Parent = workspace.devices.m4200
newmodel13 = workspace.prefabs.m4200:clone()
newmodel13:PivotTo(CFrame.new(-62.12600223634871, 2.3712000000000004, 32.9050086733578) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel13.Parent = workspace.devices.m4200
