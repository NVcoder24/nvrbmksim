newmodel0 = workspace.prefabs.m1741:clone()
newmodel0:PivotTo(CFrame.new(-17.285753535773136, 3.4022862292074043, 23.87561552940604) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel0.Parent = workspace.devices.m1741
newmodel1 = workspace.prefabs.m1741:clone()
newmodel1:PivotTo(CFrame.new(-17.684377453710475, 3.4022862292074043, 24.34156961732489) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel1.Parent = workspace.devices.m1741
newmodel2 = workspace.prefabs.m1741:clone()
newmodel2:PivotTo(CFrame.new(-19.24932826847068, 3.0715877857459053, 25.957524786184834) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel2.Parent = workspace.devices.m1741
