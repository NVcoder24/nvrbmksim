newmodel0 = workspace.prefabs.ksp2_1:clone()
newmodel0:PivotTo(CFrame.new(-11.985207764458103, 5.9282739200000005, 25.378536648462195) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel0.Parent = workspace.devices.ksp2
newmodel1 = workspace.prefabs.ksp2_1:clone()
newmodel1:PivotTo(CFrame.new(-12.56341816411858, 5.9282739200000005, 26.09922954221851) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel1.Parent = workspace.devices.ksp2
newmodel2 = workspace.prefabs.ksp2_1:clone()
newmodel2:PivotTo(CFrame.new(-14.01102026720168, 4.66632, 27.85441260388084) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel2.Parent = workspace.devices.ksp2
newmodel3 = workspace.prefabs.ksp2_1:clone()
newmodel3:PivotTo(CFrame.new(-14.640279456803148, 4.66632, 28.505119843968195) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel3.Parent = workspace.devices.ksp2
newmodel4 = workspace.prefabs.ksp2_1:clone()
newmodel4:PivotTo(CFrame.new(-20.221519274722525, 5.72336, 33.282765740417915) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel4.Parent = workspace.devices.ksp2
newmodel5 = workspace.prefabs.ksp2_1:clone()
newmodel5:PivotTo(CFrame.new(-19.484215112578298, 4.66632, 32.75762803230241) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel5.Parent = workspace.devices.ksp2
newmodel6 = workspace.prefabs.ksp2_1:clone()
newmodel6:PivotTo(CFrame.new(-26.486266823937868, 4.999200000000001, 36.833602797366) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel6.Parent = workspace.devices.ksp2
newmodel7 = workspace.prefabs.ksp2_1:clone()
newmodel7:PivotTo(CFrame.new(-27.335253276234113, 4.999200000000001, 37.18370329639083) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel7.Parent = workspace.devices.ksp2
newmodel8 = workspace.prefabs.ksp2_1:clone()
newmodel8:PivotTo(CFrame.new(-28.184239728530365, 4.999200000000001, 37.53380379541565) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0))
newmodel8.Parent = workspace.devices.ksp2
newmodel9 = workspace.prefabs.ksp2_1:clone()
newmodel9:PivotTo(CFrame.new(-32.507205007766046, 4.999200000000001, 38.939284999075376) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel9.Parent = workspace.devices.ksp2
newmodel10 = workspace.prefabs.ksp2_1:clone()
newmodel10:PivotTo(CFrame.new(-33.441490148732825, 3.8604000000000007, 39.136340069978615) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel10.Parent = workspace.devices.ksp2
newmodel11 = workspace.prefabs.ksp2_1:clone()
newmodel11:PivotTo(CFrame.new(-32.507205007766046, 3.8604000000000007, 38.939284999075376) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel11.Parent = workspace.devices.ksp2
newmodel12 = workspace.prefabs.ksp2_1:clone()
newmodel12:PivotTo(CFrame.new(-33.441490148732825, 4.999200000000001, 39.136340069978615) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0))
newmodel12.Parent = workspace.devices.ksp2
newmodel13 = workspace.prefabs.ksp2_1:clone()
newmodel13:PivotTo(CFrame.new(-35.68060687327566, 4.213720000000001, 39.57801510857126) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel13.Parent = workspace.devices.ksp2
newmodel14 = workspace.prefabs.ksp2_1:clone()
newmodel14:PivotTo(CFrame.new(-37.525194803331914, 4.213720000000001, 39.79339863322156) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0))
newmodel14.Parent = workspace.devices.ksp2
newmodel15 = workspace.prefabs.ksp2_1:clone()
newmodel15:PivotTo(CFrame.new(-38.846766279926136, 4.999200000000001, 39.92000691931861) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel15.Parent = workspace.devices.ksp2
newmodel16 = workspace.prefabs.ksp2_1:clone()
newmodel16:PivotTo(CFrame.new(-39.80131715604124, 3.8604000000000007, 39.943502674422106) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel16.Parent = workspace.devices.ksp2
newmodel17 = workspace.prefabs.ksp2_1:clone()
newmodel17:PivotTo(CFrame.new(-38.846766279926136, 3.8604000000000007, 39.92000691931861) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel17.Parent = workspace.devices.ksp2
newmodel18 = workspace.prefabs.ksp2_1:clone()
newmodel18:PivotTo(CFrame.new(-39.80131715604124, 4.999200000000001, 39.943502674422106) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0))
newmodel18.Parent = workspace.devices.ksp2
newmodel19 = workspace.prefabs.ksp2_1:clone()
newmodel19:PivotTo(CFrame.new(-42.06012451396606, 4.999200000000001, 39.971306051950236) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel19.Parent = workspace.devices.ksp2
newmodel20 = workspace.prefabs.ksp2_1:clone()
newmodel20:PivotTo(CFrame.new(-43.00990742397599, 4.999200000000001, 39.90755567741752) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel20.Parent = workspace.devices.ksp2
newmodel21 = workspace.prefabs.ksp2_1:clone()
newmodel21:PivotTo(CFrame.new(-43.95969033398592, 4.999200000000001, 39.843805302884796) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0))
newmodel21.Parent = workspace.devices.ksp2
newmodel22 = workspace.prefabs.ksp2:clone()
newmodel22:PivotTo(CFrame.new(-49.35005509503216, 4.999200000000001, 38.95810262319012) * CFrame.fromEulerAngles(0, math.rad(-104.34), 0))
newmodel22.Parent = workspace.devices.ksp2
newmodel23 = workspace.prefabs.ksp2:clone()
newmodel23:PivotTo(CFrame.new(-50.251098515309515, 4.999200000000001, 38.727759498320104) * CFrame.fromEulerAngles(0, math.rad(-104.34), 0))
newmodel23.Parent = workspace.devices.ksp2
newmodel24 = workspace.prefabs.ksp2_1:clone()
newmodel24:PivotTo(CFrame.new(-51.52747899141464, 4.999200000000001, 38.373206698729994) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel24.Parent = workspace.devices.ksp2
newmodel25 = workspace.prefabs.ksp2_1:clone()
newmodel25:PivotTo(CFrame.new(-52.42842450861833, 4.999200000000001, 38.05257160235004) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel25.Parent = workspace.devices.ksp2
newmodel26 = workspace.prefabs.ksp2:clone()
newmodel26:PivotTo(CFrame.new(-53.32937002582201, 4.999200000000001, 37.73193650597008) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel26.Parent = workspace.devices.ksp2
newmodel27 = workspace.prefabs.ksp2_1:clone()
newmodel27:PivotTo(CFrame.new(-52.42842450861833, 3.8604000000000007, 38.05257160235004) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel27.Parent = workspace.devices.ksp2
newmodel28 = workspace.prefabs.ksp2_1:clone()
newmodel28:PivotTo(CFrame.new(-51.52747899141464, 3.8604000000000007, 38.373206698729994) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel28.Parent = workspace.devices.ksp2
newmodel29 = workspace.prefabs.ksp2_1:clone()
newmodel29:PivotTo(CFrame.new(-53.32937002582201, 3.8604000000000007, 37.73193650597008) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0))
newmodel29.Parent = workspace.devices.ksp2
newmodel30 = workspace.prefabs.ksp2:clone()
newmodel30:PivotTo(CFrame.new(-55.41100981001702, 4.87072, 36.86915043882483) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0))
newmodel30.Parent = workspace.devices.ksp2
newmodel31 = workspace.prefabs.ksp2_1:clone()
newmodel31:PivotTo(CFrame.new(-58.27281568358937, 4.999200000000001, 35.41779910340179) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel31.Parent = workspace.devices.ksp2
newmodel32 = workspace.prefabs.ksp2_1:clone()
newmodel32:PivotTo(CFrame.new(-57.47696890885091, 4.213720000000001, 35.87894978499989) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel32.Parent = workspace.devices.ksp2
newmodel33 = workspace.prefabs.ksp2_1:clone()
newmodel33:PivotTo(CFrame.new(-59.06866245832782, 4.213720000000001, 34.956648421803706) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0))
newmodel33.Parent = workspace.devices.ksp2
newmodel34 = workspace.prefabs.ksp2_1:clone()
newmodel34:PivotTo(CFrame.new(-60.20973556064693, 4.999200000000001, 34.263811996067375) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel34.Parent = workspace.devices.ksp2
newmodel35 = workspace.prefabs.ksp2_1:clone()
newmodel35:PivotTo(CFrame.new(-60.989822053178024, 4.999200000000001, 33.71066214822275) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel35.Parent = workspace.devices.ksp2
newmodel36 = workspace.prefabs.ksp2:clone()
newmodel36:PivotTo(CFrame.new(-61.769908545709114, 4.999200000000001, 33.15751230037812) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel36.Parent = workspace.devices.ksp2
newmodel37 = workspace.prefabs.ksp2_1:clone()
newmodel37:PivotTo(CFrame.new(-60.989822053178024, 3.8604000000000007, 33.71066214822275) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel37.Parent = workspace.devices.ksp2
newmodel38 = workspace.prefabs.ksp2_1:clone()
newmodel38:PivotTo(CFrame.new(-60.20973556064693, 3.8604000000000007, 34.263811996067375) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel38.Parent = workspace.devices.ksp2
newmodel39 = workspace.prefabs.ksp2_1:clone()
newmodel39:PivotTo(CFrame.new(-61.769908545709114, 3.8604000000000007, 33.15751230037812) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0))
newmodel39.Parent = workspace.devices.ksp2
newmodel40 = workspace.prefabs.ksp2:clone()
newmodel40:PivotTo(CFrame.new(-63.5391951937427, 4.87072, 31.762067708019547) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0))
newmodel40.Parent = workspace.devices.ksp2
newmodel41 = workspace.prefabs.ksp2:clone()
newmodel41:PivotTo(CFrame.new(-65.89958182133168, 4.999200000000001, 29.588410835942938) * CFrame.fromEulerAngles(0, math.rad(-135.84), 0))
newmodel41.Parent = workspace.devices.ksp2
newmodel42 = workspace.prefabs.ksp2:clone()
newmodel42:PivotTo(CFrame.new(-66.54749367915036, 4.999200000000001, 28.921217142254257) * CFrame.fromEulerAngles(0, math.rad(-135.84), 0))
newmodel42.Parent = workspace.devices.ksp2
