newmodel0 = workspace.prefabs.bruk:clone()
newmodel0:PivotTo(CFrame.new(-49.30194484047441, 2.7245650905153425, 33.685624294508365) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.bruk
newmodel1 = workspace.prefabs.bruk:clone()
newmodel1:PivotTo(CFrame.new(-49.27350632221701, 2.714385299762416, 33.572797602012535) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.devices.bruk
newmodel2 = workspace.prefabs.bruk:clone()
newmodel2:PivotTo(CFrame.new(-48.88843023696915, 2.714385299762416, 33.66985790785474) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.bruk
newmodel3 = workspace.prefabs.bruk:clone()
newmodel3:PivotTo(CFrame.new(-48.934435450432765, 2.6558515029330887, 32.968292200766015) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.bruk
newmodel4 = workspace.prefabs.bruk:clone()
newmodel4:PivotTo(CFrame.new(-48.90599693217536, 2.6456717121801625, 32.85546550827017) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.bruk
newmodel5 = workspace.prefabs.bruu:clone()
newmodel5:PivotTo(CFrame.new(-32.80751380561293, 2.6124377628438022, 31.993777008070325) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.bruu
newmodel6 = workspace.prefabs.bruu:clone()
newmodel6:PivotTo(CFrame.new(-32.846327316593836, 2.601239993015583, 31.871812948953675) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.devices.bruu
newmodel7 = workspace.prefabs.bruu:clone()
newmodel7:PivotTo(CFrame.new(-32.885140827574745, 2.5900422231873637, 31.74984888983703) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.devices.bruu
newmodel8 = workspace.prefabs.bruu:clone()
newmodel8:PivotTo(CFrame.new(-33.29430960439802, 2.601239993015583, 32.01437761573237) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.devices.bruu
newmodel9 = workspace.prefabs.bruu:clone()
newmodel9:PivotTo(CFrame.new(-33.255496093417115, 2.6124377628438022, 32.13634167484902) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.devices.bruu
newmodel10 = workspace.prefabs.bru_2k:clone()
newmodel10:PivotTo(CFrame.new(-33.05237368963012, 2.6124377628438022, 32.07170055264501) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.devices.bru_2k
newmodel11 = workspace.prefabs.bru_2k:clone()
newmodel11:PivotTo(CFrame.new(-33.09118720061104, 2.601239993015583, 31.94973649352837) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.devices.bru_2k
newmodel12 = workspace.prefabs.bru_2k:clone()
newmodel12:PivotTo(CFrame.new(-33.13000071159195, 2.5900422231873637, 31.82777243441172) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.bru_2k
newmodel13 = workspace.prefabs.bru_2k:clone()
newmodel13:PivotTo(CFrame.new(-33.57798299939614, 2.5900422231873637, 31.970337101190417) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.bru_2k
newmodel14 = workspace.prefabs.rzd_k:clone()
newmodel14:PivotTo(CFrame.new(-32.804306895229075, 2.578844453359145, 31.589808553257747) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.rzd_k
newmodel15 = workspace.prefabs.rzd_k:clone()
newmodel15:PivotTo(CFrame.new(-33.05194927792829, 2.578844453359145, 31.66861759265715) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.rzd_k
newmodel16 = workspace.prefabs.rzd_k:clone()
newmodel16:PivotTo(CFrame.new(-33.33312311537894, 2.5900422231873637, 31.892413556615725) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.rzd_k
newmodel17 = workspace.prefabs.rzd_k:clone()
newmodel17:PivotTo(CFrame.new(-33.38725291187747, 2.576833944685442, 31.751207889540908) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel17.Parent = workspace.devices.rzd_k
newmodel18 = workspace.prefabs.bruk:clone()
newmodel18:PivotTo(CFrame.new(-51.30044563010174, 2.73245442834886, 33.13905271585973) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel18.Parent = workspace.devices.bruk
newmodel19 = workspace.prefabs.bruk:clone()
newmodel19:PivotTo(CFrame.new(-51.25880141701201, 2.7215111532894647, 33.021106466037565) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel19.Parent = workspace.devices.bruk
newmodel20 = workspace.prefabs.bruk:clone()
newmodel20:PivotTo(CFrame.new(-51.21715720392229, 2.7105678782300684, 32.9031602162154) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel20.Parent = workspace.devices.bruk
newmodel21 = workspace.prefabs.bruk:clone()
newmodel21:PivotTo(CFrame.new(-51.17551299083257, 2.6996246031706725, 32.78521396639324) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel21.Parent = workspace.devices.bruk
newmodel22 = workspace.prefabs.bruk:clone()
newmodel22:PivotTo(CFrame.new(-50.68219596439476, 2.697334150251264, 32.93162936876603) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.bruk
newmodel23 = workspace.prefabs.bruk:clone()
newmodel23:PivotTo(CFrame.new(-50.641520221376894, 2.6866453699606914, 32.81642605498624) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel23.Parent = workspace.devices.bruk
newmodel24 = workspace.prefabs.bruk:clone()
newmodel24:PivotTo(CFrame.new(-50.600844478359015, 2.6759565896701183, 32.70122274120646) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.bruk
newmodel25 = workspace.prefabs.bruk:clone()
newmodel25:PivotTo(CFrame.new(-51.13386877774284, 2.6886813281112767, 32.667267716571075) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.bruk
newmodel26 = workspace.prefabs.bruk:clone()
newmodel26:PivotTo(CFrame.new(-51.092224564653115, 2.677738053051881, 32.54932146674891) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.bruk
newmodel27 = workspace.prefabs.bruk:clone()
newmodel27:PivotTo(CFrame.new(-51.05058035156339, 2.666794777992485, 32.43137521692675) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel27.Parent = workspace.devices.bruk
newmodel28 = workspace.prefabs.bruk:clone()
newmodel28:PivotTo(CFrame.new(-34.90291389943104, 2.7469606301717806, 34.219274392451936) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel28.Parent = workspace.devices.bruk
newmodel29 = workspace.prefabs.bruk:clone()
newmodel29:PivotTo(CFrame.new(-34.93278482276084, 2.7347448812682686, 34.082880371255435) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel29.Parent = workspace.devices.bruk
newmodel30 = workspace.prefabs.bruk:clone()
newmodel30:PivotTo(CFrame.new(-34.96514498970145, 2.7215111532894647, 33.93512018162589) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel30.Parent = workspace.devices.bruk
newmodel31 = workspace.prefabs.bruk:clone()
newmodel31:PivotTo(CFrame.new(-34.99626053483665, 2.7087864148483063, 33.79304307621287) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel31.Parent = workspace.devices.bruk
newmodel32 = workspace.prefabs.bruk:clone()
newmodel32:PivotTo(CFrame.new(-52.59991532666269, 2.693170511301188, 32.06343016981695) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel32.Parent = workspace.devices.bruk
newmodel33 = workspace.prefabs.bruk:clone()
newmodel33:PivotTo(CFrame.new(-52.55120771331905, 2.6829907687463823, 31.9577622078439) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel33.Parent = workspace.devices.bruk
newmodel34 = workspace.prefabs.bruk:clone()
newmodel34:PivotTo(CFrame.new(-52.502500798878785, 2.6728108607354013, 31.852090758842934) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel34.Parent = workspace.devices.bruk
newmodel35 = workspace.prefabs.bruk:clone()
newmodel35:PivotTo(CFrame.new(-52.45379154622577, 2.662631107100658, 31.746421072587232) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel35.Parent = workspace.devices.bruk
newmodel36 = workspace.prefabs.bruk:clone()
newmodel36:PivotTo(CFrame.new(-52.40508244350739, 2.652451337642232, 31.64075100104236) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel36.Parent = workspace.devices.bruk
newmodel37 = workspace.prefabs.bruk:clone()
newmodel37:PivotTo(CFrame.new(-52.35637562686727, 2.6422715740181593, 31.535079568851806) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel37.Parent = workspace.devices.bruk
newmodel38 = workspace.prefabs.bruk:clone()
newmodel38:PivotTo(CFrame.new(-53.329842674376344, 2.607405743581873, 30.647550196160672) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel38.Parent = workspace.devices.bruk
newmodel39 = workspace.prefabs.bruk:clone()
newmodel39:PivotTo(CFrame.new(-53.28113482703394, 2.5972259528289463, 30.54188015562176) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel39.Parent = workspace.devices.bruk
newmodel40 = workspace.prefabs.bruk:clone()
newmodel40:PivotTo(CFrame.new(-52.61047277009055, 2.581030040899079, 30.720316668566056) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel40.Parent = workspace.devices.bruk
newmodel41 = workspace.prefabs.bruu:clone()
newmodel41:PivotTo(CFrame.new(-38.16905042058097, 2.602319149271575, 33.006410743331614) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel41.Parent = workspace.devices.bruu
newmodel42 = workspace.prefabs.bruu:clone()
newmodel42:PivotTo(CFrame.new(-38.18476611697838, 2.5911213794433565, 32.879388157790224) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel42.Parent = workspace.devices.bruu
newmodel43 = workspace.prefabs.bruu:clone()
newmodel43:PivotTo(CFrame.new(-38.6356130201351, 2.602319149271575, 33.064135565525426) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel43.Parent = workspace.devices.bruu
newmodel44 = workspace.prefabs.bruu:clone()
newmodel44:PivotTo(CFrame.new(-38.61989732373769, 2.6135169190997947, 33.191158151066816) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel44.Parent = workspace.devices.bruu
newmodel45 = workspace.prefabs.bruu:clone()
newmodel45:PivotTo(CFrame.new(-38.15333472418358, 2.6135169190997947, 33.133433328873004) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel45.Parent = workspace.devices.bruu
newmodel46 = workspace.prefabs.rzd_k:clone()
newmodel46:PivotTo(CFrame.new(-38.6513287165325, 2.5911213794433565, 32.937112979984036) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel46.Parent = workspace.devices.rzd_k
newmodel47 = workspace.prefabs.rzd_k:clone()
newmodel47:PivotTo(CFrame.new(-38.07694345129272, 2.579160125308668, 32.728287752880235) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel47.Parent = workspace.devices.rzd_k
newmodel48 = workspace.prefabs.rzd_k:clone()
newmodel48:PivotTo(CFrame.new(-38.33485693800276, 2.579160125308668, 32.76019774775756) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel48.Parent = workspace.devices.rzd_k
newmodel49 = workspace.prefabs.rzd_k:clone()
newmodel49:PivotTo(CFrame.new(-38.68216727449128, 2.57534270377632, 32.759202227253304) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel49.Parent = workspace.devices.rzd_k
newmodel50 = workspace.prefabs.bru_2k:clone()
newmodel50:PivotTo(CFrame.new(-38.90634429889748, 2.5911213794433565, 32.968664435593084) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel50.Parent = workspace.devices.bru_2k
newmodel51 = workspace.prefabs.bruk:clone()
newmodel51:PivotTo(CFrame.new(-40.98832711248069, 2.617422792840791, 33.4512701582382) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel51.Parent = workspace.devices.bruk
newmodel52 = workspace.prefabs.bruk:clone()
newmodel52:PivotTo(CFrame.new(-40.99571294017139, 2.596299727028469, 33.209945407663355) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel52.Parent = workspace.devices.bruk
newmodel53 = workspace.prefabs.bruk:clone()
newmodel53:PivotTo(CFrame.new(-40.99202002632604, 2.60686125993463, 33.33060778295078) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel53.Parent = workspace.devices.bruk
newmodel54 = workspace.prefabs.bruk:clone()
newmodel54:PivotTo(CFrame.new(-58.53046297338423, 2.7245650905153425, 29.17062725268105) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel54.Parent = workspace.devices.bruk
newmodel55 = workspace.prefabs.bruk:clone()
newmodel55:PivotTo(CFrame.new(-58.46314816177396, 2.714385299762416, 29.075720308793365) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel55.Parent = workspace.devices.bruk
newmodel56 = workspace.prefabs.bruk:clone()
newmodel56:PivotTo(CFrame.new(-58.139231953590716, 2.714385299762416, 29.30546491585997) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel56.Parent = workspace.devices.bruk
newmodel57 = workspace.prefabs.bruk:clone()
newmodel57:PivotTo(CFrame.new(-57.92842031187254, 2.6558515029330887, 28.63474189348424) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel57.Parent = workspace.devices.bruk
newmodel58 = workspace.prefabs.bruk:clone()
newmodel58:PivotTo(CFrame.new(-57.86110550026227, 2.6456717121801625, 28.539834949596553) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel58.Parent = workspace.devices.bruk
newmodel59 = workspace.prefabs.bruk:clone()
newmodel59:PivotTo(CFrame.new(-42.47567848429787, 2.629893036513126, 33.59547247549061) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel59.Parent = workspace.devices.bruk
newmodel60 = workspace.prefabs.bruk:clone()
newmodel60:PivotTo(CFrame.new(-42.46833590984694, 2.619509649945141, 33.47701717430146) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel60.Parent = workspace.devices.bruk
newmodel61 = workspace.prefabs.bruk:clone()
newmodel61:PivotTo(CFrame.new(-42.460993335396026, 2.6091262633771564, 33.35856187311231) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel61.Parent = workspace.devices.bruk
newmodel62 = workspace.prefabs.bruk:clone()
newmodel62:PivotTo(CFrame.new(-42.45365076094511, 2.5987428768091716, 33.240106571923164) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel62.Parent = workspace.devices.bruk
newmodel63 = workspace.prefabs.bruk:clone()
newmodel63:PivotTo(CFrame.new(-42.446308186494186, 2.5883594902411864, 33.121651270734006) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel63.Parent = workspace.devices.bruk
newmodel64 = workspace.prefabs.bruk:clone()
newmodel64:PivotTo(CFrame.new(-42.43896561204326, 2.577976103673201, 33.00319596954486) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel64.Parent = workspace.devices.bruk
newmodel65 = workspace.prefabs.bruk:clone()
newmodel65:PivotTo(CFrame.new(-42.8826595815608, 2.619509649945141, 33.45133489266613) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel65.Parent = workspace.devices.bruk
newmodel66 = workspace.prefabs.bruk:clone()
newmodel66:PivotTo(CFrame.new(-42.86797443265897, 2.5987428768091716, 33.21442429028783) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel66.Parent = workspace.devices.bruk
newmodel67 = workspace.prefabs.bruk:clone()
newmodel67:PivotTo(CFrame.new(-42.853289283757135, 2.577976103673201, 32.97751368790953) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel67.Parent = workspace.devices.bruk
newmodel68 = workspace.prefabs.bruk:clone()
newmodel68:PivotTo(CFrame.new(-42.89000215601173, 2.629893036513126, 33.56979019385528) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel68.Parent = workspace.devices.bruk
newmodel69 = workspace.prefabs.bruk:clone()
newmodel69:PivotTo(CFrame.new(-42.875317007109885, 2.6091262633771564, 33.33287959147698) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel69.Parent = workspace.devices.bruk
newmodel70 = workspace.prefabs.bruk:clone()
newmodel70:PivotTo(CFrame.new(-42.860631858208045, 2.5883594902411864, 33.09596898909868) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel70.Parent = workspace.devices.bruk
newmodel71 = workspace.prefabs.bruk:clone()
newmodel71:PivotTo(CFrame.new(-60.1960451269551, 2.73245442834886, 27.938321988915543) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel71.Parent = workspace.devices.bruk
newmodel72 = workspace.prefabs.bruk:clone()
newmodel72:PivotTo(CFrame.new(-60.114566974023916, 2.7215111532894647, 27.84341746359721) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel72.Parent = workspace.devices.bruk
newmodel73 = workspace.prefabs.bruk:clone()
newmodel73:PivotTo(CFrame.new(-60.03308882109274, 2.7105678782300684, 27.74851293827888) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel73.Parent = workspace.devices.bruk
newmodel74 = workspace.prefabs.bruk:clone()
newmodel74:PivotTo(CFrame.new(-59.95161066816157, 2.6996246031706725, 27.65360841296054) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel74.Parent = workspace.devices.bruk
newmodel75 = workspace.prefabs.bruk:clone()
newmodel75:PivotTo(CFrame.new(-59.54462686980519, 2.697334150251264, 27.968510535056982) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel75.Parent = workspace.devices.bruk
newmodel76 = workspace.prefabs.bruk:clone()
newmodel76:PivotTo(CFrame.new(-59.46504355763986, 2.6866453699606914, 27.875813091722797) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel76.Parent = workspace.devices.bruk
newmodel77 = workspace.prefabs.bruk:clone()
newmodel77:PivotTo(CFrame.new(-59.38546024547452, 2.6759565896701183, 27.78311564838861) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel77.Parent = workspace.devices.bruk
newmodel78 = workspace.prefabs.bruk:clone()
newmodel78:PivotTo(CFrame.new(-59.870132515230395, 2.6886813281112767, 27.558703887642206) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel78.Parent = workspace.devices.bruk
newmodel79 = workspace.prefabs.bruk:clone()
newmodel79:PivotTo(CFrame.new(-59.78865436229921, 2.677738053051881, 27.463799362323876) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel79.Parent = workspace.devices.bruk
newmodel80 = workspace.prefabs.bruk:clone()
newmodel80:PivotTo(CFrame.new(-59.707176209368036, 2.666794777992485, 27.36889483700554) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel80.Parent = workspace.devices.bruk
newmodel81 = workspace.prefabs.bruk:clone()
newmodel81:PivotTo(CFrame.new(-61.02057191478296, 2.6912683133342883, 26.4674975390418) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel81.Parent = workspace.devices.bruk
newmodel82 = workspace.prefabs.bruk:clone()
newmodel82:PivotTo(CFrame.new(-60.93693851464668, 2.681088195264936, 26.38658959599477) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel82.Parent = workspace.devices.bruk
newmodel83 = workspace.prefabs.bruk:clone()
newmodel83:PivotTo(CFrame.new(-60.85331841707199, 2.670908532624921, 26.305687771752687) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel83.Parent = workspace.devices.bruk
newmodel84 = workspace.prefabs.bruk:clone()
newmodel84:PivotTo(CFrame.new(-60.76969348587998, 2.660728752623431, 26.2247832586847) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel84.Parent = workspace.devices.bruk
newmodel85 = workspace.prefabs.bruk:clone()
newmodel85:PivotTo(CFrame.new(-60.686070764459764, 2.650548998838454, 26.143877255275456) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel85.Parent = workspace.devices.bruk
newmodel86 = workspace.prefabs.bruk:clone()
newmodel86:PivotTo(CFrame.new(-60.602445835645085, 2.64036922048246, 26.062972742616097) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel86.Parent = workspace.devices.bruk
newmodel87 = workspace.prefabs.bruk:clone()
newmodel87:PivotTo(CFrame.new(-61.189079160322535, 2.6055033625621764, 24.883477582708377) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel87.Parent = workspace.devices.bruk
newmodel88 = workspace.prefabs.bruk:clone()
newmodel88:PivotTo(CFrame.new(-61.105454791958785, 2.59532357180925, 24.802572843193367) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel88.Parent = workspace.devices.bruk
newmodel89 = workspace.prefabs.bruk:clone()
newmodel89:PivotTo(CFrame.new(-60.54281678104074, 2.581030040899079, 25.209619161545234) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel89.Parent = workspace.devices.bruk
