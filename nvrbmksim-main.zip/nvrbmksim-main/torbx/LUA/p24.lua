workspace.devices.e1:PivotTo(CFrame.new(-63.08570024508304, 2.7581583999999997, 25.49282915236076) * CFrame.fromEulerAngles(0, math.rad(-51.247), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
workspace.devices.e2:PivotTo(CFrame.new(-64.8948967266715, 2.7581583999999997, 23.23885718215557) * CFrame.fromEulerAngles(0, math.rad(-56.547), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
workspace.devices.p24:PivotTo(CFrame.new(-69.27999620210072, 7.218400000000001, 25.685505720228846) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0))
workspace.devices.p25:PivotTo(CFrame.new(-71.06029201138342, 7.218400000000001, 23.012029160323067) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0))
