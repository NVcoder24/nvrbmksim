newmodel0 = workspace.prefabs.m1742:clone()
newmodel0:PivotTo(CFrame.new(-22.410559995744777, 3.1981158858529137, 28.774173007798446) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(-10)))
newmodel0.Parent = workspace.devices.m1742
newmodel1 = workspace.prefabs.m1742:clone()
newmodel1:PivotTo(CFrame.new(-12.63024431635489, 6.844639999999999, 26.182522981876573) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel1.Parent = workspace.devices.m1742
newmodel2 = workspace.prefabs.m1742:clone()
newmodel2:PivotTo(CFrame.new(-12.63024431635489, 6.157187319999999, 26.182522981876573) * CFrame.fromEulerAngles(0, math.rad(-38.739999000000005), 0))
newmodel2.Parent = workspace.devices.m1742
