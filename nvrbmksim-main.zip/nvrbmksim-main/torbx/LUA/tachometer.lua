newmodel0 = workspace.prefabs.tachometer:clone()
newmodel0:PivotTo(CFrame.new(-48.14904272363553, 3.6467155135050344, 34.6519051115695) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel0.Parent = workspace.devices.tachometer
newmodel1 = workspace.prefabs.tachometer:clone()
newmodel1:PivotTo(CFrame.new(-57.8050330061087, 3.6467155135050344, 30.488423480096785) * CFrame.fromEulerAngles(0, math.rad(-35.346990000000005), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0) * CFrame.fromEulerAngles(math.rad(-75), 0, 0))
newmodel1.Parent = workspace.devices.tachometer
newmodel2 = workspace.prefabs.tachometer:clone()
newmodel2:PivotTo(CFrame.new(-67.5156320243497, 5.437200000000001, 27.87133430917736) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel2.Parent = workspace.devices.tachometer
newmodel3 = workspace.prefabs.tachometer:clone()
newmodel3:PivotTo(CFrame.new(-68.80680232410361, 5.437200000000001, 26.271740760980386) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0) * CFrame.fromEulerAngles(math.rad(-90), 0, math.rad(90)))
newmodel3.Parent = workspace.devices.tachometer
