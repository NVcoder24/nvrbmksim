newmodel0 = workspace.prefabs.mtkindd:clone()
newmodel0:PivotTo(CFrame.new(-16.908472690299998, 2.973816072026853, 23.318390227714932) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel0.Parent = workspace.devices.mtkind
newmodel0.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel1 = workspace.prefabs.mtkindd:clone()
newmodel1:PivotTo(CFrame.new(-16.993620657380546, 2.973816072026853, 23.417920239723387) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel1.Parent = workspace.devices.mtkind
newmodel1.Body1.Color = Color3.fromRGB(196, 40, 28)
newmodel2 = workspace.prefabs.mtkindd:clone()
newmodel2:PivotTo(CFrame.new(-17.078768624461095, 2.973816072026853, 23.517450251731844) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel2.Parent = workspace.devices.mtkind
newmodel2.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel3 = workspace.prefabs.mtkindd:clone()
newmodel3:PivotTo(CFrame.new(-17.163916591541643, 2.973816072026853, 23.616980263740302) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel3.Parent = workspace.devices.mtkind
newmodel4 = workspace.prefabs.mtkindd:clone()
newmodel4:PivotTo(CFrame.new(-17.249066456831322, 2.973816072026853, 23.716512494577746) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel4.Parent = workspace.devices.mtkind
newmodel5 = workspace.prefabs.mtkindd:clone()
newmodel5:PivotTo(CFrame.new(-17.334214423911874, 2.973816072026853, 23.816042506586204) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel5.Parent = workspace.devices.mtkind
newmodel6 = workspace.prefabs.mtkindd:clone()
newmodel6:PivotTo(CFrame.new(-17.419362390992422, 2.973816072026853, 23.915572518594658) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel6.Parent = workspace.devices.mtkind
newmodel6.Body1.Color = Color3.fromRGB(29, 156, 29)
newmodel7 = workspace.prefabs.mtkindd:clone()
newmodel7:PivotTo(CFrame.new(-17.50451035807297, 2.973816072026853, 24.015102530603116) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel7.Parent = workspace.devices.mtkind
newmodel8 = workspace.prefabs.mtkindd:clone()
newmodel8:PivotTo(CFrame.new(-17.726600826638055, 2.973816072026853, 24.274705522443618) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel8.Parent = workspace.devices.mtkind
newmodel8.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel9 = workspace.prefabs.mtkindd:clone()
newmodel9:PivotTo(CFrame.new(-17.81202023762463, 2.973816072026853, 24.374552826997657) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel9.Parent = workspace.devices.mtkind
newmodel9.Body1.Color = Color3.fromRGB(196, 40, 28)
newmodel10 = workspace.prefabs.mtkindd:clone()
newmodel10:PivotTo(CFrame.new(-17.8974396486112, 2.973816072026853, 24.474400131551697) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel10.Parent = workspace.devices.mtkind
newmodel10.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel11 = workspace.prefabs.mtkindd:clone()
newmodel11:PivotTo(CFrame.new(-17.98285905959777, 2.973816072026853, 24.574247436105736) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel11.Parent = workspace.devices.mtkind
newmodel12 = workspace.prefabs.mtkindd:clone()
newmodel12:PivotTo(CFrame.new(-18.068278470584346, 2.973816072026853, 24.674094740659775) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel12.Parent = workspace.devices.mtkind
newmodel12.Body1.Color = Color3.fromRGB(29, 156, 29)
newmodel13 = workspace.prefabs.mtkindd:clone()
newmodel13:PivotTo(CFrame.new(-18.153697881570917, 2.973816072026853, 24.773942045213815) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel13.Parent = workspace.devices.mtkind
newmodel14 = workspace.prefabs.mtkindd:clone()
newmodel14:PivotTo(CFrame.new(-18.239117292557488, 2.973816072026853, 24.873789349767854) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel14.Parent = workspace.devices.mtkind
newmodel14.Body1.Color = Color3.fromRGB(29, 156, 29)
newmodel15 = workspace.prefabs.mtkindd:clone()
newmodel15:PivotTo(CFrame.new(-18.324536703544062, 2.973816072026853, 24.973636654321894) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel15.Parent = workspace.devices.mtkind
newmodel16 = workspace.prefabs.mtkindd:clone()
newmodel16:PivotTo(CFrame.new(-18.380009783352126, 2.7090409096171295, 23.94013304669092) * CFrame.fromEulerAngles(0, math.rad(-40.547002), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel16.Parent = workspace.devices.mtkind
newmodel17 = workspace.prefabs.mtkindd:clone()
newmodel17:PivotTo(CFrame.new(-50.05641694074393, 2.608525437875471, 32.00067502848117) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel17.Parent = workspace.devices.mtkind
newmodel18 = workspace.prefabs.mtkindd:clone()
newmodel18:PivotTo(CFrame.new(-50.61260649045873, 2.608525437875471, 31.804296795501948) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel18.Parent = workspace.devices.mtkind
newmodel19 = workspace.prefabs.mtkindd:clone()
newmodel19:PivotTo(CFrame.new(-51.07517997735025, 2.608525437875471, 31.640972324509328) * CFrame.fromEulerAngles(0, math.rad(-109.447), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel19.Parent = workspace.devices.mtkind
newmodel20 = workspace.prefabs.mtkindd:clone()
newmodel20:PivotTo(CFrame.new(-19.204441763197035, 2.959437878832875, 25.886384417731207) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel20.Parent = workspace.devices.mtkind
newmodel20.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel20.Body1.Decal.Texture = 'rbxassetid://18814177678'
newmodel21 = workspace.prefabs.mtkindd:clone()
newmodel21:PivotTo(CFrame.new(-19.298195169356767, 2.959437878832875, 25.97740610598982) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel21.Parent = workspace.devices.mtkind
newmodel21.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel21.Body1.Decal.Texture = 'rbxassetid://18814157505'
newmodel22 = workspace.prefabs.mtkindd:clone()
newmodel22:PivotTo(CFrame.new(-19.391948575516494, 2.959437878832875, 26.068427794248436) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel22.Parent = workspace.devices.mtkind
newmodel22.Body1.Color = Color3.fromRGB(29, 156, 29)
newmodel22.Body1.Decal.Texture = 'rbxassetid://18814091774'
newmodel23 = workspace.prefabs.mtkindd:clone()
newmodel23:PivotTo(CFrame.new(-19.485701981676225, 2.959437878832875, 26.159449482507053) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel23.Parent = workspace.devices.mtkind
newmodel23.Body1.Decal.Texture = 'rbxassetid://18814085888'
newmodel24 = workspace.prefabs.mtkindd:clone()
newmodel24:PivotTo(CFrame.new(-19.579455387835957, 2.959437878832875, 26.250471170765667) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel24.Parent = workspace.devices.mtkind
newmodel24.Body1.Decal.Texture = 'rbxassetid://18814056577'
newmodel25 = workspace.prefabs.mtkindd:clone()
newmodel25:PivotTo(CFrame.new(-19.920948241557433, 2.959437878832875, 26.58201385648979) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel25.Parent = workspace.devices.mtkind
newmodel25.Body1.Decal.Texture = 'rbxassetid://18813313559'
newmodel26 = workspace.prefabs.mtkindd:clone()
newmodel26:PivotTo(CFrame.new(-20.017320457945086, 2.959437878832875, 26.675578050007026) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel26.Parent = workspace.devices.mtkind
newmodel26.Body1.Decal.Texture = 'rbxassetid://18813615653'
newmodel27 = workspace.prefabs.mtkindd:clone()
newmodel27:PivotTo(CFrame.new(-20.113692674332743, 2.959437878832875, 26.76914224352426) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel27.Parent = workspace.devices.mtkind
newmodel27.Body1.Decal.Texture = 'rbxassetid://18813650142'
newmodel28 = workspace.prefabs.mtkindd:clone()
newmodel28:PivotTo(CFrame.new(-20.2100648907204, 2.959437878832875, 26.8627064370415) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel28.Parent = workspace.devices.mtkind
newmodel28.Body1.Decal.Texture = 'rbxassetid://18813657472'
newmodel29 = workspace.prefabs.mtkindd:clone()
newmodel29:PivotTo(CFrame.new(-20.306437107108053, 2.959437878832875, 26.956270630558734) * CFrame.fromEulerAngles(0, math.rad(-45.847), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel29.Parent = workspace.devices.mtkind
newmodel29.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel29.Body1.Decal.Texture = 'rbxassetid://18813799682'
newmodel30 = workspace.prefabs.mtkindd:clone()
newmodel30:PivotTo(CFrame.new(-34.77326665503146, 2.6799915417308577, 33.321965312712216) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel30.Parent = workspace.devices.mtkind
newmodel31 = workspace.prefabs.mtkindd:clone()
newmodel31:PivotTo(CFrame.new(-35.46322820338382, 2.746451640634134, 34.33603016196918) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel31.Parent = workspace.devices.mtkind
newmodel32 = workspace.prefabs.mtkindd:clone()
newmodel32:PivotTo(CFrame.new(-35.49434374851902, 2.733726902192976, 34.193953056556154) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel32.Parent = workspace.devices.mtkind
newmodel33 = workspace.prefabs.mtkindd:clone()
newmodel33:PivotTo(CFrame.new(-35.53168240268127, 2.7184572160635865, 34.02346053006053) * CFrame.fromEulerAngles(0, math.rad(-77.64699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel33.Parent = workspace.devices.mtkind
newmodel34 = workspace.prefabs.mtkindd:clone()
newmodel34:PivotTo(CFrame.new(-51.97345267674802, 2.6104596808077507, 31.311204909849373) * CFrame.fromEulerAngles(0, math.rad(-114.747), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel34.Parent = workspace.devices.mtkind
newmodel35 = workspace.prefabs.mtkindd:clone()
newmodel35:PivotTo(CFrame.new(-21.368559143145557, 2.9766917106656487, 27.884659627446506) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel35.Parent = workspace.devices.mtkind
newmodel35.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel35.Body1.Decal.Texture = 'rbxassetid://18833046010'
newmodel36 = workspace.prefabs.mtkindd:clone()
newmodel36:PivotTo(CFrame.new(-21.468613971975678, 2.9766917106656487, 27.96525827276871) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel36.Parent = workspace.devices.mtkind
newmodel36.Body1.Color = Color3.fromRGB(29, 156, 29)
newmodel36.Body1.Decal.Texture = 'rbxassetid://18832701293'
newmodel37 = workspace.prefabs.mtkindd:clone()
newmodel37:PivotTo(CFrame.new(-21.570942774188303, 2.9766917106656487, 28.047688705484603) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel37.Parent = workspace.devices.mtkind
newmodel37.Body1.Color = Color3.fromRGB(196, 40, 28)
newmodel37.Body1.Decal.Texture = 'rbxassetid://18885987194'
newmodel38 = workspace.prefabs.mtkindd:clone()
newmodel38:PivotTo(CFrame.new(-21.673271576400932, 2.9766917106656487, 28.130119138200495) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel38.Parent = workspace.devices.mtkind
newmodel38.Body1.Color = Color3.fromRGB(29, 156, 29)
newmodel38.Body1.Decal.Texture = 'rbxassetid://18832848712'
newmodel39 = workspace.prefabs.mtkindd:clone()
newmodel39:PivotTo(CFrame.new(-22.303162203354205, 2.9766917106656487, 28.637524246251658) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel39.Parent = workspace.devices.mtkind
newmodel39.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel40 = workspace.prefabs.mtkindd:clone()
newmodel40:PivotTo(CFrame.new(-22.40503621089033, 2.9766917106656487, 28.71958832148881) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel40.Parent = workspace.devices.mtkind
newmodel40.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel41 = workspace.prefabs.mtkindd:clone()
newmodel41:PivotTo(CFrame.new(-22.506910218426455, 2.9766917106656487, 28.801652396725967) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel41.Parent = workspace.devices.mtkind
newmodel41.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel42 = workspace.prefabs.mtkindd:clone()
newmodel42:PivotTo(CFrame.new(-22.60878422596258, 2.9766917106656487, 28.883716471963123) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel42.Parent = workspace.devices.mtkind
newmodel42.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel43 = workspace.prefabs.mtkindd:clone()
newmodel43:PivotTo(CFrame.new(-22.710658233498705, 2.9766917106656487, 28.96578054720028) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel43.Parent = workspace.devices.mtkind
newmodel43.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel44 = workspace.prefabs.mtkindd:clone()
newmodel44:PivotTo(CFrame.new(-22.81253224103483, 2.9766917106656487, 29.04784462243743) * CFrame.fromEulerAngles(0, math.rad(-51.147), 0) * CFrame.fromEulerAngles(0, 0, math.rad(80))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel44.Parent = workspace.devices.mtkind
newmodel44.Body1.Color = Color3.fromRGB(226, 221, 77)
newmodel45 = workspace.prefabs.mtkindd:clone()
newmodel45:PivotTo(CFrame.new(-39.65723599708069, 2.66806705214629, 33.98966947661956) * CFrame.fromEulerAngles(0, math.rad(-88.24699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel45.Parent = workspace.devices.mtkind
newmodel46 = workspace.prefabs.mtkindd:clone()
newmodel46:PivotTo(CFrame.new(-40.143188994555615, 2.6680670731543015, 34.00454339917105) * CFrame.fromEulerAngles(0, math.rad(-88.24699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel46.Parent = workspace.devices.mtkind
newmodel47 = workspace.prefabs.mtkindd:clone()
newmodel47:PivotTo(CFrame.new(-40.62914050395963, 2.668067065954497, 34.0194178566817) * CFrame.fromEulerAngles(0, math.rad(-88.24699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel47.Parent = workspace.devices.mtkind
newmodel48 = workspace.prefabs.mtkindd:clone()
newmodel48:PivotTo(CFrame.new(-41.11509351084604, 2.668067065216048, 34.03429148856863) * CFrame.fromEulerAngles(0, math.rad(-88.24699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel48.Parent = workspace.devices.mtkind
newmodel49 = workspace.prefabs.mtkindd:clone()
newmodel49:PivotTo(CFrame.new(-41.6010469721362, 2.668067071941812, 34.04916135765721) * CFrame.fromEulerAngles(0, math.rad(-88.24699), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel49.Parent = workspace.devices.mtkind
newmodel50 = workspace.prefabs.mtkindd:clone()
newmodel50:PivotTo(CFrame.new(-43.95279264721716, 2.6751715406449796, 33.94146838689226) * CFrame.fromEulerAngles(0, math.rad(-93.547), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel50.Parent = workspace.devices.mtkind
newmodel51 = workspace.prefabs.mtkindd:clone()
newmodel51:PivotTo(CFrame.new(-44.27629137086322, 2.675171552842769, 33.92142062530381) * CFrame.fromEulerAngles(0, math.rad(-93.547), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel51.Parent = workspace.devices.mtkind
newmodel52 = workspace.prefabs.mtkindd:clone()
newmodel52:PivotTo(CFrame.new(-58.626595146820314, 2.606806301836567, 27.32851635002448) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel52.Parent = workspace.devices.mtkind
newmodel53 = workspace.prefabs.mtkindd:clone()
newmodel53:PivotTo(CFrame.new(-59.07412870793218, 2.606806301836567, 26.94429644257754) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel53.Parent = workspace.devices.mtkind
newmodel54 = workspace.prefabs.mtkindd:clone()
newmodel54:PivotTo(CFrame.new(-59.44633483796581, 2.606806301836567, 26.62474721262167) * CFrame.fromEulerAngles(0, math.rad(-130.647), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel54.Parent = workspace.devices.mtkind
newmodel55 = workspace.prefabs.mtkindd:clone()
newmodel55:PivotTo(CFrame.new(-60.16447833232361, 2.608557299788054, 25.99272261782522) * CFrame.fromEulerAngles(0, math.rad(-135.947), 0) * CFrame.fromEulerAngles(0, 0, math.rad(5))* CFrame.fromEulerAngles(0, math.rad(90), 0))
newmodel55.Parent = workspace.devices.mtkind
newmodel56 = workspace.prefabs.mtkindd:clone()
newmodel56:PivotTo(CFrame.new(-20.533089743241533, 3.5275199999999995, 33.504678771911884) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel56.Parent = workspace.devices.mtkind
newmodel57 = workspace.prefabs.mtkindd:clone()
newmodel57:PivotTo(CFrame.new(-28.447439026142078, 2.4004000000000008, 37.642340516099026) * CFrame.fromEulerAngles(0, math.rad(-67.58999), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel57.Parent = workspace.devices.mtkind
newmodel58 = workspace.prefabs.mtkindd:clone()
newmodel58:PivotTo(CFrame.new(-34.335775314245375, 2.3712000000000004, 39.32495853234165) * CFrame.fromEulerAngles(0, math.rad(-78.09), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel58.Parent = workspace.devices.mtkind
newmodel59 = workspace.prefabs.mtkindd:clone()
newmodel59:PivotTo(CFrame.new(-37.45558771163167, 2.3712000000000004, 39.785270953046066) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel59.Parent = workspace.devices.mtkind
newmodel60 = workspace.prefabs.mtkindd:clone()
newmodel60:PivotTo(CFrame.new(-37.629605440882266, 2.3712000000000004, 39.80559015348478) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel60.Parent = workspace.devices.mtkind
newmodel61 = workspace.prefabs.mtkindd:clone()
newmodel61:PivotTo(CFrame.new(-37.806523465620366, 2.3712000000000004, 39.82624800726413) * CFrame.fromEulerAngles(0, math.rad(-83.34001), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel61.Parent = workspace.devices.mtkind
newmodel62 = workspace.prefabs.mtkindd:clone()
newmodel62:PivotTo(CFrame.new(-40.715000410548974, 2.3712000000000004, 39.96599249505634) * CFrame.fromEulerAngles(0, math.rad(-88.58998000000003), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel62.Parent = workspace.devices.mtkind
newmodel63 = workspace.prefabs.mtkindd:clone()
newmodel63:PivotTo(CFrame.new(-43.86063322067201, 2.3712000000000004, 39.85045411495262) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel63.Parent = workspace.devices.mtkind
newmodel64 = workspace.prefabs.mtkindd:clone()
newmodel64:PivotTo(CFrame.new(-44.039810057989826, 2.3712000000000004, 39.83842758724169) * CFrame.fromEulerAngles(0, math.rad(-93.83999), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel64.Parent = workspace.devices.mtkind
newmodel65 = workspace.prefabs.mtkindd:clone()
newmodel65:PivotTo(CFrame.new(-53.40502386520297, 2.5464, 37.705018359304546) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel65.Parent = workspace.devices.mtkind
newmodel66 = workspace.prefabs.mtkindd:clone()
newmodel66:PivotTo(CFrame.new(-53.570075550040414, 2.5464, 37.64627282864038) * CFrame.fromEulerAngles(0, math.rad(-109.59), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel66.Parent = workspace.devices.mtkind
newmodel67 = workspace.prefabs.mtkindd:clone()
newmodel67:PivotTo(CFrame.new(-56.35965622942914, 2.3420000000000005, 36.43000916477048) * CFrame.fromEulerAngles(0, math.rad(-114.84), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel67.Parent = workspace.devices.mtkind
newmodel68 = workspace.prefabs.mtkindd:clone()
newmodel68:PivotTo(CFrame.new(-59.015606006678595, 2.3712000000000004, 34.98739180057691) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel68.Parent = workspace.devices.mtkind
newmodel69 = workspace.prefabs.mtkindd:clone()
newmodel69:PivotTo(CFrame.new(-59.16845911738233, 2.3712000000000004, 34.898821590301715) * CFrame.fromEulerAngles(0, math.rad(-120.09), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel69.Parent = workspace.devices.mtkind
newmodel70 = workspace.prefabs.mtkindd:clone()
newmodel70:PivotTo(CFrame.new(-61.835415115147995, 2.5464, 33.111063455197396) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel70.Parent = workspace.devices.mtkind
newmodel71 = workspace.prefabs.mtkindd:clone()
newmodel71:PivotTo(CFrame.new(-61.978325037924634, 2.5464, 33.00972520607575) * CFrame.fromEulerAngles(0, math.rad(-125.33999), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel71.Parent = workspace.devices.mtkind
newmodel72 = workspace.prefabs.mtkindd:clone()
newmodel72:PivotTo(CFrame.new(-64.33302068873952, 2.3420000000000005, 31.08191865052907) * CFrame.fromEulerAngles(0, math.rad(-130.58999), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel72.Parent = workspace.devices.mtkind
newmodel73 = workspace.prefabs.mtkindd:clone()
newmodel73:PivotTo(CFrame.new(-68.15938312550541, 7.072400000000001, 27.073809685005298) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel73.Parent = workspace.devices.mtkind
newmodel74 = workspace.prefabs.mtkindd:clone()
newmodel74:PivotTo(CFrame.new(-68.3097751206472, 7.072400000000001, 26.88749339103917) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel74.Parent = workspace.devices.mtkind
newmodel75 = workspace.prefabs.mtkindd:clone()
newmodel75:PivotTo(CFrame.new(-68.15479800370231, 5.8314, 27.079490059821328) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel75.Parent = workspace.devices.mtkind
newmodel76 = workspace.prefabs.mtkindd:clone()
newmodel76:PivotTo(CFrame.new(-68.23457912307632, 5.8314, 26.980651538022226) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel76.Parent = workspace.devices.mtkind
newmodel77 = workspace.prefabs.mtkindd:clone()
newmodel77:PivotTo(CFrame.new(-68.3143602424503, 5.8314, 26.88181301622313) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel77.Parent = workspace.devices.mtkind
newmodel78 = workspace.prefabs.mtkindd:clone()
newmodel78:PivotTo(CFrame.new(-68.61789530581576, 2.5026, 26.505772203401254) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel78.Parent = workspace.devices.mtkind
newmodel79 = workspace.prefabs.mtkindd:clone()
newmodel79:PivotTo(CFrame.new(-68.72427013164776, 2.5026, 26.373987507669113) * CFrame.fromEulerAngles(0, math.rad(-141.09), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel79.Parent = workspace.devices.mtkind
newmodel80 = workspace.prefabs.mtkindd:clone()
newmodel80:PivotTo(CFrame.new(-70.66215195375685, 2.25069744, 23.609912932477865) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel80.Parent = workspace.devices.mtkind
newmodel81 = workspace.prefabs.mtkindd:clone()
newmodel81:PivotTo(CFrame.new(-70.55938041952949, 2.25069744, 23.764245651473395) * CFrame.fromEulerAngles(0, math.rad(-146.34), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel81.Parent = workspace.devices.mtkind
newmodel82 = workspace.prefabs.mtkindd:clone()
newmodel82:PivotTo(CFrame.new(-72.2842397359839, 2.5172, 20.749329198364926) * CFrame.fromEulerAngles(0, math.rad(-151.59), 0)* CFrame.fromEulerAngles(0, 0, math.rad(90)))
newmodel82.Parent = workspace.devices.mtkind
