newmodel0 = workspace.prefabs.re_2l:clone()
newmodel0:PivotTo(CFrame.new(-16.512481445407705, 9.369418, 30.354312357844293) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel0.Parent = workspace.devices.sel_re2l
newmodel0.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_0-8"
newmodel1 = workspace.prefabs.re_2l:clone()
newmodel1:PivotTo(CFrame.new(-16.938343433218595, 9.369418, 30.720740790422546) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel1.Parent = workspace.devices.sel_re2l
newmodel1.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_0-10"
newmodel2 = workspace.prefabs.re_2l:clone()
newmodel2:PivotTo(CFrame.new(-17.36420542102949, 9.369418, 31.087169223000807) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel2.Parent = workspace.devices.sel_re2l
newmodel2.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_0-12"
newmodel3 = workspace.prefabs.re_2l:clone()
newmodel3:PivotTo(CFrame.new(-17.790067408840375, 9.369418, 31.45359765557906) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel3.Parent = workspace.devices.sel_re2l
newmodel3.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_0-14"
newmodel4 = workspace.prefabs.re_2l:clone()
newmodel4:PivotTo(CFrame.new(-15.59289667512563, 8.956822, 29.490206643235926) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel4.Parent = workspace.devices.sel_re2l
newmodel4.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_2-4"
newmodel5 = workspace.prefabs.re_2l:clone()
newmodel5:PivotTo(CFrame.new(-16.086619457596818, 8.956822, 29.98788392526604) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel5.Parent = workspace.devices.sel_re2l
newmodel5.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_2-6"
newmodel6 = workspace.prefabs.re_2l:clone()
newmodel6:PivotTo(CFrame.new(-16.512481445407705, 8.956822, 30.354312357844293) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel6.Parent = workspace.devices.sel_re2l
newmodel6.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_2-8"
newmodel7 = workspace.prefabs.re_2l:clone()
newmodel7:PivotTo(CFrame.new(-16.938343433218595, 8.956822, 30.720740790422546) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel7.Parent = workspace.devices.sel_re2l
newmodel7.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_2-10"
newmodel8 = workspace.prefabs.re_2l:clone()
newmodel8:PivotTo(CFrame.new(-17.36420542102949, 8.956822, 31.087169223000807) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel8.Parent = workspace.devices.sel_re2l
newmodel8.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_2-12"
newmodel9 = workspace.prefabs.re_2l:clone()
newmodel9:PivotTo(CFrame.new(-17.790067408840375, 8.956822, 31.45359765557906) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel9.Parent = workspace.devices.sel_re2l
newmodel9.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_2-14"
newmodel10 = workspace.prefabs.re_2l:clone()
newmodel10:PivotTo(CFrame.new(-18.21592939665127, 8.956822, 31.820026088157313) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel10.Parent = workspace.devices.sel_re2l
newmodel10.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_2-16"
newmodel11 = workspace.prefabs.re_2l:clone()
newmodel11:PivotTo(CFrame.new(-18.75571103236934, 8.956822, 32.23875809683216) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel11.Parent = workspace.devices.sel_re2l
newmodel11.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_2-18"
newmodel12 = workspace.prefabs.re_2l:clone()
newmodel12:PivotTo(CFrame.new(-15.202350003902009, 8.544226, 29.086348343259125) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel12.Parent = workspace.devices.sel_re2l
newmodel12.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_4-2"
newmodel13 = workspace.prefabs.re_2l:clone()
newmodel13:PivotTo(CFrame.new(-15.59289667512563, 8.544226, 29.490206643235926) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel13.Parent = workspace.devices.sel_re2l
newmodel13.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_4-4"
newmodel14 = workspace.prefabs.re_2l:clone()
newmodel14:PivotTo(CFrame.new(-16.086619457596818, 8.544226, 29.98788392526604) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel14.Parent = workspace.devices.sel_re2l
newmodel14.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_4-6"
newmodel15 = workspace.prefabs.re_2l:clone()
newmodel15:PivotTo(CFrame.new(-16.512481445407705, 8.544226, 30.354312357844293) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel15.Parent = workspace.devices.sel_re2l
newmodel15.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_4-8"
newmodel16 = workspace.prefabs.re_2l:clone()
newmodel16:PivotTo(CFrame.new(-16.938343433218595, 8.544226, 30.720740790422546) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel16.Parent = workspace.devices.sel_re2l
newmodel16.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_4-10"
newmodel17 = workspace.prefabs.re_2l:clone()
newmodel17:PivotTo(CFrame.new(-17.36420542102949, 8.544226, 31.087169223000807) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel17.Parent = workspace.devices.sel_re2l
newmodel17.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_4-12"
newmodel18 = workspace.prefabs.re_2l:clone()
newmodel18:PivotTo(CFrame.new(-17.790067408840375, 8.544226, 31.45359765557906) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel18.Parent = workspace.devices.sel_re2l
newmodel18.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_4-14"
newmodel19 = workspace.prefabs.re_2l:clone()
newmodel19:PivotTo(CFrame.new(-18.21592939665127, 8.544226, 31.820026088157313) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel19.Parent = workspace.devices.sel_re2l
newmodel19.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_4-16"
newmodel20 = workspace.prefabs.re_2l:clone()
newmodel20:PivotTo(CFrame.new(-18.75571103236934, 8.544226, 32.23875809683216) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel20.Parent = workspace.devices.sel_re2l
newmodel20.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_4-18"
newmodel21 = workspace.prefabs.re_2l:clone()
newmodel21:PivotTo(CFrame.new(-19.213315293003372, 8.544226, 32.564682274385135) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel21.Parent = workspace.devices.sel_re2l
newmodel21.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_4-20"
newmodel22 = workspace.prefabs.re_2l:clone()
newmodel22:PivotTo(CFrame.new(-15.202350003902009, 8.13163, 29.086348343259125) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel22.Parent = workspace.devices.sel_re2l
newmodel22.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_6-2"
newmodel23 = workspace.prefabs.re_2l:clone()
newmodel23:PivotTo(CFrame.new(-15.59289667512563, 8.13163, 29.490206643235926) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel23.Parent = workspace.devices.sel_re2l
newmodel23.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_6-4"
newmodel24 = workspace.prefabs.re_2l:clone()
newmodel24:PivotTo(CFrame.new(-16.086619457596818, 8.13163, 29.98788392526604) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel24.Parent = workspace.devices.sel_re2l
newmodel24.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_6-6"
newmodel25 = workspace.prefabs.re_2l:clone()
newmodel25:PivotTo(CFrame.new(-16.512481445407705, 8.13163, 30.354312357844293) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel25.Parent = workspace.devices.sel_re2l
newmodel25.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_6-8"
newmodel26 = workspace.prefabs.re_2l:clone()
newmodel26:PivotTo(CFrame.new(-16.938343433218595, 8.13163, 30.720740790422546) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel26.Parent = workspace.devices.sel_re2l
newmodel26.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_6-10"
newmodel27 = workspace.prefabs.re_2l:clone()
newmodel27:PivotTo(CFrame.new(-17.36420542102949, 8.13163, 31.087169223000807) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel27.Parent = workspace.devices.sel_re2l
newmodel27.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_6-12"
newmodel28 = workspace.prefabs.re_2l:clone()
newmodel28:PivotTo(CFrame.new(-17.790067408840375, 8.13163, 31.45359765557906) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel28.Parent = workspace.devices.sel_re2l
newmodel28.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_6-14"
newmodel29 = workspace.prefabs.re_2l:clone()
newmodel29:PivotTo(CFrame.new(-18.21592939665127, 8.13163, 31.820026088157313) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel29.Parent = workspace.devices.sel_re2l
newmodel29.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_6-16"
newmodel30 = workspace.prefabs.re_2l:clone()
newmodel30:PivotTo(CFrame.new(-18.75571103236934, 8.13163, 32.23875809683216) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel30.Parent = workspace.devices.sel_re2l
newmodel30.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_6-18"
newmodel31 = workspace.prefabs.re_2l:clone()
newmodel31:PivotTo(CFrame.new(-19.213315293003372, 8.13163, 32.564682274385135) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel31.Parent = workspace.devices.sel_re2l
newmodel31.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_6-20"
newmodel32 = workspace.prefabs.re_2l:clone()
newmodel32:PivotTo(CFrame.new(-19.670919553637397, 8.13163, 32.89060645193811) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel32.Parent = workspace.devices.sel_re2l
newmodel32.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_6-22"
newmodel33 = workspace.prefabs.re_2l:clone()
newmodel33:PivotTo(CFrame.new(-14.811803332678387, 7.719034, 28.68249004328233) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel33.Parent = workspace.devices.sel_re2l
newmodel33.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_8-0"
newmodel34 = workspace.prefabs.re_2l:clone()
newmodel34:PivotTo(CFrame.new(-15.202350003902009, 7.719034, 29.086348343259125) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel34.Parent = workspace.devices.sel_re2l
newmodel34.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_8-2"
newmodel35 = workspace.prefabs.re_2l:clone()
newmodel35:PivotTo(CFrame.new(-15.59289667512563, 7.719034, 29.490206643235926) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel35.Parent = workspace.devices.sel_re2l
newmodel35.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_8-4"
newmodel36 = workspace.prefabs.re_2l:clone()
newmodel36:PivotTo(CFrame.new(-16.086619457596818, 7.719034, 29.98788392526604) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel36.Parent = workspace.devices.sel_re2l
newmodel36.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_8-6"
newmodel37 = workspace.prefabs.re_2l:clone()
newmodel37:PivotTo(CFrame.new(-16.512481445407705, 7.719034, 30.354312357844293) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel37.Parent = workspace.devices.sel_re2l
newmodel37.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_8-8"
newmodel38 = workspace.prefabs.re_2l:clone()
newmodel38:PivotTo(CFrame.new(-16.938343433218595, 7.719034, 30.720740790422546) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel38.Parent = workspace.devices.sel_re2l
newmodel38.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_8-10"
newmodel39 = workspace.prefabs.re_2l:clone()
newmodel39:PivotTo(CFrame.new(-17.36420542102949, 7.719034, 31.087169223000807) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel39.Parent = workspace.devices.sel_re2l
newmodel39.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_8-12"
newmodel40 = workspace.prefabs.re_2l:clone()
newmodel40:PivotTo(CFrame.new(-17.790067408840375, 7.719034, 31.45359765557906) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel40.Parent = workspace.devices.sel_re2l
newmodel40.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_8-14"
newmodel41 = workspace.prefabs.re_2l:clone()
newmodel41:PivotTo(CFrame.new(-18.21592939665127, 7.719034, 31.820026088157313) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel41.Parent = workspace.devices.sel_re2l
newmodel41.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_8-16"
newmodel42 = workspace.prefabs.re_2l:clone()
newmodel42:PivotTo(CFrame.new(-18.75571103236934, 7.719034, 32.23875809683216) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel42.Parent = workspace.devices.sel_re2l
newmodel42.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_8-18"
newmodel43 = workspace.prefabs.re_2l:clone()
newmodel43:PivotTo(CFrame.new(-19.213315293003372, 7.719034, 32.564682274385135) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel43.Parent = workspace.devices.sel_re2l
newmodel43.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_8-20"
newmodel44 = workspace.prefabs.re_2l:clone()
newmodel44:PivotTo(CFrame.new(-19.670919553637397, 7.719034, 32.89060645193811) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel44.Parent = workspace.devices.sel_re2l
newmodel44.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_8-22"
newmodel45 = workspace.prefabs.re_2l:clone()
newmodel45:PivotTo(CFrame.new(-14.811803332678387, 7.306437999999999, 28.68249004328233) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel45.Parent = workspace.devices.sel_re2l
newmodel45.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_10-0"
newmodel46 = workspace.prefabs.re_2l:clone()
newmodel46:PivotTo(CFrame.new(-15.202350003902009, 7.306437999999999, 29.086348343259125) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel46.Parent = workspace.devices.sel_re2l
newmodel46.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_10-2"
newmodel47 = workspace.prefabs.re_2l:clone()
newmodel47:PivotTo(CFrame.new(-15.59289667512563, 7.306437999999999, 29.490206643235926) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel47.Parent = workspace.devices.sel_re2l
newmodel47.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_10-4"
newmodel48 = workspace.prefabs.re_2l:clone()
newmodel48:PivotTo(CFrame.new(-16.086619457596818, 7.306437999999999, 29.98788392526604) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel48.Parent = workspace.devices.sel_re2l
newmodel48.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_10-6"
newmodel49 = workspace.prefabs.re_2l:clone()
newmodel49:PivotTo(CFrame.new(-16.512481445407705, 7.306437999999999, 30.354312357844293) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel49.Parent = workspace.devices.sel_re2l
newmodel49.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_10-8"
newmodel50 = workspace.prefabs.re_2l:clone()
newmodel50:PivotTo(CFrame.new(-16.938343433218595, 7.306437999999999, 30.720740790422546) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel50.Parent = workspace.devices.sel_re2l
newmodel50.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_10-10"
newmodel51 = workspace.prefabs.re_2l:clone()
newmodel51:PivotTo(CFrame.new(-17.36420542102949, 7.306437999999999, 31.087169223000807) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel51.Parent = workspace.devices.sel_re2l
newmodel51.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_10-12"
newmodel52 = workspace.prefabs.re_2l:clone()
newmodel52:PivotTo(CFrame.new(-17.790067408840375, 7.306437999999999, 31.45359765557906) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel52.Parent = workspace.devices.sel_re2l
newmodel52.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_10-14"
newmodel53 = workspace.prefabs.re_2l:clone()
newmodel53:PivotTo(CFrame.new(-18.21592939665127, 7.306437999999999, 31.820026088157313) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel53.Parent = workspace.devices.sel_re2l
newmodel53.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_10-16"
newmodel54 = workspace.prefabs.re_2l:clone()
newmodel54:PivotTo(CFrame.new(-18.75571103236934, 7.306437999999999, 32.23875809683216) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel54.Parent = workspace.devices.sel_re2l
newmodel54.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_10-18"
newmodel55 = workspace.prefabs.re_2l:clone()
newmodel55:PivotTo(CFrame.new(-19.213315293003372, 7.306437999999999, 32.564682274385135) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel55.Parent = workspace.devices.sel_re2l
newmodel55.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_10-20"
newmodel56 = workspace.prefabs.re_2l:clone()
newmodel56:PivotTo(CFrame.new(-19.670919553637397, 7.306437999999999, 32.89060645193811) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel56.Parent = workspace.devices.sel_re2l
newmodel56.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_10-22"
newmodel57 = workspace.prefabs.re_2l:clone()
newmodel57:PivotTo(CFrame.new(-14.811803332678387, 6.893841999999999, 28.68249004328233) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel57.Parent = workspace.devices.sel_re2l
newmodel57.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_12-0"
newmodel58 = workspace.prefabs.re_2l:clone()
newmodel58:PivotTo(CFrame.new(-15.202350003902009, 6.893841999999999, 29.086348343259125) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel58.Parent = workspace.devices.sel_re2l
newmodel58.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_12-2"
newmodel59 = workspace.prefabs.re_2l:clone()
newmodel59:PivotTo(CFrame.new(-15.59289667512563, 6.893841999999999, 29.490206643235926) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel59.Parent = workspace.devices.sel_re2l
newmodel59.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_12-4"
newmodel60 = workspace.prefabs.re_2l:clone()
newmodel60:PivotTo(CFrame.new(-16.086619457596818, 6.893841999999999, 29.98788392526604) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel60.Parent = workspace.devices.sel_re2l
newmodel60.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_12-6"
newmodel61 = workspace.prefabs.re_2l:clone()
newmodel61:PivotTo(CFrame.new(-16.512481445407705, 6.893841999999999, 30.354312357844293) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel61.Parent = workspace.devices.sel_re2l
newmodel61.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_12-8"
newmodel62 = workspace.prefabs.re_2l:clone()
newmodel62:PivotTo(CFrame.new(-16.938343433218595, 6.893841999999999, 30.720740790422546) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel62.Parent = workspace.devices.sel_re2l
newmodel62.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_12-10"
newmodel63 = workspace.prefabs.re_2l:clone()
newmodel63:PivotTo(CFrame.new(-17.36420542102949, 6.893841999999999, 31.087169223000807) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel63.Parent = workspace.devices.sel_re2l
newmodel63.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_12-12"
newmodel64 = workspace.prefabs.re_2l:clone()
newmodel64:PivotTo(CFrame.new(-17.790067408840375, 6.893841999999999, 31.45359765557906) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel64.Parent = workspace.devices.sel_re2l
newmodel64.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_12-14"
newmodel65 = workspace.prefabs.re_2l:clone()
newmodel65:PivotTo(CFrame.new(-18.21592939665127, 6.893841999999999, 31.820026088157313) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel65.Parent = workspace.devices.sel_re2l
newmodel65.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_12-16"
newmodel66 = workspace.prefabs.re_2l:clone()
newmodel66:PivotTo(CFrame.new(-18.75571103236934, 6.893841999999999, 32.23875809683216) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel66.Parent = workspace.devices.sel_re2l
newmodel66.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_12-18"
newmodel67 = workspace.prefabs.re_2l:clone()
newmodel67:PivotTo(CFrame.new(-19.213315293003372, 6.893841999999999, 32.564682274385135) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel67.Parent = workspace.devices.sel_re2l
newmodel67.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_12-20"
newmodel68 = workspace.prefabs.re_2l:clone()
newmodel68:PivotTo(CFrame.new(-19.670919553637397, 6.893841999999999, 32.89060645193811) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel68.Parent = workspace.devices.sel_re2l
newmodel68.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_12-22"
newmodel69 = workspace.prefabs.re_2l:clone()
newmodel69:PivotTo(CFrame.new(-19.899721683954414, 6.893841999999999, 33.0535685407146) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel69.Parent = workspace.devices.sel_re2l
newmodel69.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_12-23"
newmodel70 = workspace.prefabs.re_2l:clone()
newmodel70:PivotTo(CFrame.new(-14.811803332678387, 6.4812460000000005, 28.68249004328233) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel70.Parent = workspace.devices.sel_re2l
newmodel70.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_14-0"
newmodel71 = workspace.prefabs.re_2l:clone()
newmodel71:PivotTo(CFrame.new(-15.202350003902009, 6.4812460000000005, 29.086348343259125) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel71.Parent = workspace.devices.sel_re2l
newmodel71.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_14-2"
newmodel72 = workspace.prefabs.re_2l:clone()
newmodel72:PivotTo(CFrame.new(-15.59289667512563, 6.4812460000000005, 29.490206643235926) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel72.Parent = workspace.devices.sel_re2l
newmodel72.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_14-4"
newmodel73 = workspace.prefabs.re_2l:clone()
newmodel73:PivotTo(CFrame.new(-16.086619457596818, 6.4812460000000005, 29.98788392526604) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel73.Parent = workspace.devices.sel_re2l
newmodel73.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_14-6"
newmodel74 = workspace.prefabs.re_2l:clone()
newmodel74:PivotTo(CFrame.new(-16.512481445407705, 6.4812460000000005, 30.354312357844293) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel74.Parent = workspace.devices.sel_re2l
newmodel74.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_14-8"
newmodel75 = workspace.prefabs.re_2l:clone()
newmodel75:PivotTo(CFrame.new(-16.938343433218595, 6.4812460000000005, 30.720740790422546) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel75.Parent = workspace.devices.sel_re2l
newmodel75.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_14-10"
newmodel76 = workspace.prefabs.re_2l:clone()
newmodel76:PivotTo(CFrame.new(-17.36420542102949, 6.4812460000000005, 31.087169223000807) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel76.Parent = workspace.devices.sel_re2l
newmodel76.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_14-12"
newmodel77 = workspace.prefabs.re_2l:clone()
newmodel77:PivotTo(CFrame.new(-17.790067408840375, 6.4812460000000005, 31.45359765557906) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel77.Parent = workspace.devices.sel_re2l
newmodel77.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_14-14"
newmodel78 = workspace.prefabs.re_2l:clone()
newmodel78:PivotTo(CFrame.new(-18.21592939665127, 6.4812460000000005, 31.820026088157313) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel78.Parent = workspace.devices.sel_re2l
newmodel78.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_14-16"
newmodel79 = workspace.prefabs.re_2l:clone()
newmodel79:PivotTo(CFrame.new(-18.75571103236934, 6.4812460000000005, 32.23875809683216) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel79.Parent = workspace.devices.sel_re2l
newmodel79.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_14-18"
newmodel80 = workspace.prefabs.re_2l:clone()
newmodel80:PivotTo(CFrame.new(-19.213315293003372, 6.4812460000000005, 32.564682274385135) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel80.Parent = workspace.devices.sel_re2l
newmodel80.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_14-20"
newmodel81 = workspace.prefabs.re_2l:clone()
newmodel81:PivotTo(CFrame.new(-19.670919553637397, 6.4812460000000005, 32.89060645193811) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel81.Parent = workspace.devices.sel_re2l
newmodel81.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_14-22"
newmodel82 = workspace.prefabs.re_2l:clone()
newmodel82:PivotTo(CFrame.new(-14.811803332678387, 6.06865, 28.68249004328233) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel82.Parent = workspace.devices.sel_re2l
newmodel82.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_16-0"
newmodel83 = workspace.prefabs.re_2l:clone()
newmodel83:PivotTo(CFrame.new(-15.202350003902009, 6.06865, 29.086348343259125) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel83.Parent = workspace.devices.sel_re2l
newmodel83.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_16-2"
newmodel84 = workspace.prefabs.re_2l:clone()
newmodel84:PivotTo(CFrame.new(-15.59289667512563, 6.06865, 29.490206643235926) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel84.Parent = workspace.devices.sel_re2l
newmodel84.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_16-4"
newmodel85 = workspace.prefabs.re_2l:clone()
newmodel85:PivotTo(CFrame.new(-16.086619457596818, 6.06865, 29.98788392526604) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel85.Parent = workspace.devices.sel_re2l
newmodel85.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_16-6"
newmodel86 = workspace.prefabs.re_2l:clone()
newmodel86:PivotTo(CFrame.new(-16.512481445407705, 6.06865, 30.354312357844293) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel86.Parent = workspace.devices.sel_re2l
newmodel86.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_16-8"
newmodel87 = workspace.prefabs.re_2l:clone()
newmodel87:PivotTo(CFrame.new(-16.938343433218595, 6.06865, 30.720740790422546) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel87.Parent = workspace.devices.sel_re2l
newmodel87.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_16-10"
newmodel88 = workspace.prefabs.re_2l:clone()
newmodel88:PivotTo(CFrame.new(-17.36420542102949, 6.06865, 31.087169223000807) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel88.Parent = workspace.devices.sel_re2l
newmodel88.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_16-12"
newmodel89 = workspace.prefabs.re_2l:clone()
newmodel89:PivotTo(CFrame.new(-17.790067408840375, 6.06865, 31.45359765557906) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel89.Parent = workspace.devices.sel_re2l
newmodel89.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_16-14"
newmodel90 = workspace.prefabs.re_2l:clone()
newmodel90:PivotTo(CFrame.new(-18.21592939665127, 6.06865, 31.820026088157313) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel90.Parent = workspace.devices.sel_re2l
newmodel90.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_16-16"
newmodel91 = workspace.prefabs.re_2l:clone()
newmodel91:PivotTo(CFrame.new(-18.75571103236934, 6.06865, 32.23875809683216) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel91.Parent = workspace.devices.sel_re2l
newmodel91.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_16-18"
newmodel92 = workspace.prefabs.re_2l:clone()
newmodel92:PivotTo(CFrame.new(-19.213315293003372, 6.06865, 32.564682274385135) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel92.Parent = workspace.devices.sel_re2l
newmodel92.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_16-20"
newmodel93 = workspace.prefabs.re_2l:clone()
newmodel93:PivotTo(CFrame.new(-19.670919553637397, 6.06865, 32.89060645193811) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel93.Parent = workspace.devices.sel_re2l
newmodel93.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_16-22"
newmodel94 = workspace.prefabs.re_2l:clone()
newmodel94:PivotTo(CFrame.new(-14.811803332678387, 5.656053999999999, 28.68249004328233) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel94.Parent = workspace.devices.sel_re2l
newmodel94.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_18-0"
newmodel95 = workspace.prefabs.re_2l:clone()
newmodel95:PivotTo(CFrame.new(-15.202350003902009, 5.656053999999999, 29.086348343259125) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel95.Parent = workspace.devices.sel_re2l
newmodel95.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_18-2"
newmodel96 = workspace.prefabs.re_2l:clone()
newmodel96:PivotTo(CFrame.new(-15.59289667512563, 5.656053999999999, 29.490206643235926) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel96.Parent = workspace.devices.sel_re2l
newmodel96.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_18-4"
newmodel97 = workspace.prefabs.re_2l:clone()
newmodel97:PivotTo(CFrame.new(-16.086619457596818, 5.656053999999999, 29.98788392526604) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel97.Parent = workspace.devices.sel_re2l
newmodel97.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_18-6"
newmodel98 = workspace.prefabs.re_2l:clone()
newmodel98:PivotTo(CFrame.new(-16.512481445407705, 5.656053999999999, 30.354312357844293) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel98.Parent = workspace.devices.sel_re2l
newmodel98.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_18-8"
newmodel99 = workspace.prefabs.re_2l:clone()
newmodel99:PivotTo(CFrame.new(-16.938343433218595, 5.656053999999999, 30.720740790422546) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel99.Parent = workspace.devices.sel_re2l
newmodel99.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_18-10"
newmodel100 = workspace.prefabs.re_2l:clone()
newmodel100:PivotTo(CFrame.new(-17.36420542102949, 5.656053999999999, 31.087169223000807) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel100.Parent = workspace.devices.sel_re2l
newmodel100.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_18-12"
newmodel101 = workspace.prefabs.re_2l:clone()
newmodel101:PivotTo(CFrame.new(-17.790067408840375, 5.656053999999999, 31.45359765557906) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel101.Parent = workspace.devices.sel_re2l
newmodel101.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_18-14"
newmodel102 = workspace.prefabs.re_2l:clone()
newmodel102:PivotTo(CFrame.new(-18.21592939665127, 5.656053999999999, 31.820026088157313) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel102.Parent = workspace.devices.sel_re2l
newmodel102.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_18-16"
newmodel103 = workspace.prefabs.re_2l:clone()
newmodel103:PivotTo(CFrame.new(-18.75571103236934, 5.656053999999999, 32.23875809683216) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel103.Parent = workspace.devices.sel_re2l
newmodel103.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_18-18"
newmodel104 = workspace.prefabs.re_2l:clone()
newmodel104:PivotTo(CFrame.new(-19.213315293003372, 5.656053999999999, 32.564682274385135) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel104.Parent = workspace.devices.sel_re2l
newmodel104.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_18-20"
newmodel105 = workspace.prefabs.re_2l:clone()
newmodel105:PivotTo(CFrame.new(-19.670919553637397, 5.656053999999999, 32.89060645193811) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel105.Parent = workspace.devices.sel_re2l
newmodel105.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_18-22"
newmodel106 = workspace.prefabs.re_2l:clone()
newmodel106:PivotTo(CFrame.new(-15.202350003902009, 5.2434579999999995, 29.086348343259125) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel106.Parent = workspace.devices.sel_re2l
newmodel106.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_20-2"
newmodel107 = workspace.prefabs.re_2l:clone()
newmodel107:PivotTo(CFrame.new(-15.59289667512563, 5.2434579999999995, 29.490206643235926) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel107.Parent = workspace.devices.sel_re2l
newmodel107.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_20-4"
newmodel108 = workspace.prefabs.re_2l:clone()
newmodel108:PivotTo(CFrame.new(-16.086619457596818, 5.2434579999999995, 29.98788392526604) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel108.Parent = workspace.devices.sel_re2l
newmodel108.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_20-6"
newmodel109 = workspace.prefabs.re_2l:clone()
newmodel109:PivotTo(CFrame.new(-16.512481445407705, 5.2434579999999995, 30.354312357844293) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel109.Parent = workspace.devices.sel_re2l
newmodel109.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_20-8"
newmodel110 = workspace.prefabs.re_2l:clone()
newmodel110:PivotTo(CFrame.new(-16.938343433218595, 5.2434579999999995, 30.720740790422546) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel110.Parent = workspace.devices.sel_re2l
newmodel110.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_20-10"
newmodel111 = workspace.prefabs.re_2l:clone()
newmodel111:PivotTo(CFrame.new(-17.36420542102949, 5.2434579999999995, 31.087169223000807) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel111.Parent = workspace.devices.sel_re2l
newmodel111.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_20-12"
newmodel112 = workspace.prefabs.re_2l:clone()
newmodel112:PivotTo(CFrame.new(-17.790067408840375, 5.2434579999999995, 31.45359765557906) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel112.Parent = workspace.devices.sel_re2l
newmodel112.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_20-14"
newmodel113 = workspace.prefabs.re_2l:clone()
newmodel113:PivotTo(CFrame.new(-18.21592939665127, 5.2434579999999995, 31.820026088157313) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel113.Parent = workspace.devices.sel_re2l
newmodel113.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_20-16"
newmodel114 = workspace.prefabs.re_2l:clone()
newmodel114:PivotTo(CFrame.new(-18.75571103236934, 5.2434579999999995, 32.23875809683216) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel114.Parent = workspace.devices.sel_re2l
newmodel114.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_20-18"
newmodel115 = workspace.prefabs.re_2l:clone()
newmodel115:PivotTo(CFrame.new(-19.213315293003372, 5.2434579999999995, 32.564682274385135) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel115.Parent = workspace.devices.sel_re2l
newmodel115.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_20-20"
newmodel116 = workspace.prefabs.re_2l:clone()
newmodel116:PivotTo(CFrame.new(-15.59289667512563, 4.830862, 29.490206643235926) * CFrame.fromEulerAngles(0, math.rad(-44.04), 0))
newmodel116.Parent = workspace.devices.sel_re2l
newmodel116.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_22-4"
newmodel117 = workspace.prefabs.re_2l:clone()
newmodel117:PivotTo(CFrame.new(-16.086619457596818, 4.830862, 29.98788392526604) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel117.Parent = workspace.devices.sel_re2l
newmodel117.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_22-6"
newmodel118 = workspace.prefabs.re_2l:clone()
newmodel118:PivotTo(CFrame.new(-16.512481445407705, 4.830862, 30.354312357844293) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel118.Parent = workspace.devices.sel_re2l
newmodel118.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_22-8"
newmodel119 = workspace.prefabs.re_2l:clone()
newmodel119:PivotTo(CFrame.new(-16.938343433218595, 4.830862, 30.720740790422546) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel119.Parent = workspace.devices.sel_re2l
newmodel119.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_22-10"
newmodel120 = workspace.prefabs.re_2l:clone()
newmodel120:PivotTo(CFrame.new(-17.36420542102949, 4.830862, 31.087169223000807) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel120.Parent = workspace.devices.sel_re2l
newmodel120.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_22-12"
newmodel121 = workspace.prefabs.re_2l:clone()
newmodel121:PivotTo(CFrame.new(-17.790067408840375, 4.830862, 31.45359765557906) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel121.Parent = workspace.devices.sel_re2l
newmodel121.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_22-14"
newmodel122 = workspace.prefabs.re_2l:clone()
newmodel122:PivotTo(CFrame.new(-18.21592939665127, 4.830862, 31.820026088157313) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel122.Parent = workspace.devices.sel_re2l
newmodel122.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_22-16"
newmodel123 = workspace.prefabs.re_2l:clone()
newmodel123:PivotTo(CFrame.new(-18.75571103236934, 4.830862, 32.23875809683216) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel123.Parent = workspace.devices.sel_re2l
newmodel123.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_22-18"
newmodel124 = workspace.prefabs.re_2l:clone()
newmodel124:PivotTo(CFrame.new(-16.086619457596818, 4.6245639999999995, 29.98788392526604) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel124.Parent = workspace.devices.sel_re2l
newmodel124.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_23-6"
newmodel125 = workspace.prefabs.re_2l:clone()
newmodel125:PivotTo(CFrame.new(-18.75571103236934, 4.6245639999999995, 32.23875809683216) * CFrame.fromEulerAngles(0, math.rad(-54.54), 0))
newmodel125.Parent = workspace.devices.sel_re2l
newmodel125.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_23-18"
newmodel126 = workspace.prefabs.re_2l:clone()
newmodel126:PivotTo(CFrame.new(-16.512481445407705, 4.418265999999999, 30.354312357844293) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel126.Parent = workspace.devices.sel_re2l
newmodel126.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_24-8"
newmodel127 = workspace.prefabs.re_2l:clone()
newmodel127:PivotTo(CFrame.new(-16.938343433218595, 4.418265999999999, 30.720740790422546) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel127.Parent = workspace.devices.sel_re2l
newmodel127.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_24-10"
newmodel128 = workspace.prefabs.re_2l:clone()
newmodel128:PivotTo(CFrame.new(-17.36420542102949, 4.418265999999999, 31.087169223000807) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel128.Parent = workspace.devices.sel_re2l
newmodel128.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_24-12"
newmodel129 = workspace.prefabs.re_2l:clone()
newmodel129:PivotTo(CFrame.new(-17.790067408840375, 4.418265999999999, 31.45359765557906) * CFrame.fromEulerAngles(0, math.rad(-49.29), 0))
newmodel129.Parent = workspace.devices.sel_re2l
newmodel129.Body1.Decal.Texture = "rbxgameasset://Images/SEL_RE_24-14"
