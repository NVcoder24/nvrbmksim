newmodel0 = workspace.prefabs.valveind:clone()
newmodel0:PivotTo(CFrame.new(-28.930725748649305, 2.6432353578272596, 30.895049630110385) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.valveind
newmodel1 = workspace.prefabs.valveind:clone()
newmodel1:PivotTo(CFrame.new(-29.118942049640573, 2.643235380161535, 30.97476154317323) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.devices.valveind
newmodel2 = workspace.prefabs.valveind:clone()
newmodel2:PivotTo(CFrame.new(-29.307158198341355, 2.6432353635129604, 31.054471502952516) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.valveind
newmodel3 = workspace.prefabs.valveind:clone()
newmodel3:PivotTo(CFrame.new(-29.495374983264234, 2.6432353861195867, 31.134182992139745) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.valveind
newmodel4 = workspace.prefabs.valveind:clone()
newmodel4:PivotTo(CFrame.new(-29.20898532430697, 2.624381959863184, 30.761308369426732) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.valveind
newmodel5 = workspace.prefabs.valveind:clone()
newmodel5:PivotTo(CFrame.new(-29.585418373998913, 2.624381929000358, 30.920729550987343) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.valveind
newmodel6 = workspace.prefabs.valveind:clone()
newmodel6:PivotTo(CFrame.new(-29.020770525132846, 2.624381954449835, 30.681597407798545) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.devices.valveind
newmodel7 = workspace.prefabs.valveind:clone()
newmodel7:PivotTo(CFrame.new(-29.397203351501183, 2.6243819589099546, 30.841022269874543) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.devices.valveind
newmodel8 = workspace.prefabs.valveind:clone()
newmodel8:PivotTo(CFrame.new(-29.111144337804944, 2.6041072201381508, 30.468207523302738) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.devices.valveind
newmodel9 = workspace.prefabs.valveind:clone()
newmodel9:PivotTo(CFrame.new(-29.29935962091068, 2.6041072258238516, 30.547918061055313) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.devices.valveind
newmodel10 = workspace.prefabs.valveind:clone()
newmodel10:PivotTo(CFrame.new(-29.675792669945473, 2.604107197803876, 30.707339242502968) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.devices.valveind
newmodel11 = workspace.prefabs.valveind:clone()
newmodel11:PivotTo(CFrame.new(-29.487575392413042, 2.6041072125628295, 30.62762660360537) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.devices.valveind
newmodel12 = workspace.prefabs.valveind:clone()
newmodel12:PivotTo(CFrame.new(-29.389734511987065, 2.583832479340551, 30.334523916263574) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.valveind
newmodel13 = workspace.prefabs.valveind:clone()
newmodel13:PivotTo(CFrame.new(-29.766168091167906, 2.5838324840730222, 30.493948468336967) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.valveind
newmodel14 = workspace.prefabs.valveind:clone()
newmodel14:PivotTo(CFrame.new(-29.20151686133412, 2.583832479749078, 30.254811432932048) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.valveind
newmodel15 = workspace.prefabs.valveind:clone()
newmodel15:PivotTo(CFrame.new(-29.57794979758637, 2.5838324743357286, 30.414232882350383) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.valveind
newmodel16 = workspace.prefabs.valveind:clone()
newmodel16:PivotTo(CFrame.new(-29.9589930774521, 2.6022615895840966, 30.82192793874738) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.valveind
newmodel17 = workspace.prefabs.valveind:clone()
newmodel17:PivotTo(CFrame.new(-30.151243241805368, 2.602261592154596, 30.903347906629968) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel17.Parent = workspace.devices.valveind
newmodel18 = workspace.prefabs.valveind:clone()
newmodel18:PivotTo(CFrame.new(-30.34349169060507, 2.6022615718461166, 30.984767461052442) * CFrame.fromEulerAngles(0, math.rad(22.95301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel18.Parent = workspace.devices.valveind
newmodel19 = workspace.prefabs.valveind:clone()
newmodel19:PivotTo(CFrame.new(-47.882868662747505, 2.623530667292547, 32.852361377337544) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel19.Parent = workspace.devices.valveind
newmodel20 = workspace.prefabs.valveind:clone()
newmodel20:PivotTo(CFrame.new(-48.13769842504389, 2.623530667292547, 32.788130292589024) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel20.Parent = workspace.devices.valveind
newmodel21 = workspace.prefabs.valveind:clone()
newmodel21:PivotTo(CFrame.new(-48.06495943641774, 2.637527879577821, 32.971457304188206) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel21.Parent = workspace.devices.valveind
newmodel22 = workspace.prefabs.valveind:clone()
newmodel22:PivotTo(CFrame.new(-49.38370917214138, 2.6960616764071483, 33.32902986851263) * CFrame.fromEulerAngles(0, math.rad(-14.147000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.valveind
newmodel23 = workspace.prefabs.valveind:clone()
newmodel23:PivotTo(CFrame.new(-31.9205179087225, 2.5665014570712215, 31.160501120556756) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel23.Parent = workspace.devices.valveind
newmodel24 = workspace.prefabs.valveind:clone()
newmodel24:PivotTo(CFrame.new(-32.256273677185035, 2.5665014570712215, 31.267351124570332) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.valveind
newmodel25 = workspace.prefabs.valveind:clone()
newmodel25:PivotTo(CFrame.new(-32.41043069773943, 2.611801566427039, 31.85977724618996) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.valveind
newmodel26 = workspace.prefabs.valveind:clone()
newmodel26:PivotTo(CFrame.new(-32.47129753316115, 2.594241429689417, 31.66851579249601) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.valveind
newmodel27 = workspace.prefabs.valveind:clone()
newmodel27:PivotTo(CFrame.new(-32.531281594754574, 2.5769357495132317, 31.48002939436607) * CFrame.fromEulerAngles(0, math.rad(17.653010000000002), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel27.Parent = workspace.devices.valveind
newmodel28 = workspace.prefabs.valveind:clone()
newmodel28:PivotTo(CFrame.new(-50.42448738730736, 2.7446801391958626, 33.52112904727784) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel28.Parent = workspace.devices.valveind
newmodel29 = workspace.prefabs.valveind:clone()
newmodel29:PivotTo(CFrame.new(-50.34119896112791, 2.722793589077071, 33.28523654763352) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel29.Parent = workspace.devices.valveind
newmodel30 = workspace.prefabs.valveind:clone()
newmodel30:PivotTo(CFrame.new(-50.25791053494846, 2.7009070389582788, 33.04934404798918) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel30.Parent = workspace.devices.valveind
newmodel31 = workspace.prefabs.valveind:clone()
newmodel31:PivotTo(CFrame.new(-50.17696728564708, 2.6792749836083103, 32.815708399652145) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel31.Parent = workspace.devices.valveind
newmodel32 = workspace.prefabs.valveind:clone()
newmodel32:PivotTo(CFrame.new(-50.0545318198591, 2.647463137505415, 32.47332747909025) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel32.Parent = workspace.devices.valveind
newmodel33 = workspace.prefabs.valveind:clone()
newmodel33:PivotTo(CFrame.new(-49.9848019746856, 2.6291395141501477, 32.27583608403919) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel33.Parent = workspace.devices.valveind
newmodel34 = workspace.prefabs.valveind:clone()
newmodel34:PivotTo(CFrame.new(-50.54579637089927, 2.6278650479173336, 32.07739285192861) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel34.Parent = workspace.devices.valveind
newmodel35 = workspace.prefabs.valveind:clone()
newmodel35:PivotTo(CFrame.new(-50.61552621607276, 2.646188671272601, 32.27488424697967) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel35.Parent = workspace.devices.valveind
newmodel36 = workspace.prefabs.valveind:clone()
newmodel36:PivotTo(CFrame.new(-51.03865740752774, 2.6278650479173336, 31.903374516763847) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel36.Parent = workspace.devices.valveind
newmodel37 = workspace.prefabs.valveind:clone()
newmodel37:PivotTo(CFrame.new(-49.829857012403515, 2.588418358749743, 31.852018591485248) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel37.Parent = workspace.devices.valveind
newmodel38 = workspace.prefabs.valveind:clone()
newmodel38:PivotTo(CFrame.new(-50.9524562618361, 2.711212084706919, 32.9441088980254) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel38.Parent = workspace.devices.valveind
newmodel39 = workspace.prefabs.valveind:clone()
newmodel39:PivotTo(CFrame.new(-51.02129160214733, 2.711212084706919, 32.91980466127054) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel39.Parent = workspace.devices.valveind
newmodel40 = workspace.prefabs.valveind:clone()
newmodel40:PivotTo(CFrame.new(-51.108387252701235, 2.646188671272601, 32.10086591181492) * CFrame.fromEulerAngles(0, math.rad(-19.447000000000003), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel40.Parent = workspace.devices.valveind
newmodel41 = workspace.prefabs.valveind:clone()
newmodel41:PivotTo(CFrame.new(-33.89091816467762, 2.6763013917223435, 33.08554805201839) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel41.Parent = workspace.devices.valveind
newmodel42 = workspace.prefabs.valveind:clone()
newmodel42:PivotTo(CFrame.new(-34.096289230482625, 2.6763013826744775, 33.13052645897834) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel42.Parent = workspace.devices.valveind
newmodel43 = workspace.prefabs.valveind:clone()
newmodel43:PivotTo(CFrame.new(-33.944437045582724, 2.6544148270185812, 32.841175462054586) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel43.Parent = workspace.devices.valveind
newmodel44 = workspace.prefabs.valveind:clone()
newmodel44:PivotTo(CFrame.new(-34.14980798907024, 2.6544148161540746, 32.886152353575405) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel44.Parent = workspace.devices.valveind
newmodel45 = workspace.prefabs.valveind:clone()
newmodel45:PivotTo(CFrame.new(-34.52127243079783, 2.7497994273958177, 34.08359602800048) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel45.Parent = workspace.devices.valveind
newmodel46 = workspace.prefabs.valveind:clone()
newmodel46:PivotTo(CFrame.new(-34.5791504480247, 2.7261315087152385, 33.81933760884082) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel46.Parent = workspace.devices.valveind
newmodel47 = workspace.prefabs.valveind:clone()
newmodel47:PivotTo(CFrame.new(-34.63702383734358, 2.7024634067788744, 33.555068797283994) * CFrame.fromEulerAngles(0, math.rad(12.353009999999998), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel47.Parent = workspace.devices.valveind
newmodel48 = workspace.prefabs.valveind:clone()
newmodel48:PivotTo(CFrame.new(-51.99916041060411, 2.6310737570824267, 31.558801300532537) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel48.Parent = workspace.devices.valveind
newmodel49 = workspace.prefabs.valveind:clone()
newmodel49:PivotTo(CFrame.new(-52.90837943373893, 2.719220700370056, 32.3222490880485) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel49.Parent = workspace.devices.valveind
newmodel50 = workspace.prefabs.valveind:clone()
newmodel50:PivotTo(CFrame.new(-52.09414071292181, 2.6509243490506336, 31.764857879583406) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel50.Parent = workspace.devices.valveind
newmodel51 = workspace.prefabs.valveind:clone()
newmodel51:PivotTo(CFrame.new(-52.367522983928616, 2.628528781174734, 31.35697588053619) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel51.Parent = workspace.devices.valveind
newmodel52 = workspace.prefabs.valveind:clone()
newmodel52:PivotTo(CFrame.new(-52.537241861434424, 2.628528729185173, 31.278742683692844) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel52.Parent = workspace.devices.valveind
newmodel53 = workspace.prefabs.valveind:clone()
newmodel53:PivotTo(CFrame.new(-52.7069577546531, 2.6285287663725074, 31.200515232192558) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel53.Parent = workspace.devices.valveind
newmodel54 = workspace.prefabs.valveind:clone()
newmodel54:PivotTo(CFrame.new(-52.876680414131954, 2.6285287567467135, 31.122282785396052) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel54.Parent = workspace.devices.valveind
newmodel55 = workspace.prefabs.valveind:clone()
newmodel55:PivotTo(CFrame.new(-51.79469689172551, 2.588064214729759, 31.111733986302596) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel55.Parent = workspace.devices.valveind
newmodel56 = workspace.prefabs.valveind:clone()
newmodel56:PivotTo(CFrame.new(-52.01745537339975, 2.58806430047875, 31.009059739436374) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel56.Parent = workspace.devices.valveind
newmodel57 = workspace.prefabs.valveind:clone()
newmodel57:PivotTo(CFrame.new(-52.240208452176546, 2.588064277072186, 30.906382367095354) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel57.Parent = workspace.devices.valveind
newmodel58 = workspace.prefabs.valveind:clone()
newmodel58:PivotTo(CFrame.new(-52.462961537473355, 2.5880642632914155, 30.803704995875023) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel58.Parent = workspace.devices.valveind
newmodel59 = workspace.prefabs.valveind:clone()
newmodel59:PivotTo(CFrame.new(-53.45064176908394, 2.647615888247702, 31.097951088341368) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel59.Parent = workspace.devices.valveind
newmodel60 = workspace.prefabs.valveind:clone()
newmodel60:PivotTo(CFrame.new(-53.68002587628429, 2.6476158541938877, 30.992217495836158) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel60.Parent = workspace.devices.valveind
newmodel61 = workspace.prefabs.valveind:clone()
newmodel61:PivotTo(CFrame.new(-53.9094088794337, 2.6476158162794814, 30.8864819354193) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel61.Parent = workspace.devices.valveind
newmodel62 = workspace.prefabs.valveind:clone()
newmodel62:PivotTo(CFrame.new(-53.354443151284244, 2.627510835928023, 30.8892542960716) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel62.Parent = workspace.devices.valveind
newmodel63 = workspace.prefabs.valveind:clone()
newmodel63:PivotTo(CFrame.new(-53.81321050517324, 2.627510814858755, 30.677785671499734) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel63.Parent = workspace.devices.valveind
newmodel64 = workspace.prefabs.valveind:clone()
newmodel64:PivotTo(CFrame.new(-53.58382682773755, 2.6275107490884237, 30.78351500098198) * CFrame.fromEulerAngles(0, math.rad(-24.747), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel64.Parent = workspace.devices.valveind
newmodel65 = workspace.prefabs.valveind:clone()
newmodel65:PivotTo(CFrame.new(-37.738380345874695, 2.612880750577241, 33.07476658000654) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel65.Parent = workspace.devices.valveind
newmodel66 = workspace.prefabs.valveind:clone()
newmodel66:PivotTo(CFrame.new(-37.762845961393566, 2.595447806988478, 32.87701305762856) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel66.Parent = workspace.devices.valveind
newmodel67 = workspace.prefabs.valveind:clone()
newmodel67:PivotTo(CFrame.new(-37.78731145779767, 2.5780149152595273, 32.67926508857603) * CFrame.fromEulerAngles(0, math.rad(7.052999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel67.Parent = workspace.devices.valveind
newmodel68 = workspace.prefabs.valveind:clone()
newmodel68:PivotTo(CFrame.new(-39.56790021033589, 2.7148945138972933, 34.522424049774834) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel68.Parent = workspace.devices.valveind
newmodel69 = workspace.prefabs.valveind:clone()
newmodel69:PivotTo(CFrame.new(-39.57626244483176, 2.6909716213400214, 34.249117580908646) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel69.Parent = workspace.devices.valveind
newmodel70 = workspace.prefabs.valveind:clone()
newmodel70:PivotTo(CFrame.new(-39.59573309458668, 2.6436361152996826, 33.70840718365401) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel70.Parent = workspace.devices.valveind
newmodel71 = workspace.prefabs.valveind:clone()
newmodel71:PivotTo(CFrame.new(-40.053852925032565, 2.7148945108023192, 34.537297672673084) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel71.Parent = workspace.devices.valveind
newmodel72 = workspace.prefabs.valveind:clone()
newmodel72:PivotTo(CFrame.new(-40.062214992972365, 2.6909716259807546, 34.26398829359031) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel72.Parent = workspace.devices.valveind
newmodel73 = workspace.prefabs.valveind:clone()
newmodel73:PivotTo(CFrame.new(-40.081683692519654, 2.643636118133269, 33.723282485046255) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel73.Parent = workspace.devices.valveind
newmodel74 = workspace.prefabs.valveind:clone()
newmodel74:PivotTo(CFrame.new(-40.539803522592536, 2.7148945109429166, 34.55217297400121) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel74.Parent = workspace.devices.valveind
newmodel75 = workspace.prefabs.valveind:clone()
newmodel75:PivotTo(CFrame.new(-40.548161070817216, 2.6909716334518503, 34.2788599704099) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel75.Parent = workspace.devices.valveind
newmodel76 = workspace.prefabs.valveind:clone()
newmodel76:PivotTo(CFrame.new(-40.56763640740282, 2.6436361163847892, 33.73815610797656) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel76.Parent = workspace.devices.valveind
newmodel77 = workspace.prefabs.valveind:clone()
newmodel77:PivotTo(CFrame.new(-41.02575457506917, 2.714894522250859, 34.56704451261916) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel77.Parent = workspace.devices.valveind
newmodel78 = workspace.prefabs.valveind:clone()
newmodel78:PivotTo(CFrame.new(-41.03411784690286, 2.6909716314353904, 34.29373429868356) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel78.Parent = workspace.devices.valveind
newmodel79 = workspace.prefabs.valveind:clone()
newmodel79:PivotTo(CFrame.new(-41.05358941405609, 2.6436361139630917, 33.75302973982341) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel79.Parent = workspace.devices.valveind
newmodel80 = workspace.prefabs.valveind:clone()
newmodel80:PivotTo(CFrame.new(-41.511709980984634, 2.7148945359838157, 34.58191676557717) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel80.Parent = workspace.devices.valveind
newmodel81 = workspace.prefabs.valveind:clone()
newmodel81:PivotTo(CFrame.new(-41.52007011249835, 2.6909716136563318, 34.30860471175207) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel81.Parent = workspace.devices.valveind
newmodel82 = workspace.prefabs.valveind:clone()
newmodel82:PivotTo(CFrame.new(-41.5395428739475, 2.6436361105902337, 33.767899608671584) * CFrame.fromEulerAngles(0, math.rad(1.7530100000000033), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel82.Parent = workspace.devices.valveind
newmodel83 = workspace.prefabs.valveind:clone()
newmodel83:PivotTo(CFrame.new(-56.90609613296425, 2.623530667292547, 28.906929215016653) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel83.Parent = workspace.devices.valveind
newmodel84 = workspace.prefabs.valveind:clone()
newmodel84:PivotTo(CFrame.new(-57.120452447203164, 2.623530667292547, 28.754892342693168) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel84.Parent = workspace.devices.valveind
newmodel85 = workspace.prefabs.valveind:clone()
newmodel85:PivotTo(CFrame.new(-57.11893170858465, 2.637527879577821, 28.952116684502933) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel85.Parent = workspace.devices.valveind
newmodel86 = workspace.prefabs.valveind:clone()
newmodel86:PivotTo(CFrame.new(-58.47774049989345, 2.6960616764071483, 28.808597790657323) * CFrame.fromEulerAngles(0, math.rad(-35.346999999999994), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel86.Parent = workspace.devices.valveind
newmodel87 = workspace.prefabs.valveind:clone()
newmodel87:PivotTo(CFrame.new(-44.34681831718426, 2.7130911781625247, 34.35130200107726) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel87.Parent = workspace.devices.valveind
newmodel88 = workspace.prefabs.valveind:clone()
newmodel88:PivotTo(CFrame.new(-43.96211667213889, 2.7130911781625247, 34.37514813072937) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel88.Parent = workspace.devices.valveind
newmodel89 = workspace.prefabs.valveind:clone()
newmodel89:PivotTo(CFrame.new(-44.17427667146049, 2.6545574461892345, 33.69166988634028) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel89.Parent = workspace.devices.valveind
newmodel90 = workspace.prefabs.valveind:clone()
newmodel90:PivotTo(CFrame.new(-44.369540651679316, 2.6545574527522464, 33.67956421635314) * CFrame.fromEulerAngles(0, math.rad(-3.546999999999997), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel90.Parent = workspace.devices.valveind
newmodel91 = workspace.prefabs.valveind:clone()
newmodel91:PivotTo(CFrame.new(-59.51958951555237, 2.7429610031569585, 28.61296850340397) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel91.Parent = workspace.devices.valveind
newmodel92 = workspace.prefabs.valveind:clone()
newmodel92:PivotTo(CFrame.new(-59.35663320969002, 2.7210744530381668, 28.4231594527673) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel92.Parent = workspace.devices.valveind
newmodel93 = workspace.prefabs.valveind:clone()
newmodel93:PivotTo(CFrame.new(-59.19367690382766, 2.6991879029193746, 28.233350402130633) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel93.Parent = workspace.devices.valveind
newmodel94 = workspace.prefabs.valveind:clone()
newmodel94:PivotTo(CFrame.new(-59.03372319507053, 2.677555847569406, 28.04479739410325) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel94.Parent = workspace.devices.valveind
newmodel95 = workspace.prefabs.valveind:clone()
newmodel95:PivotTo(CFrame.new(-58.795760343000985, 2.6457440014665106, 27.769863185459702) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel95.Parent = workspace.devices.valveind
newmodel96 = workspace.prefabs.valveind:clone()
newmodel96:PivotTo(CFrame.new(-58.65933180786041, 2.627420378111243, 27.610953282601095) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel96.Parent = workspace.devices.valveind
newmodel97 = workspace.prefabs.valveind:clone()
newmodel97:PivotTo(CFrame.new(-59.11018770367369, 2.6264897390862103, 27.222738649991868) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel97.Parent = workspace.devices.valveind
newmodel98 = workspace.prefabs.valveind:clone()
newmodel98:PivotTo(CFrame.new(-59.24661623881427, 2.644813362441478, 27.38164855285047) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel98.Parent = workspace.devices.valveind
newmodel99 = workspace.prefabs.valveind:clone()
newmodel99:PivotTo(CFrame.new(-59.50676447317381, 2.6264897390862103, 26.882266553788888) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel99.Parent = workspace.devices.valveind
newmodel100 = workspace.prefabs.valveind:clone()
newmodel100:PivotTo(CFrame.new(-58.361199529480736, 2.58704304991862, 27.271518125520057) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel100.Parent = workspace.devices.valveind
newmodel101 = workspace.prefabs.valveind:clone()
newmodel101:PivotTo(CFrame.new(-59.8027522165468, 2.7098367758757957, 27.88374044043364) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel101.Parent = workspace.devices.valveind
newmodel102 = workspace.prefabs.valveind:clone()
newmodel102:PivotTo(CFrame.new(-59.85814003351609, 2.7098367758757957, 27.83618847169021) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel102.Parent = workspace.devices.valveind
newmodel103 = workspace.prefabs.valveind:clone()
newmodel103:PivotTo(CFrame.new(-59.643193008314384, 2.644813362441478, 27.04117645664749) * CFrame.fromEulerAngles(0, math.rad(-40.647000000000006), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel103.Parent = workspace.devices.valveind
newmodel104 = workspace.prefabs.valveind:clone()
newmodel104:PivotTo(CFrame.new(-60.27798320280763, 2.62917137606273, 26.214266077750686) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel104.Parent = workspace.devices.valveind
newmodel105 = workspace.prefabs.valveind:clone()
newmodel105:PivotTo(CFrame.new(-61.399860376596735, 2.719220700370056, 26.59540851500103) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel105.Parent = workspace.devices.valveind
newmodel106 = workspace.prefabs.valveind:clone()
newmodel106:PivotTo(CFrame.new(-60.44105072111694, 2.649021968030937, 26.372030319804953) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel106.Parent = workspace.devices.valveind
newmodel107 = workspace.prefabs.valveind:clone()
newmodel107:PivotTo(CFrame.new(-60.5484324874824, 2.6266264134536104, 25.892891269454214) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel107.Parent = workspace.devices.valveind
newmodel108 = workspace.prefabs.valveind:clone()
newmodel108:PivotTo(CFrame.new(-60.6783756394491, 2.626626501864701, 25.75858319887898) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel108.Parent = workspace.devices.valveind
newmodel109 = workspace.prefabs.valveind:clone()
newmodel109:PivotTo(CFrame.new(-60.808314744392455, 2.6266263062864508, 25.6242687180508) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel109.Parent = workspace.devices.valveind
newmodel110 = workspace.prefabs.valveind:clone()
newmodel110:PivotTo(CFrame.new(-60.938257684920885, 2.6266263676025687, 25.48996044480508) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel110.Parent = workspace.devices.valveind
newmodel111 = workspace.prefabs.valveind:clone()
newmodel111:PivotTo(CFrame.new(-59.9256904371162, 2.5861619118385932, 25.871392699200456) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel111.Parent = workspace.devices.valveind
newmodel112 = workspace.prefabs.valveind:clone()
newmodel112:PivotTo(CFrame.new(-60.096238616498944, 2.5861618388925787, 25.695109511798847) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel112.Parent = workspace.devices.valveind
newmodel113 = workspace.prefabs.valveind:clone()
newmodel113:PivotTo(CFrame.new(-60.26678502325047, 2.5861618037929737, 25.51882822253124) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel113.Parent = workspace.devices.valveind
newmodel114 = workspace.prefabs.valveind:clone()
newmodel114:PivotTo(CFrame.new(-60.43733249434623, 2.5861618324220186, 25.34254893634382) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel114.Parent = workspace.devices.valveind
newmodel115 = workspace.prefabs.valveind:clone()
newmodel115:PivotTo(CFrame.new(-61.46457646883105, 2.645713629495239, 25.259715407000307) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel115.Parent = workspace.devices.valveind
newmodel116 = workspace.prefabs.valveind:clone()
newmodel116:PivotTo(CFrame.new(-61.640200761305444, 2.645713568946157, 25.078185119524758) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel116.Parent = workspace.devices.valveind
newmodel117 = workspace.prefabs.valveind:clone()
newmodel117:PivotTo(CFrame.new(-61.81583002766046, 2.645713722842818, 24.896657544984315) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel117.Parent = workspace.devices.valveind
newmodel118 = workspace.prefabs.valveind:clone()
newmodel118:PivotTo(CFrame.new(-61.29942460024013, 2.6256085694074853, 25.09992548978476) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel118.Parent = workspace.devices.valveind
newmodel119 = workspace.prefabs.valveind:clone()
newmodel119:PivotTo(CFrame.new(-61.65066655587358, 2.6256083696597834, 24.736869385857425) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel119.Parent = workspace.devices.valveind
newmodel120 = workspace.prefabs.valveind:clone()
newmodel120:PivotTo(CFrame.new(-61.47504247246008, 2.625608455658342, 24.918399875594826) * CFrame.fromEulerAngles(0, math.rad(-45.947), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel120.Parent = workspace.devices.valveind
