newmodel0 = workspace.prefabs.np_btn:clone()
newmodel0.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel0.id.Value = 1
newmodel0:PivotTo(CFrame.new(-21.978560526677022, 2.7288915015853363, 27.749896685106716) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel0.Parent = workspace.devices.np
newmodel0.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_0-8"
newmodel1 = workspace.prefabs.np_btn:clone()
newmodel1.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel1.id.Value = 2
newmodel1:PivotTo(CFrame.new(-22.0922591798168, 2.7288915015853363, 27.841486074635203) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel1.Parent = workspace.devices.np
newmodel1.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_0-10"
newmodel2 = workspace.prefabs.np_btn:clone()
newmodel2.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel2.id.Value = 3
newmodel2:PivotTo(CFrame.new(-22.205957832956578, 2.7288915015853363, 27.933075464163686) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel2.Parent = workspace.devices.np
newmodel2.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_0-12"
newmodel3 = workspace.prefabs.np_btn:clone()
newmodel3.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel3.id.Value = 4
newmodel3:PivotTo(CFrame.new(-22.319656486096353, 2.7288915015853363, 28.024664853692173) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel3.Parent = workspace.devices.np
newmodel3.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_0-14"
newmodel4 = workspace.prefabs.np_btn:clone()
newmodel4.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel4.id.Value = 5
newmodel4:PivotTo(CFrame.new(-21.85363297909222, 2.722529132364757, 27.555879603094983) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel4.Parent = workspace.devices.np
newmodel4.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_1-5"
newmodel5 = workspace.prefabs.np_btn:clone()
newmodel5.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel5.id.Value = 6
newmodel5:PivotTo(CFrame.new(-21.967331632232, 2.722529132364757, 27.647468992623466) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel5.Parent = workspace.devices.np
newmodel5.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_1-7"
newmodel6 = workspace.prefabs.np_btn:clone()
newmodel6.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel6.id.Value = 7
newmodel6:PivotTo(CFrame.new(-22.081030285371778, 2.722529132364757, 27.739058382151953) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel6.Parent = workspace.devices.np
newmodel6.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_1-9"
newmodel7 = workspace.prefabs.np_btn:clone()
newmodel7.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel7.id.Value = 8
newmodel7:PivotTo(CFrame.new(-22.194728938511556, 2.722529132364757, 27.830647771680436) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel7.Parent = workspace.devices.np
newmodel7.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_1-11"
newmodel8 = workspace.prefabs.np_btn:clone()
newmodel8.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel8.id.Value = 9
newmodel8:PivotTo(CFrame.new(-22.30842759165133, 2.722529132364757, 27.92223716120892) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel8.Parent = workspace.devices.np
newmodel8.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_1-13"
newmodel9 = workspace.prefabs.np_btn:clone()
newmodel9.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel9.id.Value = 10
newmodel9:PivotTo(CFrame.new(-22.42212624479111, 2.722529132364757, 28.013826550737406) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel9.Parent = workspace.devices.np
newmodel9.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_1-15"
newmodel10 = workspace.prefabs.np_btn:clone()
newmodel10.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel10.id.Value = 11
newmodel10:PivotTo(CFrame.new(-22.535824897930887, 2.722529132364757, 28.10541594026589) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel10.Parent = workspace.devices.np
newmodel10.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_1-17"
newmodel11 = workspace.prefabs.np_btn:clone()
newmodel11.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel11.id.Value = 12
newmodel11:PivotTo(CFrame.new(-21.842404084647203, 2.7161667631441784, 27.453451910611726) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel11.Parent = workspace.devices.np
newmodel11.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_2-4"
newmodel12 = workspace.prefabs.np_btn:clone()
newmodel12.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel12.id.Value = 13
newmodel12:PivotTo(CFrame.new(-21.956102737786978, 2.7161667631441784, 27.545041300140213) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel12.Parent = workspace.devices.np
newmodel12.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_2-6"
newmodel13 = workspace.prefabs.np_btn:clone()
newmodel13.Body2.Color = Color3.fromRGB(0, 62, 100)
newmodel13.id.Value = 14
newmodel13:PivotTo(CFrame.new(-22.069801390926756, 2.7161667631441784, 27.6366306896687) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel13.Parent = workspace.devices.np
newmodel13.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_2-8"
newmodel14 = workspace.prefabs.np_btn:clone()
newmodel14.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel14.id.Value = 15
newmodel14:PivotTo(CFrame.new(-22.183500044066534, 2.7161667631441784, 27.728220079197186) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel14.Parent = workspace.devices.np
newmodel14.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_2-10"
newmodel15 = workspace.prefabs.np_btn:clone()
newmodel15.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel15.id.Value = 16
newmodel15:PivotTo(CFrame.new(-22.297198697206312, 2.7161667631441784, 27.81980946872567) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel15.Parent = workspace.devices.np
newmodel15.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_2-12"
newmodel16 = workspace.prefabs.np_btn:clone()
newmodel16.Body2.Color = Color3.fromRGB(0, 62, 100)
newmodel16.id.Value = 17
newmodel16:PivotTo(CFrame.new(-22.41089735034609, 2.7161667631441784, 27.911398858254152) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel16.Parent = workspace.devices.np
newmodel16.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_2-14"
newmodel17 = workspace.prefabs.np_btn:clone()
newmodel17.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel17.id.Value = 18
newmodel17:PivotTo(CFrame.new(-22.52459600348587, 2.7161667631441784, 28.00298824778264) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel17.Parent = workspace.devices.np
newmodel17.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_2-16"
newmodel18 = workspace.prefabs.np_btn:clone()
newmodel18.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel18.id.Value = 19
newmodel18:PivotTo(CFrame.new(-22.638294656625646, 2.7161667631441784, 28.094577637311122) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel18.Parent = workspace.devices.np
newmodel18.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_2-18"
newmodel19 = workspace.prefabs.np_btn:clone()
newmodel19.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel19.id.Value = 20
newmodel19:PivotTo(CFrame.new(-21.83117519020218, 2.709804393923599, 27.351024218128476) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel19.Parent = workspace.devices.np
newmodel19.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_3-3"
newmodel20 = workspace.prefabs.np_btn:clone()
newmodel20.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel20.id.Value = 21
newmodel20:PivotTo(CFrame.new(-21.94487384334196, 2.709804393923599, 27.442613607656963) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel20.Parent = workspace.devices.np
newmodel20.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_3-5"
newmodel21 = workspace.prefabs.np_btn:clone()
newmodel21.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel21:PivotTo(CFrame.new(-22.058572496481737, 2.709804393923599, 27.534202997185446) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel21.Parent = workspace.devices.np
newmodel21.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_3-7"
newmodel22 = workspace.prefabs.np_btn:clone()
newmodel22.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel22.id.Value = 23
newmodel22:PivotTo(CFrame.new(-22.172271149621515, 2.709804393923599, 27.625792386713933) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel22.Parent = workspace.devices.np
newmodel22.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_3-9"
newmodel23 = workspace.prefabs.np_btn:clone()
newmodel23.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel23.id.Value = 24
newmodel23:PivotTo(CFrame.new(-22.285969802761294, 2.709804393923599, 27.717381776242416) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel23.Parent = workspace.devices.np
newmodel23.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_3-11"
newmodel24 = workspace.prefabs.np_btn:clone()
newmodel24.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel24.id.Value = 25
newmodel24:PivotTo(CFrame.new(-22.39966845590107, 2.709804393923599, 27.808971165770902) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel24.Parent = workspace.devices.np
newmodel24.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_3-13"
newmodel25 = workspace.prefabs.np_btn:clone()
newmodel25.Body2.Color = Color3.fromRGB(0, 143, 156)
newmodel25:PivotTo(CFrame.new(-22.51336710904085, 2.709804393923599, 27.900560555299386) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel25.Parent = workspace.devices.np
newmodel25.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_3-15"
newmodel26 = workspace.prefabs.np_btn:clone()
newmodel26.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel26.id.Value = 27
newmodel26:PivotTo(CFrame.new(-22.627065762180624, 2.709804393923599, 27.992149944827872) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel26.Parent = workspace.devices.np
newmodel26.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_3-17"
newmodel27 = workspace.prefabs.np_btn:clone()
newmodel27.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel27.id.Value = 28
newmodel27:PivotTo(CFrame.new(-22.7407644153204, 2.709804393923599, 28.083739334356355) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel27.Parent = workspace.devices.np
newmodel27.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_3-19"
newmodel28 = workspace.prefabs.np_btn:clone()
newmodel28.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel28.id.Value = 29
newmodel28:PivotTo(CFrame.new(-21.819946295757163, 2.70344202470302, 27.248596525645226) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel28.Parent = workspace.devices.np
newmodel28.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_4-2"
newmodel29 = workspace.prefabs.np_btn:clone()
newmodel29.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel29.id.Value = 30
newmodel29:PivotTo(CFrame.new(-21.93364494889694, 2.70344202470302, 27.34018591517371) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel29.Parent = workspace.devices.np
newmodel29.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_4-4"
newmodel30 = workspace.prefabs.np_btn:clone()
newmodel30.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel30.id.Value = 31
newmodel30:PivotTo(CFrame.new(-22.047343602036715, 2.70344202470302, 27.431775304702192) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel30.Parent = workspace.devices.np
newmodel30.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_4-6"
newmodel31 = workspace.prefabs.np_btn:clone()
newmodel31.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel31.id.Value = 32
newmodel31:PivotTo(CFrame.new(-22.161042255176493, 2.70344202470302, 27.52336469423068) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel31.Parent = workspace.devices.np
newmodel31.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_4-8"
newmodel32 = workspace.prefabs.np_btn:clone()
newmodel32.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel32.id.Value = 33
newmodel32:PivotTo(CFrame.new(-22.27474090831627, 2.70344202470302, 27.614954083759166) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel32.Parent = workspace.devices.np
newmodel32.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_4-10"
newmodel33 = workspace.prefabs.np_btn:clone()
newmodel33.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel33.id.Value = 34
newmodel33:PivotTo(CFrame.new(-22.388439561456046, 2.70344202470302, 27.70654347328765) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel33.Parent = workspace.devices.np
newmodel33.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_4-12"
newmodel34 = workspace.prefabs.np_btn:clone()
newmodel34.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel34.id.Value = 35
newmodel34:PivotTo(CFrame.new(-22.502138214595828, 2.70344202470302, 27.798132862816136) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel34.Parent = workspace.devices.np
newmodel34.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_4-14"
newmodel35 = workspace.prefabs.np_btn:clone()
newmodel35.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel35.id.Value = 36
newmodel35:PivotTo(CFrame.new(-22.615836867735602, 2.70344202470302, 27.88972225234462) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel35.Parent = workspace.devices.np
newmodel35.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_4-16"
newmodel36 = workspace.prefabs.np_btn:clone()
newmodel36.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel36.id.Value = 37
newmodel36:PivotTo(CFrame.new(-22.72953552087538, 2.70344202470302, 27.981311641873106) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel36.Parent = workspace.devices.np
newmodel36.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_4-18"
newmodel37 = workspace.prefabs.np_btn:clone()
newmodel37.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel37.id.Value = 38
newmodel37:PivotTo(CFrame.new(-22.84323417401516, 2.70344202470302, 28.07290103140159) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel37.Parent = workspace.devices.np
newmodel37.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_4-20"
newmodel38 = workspace.prefabs.np_btn:clone()
newmodel38.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel38.id.Value = 39
newmodel38:PivotTo(CFrame.new(-21.80871740131214, 2.6970796554824408, 27.146168833161973) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel38.Parent = workspace.devices.np
newmodel38.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_5-1"
newmodel39 = workspace.prefabs.np_btn:clone()
newmodel39.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel39.id.Value = 40
newmodel39:PivotTo(CFrame.new(-21.92241605445192, 2.6970796554824408, 27.23775822269046) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel39.Parent = workspace.devices.np
newmodel39.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_5-3"
newmodel40 = workspace.prefabs.np_btn:clone()
newmodel40.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel40.id.Value = 41
newmodel40:PivotTo(CFrame.new(-22.036114707591697, 2.6970796554824408, 27.329347612218942) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel40.Parent = workspace.devices.np
newmodel40.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_5-5"
newmodel41 = workspace.prefabs.np_btn:clone()
newmodel41.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel41.id.Value = 42
newmodel41:PivotTo(CFrame.new(-22.149813360731475, 2.6970796554824408, 27.42093700174743) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel41.Parent = workspace.devices.np
newmodel41.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_5-7"
newmodel42 = workspace.prefabs.np_btn:clone()
newmodel42.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel42.id.Value = 43
newmodel42:PivotTo(CFrame.new(-22.26351201387125, 2.6970796554824408, 27.512526391275912) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel42.Parent = workspace.devices.np
newmodel42.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_5-9"
newmodel43 = workspace.prefabs.np_btn:clone()
newmodel43.Body2.Color = Color3.fromRGB(0, 143, 156)
newmodel43.id.Value = 44
newmodel43:PivotTo(CFrame.new(-22.377210667011028, 2.6970796554824408, 27.6041157808044) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel43.Parent = workspace.devices.np
newmodel43.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_5-11"
newmodel44 = workspace.prefabs.np_btn:clone()
newmodel44.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel44.id.Value = 45
newmodel44:PivotTo(CFrame.new(-22.490909320150806, 2.6970796554824408, 27.695705170332882) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel44.Parent = workspace.devices.np
newmodel44.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_5-13"
newmodel45 = workspace.prefabs.np_btn:clone()
newmodel45.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel45.id.Value = 46
newmodel45:PivotTo(CFrame.new(-22.604607973290584, 2.6970796554824408, 27.787294559861365) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel45.Parent = workspace.devices.np
newmodel45.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_5-15"
newmodel46 = workspace.prefabs.np_btn:clone()
newmodel46.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel46.id.Value = 47
newmodel46:PivotTo(CFrame.new(-22.718306626430362, 2.6970796554824408, 27.878883949389852) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel46.Parent = workspace.devices.np
newmodel46.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_5-17"
newmodel47 = workspace.prefabs.np_btn:clone()
newmodel47.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel47.id.Value = 48
newmodel47:PivotTo(CFrame.new(-22.832005279570136, 2.6970796554824408, 27.97047333891834) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel47.Parent = workspace.devices.np
newmodel47.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_5-19"
newmodel48 = workspace.prefabs.np_btn:clone()
newmodel48.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel48.id.Value = 49
newmodel48:PivotTo(CFrame.new(-22.945703932709918, 2.6970796554824408, 28.062062728446822) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel48.Parent = workspace.devices.np
newmodel48.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_5-21"
newmodel49 = workspace.prefabs.np_btn:clone()
newmodel49.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel49.id.Value = 50
newmodel49:PivotTo(CFrame.new(-21.911187160006897, 2.6907172862618616, 27.135330530207206) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel49.Parent = workspace.devices.np
newmodel49.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_6-2"
newmodel50 = workspace.prefabs.np_btn:clone()
newmodel50.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel50.id.Value = 51
newmodel50:PivotTo(CFrame.new(-22.024885813146675, 2.6907172862618616, 27.226919919735693) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel50.Parent = workspace.devices.np
newmodel50.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_6-4"
newmodel51 = workspace.prefabs.np_btn:clone()
newmodel51.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel51.id.Value = 52
newmodel51:PivotTo(CFrame.new(-22.138584466286453, 2.6907172862618616, 27.318509309264176) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel51.Parent = workspace.devices.np
newmodel51.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_6-6"
newmodel52 = workspace.prefabs.np_btn:clone()
newmodel52.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel52.id.Value = 53
newmodel52:PivotTo(CFrame.new(-22.25228311942623, 2.6907172862618616, 27.410098698792662) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel52.Parent = workspace.devices.np
newmodel52.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_6-8"
newmodel53 = workspace.prefabs.np_btn:clone()
newmodel53.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel53.id.Value = 54
newmodel53:PivotTo(CFrame.new(-22.36598177256601, 2.6907172862618616, 27.501688088321146) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel53.Parent = workspace.devices.np
newmodel53.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_6-10"
newmodel54 = workspace.prefabs.np_btn:clone()
newmodel54.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel54.id.Value = 55
newmodel54:PivotTo(CFrame.new(-22.479680425705787, 2.6907172862618616, 27.593277477849632) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel54.Parent = workspace.devices.np
newmodel54.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_6-12"
newmodel55 = workspace.prefabs.np_btn:clone()
newmodel55.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel55.id.Value = 56
newmodel55:PivotTo(CFrame.new(-22.59337907884556, 2.6907172862618616, 27.684866867378116) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel55.Parent = workspace.devices.np
newmodel55.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_6-14"
newmodel56 = workspace.prefabs.np_btn:clone()
newmodel56.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel56.id.Value = 57
newmodel56:PivotTo(CFrame.new(-22.70707773198534, 2.6907172862618616, 27.7764562569066) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel56.Parent = workspace.devices.np
newmodel56.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_6-16"
newmodel57 = workspace.prefabs.np_btn:clone()
newmodel57.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel57.id.Value = 58
newmodel57:PivotTo(CFrame.new(-22.820776385125118, 2.6907172862618616, 27.868045646435085) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel57.Parent = workspace.devices.np
newmodel57.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_6-18"
newmodel58 = workspace.prefabs.np_btn:clone()
newmodel58.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel58.id.Value = 59
newmodel58:PivotTo(CFrame.new(-22.934475038264893, 2.6907172862618616, 27.95963503596357) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel58.Parent = workspace.devices.np
newmodel58.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_6-20"
newmodel59 = workspace.prefabs.np_btn:clone()
newmodel59.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel59.id.Value = 60
newmodel59:PivotTo(CFrame.new(-21.899958265561878, 2.684354917041283, 27.032902837723956) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel59.Parent = workspace.devices.np
newmodel59.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_7-1"
newmodel60 = workspace.prefabs.np_btn:clone()
newmodel60.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel60:PivotTo(CFrame.new(-22.013656918701656, 2.684354917041283, 27.12449222725244) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel60.Parent = workspace.devices.np
newmodel60.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_7-3"
newmodel61 = workspace.prefabs.np_btn:clone()
newmodel61.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel61.id.Value = 62
newmodel61:PivotTo(CFrame.new(-22.12735557184143, 2.684354917041283, 27.216081616780926) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel61.Parent = workspace.devices.np
newmodel61.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_7-5"
newmodel62 = workspace.prefabs.np_btn:clone()
newmodel62.Body2.Color = Color3.fromRGB(0, 143, 156)
newmodel62.id.Value = 63
newmodel62:PivotTo(CFrame.new(-22.241054224981212, 2.684354917041283, 27.30767100630941) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel62.Parent = workspace.devices.np
newmodel62.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_7-7"
newmodel63 = workspace.prefabs.np_btn:clone()
newmodel63.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel63.id.Value = 64
newmodel63:PivotTo(CFrame.new(-22.354752878120987, 2.684354917041283, 27.399260395837892) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel63.Parent = workspace.devices.np
newmodel63.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_7-9"
newmodel64 = workspace.prefabs.np_btn:clone()
newmodel64.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel64:PivotTo(CFrame.new(-22.468451531260765, 2.684354917041283, 27.49084978536638) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel64.Parent = workspace.devices.np
newmodel64.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_7-11"
newmodel65 = workspace.prefabs.np_btn:clone()
newmodel65.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel65.id.Value = 66
newmodel65:PivotTo(CFrame.new(-22.582150184400543, 2.684354917041283, 27.582439174894866) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel65.Parent = workspace.devices.np
newmodel65.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_7-13"
newmodel66 = workspace.prefabs.np_btn:clone()
newmodel66.Body2.Color = Color3.fromRGB(0, 143, 156)
newmodel66.id.Value = 67
newmodel66:PivotTo(CFrame.new(-22.69584883754032, 2.684354917041283, 27.674028564423352) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel66.Parent = workspace.devices.np
newmodel66.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_7-15"
newmodel67 = workspace.prefabs.np_btn:clone()
newmodel67.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel67.id.Value = 68
newmodel67:PivotTo(CFrame.new(-22.809547490680096, 2.684354917041283, 27.765617953951836) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel67.Parent = workspace.devices.np
newmodel67.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_7-17"
newmodel68 = workspace.prefabs.np_btn:clone()
newmodel68.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel68:PivotTo(CFrame.new(-22.923246143819874, 2.684354917041283, 27.85720734348032) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel68.Parent = workspace.devices.np
newmodel68.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_7-19"
newmodel69 = workspace.prefabs.np_btn:clone()
newmodel69.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel69.id.Value = 70
newmodel69:PivotTo(CFrame.new(-23.036944796959652, 2.684354917041283, 27.948796733008805) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel69.Parent = workspace.devices.np
newmodel69.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_7-21"
newmodel70 = workspace.prefabs.np_btn:clone()
newmodel70.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel70.id.Value = 71
newmodel70:PivotTo(CFrame.new(-21.888729371116856, 2.6779925478207036, 26.930475145240703) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel70.Parent = workspace.devices.np
newmodel70.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_8-0"
newmodel71 = workspace.prefabs.np_btn:clone()
newmodel71.Body2.Color = Color3.fromRGB(0, 62, 100)
newmodel71.id.Value = 72
newmodel71:PivotTo(CFrame.new(-22.002428024256634, 2.6779925478207036, 27.022064534769186) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel71.Parent = workspace.devices.np
newmodel71.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_8-2"
newmodel72 = workspace.prefabs.np_btn:clone()
newmodel72.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel72.id.Value = 73
newmodel72:PivotTo(CFrame.new(-22.116126677396412, 2.6779925478207036, 27.113653924297672) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel72.Parent = workspace.devices.np
newmodel72.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_8-4"
newmodel73 = workspace.prefabs.np_btn:clone()
newmodel73.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel73.id.Value = 74
newmodel73:PivotTo(CFrame.new(-22.229825330536187, 2.6779925478207036, 27.20524331382616) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel73.Parent = workspace.devices.np
newmodel73.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_8-6"
newmodel74 = workspace.prefabs.np_btn:clone()
newmodel74.Body2.Color = Color3.fromRGB(0, 62, 100)
newmodel74.id.Value = 75
newmodel74:PivotTo(CFrame.new(-22.34352398367597, 2.6779925478207036, 27.296832703354642) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel74.Parent = workspace.devices.np
newmodel74.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_8-8"
newmodel75 = workspace.prefabs.np_btn:clone()
newmodel75.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel75.id.Value = 76
newmodel75:PivotTo(CFrame.new(-22.457222636815747, 2.6779925478207036, 27.388422092883125) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel75.Parent = workspace.devices.np
newmodel75.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_8-10"
newmodel76 = workspace.prefabs.np_btn:clone()
newmodel76.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel76.id.Value = 77
newmodel76:PivotTo(CFrame.new(-22.57092128995552, 2.6779925478207036, 27.480011482411612) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel76.Parent = workspace.devices.np
newmodel76.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_8-12"
newmodel77 = workspace.prefabs.np_btn:clone()
newmodel77.Body2.Color = Color3.fromRGB(0, 62, 100)
newmodel77.id.Value = 78
newmodel77:PivotTo(CFrame.new(-22.6846199430953, 2.6779925478207036, 27.571600871940095) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel77.Parent = workspace.devices.np
newmodel77.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_8-14"
newmodel78 = workspace.prefabs.np_btn:clone()
newmodel78.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel78.id.Value = 79
newmodel78:PivotTo(CFrame.new(-22.798318596235077, 2.6779925478207036, 27.663190261468582) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel78.Parent = workspace.devices.np
newmodel78.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_8-16"
newmodel79 = workspace.prefabs.np_btn:clone()
newmodel79.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel79.id.Value = 80
newmodel79:PivotTo(CFrame.new(-22.912017249374856, 2.6779925478207036, 27.75477965099707) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel79.Parent = workspace.devices.np
newmodel79.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_8-18"
newmodel80 = workspace.prefabs.np_btn:clone()
newmodel80.Body2.Color = Color3.fromRGB(0, 62, 100)
newmodel80.id.Value = 81
newmodel80:PivotTo(CFrame.new(-23.025715902514634, 2.6779925478207036, 27.846369040525552) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel80.Parent = workspace.devices.np
newmodel80.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_8-20"
newmodel81 = workspace.prefabs.np_btn:clone()
newmodel81.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel81.id.Value = 82
newmodel81:PivotTo(CFrame.new(-23.139414555654408, 2.6779925478207036, 27.93795843005404) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel81.Parent = workspace.devices.np
newmodel81.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_8-22"
newmodel82 = workspace.prefabs.np_btn:clone()
newmodel82.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel82.id.Value = 83
newmodel82:PivotTo(CFrame.new(-21.991199129811612, 2.671630178600125, 26.919636842285936) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel82.Parent = workspace.devices.np
newmodel82.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_9-1"
newmodel83 = workspace.prefabs.np_btn:clone()
newmodel83.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel83.id.Value = 84
newmodel83:PivotTo(CFrame.new(-22.10489778295139, 2.671630178600125, 27.01122623181442) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel83.Parent = workspace.devices.np
newmodel83.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_9-3"
newmodel84 = workspace.prefabs.np_btn:clone()
newmodel84.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel84.id.Value = 85
newmodel84:PivotTo(CFrame.new(-22.21859643609117, 2.671630178600125, 27.102815621342906) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel84.Parent = workspace.devices.np
newmodel84.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_9-5"
newmodel85 = workspace.prefabs.np_btn:clone()
newmodel85.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel85.id.Value = 86
newmodel85:PivotTo(CFrame.new(-22.332295089230946, 2.671630178600125, 27.19440501087139) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel85.Parent = workspace.devices.np
newmodel85.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_9-7"
newmodel86 = workspace.prefabs.np_btn:clone()
newmodel86.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel86.id.Value = 87
newmodel86:PivotTo(CFrame.new(-22.445993742370725, 2.671630178600125, 27.285994400399876) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel86.Parent = workspace.devices.np
newmodel86.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_9-9"
newmodel87 = workspace.prefabs.np_btn:clone()
newmodel87.Body2.Color = Color3.fromRGB(0, 143, 156)
newmodel87.id.Value = 88
newmodel87:PivotTo(CFrame.new(-22.559692395510503, 2.671630178600125, 27.37758378992836) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel87.Parent = workspace.devices.np
newmodel87.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_9-11"
newmodel88 = workspace.prefabs.np_btn:clone()
newmodel88.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel88.id.Value = 89
newmodel88:PivotTo(CFrame.new(-22.67339104865028, 2.671630178600125, 27.469173179456845) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel88.Parent = workspace.devices.np
newmodel88.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_9-13"
newmodel89 = workspace.prefabs.np_btn:clone()
newmodel89.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel89.id.Value = 90
newmodel89:PivotTo(CFrame.new(-22.78708970179006, 2.671630178600125, 27.56076256898533) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel89.Parent = workspace.devices.np
newmodel89.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_9-15"
newmodel90 = workspace.prefabs.np_btn:clone()
newmodel90.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel90.id.Value = 91
newmodel90:PivotTo(CFrame.new(-22.900788354929833, 2.671630178600125, 27.652351958513815) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel90.Parent = workspace.devices.np
newmodel90.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_9-17"
newmodel91 = workspace.prefabs.np_btn:clone()
newmodel91.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel91.id.Value = 92
newmodel91:PivotTo(CFrame.new(-23.014487008069608, 2.671630178600125, 27.7439413480423) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel91.Parent = workspace.devices.np
newmodel91.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_9-19"
newmodel92 = workspace.prefabs.np_btn:clone()
newmodel92.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel92.id.Value = 93
newmodel92:PivotTo(CFrame.new(-23.128185661209386, 2.671630178600125, 27.835530737570785) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel92.Parent = workspace.devices.np
newmodel92.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_9-21"
newmodel93 = workspace.prefabs.np_btn:clone()
newmodel93.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel93.id.Value = 94
newmodel93:PivotTo(CFrame.new(-21.979970235366594, 2.6652678093795457, 26.817209149802682) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel93.Parent = workspace.devices.np
newmodel93.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_10-0"
newmodel94 = workspace.prefabs.np_btn:clone()
newmodel94.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel94.id.Value = 95
newmodel94:PivotTo(CFrame.new(-22.09366888850637, 2.6652678093795457, 26.908798539331166) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel94.Parent = workspace.devices.np
newmodel94.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_10-2"
newmodel95 = workspace.prefabs.np_btn:clone()
newmodel95.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel95.id.Value = 96
newmodel95:PivotTo(CFrame.new(-22.20736754164615, 2.6652678093795457, 27.000387928859652) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel95.Parent = workspace.devices.np
newmodel95.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_10-4"
newmodel96 = workspace.prefabs.np_btn:clone()
newmodel96.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel96.id.Value = 97
newmodel96:PivotTo(CFrame.new(-22.321066194785928, 2.6652678093795457, 27.09197731838814) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel96.Parent = workspace.devices.np
newmodel96.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_10-6"
newmodel97 = workspace.prefabs.np_btn:clone()
newmodel97.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel97.id.Value = 98
newmodel97:PivotTo(CFrame.new(-22.434764847925702, 2.6652678093795457, 27.183566707916622) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel97.Parent = workspace.devices.np
newmodel97.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_10-8"
newmodel98 = workspace.prefabs.np_btn:clone()
newmodel98.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel98.id.Value = 99
newmodel98:PivotTo(CFrame.new(-22.54846350106548, 2.6652678093795457, 27.27515609744511) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel98.Parent = workspace.devices.np
newmodel98.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_10-10"
newmodel99 = workspace.prefabs.np_btn:clone()
newmodel99.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel99.id.Value = 100
newmodel99:PivotTo(CFrame.new(-22.66216215420526, 2.6652678093795457, 27.366745486973592) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel99.Parent = workspace.devices.np
newmodel99.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_10-12"
newmodel100 = workspace.prefabs.np_btn:clone()
newmodel100.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel100.id.Value = 101
newmodel100:PivotTo(CFrame.new(-22.775860807345033, 2.6652678093795457, 27.45833487650208) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel100.Parent = workspace.devices.np
newmodel100.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_10-14"
newmodel101 = workspace.prefabs.np_btn:clone()
newmodel101.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel101.id.Value = 102
newmodel101:PivotTo(CFrame.new(-22.88955946048481, 2.6652678093795457, 27.549924266030562) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel101.Parent = workspace.devices.np
newmodel101.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_10-16"
newmodel102 = workspace.prefabs.np_btn:clone()
newmodel102.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel102.id.Value = 103
newmodel102:PivotTo(CFrame.new(-23.00325811362459, 2.6652678093795457, 27.641513655559045) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel102.Parent = workspace.devices.np
newmodel102.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_10-18"
newmodel103 = workspace.prefabs.np_btn:clone()
newmodel103.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel103.id.Value = 104
newmodel103:PivotTo(CFrame.new(-23.116956766764368, 2.6652678093795457, 27.73310304508753) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel103.Parent = workspace.devices.np
newmodel103.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_10-20"
newmodel104 = workspace.prefabs.np_btn:clone()
newmodel104.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel104.id.Value = 105
newmodel104:PivotTo(CFrame.new(-23.230655419904146, 2.6652678093795457, 27.82469243461602) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel104.Parent = workspace.devices.np
newmodel104.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_10-22"
newmodel105 = workspace.prefabs.np_btn:clone()
newmodel105.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel105.id.Value = 106
newmodel105:PivotTo(CFrame.new(-22.08243999406135, 2.6589054401589665, 26.806370846847916) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel105.Parent = workspace.devices.np
newmodel105.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_11-1"
newmodel106 = workspace.prefabs.np_btn:clone()
newmodel106.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel106.id.Value = 107
newmodel106:PivotTo(CFrame.new(-22.196138647201128, 2.6589054401589665, 26.8979602363764) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel106.Parent = workspace.devices.np
newmodel106.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_11-3"
newmodel107 = workspace.prefabs.np_btn:clone()
newmodel107.Body2.Color = Color3.fromRGB(0, 143, 156)
newmodel107.id.Value = 108
newmodel107:PivotTo(CFrame.new(-22.309837300340906, 2.6589054401589665, 26.989549625904885) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel107.Parent = workspace.devices.np
newmodel107.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_11-5"
newmodel108 = workspace.prefabs.np_btn:clone()
newmodel108.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel108:PivotTo(CFrame.new(-22.423535953480684, 2.6589054401589665, 27.081139015433372) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel108.Parent = workspace.devices.np
newmodel108.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_11-7"
newmodel109 = workspace.prefabs.np_btn:clone()
newmodel109.Body2.Color = Color3.fromRGB(0, 143, 156)
newmodel109.id.Value = 110
newmodel109:PivotTo(CFrame.new(-22.53723460662046, 2.6589054401589665, 27.172728404961855) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel109.Parent = workspace.devices.np
newmodel109.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_11-9"
newmodel110 = workspace.prefabs.np_btn:clone()
newmodel110.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel110.id.Value = 111
newmodel110:PivotTo(CFrame.new(-22.650933259760237, 2.6589054401589665, 27.264317794490342) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel110.Parent = workspace.devices.np
newmodel110.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_11-11"
newmodel111 = workspace.prefabs.np_btn:clone()
newmodel111.Body2.Color = Color3.fromRGB(0, 143, 156)
newmodel111.id.Value = 112
newmodel111:PivotTo(CFrame.new(-22.764631912900015, 2.6589054401589665, 27.355907184018825) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel111.Parent = workspace.devices.np
newmodel111.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_11-13"
newmodel112 = workspace.prefabs.np_btn:clone()
newmodel112.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel112:PivotTo(CFrame.new(-22.878330566039793, 2.6589054401589665, 27.447496573547312) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel112.Parent = workspace.devices.np
newmodel112.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_11-15"
newmodel113 = workspace.prefabs.np_btn:clone()
newmodel113.Body2.Color = Color3.fromRGB(0, 143, 156)
newmodel113.id.Value = 114
newmodel113:PivotTo(CFrame.new(-22.99202921917957, 2.6589054401589665, 27.539085963075795) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel113.Parent = workspace.devices.np
newmodel113.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_11-17"
newmodel114 = workspace.prefabs.np_btn:clone()
newmodel114.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel114.id.Value = 115
newmodel114:PivotTo(CFrame.new(-23.10572787231935, 2.6589054401589665, 27.630675352604282) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel114.Parent = workspace.devices.np
newmodel114.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_11-19"
newmodel115 = workspace.prefabs.np_btn:clone()
newmodel115.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel115.id.Value = 116
newmodel115:PivotTo(CFrame.new(-23.219426525459124, 2.6589054401589665, 27.722264742132765) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel115.Parent = workspace.devices.np
newmodel115.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_11-21"
newmodel116 = workspace.prefabs.np_btn:clone()
newmodel116.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel116.id.Value = 117
newmodel116:PivotTo(CFrame.new(-22.071211099616328, 2.6525430709383877, 26.703943154364666) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel116.Parent = workspace.devices.np
newmodel116.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_12-0"
newmodel117 = workspace.prefabs.np_btn:clone()
newmodel117.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel117.id.Value = 118
newmodel117:PivotTo(CFrame.new(-22.184909752756106, 2.6525430709383877, 26.795532543893152) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel117.Parent = workspace.devices.np
newmodel117.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_12-2"
newmodel118 = workspace.prefabs.np_btn:clone()
newmodel118.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel118.id.Value = 119
newmodel118:PivotTo(CFrame.new(-22.298608405895884, 2.6525430709383877, 26.887121933421636) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel118.Parent = workspace.devices.np
newmodel118.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_12-4"
newmodel119 = workspace.prefabs.np_btn:clone()
newmodel119.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel119.id.Value = 120
newmodel119:PivotTo(CFrame.new(-22.412307059035662, 2.6525430709383877, 26.97871132295012) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel119.Parent = workspace.devices.np
newmodel119.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_12-6"
newmodel120 = workspace.prefabs.np_btn:clone()
newmodel120.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel120.id.Value = 121
newmodel120:PivotTo(CFrame.new(-22.52600571217544, 2.6525430709383877, 27.070300712478605) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel120.Parent = workspace.devices.np
newmodel120.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_12-8"
newmodel121 = workspace.prefabs.np_btn:clone()
newmodel121.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel121.id.Value = 122
newmodel121:PivotTo(CFrame.new(-22.639704365315218, 2.6525430709383877, 27.161890102007092) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel121.Parent = workspace.devices.np
newmodel121.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_12-10"
newmodel122 = workspace.prefabs.np_btn:clone()
newmodel122.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel122.id.Value = 123
newmodel122:PivotTo(CFrame.new(-22.753403018454996, 2.6525430709383877, 27.253479491535575) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel122.Parent = workspace.devices.np
newmodel122.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_12-12"
newmodel123 = workspace.prefabs.np_btn:clone()
newmodel123.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel123.id.Value = 124
newmodel123:PivotTo(CFrame.new(-22.867101671594774, 2.6525430709383877, 27.345068881064062) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel123.Parent = workspace.devices.np
newmodel123.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_12-14"
newmodel124 = workspace.prefabs.np_btn:clone()
newmodel124.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel124.id.Value = 125
newmodel124:PivotTo(CFrame.new(-22.980800324734552, 2.6525430709383877, 27.436658270592545) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel124.Parent = workspace.devices.np
newmodel124.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_12-16"
newmodel125 = workspace.prefabs.np_btn:clone()
newmodel125.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel125.id.Value = 126
newmodel125:PivotTo(CFrame.new(-23.09449897787433, 2.6525430709383877, 27.528247660121032) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel125.Parent = workspace.devices.np
newmodel125.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_12-18"
newmodel126 = workspace.prefabs.np_btn:clone()
newmodel126.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel126.id.Value = 127
newmodel126:PivotTo(CFrame.new(-23.2081976310141, 2.6525430709383877, 27.619837049649515) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel126.Parent = workspace.devices.np
newmodel126.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_12-20"
newmodel127 = workspace.prefabs.np_btn:clone()
newmodel127.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel127.id.Value = 128
newmodel127:PivotTo(CFrame.new(-23.32189628415388, 2.6525430709383877, 27.711426439178) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel127.Parent = workspace.devices.np
newmodel127.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_12-22"
newmodel128 = workspace.prefabs.np_btn:clone()
newmodel128.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel128.id.Value = 129
newmodel128:PivotTo(CFrame.new(-22.173680858311087, 2.6461807017178085, 26.6931048514099) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel128.Parent = workspace.devices.np
newmodel128.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_13-1"
newmodel129 = workspace.prefabs.np_btn:clone()
newmodel129.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel129.id.Value = 130
newmodel129:PivotTo(CFrame.new(-22.287379511450865, 2.6461807017178085, 26.784694240938382) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel129.Parent = workspace.devices.np
newmodel129.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_13-3"
newmodel130 = workspace.prefabs.np_btn:clone()
newmodel130.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel130.id.Value = 131
newmodel130:PivotTo(CFrame.new(-22.401078164590643, 2.6461807017178085, 26.87628363046687) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel130.Parent = workspace.devices.np
newmodel130.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_13-5"
newmodel131 = workspace.prefabs.np_btn:clone()
newmodel131.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel131.id.Value = 132
newmodel131:PivotTo(CFrame.new(-22.51477681773042, 2.6461807017178085, 26.967873019995352) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel131.Parent = workspace.devices.np
newmodel131.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_13-7"
newmodel132 = workspace.prefabs.np_btn:clone()
newmodel132.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel132.id.Value = 133
newmodel132:PivotTo(CFrame.new(-22.628475470870196, 2.6461807017178085, 27.05946240952384) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel132.Parent = workspace.devices.np
newmodel132.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_13-9"
newmodel133 = workspace.prefabs.np_btn:clone()
newmodel133.Body2.Color = Color3.fromRGB(0, 143, 156)
newmodel133.id.Value = 134
newmodel133:PivotTo(CFrame.new(-22.742174124009974, 2.6461807017178085, 27.151051799052322) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel133.Parent = workspace.devices.np
newmodel133.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_13-11"
newmodel134 = workspace.prefabs.np_btn:clone()
newmodel134.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel134.id.Value = 135
newmodel134:PivotTo(CFrame.new(-22.855872777149752, 2.6461807017178085, 27.24264118858081) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel134.Parent = workspace.devices.np
newmodel134.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_13-13"
newmodel135 = workspace.prefabs.np_btn:clone()
newmodel135.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel135.id.Value = 136
newmodel135:PivotTo(CFrame.new(-22.969571430289527, 2.6461807017178085, 27.334230578109292) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel135.Parent = workspace.devices.np
newmodel135.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_13-15"
newmodel136 = workspace.prefabs.np_btn:clone()
newmodel136.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel136.id.Value = 137
newmodel136:PivotTo(CFrame.new(-23.083270083429305, 2.6461807017178085, 27.42581996763778) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel136.Parent = workspace.devices.np
newmodel136.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_13-17"
newmodel137 = workspace.prefabs.np_btn:clone()
newmodel137.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel137.id.Value = 138
newmodel137:PivotTo(CFrame.new(-23.196968736569083, 2.6461807017178085, 27.51740935716626) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel137.Parent = workspace.devices.np
newmodel137.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_13-19"
newmodel138 = workspace.prefabs.np_btn:clone()
newmodel138.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel138.id.Value = 139
newmodel138:PivotTo(CFrame.new(-23.31066738970886, 2.6461807017178085, 27.608998746694745) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel138.Parent = workspace.devices.np
newmodel138.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_13-21"
newmodel139 = workspace.prefabs.np_btn:clone()
newmodel139.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel139.id.Value = 140
newmodel139:PivotTo(CFrame.new(-22.162451963866065, 2.6398183324972297, 26.590677158926646) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel139.Parent = workspace.devices.np
newmodel139.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_14-0"
newmodel140 = workspace.prefabs.np_btn:clone()
newmodel140.Body2.Color = Color3.fromRGB(0, 62, 100)
newmodel140.id.Value = 141
newmodel140:PivotTo(CFrame.new(-22.276150617005843, 2.6398183324972297, 26.682266548455132) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel140.Parent = workspace.devices.np
newmodel140.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_14-2"
newmodel141 = workspace.prefabs.np_btn:clone()
newmodel141.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel141.id.Value = 142
newmodel141:PivotTo(CFrame.new(-22.38984927014562, 2.6398183324972297, 26.773855937983615) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel141.Parent = workspace.devices.np
newmodel141.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_14-4"
newmodel142 = workspace.prefabs.np_btn:clone()
newmodel142.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel142.id.Value = 143
newmodel142:PivotTo(CFrame.new(-22.5035479232854, 2.6398183324972297, 26.8654453275121) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel142.Parent = workspace.devices.np
newmodel142.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_14-6"
newmodel143 = workspace.prefabs.np_btn:clone()
newmodel143.Body2.Color = Color3.fromRGB(0, 62, 100)
newmodel143.id.Value = 144
newmodel143:PivotTo(CFrame.new(-22.617246576425174, 2.6398183324972297, 26.957034717040585) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel143.Parent = workspace.devices.np
newmodel143.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_14-8"
newmodel144 = workspace.prefabs.np_btn:clone()
newmodel144.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel144.id.Value = 145
newmodel144:PivotTo(CFrame.new(-22.730945229564952, 2.6398183324972297, 27.048624106569072) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel144.Parent = workspace.devices.np
newmodel144.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_14-10"
newmodel145 = workspace.prefabs.np_btn:clone()
newmodel145.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel145.id.Value = 146
newmodel145:PivotTo(CFrame.new(-22.84464388270473, 2.6398183324972297, 27.140213496097555) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel145.Parent = workspace.devices.np
newmodel145.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_14-12"
newmodel146 = workspace.prefabs.np_btn:clone()
newmodel146.Body2.Color = Color3.fromRGB(0, 62, 100)
newmodel146.id.Value = 147
newmodel146:PivotTo(CFrame.new(-22.95834253584451, 2.6398183324972297, 27.231802885626042) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel146.Parent = workspace.devices.np
newmodel146.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_14-14"
newmodel147 = workspace.prefabs.np_btn:clone()
newmodel147.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel147.id.Value = 148
newmodel147:PivotTo(CFrame.new(-23.072041188984286, 2.6398183324972297, 27.323392275154525) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel147.Parent = workspace.devices.np
newmodel147.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_14-16"
newmodel148 = workspace.prefabs.np_btn:clone()
newmodel148.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel148.id.Value = 149
newmodel148:PivotTo(CFrame.new(-23.185739842124065, 2.6398183324972297, 27.414981664683012) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel148.Parent = workspace.devices.np
newmodel148.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_14-18"
newmodel149 = workspace.prefabs.np_btn:clone()
newmodel149.Body2.Color = Color3.fromRGB(0, 62, 100)
newmodel149.id.Value = 150
newmodel149:PivotTo(CFrame.new(-23.29943849526384, 2.6398183324972297, 27.5065710542115) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel149.Parent = workspace.devices.np
newmodel149.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_14-20"
newmodel150 = workspace.prefabs.np_btn:clone()
newmodel150.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel150.id.Value = 151
newmodel150:PivotTo(CFrame.new(-23.413137148403617, 2.6398183324972297, 27.59816044373998) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel150.Parent = workspace.devices.np
newmodel150.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_14-22"
newmodel151 = workspace.prefabs.np_btn:clone()
newmodel151.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel151.id.Value = 152
newmodel151:PivotTo(CFrame.new(-22.26492172256082, 2.6334559632766505, 26.57983885597188) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel151.Parent = workspace.devices.np
newmodel151.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_15-1"
newmodel152 = workspace.prefabs.np_btn:clone()
newmodel152.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel152:PivotTo(CFrame.new(-22.3786203757006, 2.6334559632766505, 26.671428245500366) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel152.Parent = workspace.devices.np
newmodel152.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_15-3"
newmodel153 = workspace.prefabs.np_btn:clone()
newmodel153.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel153.id.Value = 154
newmodel153:PivotTo(CFrame.new(-22.492319028840377, 2.6334559632766505, 26.76301763502885) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel153.Parent = workspace.devices.np
newmodel153.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_15-5"
newmodel154 = workspace.prefabs.np_btn:clone()
newmodel154.Body2.Color = Color3.fromRGB(0, 143, 156)
newmodel154.id.Value = 155
newmodel154:PivotTo(CFrame.new(-22.606017681980155, 2.6334559632766505, 26.854607024557335) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel154.Parent = workspace.devices.np
newmodel154.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_15-7"
newmodel155 = workspace.prefabs.np_btn:clone()
newmodel155.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel155.id.Value = 156
newmodel155:PivotTo(CFrame.new(-22.719716335119934, 2.6334559632766505, 26.94619641408582) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel155.Parent = workspace.devices.np
newmodel155.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_15-9"
newmodel156 = workspace.prefabs.np_btn:clone()
newmodel156.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel156:PivotTo(CFrame.new(-22.83341498825971, 2.6334559632766505, 27.037785803614305) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel156.Parent = workspace.devices.np
newmodel156.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_15-11"
newmodel157 = workspace.prefabs.np_btn:clone()
newmodel157.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel157.id.Value = 158
newmodel157:PivotTo(CFrame.new(-22.94711364139949, 2.6334559632766505, 27.12937519314279) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel157.Parent = workspace.devices.np
newmodel157.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_15-13"
newmodel158 = workspace.prefabs.np_btn:clone()
newmodel158.Body2.Color = Color3.fromRGB(0, 143, 156)
newmodel158.id.Value = 159
newmodel158:PivotTo(CFrame.new(-23.060812294539264, 2.6334559632766505, 27.22096458267127) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel158.Parent = workspace.devices.np
newmodel158.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_15-15"
newmodel159 = workspace.prefabs.np_btn:clone()
newmodel159.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel159.id.Value = 160
newmodel159:PivotTo(CFrame.new(-23.174510947679043, 2.6334559632766505, 27.31255397219976) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel159.Parent = workspace.devices.np
newmodel159.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_15-17"
newmodel160 = workspace.prefabs.np_btn:clone()
newmodel160.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel160:PivotTo(CFrame.new(-23.28820960081882, 2.6334559632766505, 27.404143361728245) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel160.Parent = workspace.devices.np
newmodel160.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_15-19"
newmodel161 = workspace.prefabs.np_btn:clone()
newmodel161.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel161.id.Value = 162
newmodel161:PivotTo(CFrame.new(-23.4019082539586, 2.6334559632766505, 27.495732751256728) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel161.Parent = workspace.devices.np
newmodel161.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_15-21"
newmodel162 = workspace.prefabs.np_btn:clone()
newmodel162.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel162.id.Value = 163
newmodel162:PivotTo(CFrame.new(-22.36739148125558, 2.6270935940560713, 26.569000553017112) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel162.Parent = workspace.devices.np
newmodel162.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_16-2"
newmodel163 = workspace.prefabs.np_btn:clone()
newmodel163.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel163.id.Value = 164
newmodel163:PivotTo(CFrame.new(-22.48109013439536, 2.6270935940560713, 26.6605899425456) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel163.Parent = workspace.devices.np
newmodel163.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_16-4"
newmodel164 = workspace.prefabs.np_btn:clone()
newmodel164.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel164.id.Value = 165
newmodel164:PivotTo(CFrame.new(-22.594788787535133, 2.6270935940560713, 26.752179332074082) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel164.Parent = workspace.devices.np
newmodel164.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_16-6"
newmodel165 = workspace.prefabs.np_btn:clone()
newmodel165.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel165.id.Value = 166
newmodel165:PivotTo(CFrame.new(-22.70848744067491, 2.6270935940560713, 26.84376872160257) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel165.Parent = workspace.devices.np
newmodel165.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_16-8"
newmodel166 = workspace.prefabs.np_btn:clone()
newmodel166.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel166.id.Value = 167
newmodel166:PivotTo(CFrame.new(-22.82218609381469, 2.6270935940560713, 26.935358111131052) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel166.Parent = workspace.devices.np
newmodel166.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_16-10"
newmodel167 = workspace.prefabs.np_btn:clone()
newmodel167.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel167.id.Value = 168
newmodel167:PivotTo(CFrame.new(-22.935884746954464, 2.6270935940560713, 27.02694750065954) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel167.Parent = workspace.devices.np
newmodel167.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_16-12"
newmodel168 = workspace.prefabs.np_btn:clone()
newmodel168.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel168.id.Value = 169
newmodel168:PivotTo(CFrame.new(-23.049583400094242, 2.6270935940560713, 27.11853689018802) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel168.Parent = workspace.devices.np
newmodel168.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_16-14"
newmodel169 = workspace.prefabs.np_btn:clone()
newmodel169.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel169.id.Value = 170
newmodel169:PivotTo(CFrame.new(-23.16328205323402, 2.6270935940560713, 27.210126279716505) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel169.Parent = workspace.devices.np
newmodel169.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_16-16"
newmodel170 = workspace.prefabs.np_btn:clone()
newmodel170.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel170.id.Value = 171
newmodel170:PivotTo(CFrame.new(-23.2769807063738, 2.6270935940560713, 27.30171566924499) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel170.Parent = workspace.devices.np
newmodel170.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_16-18"
newmodel171 = workspace.prefabs.np_btn:clone()
newmodel171.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel171.id.Value = 172
newmodel171:PivotTo(CFrame.new(-23.390679359513577, 2.6270935940560713, 27.39330505877348) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel171.Parent = workspace.devices.np
newmodel171.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_16-20"
newmodel172 = workspace.prefabs.np_btn:clone()
newmodel172.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel172.id.Value = 173
newmodel172:PivotTo(CFrame.new(-23.504378012653355, 2.6270935940560713, 27.48489444830196) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel172.Parent = workspace.devices.np
newmodel172.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_16-22"
newmodel173 = workspace.prefabs.np_btn:clone()
newmodel173.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel173.id.Value = 174
newmodel173:PivotTo(CFrame.new(-22.35616258681056, 2.6207312248354926, 26.46657286053386) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel173.Parent = workspace.devices.np
newmodel173.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_17-1"
newmodel174 = workspace.prefabs.np_btn:clone()
newmodel174.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel174.id.Value = 175
newmodel174:PivotTo(CFrame.new(-22.469861239950337, 2.6207312248354926, 26.558162250062345) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel174.Parent = workspace.devices.np
newmodel174.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_17-3"
newmodel175 = workspace.prefabs.np_btn:clone()
newmodel175.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel175.id.Value = 176
newmodel175:PivotTo(CFrame.new(-22.58355989309011, 2.6207312248354926, 26.649751639590832) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel175.Parent = workspace.devices.np
newmodel175.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_17-5"
newmodel176 = workspace.prefabs.np_btn:clone()
newmodel176.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel176.id.Value = 177
newmodel176:PivotTo(CFrame.new(-22.69725854622989, 2.6207312248354926, 26.741341029119315) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel176.Parent = workspace.devices.np
newmodel176.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_17-7"
newmodel177 = workspace.prefabs.np_btn:clone()
newmodel177.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel177.id.Value = 178
newmodel177:PivotTo(CFrame.new(-22.810957199369668, 2.6207312248354926, 26.8329304186478) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel177.Parent = workspace.devices.np
newmodel177.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_17-9"
newmodel178 = workspace.prefabs.np_btn:clone()
newmodel178.Body2.Color = Color3.fromRGB(0, 143, 156)
newmodel178.id.Value = 179
newmodel178:PivotTo(CFrame.new(-22.924655852509446, 2.6207312248354926, 26.924519808176285) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel178.Parent = workspace.devices.np
newmodel178.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_17-11"
newmodel179 = workspace.prefabs.np_btn:clone()
newmodel179.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel179.id.Value = 180
newmodel179:PivotTo(CFrame.new(-23.038354505649224, 2.6207312248354926, 27.016109197704772) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel179.Parent = workspace.devices.np
newmodel179.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_17-13"
newmodel180 = workspace.prefabs.np_btn:clone()
newmodel180.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel180.id.Value = 181
newmodel180:PivotTo(CFrame.new(-23.152053158789002, 2.6207312248354926, 27.107698587233255) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel180.Parent = workspace.devices.np
newmodel180.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_17-15"
newmodel181 = workspace.prefabs.np_btn:clone()
newmodel181.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel181.id.Value = 182
newmodel181:PivotTo(CFrame.new(-23.26575181192878, 2.6207312248354926, 27.19928797676174) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel181.Parent = workspace.devices.np
newmodel181.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_17-17"
newmodel182 = workspace.prefabs.np_btn:clone()
newmodel182.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel182.id.Value = 183
newmodel182:PivotTo(CFrame.new(-23.379450465068558, 2.6207312248354926, 27.290877366290225) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel182.Parent = workspace.devices.np
newmodel182.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_17-19"
newmodel183 = workspace.prefabs.np_btn:clone()
newmodel183.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel183.id.Value = 184
newmodel183:PivotTo(CFrame.new(-23.493149118208336, 2.6207312248354926, 27.38246675581871) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel183.Parent = workspace.devices.np
newmodel183.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_17-21"
newmodel184 = workspace.prefabs.np_btn:clone()
newmodel184.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel184.id.Value = 185
newmodel184:PivotTo(CFrame.new(-22.458632345505315, 2.6143688556149134, 26.455734557579092) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel184.Parent = workspace.devices.np
newmodel184.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_18-2"
newmodel185 = workspace.prefabs.np_btn:clone()
newmodel185.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel185.id.Value = 186
newmodel185:PivotTo(CFrame.new(-22.572330998645093, 2.6143688556149134, 26.54732394710758) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel185.Parent = workspace.devices.np
newmodel185.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_18-4"
newmodel186 = workspace.prefabs.np_btn:clone()
newmodel186.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel186.id.Value = 187
newmodel186:PivotTo(CFrame.new(-22.68602965178487, 2.6143688556149134, 26.63891333663606) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel186.Parent = workspace.devices.np
newmodel186.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_18-6"
newmodel187 = workspace.prefabs.np_btn:clone()
newmodel187.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel187.id.Value = 188
newmodel187:PivotTo(CFrame.new(-22.79972830492465, 2.6143688556149134, 26.73050272616455) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel187.Parent = workspace.devices.np
newmodel187.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_18-8"
newmodel188 = workspace.prefabs.np_btn:clone()
newmodel188.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel188.id.Value = 189
newmodel188:PivotTo(CFrame.new(-22.913426958064427, 2.6143688556149134, 26.822092115693035) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel188.Parent = workspace.devices.np
newmodel188.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_18-10"
newmodel189 = workspace.prefabs.np_btn:clone()
newmodel189.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel189.id.Value = 190
newmodel189:PivotTo(CFrame.new(-23.027125611204205, 2.6143688556149134, 26.91368150522152) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel189.Parent = workspace.devices.np
newmodel189.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_18-12"
newmodel190 = workspace.prefabs.np_btn:clone()
newmodel190.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel190.id.Value = 191
newmodel190:PivotTo(CFrame.new(-23.140824264343983, 2.6143688556149134, 27.005270894750005) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel190.Parent = workspace.devices.np
newmodel190.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_18-14"
newmodel191 = workspace.prefabs.np_btn:clone()
newmodel191.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel191.id.Value = 192
newmodel191:PivotTo(CFrame.new(-23.254522917483758, 2.6143688556149134, 27.09686028427849) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel191.Parent = workspace.devices.np
newmodel191.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_18-16"
newmodel192 = workspace.prefabs.np_btn:clone()
newmodel192.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel192.id.Value = 193
newmodel192:PivotTo(CFrame.new(-23.368221570623536, 2.6143688556149134, 27.18844967380697) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel192.Parent = workspace.devices.np
newmodel192.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_18-18"
newmodel193 = workspace.prefabs.np_btn:clone()
newmodel193.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel193.id.Value = 194
newmodel193:PivotTo(CFrame.new(-23.48192022376331, 2.6143688556149134, 27.280039063335458) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel193.Parent = workspace.devices.np
newmodel193.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_18-20"
newmodel194 = workspace.prefabs.np_btn:clone()
newmodel194.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel194.id.Value = 195
newmodel194:PivotTo(CFrame.new(-22.561102104200074, 2.6080064863943346, 26.44489625462433) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel194.Parent = workspace.devices.np
newmodel194.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_19-3"
newmodel195 = workspace.prefabs.np_btn:clone()
newmodel195.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel195.id.Value = 196
newmodel195:PivotTo(CFrame.new(-22.674800757339852, 2.6080064863943346, 26.536485644152812) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel195.Parent = workspace.devices.np
newmodel195.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_19-5"
newmodel196 = workspace.prefabs.np_btn:clone()
newmodel196.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel196:PivotTo(CFrame.new(-22.78849941047963, 2.6080064863943346, 26.6280750336813) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel196.Parent = workspace.devices.np
newmodel196.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_19-7"
newmodel197 = workspace.prefabs.np_btn:clone()
newmodel197.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel197.id.Value = 198
newmodel197:PivotTo(CFrame.new(-22.902198063619405, 2.6080064863943346, 26.71966442320978) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel197.Parent = workspace.devices.np
newmodel197.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_19-9"
newmodel198 = workspace.prefabs.np_btn:clone()
newmodel198.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel198.id.Value = 199
newmodel198:PivotTo(CFrame.new(-23.015896716759183, 2.6080064863943346, 26.811253812738265) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel198.Parent = workspace.devices.np
newmodel198.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_19-11"
newmodel199 = workspace.prefabs.np_btn:clone()
newmodel199.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel199.id.Value = 200
newmodel199:PivotTo(CFrame.new(-23.129595369898958, 2.6080064863943346, 26.90284320226675) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel199.Parent = workspace.devices.np
newmodel199.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_19-13"
newmodel200 = workspace.prefabs.np_btn:clone()
newmodel200.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel200:PivotTo(CFrame.new(-23.243294023038736, 2.6080064863943346, 26.99443259179524) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel200.Parent = workspace.devices.np
newmodel200.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_19-15"
newmodel201 = workspace.prefabs.np_btn:clone()
newmodel201.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel201.id.Value = 202
newmodel201:PivotTo(CFrame.new(-23.356992676178514, 2.6080064863943346, 27.08602198132372) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel201.Parent = workspace.devices.np
newmodel201.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_19-17"
newmodel202 = workspace.prefabs.np_btn:clone()
newmodel202.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel202.id.Value = 203
newmodel202:PivotTo(CFrame.new(-23.470691329318292, 2.6080064863943346, 27.177611370852205) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel202.Parent = workspace.devices.np
newmodel202.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_19-19"
newmodel203 = workspace.prefabs.np_btn:clone()
newmodel203.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel203.id.Value = 204
newmodel203:PivotTo(CFrame.new(-22.66357186289483, 2.6016441171737554, 26.43405795166956) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel203.Parent = workspace.devices.np
newmodel203.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_20-4"
newmodel204 = workspace.prefabs.np_btn:clone()
newmodel204.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel204.id.Value = 205
newmodel204:PivotTo(CFrame.new(-22.777270516034605, 2.6016441171737554, 26.525647341198045) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel204.Parent = workspace.devices.np
newmodel204.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_20-6"
newmodel205 = workspace.prefabs.np_btn:clone()
newmodel205.Body2.Color = Color3.fromRGB(0, 62, 100)
newmodel205.id.Value = 206
newmodel205:PivotTo(CFrame.new(-22.890969169174383, 2.6016441171737554, 26.617236730726532) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel205.Parent = workspace.devices.np
newmodel205.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_20-8"
newmodel206 = workspace.prefabs.np_btn:clone()
newmodel206.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel206.id.Value = 207
newmodel206:PivotTo(CFrame.new(-23.00466782231416, 2.6016441171737554, 26.708826120255015) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel206.Parent = workspace.devices.np
newmodel206.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_20-10"
newmodel207 = workspace.prefabs.np_btn:clone()
newmodel207.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel207.id.Value = 208
newmodel207:PivotTo(CFrame.new(-23.11836647545394, 2.6016441171737554, 26.800415509783498) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel207.Parent = workspace.devices.np
newmodel207.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_20-12"
newmodel208 = workspace.prefabs.np_btn:clone()
newmodel208.Body2.Color = Color3.fromRGB(0, 62, 100)
newmodel208.id.Value = 209
newmodel208:PivotTo(CFrame.new(-23.232065128593717, 2.6016441171737554, 26.892004899311985) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel208.Parent = workspace.devices.np
newmodel208.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_20-14"
newmodel209 = workspace.prefabs.np_btn:clone()
newmodel209.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel209.id.Value = 210
newmodel209:PivotTo(CFrame.new(-23.345763781733496, 2.6016441171737554, 26.98359428884047) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel209.Parent = workspace.devices.np
newmodel209.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_20-16"
newmodel210 = workspace.prefabs.np_btn:clone()
newmodel210.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel210.id.Value = 211
newmodel210:PivotTo(CFrame.new(-23.459462434873274, 2.6016441171737554, 27.075183678368955) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel210.Parent = workspace.devices.np
newmodel210.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_20-18"
newmodel211 = workspace.prefabs.np_btn:clone()
newmodel211.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel211.id.Value = 212
newmodel211:PivotTo(CFrame.new(-22.766041621589586, 2.5952817479531762, 26.42321964871479) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel211.Parent = workspace.devices.np
newmodel211.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_21-5"
newmodel212 = workspace.prefabs.np_btn:clone()
newmodel212.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel212.id.Value = 213
newmodel212:PivotTo(CFrame.new(-22.879740274729365, 2.5952817479531762, 26.51480903824328) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel212.Parent = workspace.devices.np
newmodel212.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_21-7"
newmodel213 = workspace.prefabs.np_btn:clone()
newmodel213.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel213.id.Value = 214
newmodel213:PivotTo(CFrame.new(-22.993438927869143, 2.5952817479531762, 26.606398427771765) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel213.Parent = workspace.devices.np
newmodel213.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_21-9"
newmodel214 = workspace.prefabs.np_btn:clone()
newmodel214.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel214.id.Value = 215
newmodel214:PivotTo(CFrame.new(-23.10713758100892, 2.5952817479531762, 26.69798781730025) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel214.Parent = workspace.devices.np
newmodel214.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_21-11"
newmodel215 = workspace.prefabs.np_btn:clone()
newmodel215.Body2.Color = Color3.fromRGB(239, 243, 18)
newmodel215.id.Value = 216
newmodel215:PivotTo(CFrame.new(-23.220836234148695, 2.5952817479531762, 26.78957720682873) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel215.Parent = workspace.devices.np
newmodel215.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_21-13"
newmodel216 = workspace.prefabs.np_btn:clone()
newmodel216.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel216.id.Value = 217
newmodel216:PivotTo(CFrame.new(-23.334534887288473, 2.5952817479531762, 26.881166596357218) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel216.Parent = workspace.devices.np
newmodel216.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_21-15"
newmodel217 = workspace.prefabs.np_btn:clone()
newmodel217.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel217.id.Value = 218
newmodel217:PivotTo(CFrame.new(-23.44823354042825, 2.5952817479531762, 26.9727559858857) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel217.Parent = workspace.devices.np
newmodel217.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_21-17"
newmodel218 = workspace.prefabs.np_btn:clone()
newmodel218.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel218.id.Value = 219
newmodel218:PivotTo(CFrame.new(-22.98221003342412, 2.5889193787325975, 26.50397073528851) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel218.Parent = workspace.devices.np
newmodel218.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_22-8"
newmodel219 = workspace.prefabs.np_btn:clone()
newmodel219.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel219.id.Value = 220
newmodel219:PivotTo(CFrame.new(-23.0959086865639, 2.5889193787325975, 26.595560124817) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel219.Parent = workspace.devices.np
newmodel219.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_22-10"
newmodel220 = workspace.prefabs.np_btn:clone()
newmodel220.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel220.id.Value = 221
newmodel220:PivotTo(CFrame.new(-23.209607339703677, 2.5889193787325975, 26.68714951434548) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel220.Parent = workspace.devices.np
newmodel220.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_22-12"
newmodel221 = workspace.prefabs.np_btn:clone()
newmodel221.Body2.Color = Color3.fromRGB(170, 32, 34)
newmodel221.id.Value = 222
newmodel221:PivotTo(CFrame.new(-23.323305992843455, 2.5889193787325975, 26.778738903873965) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel221.Parent = workspace.devices.np
newmodel221.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_22-14"
newmodel222 = workspace.prefabs.np_btn:clone()
newmodel222.Body2.Color = Color3.fromRGB(252, 250, 255)
newmodel222.id.Value = 223
newmodel222:PivotTo(CFrame.new(-23.437004645983233, 2.5889193787325975, 26.87032829340245) * CFrame.fromEulerAngles(0, math.rad(38.85301), 0) * CFrame.fromEulerAngles(math.rad(-5), 0, 0))
newmodel222.Parent = workspace.devices.np
newmodel222.Body2.Decal.Texture = "rbxgameasset://Images/NPBTN_22-16"
