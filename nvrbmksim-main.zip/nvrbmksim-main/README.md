Rbmk simulator © 2025 by Nemychnikov Vasiliy is licensed under CC BY-NC 4.0. To view a copy of this license, visit https://creativecommons.org/licenses/by-nc/4.0/ 
